var classansys_1_1dpf_1_1DpfException =
[
    [ "DpfException", "classansys_1_1dpf_1_1DpfException.xhtml#ab417aeb3168e72745df2f8c98d912428", null ],
    [ "error", "classansys_1_1dpf_1_1DpfException.xhtml#a07c601a38ec182b458074da6f0e52478", null ],
    [ "message", "classansys_1_1dpf_1_1DpfException.xhtml#a69cc4e277ea17f9e7d83872db1edbf24", null ],
    [ "nature", "classansys_1_1dpf_1_1DpfException.xhtml#ad21aba4144b3dbcb6e619931ac6ae6ed", null ],
    [ "origin", "classansys_1_1dpf_1_1DpfException.xhtml#a613c503433eb563fed99099941cc416d", null ],
    [ "what", "classansys_1_1dpf_1_1DpfException.xhtml#a0df1c0ba45617a9f207739f935d0e074", null ]
];