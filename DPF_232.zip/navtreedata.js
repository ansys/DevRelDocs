/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "Concepts and Terminology", "md_cpp_doc_02_Concepts.xhtml", null ],
    [ "Ways of Using DPF", "md_cpp_doc_03_Ways_of_Using.xhtml", null ],
    [ "Using DPF: Step by Step", "md_cpp_doc_05_Using_DPF.xhtml", null ],
    [ "Debugging DPF", "md_cpp_doc_06_Debugging_DPF.xhtml", null ],
    [ "DPF XML Files", "md_cpp_doc_07_DPF_XML_Files.xhtml", null ],
    [ "Deprecated List", "deprecated.xhtml", null ],
    [ "Operators", "dataProcessingDoc.html", null ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Typedefs", "namespacemembers_type.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Examples", "examples.xhtml", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"CompleteRST_8cpp-example.xhtml",
"classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fafbbb18218f01ff212fea92a133b88e21",
"classansys_1_1dpf_1_1FieldDefinition.xhtml#abb7364b9d7860660498d8b28bf9aa212",
"classansys_1_1dpf_1_1MeshedRegion.xhtml#a856308261c05f739c04f38c1b35ca072",
"classansys_1_1dpf_1_1Operator.xhtml#a9fcb797a323d6331a41ef183dcd60e9b",
"classansys_1_1dpf_1_1OperatorMain.xhtml#ad6d1c029bc239f8b47f7ae34d011a4ad",
"classansys_1_1dpf_1_1ResultInfo.xhtml#ac3786ae43ac33386010794e990a31146",
"classansys_1_1dpf_1_1TimeFreqSupport.xhtml#a190d202d30643f5ea398555b5dbea12b",
"classansys_1_1dpf_1_1Workflow.xhtml#a9836bf24a8037281f69e7f32285daa45",
"namespaceansys_1_1dpf.xhtml#aa4a44a04a0aafb8fe0645f019bbd94d1a2970c8895cf1e20fb11a14896cc974bd",
"structansys_1_1dpf_1_1homogeneities.xhtml#aa104a88dec65b76bc2e02348c85c6d7f",
"structansys_1_1dpf_1_1unit__systems.xhtml#aa450fcd215dfb82da86556e7969948b0"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';