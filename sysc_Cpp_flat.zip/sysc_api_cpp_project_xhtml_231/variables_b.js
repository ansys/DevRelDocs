var searchData=
[
  ['restartssupported_0',['restartsSupported',['../structsysc_1_1SetupInfo.xhtml#a46dc0b1c447b1534103f3f05455ee717',1,'sysc::SetupInfo::restartsSupported()'],['../structsysc_1_1SetupFileInfo.xhtml#a65df447274a91c50920e5af5296c60e3',1,'sysc::SetupFileInfo::restartsSupported()']]]
];
