var structsysc_1_1ResultsInfo =
[
    [ "ResultsInfo", "structsysc_1_1ResultsInfo.xhtml#a673c9e77e725e4d4311106fac4ea7110", null ],
    [ "baseFileName", "structsysc_1_1ResultsInfo.xhtml#acc2c96ab4d0c7b8bc630583a814cead4", null ]
];