var searchData=
[
  ['nodecoords_0',['nodeCoords',['../structsysc_1_1NodeData.xhtml#abdcd98cafd25df6b765a63447f8f31a4',1,'sysc::NodeData']]],
  ['nodeids_1',['nodeIds',['../structsysc_1_1NodeData.xhtml#a2b8d2f98597580854d5698d9a600f367',1,'sysc::NodeData']]]
];
