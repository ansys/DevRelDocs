var searchData=
[
  ['datatransfer_0',['DataTransfer',['../classsysc_1_1DataTransfer.xhtml',1,'sysc']]],
  ['dimensionality_1',['Dimensionality',['../structsysc_1_1Dimensionality.xhtml',1,'sysc']]]
];
