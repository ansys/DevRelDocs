var searchData=
[
  ['nodedata_0',['NodeData',['../structsysc_1_1NodeData.xhtml',1,'sysc']]]
];
