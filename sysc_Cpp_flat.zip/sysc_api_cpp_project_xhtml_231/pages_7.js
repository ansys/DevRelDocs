var searchData=
[
  ['notes_20about_20python_20apis_20reference_20documentation_0',['Notes About Python APIs Reference Documentation',['../md_PythonAPIsNotes.xhtml',1,'']]]
];
