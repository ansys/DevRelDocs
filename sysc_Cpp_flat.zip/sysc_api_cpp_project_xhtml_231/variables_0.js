var searchData=
[
  ['amountofsubstance_0',['amountOfSubstance',['../structsysc_1_1Dimensionality.xhtml#aa0de60275ce09315d344f2a96f397cca',1,'sysc::Dimensionality']]],
  ['analysistype_1',['analysisType',['../structsysc_1_1SetupInfo.xhtml#a45906ec4c888b7d0fbd42066f318284b',1,'sysc::SetupInfo']]],
  ['angle_2',['angle',['../structsysc_1_1Dimensionality.xhtml#a03f6d1e6e0ebb147b85242eb889572a7',1,'sysc::Dimensionality']]]
];
