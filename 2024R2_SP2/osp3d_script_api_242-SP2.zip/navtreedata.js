/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Statistics on Structures Script API Documentation (Beta)", "index.xhtml", [
    [ "Overview", "index.xhtml", "index" ],
    [ "Module tmath", "md_doc_swig_doc_src_tmath.xhtml", null ],
    [ "Deprecated List", "deprecated.xhtml", null ],
    [ "Modules", "modules.xhtml", "modules" ]
  ] ]
];

var NAVTREEINDEX =
[
"another_lua_example__postpocess_field_data.xhtml",
"class_compute_mean_plus_sigma.xhtml#a30b1bcf63b9bdc707fea30bd96d70447",
"class_compute_variance.xhtml#ac597f6cab052d215247719908ce3cb0b",
"class_data_model_reporter.xhtml#a6607e8625bffd2ac3fad644252019d61",
"class_export_reference_design.xhtml#ae7616f698ea9bc6e01cc3b7aa80a13f0",
"class_index_mapper.xhtml#a400f48c00a9753ddadc21b980d382460",
"class_matrix.xhtml#a52353850b8d700400f021350033e1d1f",
"class_mesh_mapper___ray.xhtml#ac51e80d987e5d67c6d63e66fe2cbcc66",
"class_random_field_group.xhtml#a798f429a8eba44cef1e0c5e8f7a58f3d",
"class_scene.xhtml#a15961a85b2b62c89830eb160d7948a64",
"class_scene_manager.xhtml#a757e1eda9c70aeefe7764241ec59bde3",
"class_value_type_int.xhtml#a945190dbb867b410997fa2d77a1a629f",
"struct_compute_nodal_coor_deviation.xhtml#aad269398b809e89e37bf0121f27b5a3c",
"struct_export_item_info.xhtml#acf1b366f46b9570951935096bc25e2e6a60f392f66eb67de3c1fd3c8dd84b0ce8"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';