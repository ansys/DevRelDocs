var searchData=
[
  ['qualitymeasurebase',['QualityMeasureBase',['../struct_quality_measure_base.xhtml',1,'']]]
];
