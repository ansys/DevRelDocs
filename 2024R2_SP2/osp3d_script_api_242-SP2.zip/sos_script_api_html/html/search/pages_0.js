var searchData=
[
  ['a_20simple_20example_20to_20post_20process_20field_20data_20computing_20the_203_2dvec_20norm',['A simple example to post process field data computing the 3-vec norm',['../another_lua_example__postpocess_field_data.xhtml',1,'lua_examples']]],
  ['automated_20image_20output',['Automated image output',['../example_animated_3dgraphics.xhtml',1,'lua_examples']]]
];
