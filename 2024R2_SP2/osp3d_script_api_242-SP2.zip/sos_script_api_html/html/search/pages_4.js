var searchData=
[
  ['fast_20execution',['Fast Execution',['../example_fastexecution.xhtml',1,'lua_examples']]]
];
