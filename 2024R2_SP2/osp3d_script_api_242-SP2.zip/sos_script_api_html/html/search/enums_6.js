var searchData=
[
  ['sampleusage',['SampleUsage',['../group__training__plan.xhtml#gafce529ac7282fd94c419e8bea8492268',1,'training_plan_base.hpp']]],
  ['some_5fenums',['some_enums',['../class_sym_sparse_matrix.xhtml#ac260c934c749111f08dbbd4f34fa6b31',1,'SymSparseMatrix']]]
];
