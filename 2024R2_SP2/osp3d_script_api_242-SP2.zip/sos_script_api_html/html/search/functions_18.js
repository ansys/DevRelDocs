var searchData=
[
  ['zeromatrix',['ZeroMatrix',['../group__tmath.xhtml#gae3e484630e8e2705b6d3a9a8bae29f66',1,'matrix_create.hpp']]],
  ['zerovector',['ZeroVector',['../group__tmath.xhtml#ga3f4a03c007e95a28d84f4b41e1d84e4a',1,'matrix_create.hpp']]]
];
