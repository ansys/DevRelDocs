var searchData=
[
  ['observerptr',['ObserverPtr',['../class_data_object_ptr.xhtml#afa0bd4d832168701ce39642b559bf810',1,'DataObjectPtr']]],
  ['observerptrlist',['ObserverPtrList',['../class_data_object_ptr.xhtml#a46d3f34a7866e39589a2b26177a3c85b',1,'DataObjectPtr']]]
];
