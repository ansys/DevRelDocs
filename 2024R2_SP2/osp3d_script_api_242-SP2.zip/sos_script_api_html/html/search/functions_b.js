var searchData=
[
  ['krigingmodel',['KrigingModel',['../class_kriging_model.xhtml#ad2c5630687bfd2e43bc9d4a76ab1ba92',1,'KrigingModel::KrigingModel()'],['../class_kriging_model.xhtml#a7e9c455228078e06bafb139efbf20f33',1,'KrigingModel::KrigingModel(InternalModelType *model, quality_measure::ResidualsBase *residuals, string description, PropertyList properties=PropertyList())'],['../class_kriging_model.xhtml#a1acecabebf2abee48520a25db45dc84f',1,'KrigingModel::KrigingModel(KrigingModel other)']]]
];
