var searchData=
[
  ['loaddatabasesettings',['LoadDataBaseSettings',['../struct_load_data_base_settings.xhtml',1,'']]]
];
