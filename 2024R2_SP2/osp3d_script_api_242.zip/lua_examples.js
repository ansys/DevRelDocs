var lua_examples =
[
    [ "Useful Functions", "example_usefulfunctions.xhtml", null ],
    [ "Linear Algebra", "example_linearalgebra.xhtml", null ],
    [ "Error Handling", "example_errorhandling.xhtml", null ],
    [ "Fast Execution", "example_fastexecution.xhtml", null ],
    [ "Command Line Arguments", "example_cmdlinearguments.xhtml", null ],
    [ "Data and Filters", "example_dataandfilters.xhtml", null ],
    [ "Extract Substructure", "example_extractsubstructure.xhtml", null ],
    [ "Check Mesh Connectivity", "example_checkmeshconnectivity.xhtml", null ],
    [ "A simple example to post process field data computing the 3-vec norm", "another_lua_example__postpocess_field_data.xhtml", null ],
    [ "Automated image output", "example_animated_3dgraphics.xhtml", null ]
];