var searchData=
[
  ['fmop_5fdataobject_5ftypes',['fmop_dataobject_types',['../sos__capi__common_8h.xhtml#a69eb42c1b3b49f22b9e73c6c9869cb75',1,'sos_capi_common.h']]],
  ['fmop_5ferror_5ft',['fmop_error_t',['../sos__capi__common_8h.xhtml#a4847f3fa2943ffd694eb6cbe169a8bec',1,'sos_capi_common.h']]],
  ['fmop_5flicense_5ft',['fmop_license_t',['../sos__capi__common_8h.xhtml#afe21e382a604ef55cba4d683d706422e',1,'sos_capi_common.h']]]
];
