var indexSectionsWithContent =
{
  0: "dfs",
  1: "fs",
  2: "f",
  3: "f",
  4: "f",
  5: "f",
  6: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "enums",
  5: "enumvalues",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Enumerations",
  5: "Enumerator",
  6: "Pages"
};

