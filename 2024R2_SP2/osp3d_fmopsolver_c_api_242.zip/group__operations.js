var group__operations =
[
    [ "FMOP_approxField", "group__operations.xhtml#ga1bd5d62d9c5ba6d327b0368a8b4e2e31", null ],
    [ "FMOP_approxFieldExtrapolate", "group__operations.xhtml#ga4380a704857be093fc6444aa5b8fdadc", null ]
];