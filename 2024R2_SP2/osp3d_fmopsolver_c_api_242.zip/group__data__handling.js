var group__data__handling =
[
    [ "FMOP_getModel", "group__data__handling.xhtml#gaae65fdf242dba6c37b9de818be7c9dcc", null ],
    [ "FMOP_loadDbFile", "group__data__handling.xhtml#gadf36057836bc12095f01665fa068ba4c", null ],
    [ "FMOP_loadDbFileWMesh", "group__data__handling.xhtml#gab3f6b6b4a84878f3c774a12a2b4cf958", null ],
    [ "FMOP_releaseDb", "group__data__handling.xhtml#gaf36d28d4c5c718284a0f4236f2740e06", null ],
    [ "FMOP_releaseIdents", "group__data__handling.xhtml#ga37bdee678571cd855ac0bb10675b1d8c", null ],
    [ "FMOP_releaseModel", "group__data__handling.xhtml#ga3ad01c460ed6e409b79e258a523d0bf9", null ]
];