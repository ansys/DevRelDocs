var structSyscFaceData =
[
    [ "faceCellConnectivity", "structSyscFaceData.xhtml#a12560838da4a3f554793e027b6c43bc9", null ],
    [ "faceIds", "structSyscFaceData.xhtml#ab06db951659e8d349a540904d6831b38", null ],
    [ "faceNodeConnectivity", "structSyscFaceData.xhtml#a0ecb329fe163fb5fc7591fcd7531569a", null ],
    [ "faceNodeCounts", "structSyscFaceData.xhtml#a1834bd4b6994f302fa8e91f101eadb9f", null ],
    [ "faceTypes", "structSyscFaceData.xhtml#ab78be0450a2fade5154ad69875cff375", null ]
];