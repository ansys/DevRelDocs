var structSyscTimeStep =
[
    [ "startTime", "structSyscTimeStep.xhtml#a73ab2a39df940f48522d8bd3854dbe9b", null ],
    [ "timeStepNumber", "structSyscTimeStep.xhtml#a95502a2d37654fa3cd767392b07c4088", null ],
    [ "timeStepSize", "structSyscTimeStep.xhtml#a10efd15748ecfc0e40ac8ad411467a3e", null ]
];