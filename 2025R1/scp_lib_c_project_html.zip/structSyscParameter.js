var structSyscParameter =
[
    [ "displayName", "structSyscParameter.xhtml#a28dadb5ca8618970f5019270c94fd582", null ],
    [ "name", "structSyscParameter.xhtml#af4cc31b045f137e214d4f790987ca42d", null ]
];