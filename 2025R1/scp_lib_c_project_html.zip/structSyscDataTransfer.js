var structSyscDataTransfer =
[
    [ "sourceVariable", "structSyscDataTransfer.xhtml#a75ab076255c5c6861138810f25ce9a46", null ],
    [ "targetSide", "structSyscDataTransfer.xhtml#ab79ebf125798afce8652e2f40cb33e91", null ],
    [ "targetVariable", "structSyscDataTransfer.xhtml#a71ca350ac0121f402db52a74e84edfa0", null ]
];