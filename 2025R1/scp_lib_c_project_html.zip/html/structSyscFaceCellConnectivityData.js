var structSyscFaceCellConnectivityData =
[
    [ "cell0Ids", "structSyscFaceCellConnectivityData.xhtml#a33553e003b9aa6c8d85a4e1aa4f28367", null ],
    [ "cell1Ids", "structSyscFaceCellConnectivityData.xhtml#af531282e2ae53cea1989f7ff6bb5eb82", null ]
];