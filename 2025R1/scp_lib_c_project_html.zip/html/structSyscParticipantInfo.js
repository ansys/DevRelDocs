var structSyscParticipantInfo =
[
    [ "buildInformation", "structSyscParticipantInfo.xhtml#aa341c59a4953b40db05064cd5495d9f7", null ],
    [ "participantName", "structSyscParticipantInfo.xhtml#afda543c3aeea91e0136520fca2487d6b", null ],
    [ "scHost", "structSyscParticipantInfo.xhtml#a04b95234f786ebe57fd1650eca58f411", null ],
    [ "scPort", "structSyscParticipantInfo.xhtml#a39c22384e8889c14c55ae7e4921873cb", null ],
    [ "transcriptFilename", "structSyscParticipantInfo.xhtml#a622cd703147ec31e2c80b1933ea773a1", null ]
];