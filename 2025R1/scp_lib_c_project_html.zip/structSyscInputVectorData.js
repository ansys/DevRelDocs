var structSyscInputVectorData =
[
    [ "data0", "structSyscInputVectorData.xhtml#a5d82442ce980b42b83952c7cc5add7c1", null ],
    [ "data1", "structSyscInputVectorData.xhtml#a55afda92952939d2ff72b07e3792e509", null ],
    [ "data2", "structSyscInputVectorData.xhtml#a8e8fa224f82b93e781c57d6b9db9fe19", null ],
    [ "dimension", "structSyscInputVectorData.xhtml#a7bb398945453b66b673ddc252458f69d", null ],
    [ "primitiveType", "structSyscInputVectorData.xhtml#a9f94dd62dccc2b3899c69b2ce1c6d1ea", null ],
    [ "size", "structSyscInputVectorData.xhtml#aef2f006ed5084f3c78dd98f7b4bf5429", null ]
];