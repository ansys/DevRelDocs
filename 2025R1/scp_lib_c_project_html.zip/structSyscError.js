var structSyscError =
[
    [ "message", "structSyscError.xhtml#a166e507f0606a321e1e076f7889d5844", null ],
    [ "retcode", "structSyscError.xhtml#afbc03fa7fe0724b2810626b319364f27", null ]
];