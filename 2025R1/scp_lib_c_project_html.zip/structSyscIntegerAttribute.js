var structSyscIntegerAttribute =
[
    [ "modifiable", "structSyscIntegerAttribute.xhtml#a00f7c6e6e82db0990246f8405e207a3c", null ],
    [ "name", "structSyscIntegerAttribute.xhtml#ab13f95caf8c2c7b73b3c3f2435876f27", null ],
    [ "value", "structSyscIntegerAttribute.xhtml#a272f235cfc28cb256a9f5793cb3d51f4", null ]
];