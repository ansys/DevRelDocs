var structSyscRegion =
[
    [ "displayName", "structSyscRegion.xhtml#ac6572b0ff5814075613806b50506d7dd", null ],
    [ "name", "structSyscRegion.xhtml#a9ad96fdd8a6a46c8d0b4ac7ffb23d7a8", null ],
    [ "regionDiscretizationType", "structSyscRegion.xhtml#aba2c044546a908f37b3419408410b3a5", null ],
    [ "topology", "structSyscRegion.xhtml#a7fd5681f99d4737e705ef1c670ad6268", null ]
];