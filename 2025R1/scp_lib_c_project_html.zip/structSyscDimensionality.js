var structSyscDimensionality =
[
    [ "amountOfSubstance", "structSyscDimensionality.xhtml#a7cb2bcc42a70ccbcbc067d2f8e3537f1", null ],
    [ "angle", "structSyscDimensionality.xhtml#a97ee853763b54b62bbd1ead7cbd1a761", null ],
    [ "current", "structSyscDimensionality.xhtml#a2c8448dbd321dd0ba7eea2948af0267a", null ],
    [ "length", "structSyscDimensionality.xhtml#ade2aab9da75df70b06a24decd849a28a", null ],
    [ "luminousIntensity", "structSyscDimensionality.xhtml#a7c44af07621ed3d5a1e6f21fdc7f0451", null ],
    [ "mass", "structSyscDimensionality.xhtml#aa2b7a661b200b1e3215213c03395357b", null ],
    [ "temperature", "structSyscDimensionality.xhtml#a4178e31fd49a0bc202c9252953978eeb", null ],
    [ "time", "structSyscDimensionality.xhtml#a0800961b23f992e62860634b94f239c8", null ]
];