/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Introduction",url:"index.xhtml"},
{text:"Getting started",url:"",children:[
{text:"User Guide",url:"_getting_started_user_guide.xhtml"}]},
{text:"Usage examples",url:"_usage_examples.xhtml"},
{text:"Changelog",url:"_changelog.xhtml"},
{text:"Classes",url:"annotated.xhtml",children:[
{text:"Class List",url:"annotated.xhtml"},
{text:"Class Index",url:"classes.xhtml"},
{text:"Class Hierarchy",url:"hierarchy.xhtml"},
{text:"Class Members",url:"functions.xhtml",children:[
{text:"All",url:"functions.xhtml",children:[
{text:"a",url:"functions.xhtml#index_a"},
{text:"b",url:"functions_b.xhtml#index_b"},
{text:"c",url:"functions_c.xhtml#index_c"},
{text:"d",url:"functions_d.xhtml#index_d"},
{text:"e",url:"functions_e.xhtml#index_e"},
{text:"f",url:"functions_f.xhtml#index_f"},
{text:"g",url:"functions_g.xhtml#index_g"},
{text:"h",url:"functions_h.xhtml#index_h"},
{text:"i",url:"functions_i.xhtml#index_i"},
{text:"l",url:"functions_l.xhtml#index_l"},
{text:"m",url:"functions_m.xhtml#index_m"},
{text:"n",url:"functions_n.xhtml#index_n"},
{text:"o",url:"functions_o.xhtml#index_o"},
{text:"p",url:"functions_p.xhtml#index_p"},
{text:"r",url:"functions_r.xhtml#index_r"},
{text:"s",url:"functions_s.xhtml#index_s"},
{text:"t",url:"functions_t.xhtml#index_t"},
{text:"u",url:"functions_u.xhtml#index_u"},
{text:"v",url:"functions_v.xhtml#index_v"},
{text:"w",url:"functions_w.xhtml#index_w"},
{text:"x",url:"functions_x.xhtml#index_x"},
{text:"y",url:"functions_y.xhtml#index_y"},
{text:"z",url:"functions_z.xhtml#index_z"}]},
{text:"Functions",url:"functions_func.xhtml",children:[
{text:"a",url:"functions_func.xhtml#index_a"},
{text:"c",url:"functions_func.xhtml#index_c"},
{text:"d",url:"functions_func.xhtml#index_d"},
{text:"e",url:"functions_func.xhtml#index_e"},
{text:"f",url:"functions_func.xhtml#index_f"},
{text:"g",url:"functions_func.xhtml#index_g"},
{text:"i",url:"functions_func.xhtml#index_i"},
{text:"l",url:"functions_func.xhtml#index_l"},
{text:"r",url:"functions_func.xhtml#index_r"},
{text:"s",url:"functions_func.xhtml#index_s"},
{text:"u",url:"functions_func.xhtml#index_u"}]},
{text:"Variables",url:"functions_vars.xhtml",children:[
{text:"a",url:"functions_vars.xhtml#index_a"},
{text:"b",url:"functions_vars_b.xhtml#index_b"},
{text:"c",url:"functions_vars_c.xhtml#index_c"},
{text:"d",url:"functions_vars_d.xhtml#index_d"},
{text:"e",url:"functions_vars_e.xhtml#index_e"},
{text:"f",url:"functions_vars_f.xhtml#index_f"},
{text:"g",url:"functions_vars_g.xhtml#index_g"},
{text:"h",url:"functions_vars_h.xhtml#index_h"},
{text:"i",url:"functions_vars_i.xhtml#index_i"},
{text:"l",url:"functions_vars_l.xhtml#index_l"},
{text:"m",url:"functions_vars_m.xhtml#index_m"},
{text:"n",url:"functions_vars_n.xhtml#index_n"},
{text:"o",url:"functions_vars_o.xhtml#index_o"},
{text:"p",url:"functions_vars_p.xhtml#index_p"},
{text:"r",url:"functions_vars_r.xhtml#index_r"},
{text:"s",url:"functions_vars_s.xhtml#index_s"},
{text:"t",url:"functions_vars_t.xhtml#index_t"},
{text:"u",url:"functions_vars_u.xhtml#index_u"},
{text:"v",url:"functions_vars_v.xhtml#index_v"},
{text:"w",url:"functions_vars_w.xhtml#index_w"},
{text:"x",url:"functions_vars_x.xhtml#index_x"},
{text:"y",url:"functions_vars_y.xhtml#index_y"},
{text:"z",url:"functions_vars_z.xhtml#index_z"}]}]}]}]}
