var searchData=
[
  ['add_0',['Add',['../class_speos_n_x_1_1_optical_properties_geometry.xhtml#ab437b6f556464b59bf1f8cbb621b3724',1,'SpeosNX.OpticalPropertiesGeometry.Add()'],['../class_speos_n_x_1_1_sensor_light_field_selections.xhtml#ab437b6f556464b59bf1f8cbb621b3724',1,'SpeosNX.SensorLightFieldSelections.Add()'],['../class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#ab437b6f556464b59bf1f8cbb621b3724',1,'SpeosNX.SourceSurfaceEmissiveFaces.Add()'],['../class_speos_n_x_1_1_folder_builder.xhtml#a3edde4a5462dcfe792466658461faea7',1,'SpeosNX.FolderBuilder.Add()']]],
  ['addgeometries_1',['AddGeometries',['../class_speos_n_x_1_1_simulation_common_builder.xhtml#aa10491a90fb89595e1eddd012de455ef',1,'SpeosNX::SimulationCommonBuilder']]],
  ['addsensors_2',['AddSensors',['../class_speos_n_x_1_1_simulation_common_builder.xhtml#a55b5c4032c272c682127e349cd797a79',1,'SpeosNX::SimulationCommonBuilder']]],
  ['addsourcefacefilteringreferences_3',['AddSourceFaceFilteringReferences',['../class_speos_n_x_1_1_simulation_inverse_builder.xhtml#a053588683e97295e7450f0801c876eec',1,'SpeosNX::SimulationInverseBuilder']]],
  ['addsources_4',['AddSources',['../class_speos_n_x_1_1_simulation_common_builder.xhtml#a7131b0a2a313b3c379c6a7c6ef1662c9',1,'SpeosNX.SimulationCommonBuilder.AddSources()'],['../class_speos_n_x_1_1_source_group_builder.xhtml#ac46b654bd2f52fe74f58eb1a703e7db2',1,'SpeosNX.SourceGroupBuilder.AddSources()']]]
];
