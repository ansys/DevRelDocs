var searchData=
[
  ['linkedexport_0',['LinkedExport',['../class_speos_n_x_1_1_feature_simulation.xhtml#ae41856e50d4fccfcbd2570fef9ddea82',1,'SpeosNX::FeatureSimulation']]],
  ['load_1',['Load',['../class_speos_n_x_1_1_part_collection.xhtml#a7454373b1b420f2482537b7ee8e83503',1,'SpeosNX::PartCollection']]]
];
