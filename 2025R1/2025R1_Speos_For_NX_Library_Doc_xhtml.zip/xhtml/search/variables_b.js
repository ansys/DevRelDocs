var searchData=
[
  ['name_0',['Name',['../class_speos_n_x_1_1_feature_builder.xhtml#a19218d0239b929ca8aecfa629d0185d0',1,'SpeosNX.FeatureBuilder.Name'],['../class_speos_n_x_1_1_feature.xhtml#a19218d0239b929ca8aecfa629d0185d0',1,'SpeosNX.Feature.Name']]],
  ['namewithcontext_1',['NameWithContext',['../class_speos_n_x_1_1_feature_builder.xhtml#a89ee075a30b71ff6e3192d6bd6dd5515',1,'SpeosNX::FeatureBuilder']]],
  ['nearfield_2',['NearField',['../class_speos_n_x_1_1_sensor_intensity_builder.xhtml#a2f0dd448a30c680618472417c64ad302',1,'SpeosNX::SensorIntensityBuilder']]],
  ['northdirection_3',['NorthDirection',['../class_speos_n_x_1_1_zenith_north_system.xhtml#a3f4df40333e3b971acf5ae1f5ef27402',1,'SpeosNX::ZenithNorthSystem']]],
  ['northdirectionreversed_4',['NorthDirectionReversed',['../class_speos_n_x_1_1_zenith_north_system.xhtml#a310eb55d3ba0e3aff435905635c102b7',1,'SpeosNX::ZenithNorthSystem']]],
  ['numberofray_5',['NumberOfRay',['../class_speos_n_x_1_1_speos_pattern_builder.xhtml#a1811cd5b1ac3b0bd6e780bce2adfe042',1,'SpeosNX::SpeosPatternBuilder']]],
  ['numberofrays_6',['NumberOfRays',['../class_speos_n_x_1_1_source_display_builder.xhtml#aaa149f4084199f582574fb95a19750ec',1,'SpeosNX.SourceDisplayBuilder.NumberOfRays'],['../class_speos_n_x_1_1_source_light_field_builder.xhtml#aaa149f4084199f582574fb95a19750ec',1,'SpeosNX.SourceLightFieldBuilder.NumberOfRays'],['../class_speos_n_x_1_1_source_luminaire_builder.xhtml#aaa149f4084199f582574fb95a19750ec',1,'SpeosNX.SourceLuminaireBuilder.NumberOfRays'],['../class_speos_n_x_1_1_source_ray_file_builder.xhtml#aaa149f4084199f582574fb95a19750ec',1,'SpeosNX.SourceRayFileBuilder.NumberOfRays'],['../class_speos_n_x_1_1_source_surface_builder.xhtml#aaa149f4084199f582574fb95a19750ec',1,'SpeosNX.SourceSurfaceBuilder.NumberOfRays'],['../class_speos_n_x_1_1_source_surface_thermic_builder.xhtml#aaa149f4084199f582574fb95a19750ec',1,'SpeosNX.SourceSurfaceThermicBuilder.NumberOfRays']]],
  ['numberofsequences_7',['NumberOfSequences',['../class_speos_n_x_1_1_sensor_physical_camera_builder.xhtml#a6af2df89c067013626c00272878f9d9e',1,'SpeosNX::SensorPhysicalCameraBuilder']]],
  ['numberstandardpasses_8',['NumberStandardPasses',['../class_speos_n_x_1_1_simulation_settings.xhtml#a96e94fb339378306db82ec6a60396b22',1,'SpeosNX::SimulationSettings']]],
  ['nxsessiontag_9',['NXSessionTag',['../class_speos_n_x_1_1_session.xhtml#a8ae3ec3b4c717182e5c91c3532ea78a3',1,'SpeosNX::Session']]]
];
