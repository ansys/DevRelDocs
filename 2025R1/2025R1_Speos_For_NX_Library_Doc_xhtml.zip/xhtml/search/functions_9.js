var searchData=
[
  ['saveaspreset_0',['SaveAsPreset',['../class_speos_n_x_1_1_simulation_settings.xhtml#af481834f7c7cca6d477a24350b6ad5f2',1,'SpeosNX::SimulationSettings']]],
  ['showresult_1',['ShowResult',['../class_speos_n_x_1_1_feature_builder.xhtml#ae0fcd0d60a901105f0702ff7da8b1041',1,'SpeosNX::FeatureBuilder']]]
];
