var searchData=
[
  ['gammacorrection_0',['GammaCorrection',['../class_speos_n_x_1_1_sensor_camera_builder.xhtml#ac2c4a2fbb62c65cc6cbec857ca9919da',1,'SpeosNX::SensorCameraBuilder']]],
  ['gatheringsourcenumber_1',['GatheringSourceNumber',['../class_speos_n_x_1_1_simulation_settings.xhtml#a605bd49b9087e31e3447d8bd547a7714',1,'SpeosNX::SimulationSettings']]],
  ['gaussianfwhmangle_2',['GaussianFWHMAngle',['../class_speos_n_x_1_1_source_display_builder.xhtml#ae942485ca7f6424861badd0a17717a88',1,'SpeosNX::SourceDisplayBuilder']]],
  ['gaussianfwhmanglex_3',['GaussianFWHMAngleX',['../class_speos_n_x_1_1_source_display_builder.xhtml#ad6ea73208d1290bbc84771f72c8498fa',1,'SpeosNX::SourceDisplayBuilder']]],
  ['gaussianfwhmangley_4',['GaussianFWHMAngleY',['../class_speos_n_x_1_1_source_display_builder.xhtml#a26d44695dc3a431cd107819bfb868362',1,'SpeosNX::SourceDisplayBuilder']]],
  ['geometricaldistancetolerance_5',['GeometricalDistanceTolerance',['../class_speos_n_x_1_1_simulation_settings.xhtml#a679a64aa6f22f3ced583eb21762e6b41',1,'SpeosNX::SimulationSettings']]],
  ['geometries_6',['Geometries',['../class_speos_n_x_1_1_component_light_box_export_builder.xhtml#aad591c452737d164b58956acd8acb541',1,'SpeosNX.ComponentLightBoxExportBuilder.Geometries'],['../class_speos_n_x_1_1_simulation_common_builder.xhtml#aad591c452737d164b58956acd8acb541',1,'SpeosNX.SimulationCommonBuilder.Geometries']]],
  ['greengain_7',['GreenGain',['../class_speos_n_x_1_1_sensor_camera_builder.xhtml#ab295b63fcc4308c1953aa8d0b01cb8e7',1,'SpeosNX::SensorCameraBuilder']]],
  ['greenspectrumfile_8',['GreenSpectrumFile',['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#a71e30d101d726c8744a9b69efb178358',1,'SpeosNX::SourceAmbientEnvironmentBuilder']]],
  ['greenspectrumfilepath_9',['GreenSpectrumFilePath',['../class_speos_n_x_1_1_source_display_builder.xhtml#adbd5552b771bee21f7509ddc489a4e0b',1,'SpeosNX::SourceDisplayBuilder']]],
  ['gridoriginx_10',['GridOriginX',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a3e462caa50357a9788b8735930dc8af0',1,'SpeosNX.SensorCommonBuilder.GridOriginX'],['../class_speos_n_x_1_1_sensor_human_eye_builder.xhtml#a3e462caa50357a9788b8735930dc8af0',1,'SpeosNX.SensorHumanEyeBuilder.GridOriginX']]],
  ['gridoriginy_11',['GridOriginY',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a7c3aa08faef640884a10d6766ce36efe',1,'SpeosNX.SensorCommonBuilder.GridOriginY'],['../class_speos_n_x_1_1_sensor_human_eye_builder.xhtml#a7c3aa08faef640884a10d6766ce36efe',1,'SpeosNX.SensorHumanEyeBuilder.GridOriginY']]],
  ['gridstepx_12',['GridStepX',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a03d8d2fd56c4163a396dc0fd8a90f963',1,'SpeosNX.SensorCommonBuilder.GridStepX'],['../class_speos_n_x_1_1_sensor_human_eye_builder.xhtml#a03d8d2fd56c4163a396dc0fd8a90f963',1,'SpeosNX.SensorHumanEyeBuilder.GridStepX']]],
  ['gridstepy_13',['GridStepY',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a2528f56fb7db94f6d20bbed9d51bde14',1,'SpeosNX.SensorCommonBuilder.GridStepY'],['../class_speos_n_x_1_1_sensor_human_eye_builder.xhtml#a2528f56fb7db94f6d20bbed9d51bde14',1,'SpeosNX.SensorHumanEyeBuilder.GridStepY']]],
  ['groundorigin_14',['GroundOrigin',['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#aaeeb813ba4dc675ca6f27de6d612472a',1,'SpeosNX::SourceAmbientEnvironmentBuilder']]]
];
