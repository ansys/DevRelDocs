var searchData=
[
  ['findfromname_0',['FindFromName',['../class_speos_n_x_1_1_feature_collection.xhtml#a3dfb805746ced02afb3ddcabff01c248',1,'SpeosNX.FeatureCollection.FindFromName()'],['../class_speos_n_x_1_1_part_collection.xhtml#aec7a66a9a59128bd343c92d7d1477b7b',1,'SpeosNX.PartCollection.FindFromName()']]],
  ['findfromtag_1',['FindFromTag',['../class_speos_n_x_1_1_feature_collection.xhtml#a9efd365eb21c4a0d89cff856870d8a6b',1,'SpeosNX.FeatureCollection.FindFromTag()'],['../class_speos_n_x_1_1_part_collection.xhtml#a4b9ad4999619b5bb0bb0bbe7763d1e88',1,'SpeosNX.PartCollection.FindFromTag()']]]
];
