var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwxyz",
  1: "_acfoprstz",
  2: "acdefgilrsu",
  3: "abcdefghilmnoprstuvwxyz",
  4: "cefglnsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Pages"
};

