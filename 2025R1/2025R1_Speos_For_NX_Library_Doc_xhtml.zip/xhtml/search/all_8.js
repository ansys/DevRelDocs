var searchData=
[
  ['hasfluxinlumen_0',['HasFluxInLumen',['../class_speos_n_x_1_1_ray_file_data.xhtml#a07a5d7a44f5ab47715ab38bfa11a398d',1,'SpeosNX::RayFileData']]],
  ['hasfluxinwatt_1',['HasFluxInWatt',['../class_speos_n_x_1_1_ray_file_data.xhtml#a079bb3f8e90163f96012a61156824686',1,'SpeosNX::RayFileData']]],
  ['haspower_2',['HasPower',['../class_speos_n_x_1_1_ray_file_data.xhtml#a9d14c141a7a5352387f951cd12c62fcf',1,'SpeosNX::RayFileData']]],
  ['height_3',['Height',['../class_speos_n_x_1_1_sensor_camera_builder.xhtml#a37eb7401ae5f6ba4e112d3909cae96f0',1,'SpeosNX.SensorCameraBuilder.Height'],['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#a37eb7401ae5f6ba4e112d3909cae96f0',1,'SpeosNX.SourceAmbientEnvironmentBuilder.Height']]],
  ['horizontalfov_4',['HorizontalFOV',['../class_speos_n_x_1_1_sensor_camera_builder.xhtml#a02946d0fe38b0f9101891760028ffc57',1,'SpeosNX::SensorCameraBuilder']]],
  ['horizontalpixels_5',['HorizontalPixels',['../class_speos_n_x_1_1_sensor_camera_builder.xhtml#afcfe41111470f3b67568e5a8f450d8c2',1,'SpeosNX::SensorCameraBuilder']]],
  ['hour_6',['Hour',['../class_speos_n_x_1_1_timezone.xhtml#a95d51cc8afe6e3f810f20530a095b8fb',1,'SpeosNX::Timezone']]],
  ['hvratio_7',['HVRatio',['../class_speos_n_x_1_1_sensor_radiance_builder.xhtml#a186676d817057dd66ffc7d12c8168f7c',1,'SpeosNX::SensorRadianceBuilder']]]
];
