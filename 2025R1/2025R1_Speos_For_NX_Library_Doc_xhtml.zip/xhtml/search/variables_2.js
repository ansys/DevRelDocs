var searchData=
[
  ['cameramode_0',['CameraMode',['../class_speos_n_x_1_1_sensor_camera_builder.xhtml#a932c5ab6f914702d97b2a6bbeaf6d434',1,'SpeosNX::SensorCameraBuilder']]],
  ['cameraname_1',['CameraName',['../class_speos_n_x_1_1_sensor_radiance_builder.xhtml#a0cd4951ca1eb2abeda10258ed12308da',1,'SpeosNX::SensorRadianceBuilder']]],
  ['category_2',['Category',['../class_speos_n_x_1_1_folder_builder.xhtml#ad118727ac7e398ef5e18f05f5e47adeb',1,'SpeosNX::FolderBuilder']]],
  ['celldiameter_3',['CellDiameter',['../class_speos_n_x_1_1_sensor_intensity_builder.xhtml#a54568300b967caf42f3ff41ceda48c6e',1,'SpeosNX::SensorIntensityBuilder']]],
  ['celldistance_4',['CellDistance',['../class_speos_n_x_1_1_sensor_intensity_builder.xhtml#a89261bcae91ef4d99878985e6fecd12b',1,'SpeosNX::SensorIntensityBuilder']]],
  ['cietype_5',['CIEType',['../class_speos_n_x_1_1_source_ambient_general_sky_builder.xhtml#a674ad9b178d1917ad64dc322cdf3397e',1,'SpeosNX::SourceAmbientGeneralSkyBuilder']]],
  ['colorimetricstandardmode_6',['ColorimetricStandardMode',['../class_speos_n_x_1_1_simulation_settings.xhtml#a8cd8df840ebc47628906cab51ae84dee',1,'SpeosNX::SimulationSettings']]],
  ['colormode_7',['ColorMode',['../class_speos_n_x_1_1_sensor_camera_builder.xhtml#ae310087df32e1820a6892c84c983fe4a',1,'SpeosNX::SensorCameraBuilder']]],
  ['colorspace_8',['ColorSpace',['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#aeaf08fe09b5dba864e9567b46973cc03',1,'SpeosNX.SourceAmbientEnvironmentBuilder.ColorSpace'],['../class_speos_n_x_1_1_source_display_builder.xhtml#aeaf08fe09b5dba864e9567b46973cc03',1,'SpeosNX.SourceDisplayBuilder.ColorSpace']]],
  ['conoscopicresolution_9',['ConoscopicResolution',['../class_speos_n_x_1_1_sensor_intensity_builder.xhtml#abedf381f29e2c1484a54512e0b4a9ce6',1,'SpeosNX::SensorIntensityBuilder']]],
  ['conoscopicsampling_10',['ConoscopicSampling',['../class_speos_n_x_1_1_sensor_intensity_builder.xhtml#aa0179072787bd47dc53512ac9c22120f',1,'SpeosNX::SensorIntensityBuilder']]],
  ['conoscopicthetamax_11',['ConoscopicThetaMax',['../class_speos_n_x_1_1_sensor_intensity_builder.xhtml#af4244f96e7755ee9944d6c39bb61d083',1,'SpeosNX::SensorIntensityBuilder']]],
  ['contrast_12',['Contrast',['../class_speos_n_x_1_1_source_display_builder.xhtml#ac35d783502acc19412173b338d6334f1',1,'SpeosNX::SourceDisplayBuilder']]],
  ['cosn_13',['CosN',['../class_speos_n_x_1_1_source_display_builder.xhtml#ab6af473ac0abd6943d5eac98e2fb5140',1,'SpeosNX.SourceDisplayBuilder.CosN'],['../class_speos_n_x_1_1_source_surface_thermic_builder.xhtml#ab6af473ac0abd6943d5eac98e2fb5140',1,'SpeosNX.SourceSurfaceThermicBuilder.CosN']]],
  ['customaxissystem_14',['CustomAxisSystem',['../class_speos_n_x_1_1_component_light_box_export_builder.xhtml#ad4a0da998b5304280cb2770f84243b6d',1,'SpeosNX.ComponentLightBoxExportBuilder.CustomAxisSystem'],['../class_speos_n_x_1_1_component_light_box_import_builder.xhtml#ad4a0da998b5304280cb2770f84243b6d',1,'SpeosNX.ComponentLightBoxImportBuilder.CustomAxisSystem'],['../class_speos_n_x_1_1_sensor_light_field_builder.xhtml#ad4a0da998b5304280cb2770f84243b6d',1,'SpeosNX.SensorLightFieldBuilder.CustomAxisSystem'],['../class_speos_n_x_1_1_source_light_field_builder.xhtml#ad4a0da998b5304280cb2770f84243b6d',1,'SpeosNX.SourceLightFieldBuilder.CustomAxisSystem']]]
];
