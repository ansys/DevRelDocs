var searchData=
[
  ['xdirection_0',['XDirection',['../class_speos_n_x_1_1_source_display_builder.xhtml#a6f2c95537ef8210d7f1a99643aeeff4f',1,'SpeosNX::SourceDisplayBuilder']]],
  ['xdirectionreversed_1',['XDirectionReversed',['../class_speos_n_x_1_1_source_display_builder.xhtml#a42df9e8270fbe6b5a4944cb1e94b9885',1,'SpeosNX::SourceDisplayBuilder']]],
  ['xend_2',['XEnd',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a26309a89380b2756527ec19cffef2b6c',1,'SpeosNX.SensorCommonBuilder.XEnd'],['../class_speos_n_x_1_1_source_display_builder.xhtml#a26309a89380b2756527ec19cffef2b6c',1,'SpeosNX.SourceDisplayBuilder.XEnd']]],
  ['xmirroredextent_3',['XMirroredExtent',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#ae7c2faf5c62ec2baf03149375fadd672',1,'SpeosNX.SensorCommonBuilder.XMirroredExtent'],['../class_speos_n_x_1_1_source_display_builder.xhtml#ae7c2faf5c62ec2baf03149375fadd672',1,'SpeosNX.SourceDisplayBuilder.XMirroredExtent']]],
  ['xresolution_4',['XResolution',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#af339e4c5181343e4c3e38d92c9c05c47',1,'SpeosNX::SensorCommonBuilder']]],
  ['xsampling_5',['XSampling',['../class_speos_n_x_1_1_sensor3_d_energy_density_builder.xhtml#a9694a3d43cce188431740d9b8c364ac2',1,'SpeosNX.Sensor3DEnergyDensityBuilder.XSampling'],['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a9694a3d43cce188431740d9b8c364ac2',1,'SpeosNX.SensorCommonBuilder.XSampling']]],
  ['xsize_6',['XSize',['../class_speos_n_x_1_1_sensor3_d_energy_density_builder.xhtml#a0eb240206c3df3efb04b766e07808ada',1,'SpeosNX::Sensor3DEnergyDensityBuilder']]],
  ['xstart_7',['XStart',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#abcbac58872bdd9d694ee7177d1ef7973',1,'SpeosNX.SensorCommonBuilder.XStart'],['../class_speos_n_x_1_1_source_display_builder.xhtml#abcbac58872bdd9d694ee7177d1ef7973',1,'SpeosNX.SourceDisplayBuilder.XStart']]]
];
