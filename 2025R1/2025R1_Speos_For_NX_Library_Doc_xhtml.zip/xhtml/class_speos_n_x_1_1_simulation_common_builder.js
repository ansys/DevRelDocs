var class_speos_n_x_1_1_simulation_common_builder =
[
    [ "AddGeometries", "class_speos_n_x_1_1_simulation_common_builder.xhtml#aa10491a90fb89595e1eddd012de455ef", null ],
    [ "AddSensors", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a55b5c4032c272c682127e349cd797a79", null ],
    [ "AddSources", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a7131b0a2a313b3c379c6a7c6ef1662c9", null ],
    [ "RemoveGeometries", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a72a0f1aff0152618207092c4f7c72121", null ],
    [ "RemoveSensors", "class_speos_n_x_1_1_simulation_common_builder.xhtml#af39872183312cd1cf9335f80b8b066e6", null ],
    [ "RemoveSources", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a22c55e6f209f7acea541afa58c1bc868", null ]
];