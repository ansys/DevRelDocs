var class_speos_n_x_1_1_source_surface_emissive_faces =
[
    [ "Add", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#ab437b6f556464b59bf1f8cbb621b3724", null ],
    [ "Clear", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#ad1f121ac89b5e624a0351c969e95d985", null ],
    [ "Remove", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#ae5875ad27243653f6c314b4a8fa08a29", null ],
    [ "RevertFace", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#a2eaf50be619ae23dc0aa4cc990a4dd19", null ]
];