var class_speos_n_x_1_1_sensor_camera_builder =
[
    [ "UpdateWavelengthSamplingFromResolution", "class_speos_n_x_1_1_sensor_camera_builder.xhtml#aa84cc20a2aa99d1c8ff2ff353cb0923a", null ]
];