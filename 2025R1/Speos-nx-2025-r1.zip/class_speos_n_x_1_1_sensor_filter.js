var class_speos_n_x_1_1_sensor_filter =
[
    [ "AddNewGroup", "class_speos_n_x_1_1_sensor_filter.xhtml#a887ceed83fc45e80d3ddc8a3a4f31b93", null ],
    [ "RemoveGroup", "class_speos_n_x_1_1_sensor_filter.xhtml#a549c22d0cf03e56d57ff47f8bd46bd35", null ]
];