var class_speos_n_x_1_1_simulation_inverse_builder =
[
    [ "AddSourceFaceFilteringReferences", "class_speos_n_x_1_1_simulation_inverse_builder.xhtml#a053588683e97295e7450f0801c876eec", null ],
    [ "DeleteSourceFaceFilteringReferences", "class_speos_n_x_1_1_simulation_inverse_builder.xhtml#a1f2eebc9ec162ea073fb198b19096657", null ]
];