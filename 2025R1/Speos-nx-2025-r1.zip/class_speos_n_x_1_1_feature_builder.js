var class_speos_n_x_1_1_feature_builder =
[
    [ "Commit", "class_speos_n_x_1_1_feature_builder.xhtml#a77581800008ea3179049e650e9d1787b", null ],
    [ "ShowResult", "class_speos_n_x_1_1_feature_builder.xhtml#ae0fcd0d60a901105f0702ff7da8b1041", null ]
];