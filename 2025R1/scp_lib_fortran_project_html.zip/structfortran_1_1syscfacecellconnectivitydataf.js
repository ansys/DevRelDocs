var structfortran_1_1syscfacecellconnectivitydataf =
[
    [ "cell0ids", "structfortran_1_1syscfacecellconnectivitydataf.xhtml#aa09ee35bf407e026b955244f7743618a", null ],
    [ "cell1ids", "structfortran_1_1syscfacecellconnectivitydataf.xhtml#a1a9a40f5189107de989decbaeccd8112", null ]
];