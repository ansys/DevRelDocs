var interfacefortran_1_1syscgetcelldataf =
[
    [ "syscgetcelldataf", "interfacefortran_1_1syscgetcelldataf.xhtml#a48f9b149e7123172299ff88f71b26b80", null ],
    [ "syscgetfacedataf_i", "interfacefortran_1_1syscgetcelldataf.xhtml#a650453591ca50d309f6262a1e63963e9", null ],
    [ "syscgetfacedataf_tn", "interfacefortran_1_1syscgetcelldataf.xhtml#ad82b8c8ff9ebbc59c102d46490dadf91", null ]
];