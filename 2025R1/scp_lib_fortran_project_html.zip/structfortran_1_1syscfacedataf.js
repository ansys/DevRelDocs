var structfortran_1_1syscfacedataf =
[
    [ "facecellconnectivity", "structfortran_1_1syscfacedataf.xhtml#a60fd49965317a12753680728055cddcf", null ],
    [ "faceids", "structfortran_1_1syscfacedataf.xhtml#ac15be376d8a7d00e486707ac0269056e", null ],
    [ "facenodeconnectivity", "structfortran_1_1syscfacedataf.xhtml#a62c5148ef54c724d306a1d2ed512ccf1", null ],
    [ "facenodecounts", "structfortran_1_1syscfacedataf.xhtml#a2abe8c3dbc5763c1d6a59c79a2e14e79", null ],
    [ "facetypes", "structfortran_1_1syscfacedataf.xhtml#acb27a555d3934aa9aac98ece4c77b167", null ]
];