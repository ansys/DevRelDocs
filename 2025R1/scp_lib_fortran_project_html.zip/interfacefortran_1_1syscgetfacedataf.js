var interfacefortran_1_1syscgetfacedataf =
[
    [ "syscgetfacedataf", "interfacefortran_1_1syscgetfacedataf.xhtml#ae9a6152011424543a301b1091a863f5b", null ],
    [ "syscgetfacedataf_cn", "interfacefortran_1_1syscgetfacedataf.xhtml#a20801c611ee9d84e56a5ce3f1b179f5c", null ],
    [ "syscgetfacedataf_itn", "interfacefortran_1_1syscgetfacedataf.xhtml#a90367f1647e014b59ed7fbd5437500a9", null ]
];