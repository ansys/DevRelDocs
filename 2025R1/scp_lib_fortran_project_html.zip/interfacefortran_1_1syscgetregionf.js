var interfacefortran_1_1syscgetregionf =
[
    [ "syscgetregionf", "interfacefortran_1_1syscgetregionf.xhtml#a54b1b07b43df89ae124a82bf7b2984b0", null ],
    [ "syscgetregionf_dt", "interfacefortran_1_1syscgetregionf.xhtml#a5195a09454601955d703e0359b40731a", null ],
    [ "syscgetregionf_t", "interfacefortran_1_1syscgetregionf.xhtml#a6ddf1e36616695a0bb954425a1b30896", null ],
    [ "syscgetregionf_tm", "interfacefortran_1_1syscgetregionf.xhtml#a314e7f693be1c5c4d7833bfd467de815", null ]
];