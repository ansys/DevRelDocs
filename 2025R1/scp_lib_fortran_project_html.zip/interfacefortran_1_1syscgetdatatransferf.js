var interfacefortran_1_1syscgetdatatransferf =
[
    [ "syscgetdatatransferf", "interfacefortran_1_1syscgetdatatransferf.xhtml#a7dfe2901d48eab20fe578ec65a3d1343", null ]
];