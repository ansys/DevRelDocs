/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "System Coupling 2025 R1 Participant Library:  Fortran Interfaces", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "User guide", "md_01b_Contents.xhtml", [
      [ "System Coupling Participant library capabilities", "md_02_ParticipantLibraryCapabilities.xhtml", null ],
      [ "Concepts overview", "md_03_ConceptsAndTerminology.xhtml", null ],
      [ "Standalone mapping", "md_04_ParticipantStepsForMapping.xhtml", null ],
      [ "Steps to set up and execute the coupled analysis", "md_05_StepsToSetupAndExecutedCoupledAnalysis.xhtml", null ],
      [ "Completing the System Coupling participant setup", "md_06_ParticipantSetup.xhtml", null ],
      [ "Participant steps in a coupled analysis", "md_07_ParticipantStepsInCoupledAnalysis.xhtml", null ],
      [ "Command line arguments for participant solvers", "md_08_CommandLineArguments.xhtml", null ],
      [ "Execution in a parallel environment", "md_09_ParallelExecution.xhtml", null ],
      [ "Access to parameter data", "md_10_ParameterDataAccess.xhtml", null ],
      [ "Access to heavyweight data", "md_11_HeavyweightDataAccess.xhtml", null ],
      [ "Mesh and point cloud data access", "md_12_MeshDataAccess.xhtml", null ],
      [ "Creating restart points and restarting a coupled analysis", "md_13_Restarts.xhtml", null ],
      [ "Multi-region coupling interfaces", "md_14_Multiregion.xhtml", null ],
      [ "Testing and debugging tools", "md_15_TestingDebuggingTools.xhtml", null ],
      [ "Migration guide and known issues", "md_16_MigrationGuide.xhtml", null ],
      [ "Compiling, linking, and executing applications that use the participant library", "md_17_CompilingLinkingExecuting.xhtml", null ],
      [ "Heat transfer in square channel air flow tutorial", "md_18_ChannelFlowTutorial.xhtml", null ],
      [ "Oscillating plate damping tutorial", "md_19_PlateDampingTutorial.xhtml", null ],
      [ "Pipe mapping tutorial", "md_20_PipeMappingTutorial.xhtml", null ]
    ] ],
    [ "Data Types List", "annotated.xhtml", [
      [ "Data Types List", "annotated.xhtml", "annotated_dup" ],
      [ "Data Types", "classes.xhtml", null ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions/Subroutines", "functions_func.xhtml", null ],
        [ "Variables", "functions_vars.xhtml", null ]
      ] ]
    ] ],
    [ "Changelog", "md_21_ReleaseNotes.xhtml", null ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.xhtml",
"interfacefortran_1_1syscoutputcomplexvectordataaccessf.xhtml"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';