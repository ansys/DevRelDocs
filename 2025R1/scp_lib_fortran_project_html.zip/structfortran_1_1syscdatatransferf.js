var structfortran_1_1syscdatatransferf =
[
    [ "sourcevariable", "structfortran_1_1syscdatatransferf.xhtml#af21e64ccd79e4331f04477e979a5ad7e", null ],
    [ "targetside", "structfortran_1_1syscdatatransferf.xhtml#a9f6c6078b224bb2f4b9d69236dae416c", null ],
    [ "targetvariable", "structfortran_1_1syscdatatransferf.xhtml#a25b318e666a7df521caa1cf70944be48", null ]
];