var structfortran_1_1syscrealattributef =
[
    [ "dimensionality", "structfortran_1_1syscrealattributef.xhtml#a627f420eb85a779240c8821a05884707", null ],
    [ "name", "structfortran_1_1syscrealattributef.xhtml#a72f0326f2d38c6a753a748136992df3a", null ],
    [ "value", "structfortran_1_1syscrealattributef.xhtml#a631d998f8e50b318684c7f3ad5cd01a4", null ]
];