var interfacefortran_1_1syscgetsetupfileinfof =
[
    [ "syscgetsetupfileinfof", "interfacefortran_1_1syscgetsetupfileinfof.xhtml#abe48d99971ec8f83f367fdb7a87dfed3", null ]
];