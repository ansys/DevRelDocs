var structfortran_1_1syscpointcloudf =
[
    [ "nodecoords", "structfortran_1_1syscpointcloudf.xhtml#ada1acb5d25c5ab0e62ade22161a73b14", null ],
    [ "nodeids", "structfortran_1_1syscpointcloudf.xhtml#a34207f80097afcc6f7e37b61187e604e", null ]
];