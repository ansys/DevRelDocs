var structfortran_1_1syscvariablef =
[
    [ "datatype", "structfortran_1_1syscvariablef.xhtml#a5630b71110de368c88758358db3b720d", null ],
    [ "displayname", "structfortran_1_1syscvariablef.xhtml#a9278aae61ed92d3128608932a9d9f464", null ],
    [ "isextensive", "structfortran_1_1syscvariablef.xhtml#ad3267dcbbecf72d992ab42706eabff7e", null ],
    [ "location", "structfortran_1_1syscvariablef.xhtml#a273794a0cba93c1b658a44d52509602e", null ],
    [ "quantitytype", "structfortran_1_1syscvariablef.xhtml#a75a35f6f8588983f49b7c297cf909f89", null ],
    [ "tensortype", "structfortran_1_1syscvariablef.xhtml#a0002a1ee2cd59d127b4870b6a9ae3a6c", null ],
    [ "variablename", "structfortran_1_1syscvariablef.xhtml#a4b564b900d619390a32c15b030dd7e70", null ]
];