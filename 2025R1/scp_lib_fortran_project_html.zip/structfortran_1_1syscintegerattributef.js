var structfortran_1_1syscintegerattributef =
[
    [ "name", "structfortran_1_1syscintegerattributef.xhtml#a72f0326f2d38c6a753a748136992df3a", null ],
    [ "value", "structfortran_1_1syscintegerattributef.xhtml#a4a90717b8eeddc3fd746579d763ccc56", null ]
];