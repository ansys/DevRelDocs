var interfacefortran_1_1syscgetnodedataf =
[
    [ "syscgetnodedataf", "interfacefortran_1_1syscgetnodedataf.xhtml#ab0c2e03306ceb3c4874622518edf3cef", null ],
    [ "syscgetnodedataf_c", "interfacefortran_1_1syscgetnodedataf.xhtml#ab16062b2cefc75ceeb5f817af11ab3e1", null ],
    [ "syscgetnodedataf_ic", "interfacefortran_1_1syscgetnodedataf.xhtml#a224ef609645a62ffa063d9dfbf289634", null ]
];