var interfacefortran_1_1syscgetvariablef =
[
    [ "syscgetvariablef", "interfacefortran_1_1syscgetvariablef.xhtml#a608cb70dd0a2392044f91c81fbfd3935", null ],
    [ "syscgetvariablef_dtelqd", "interfacefortran_1_1syscgetvariablef.xhtml#a7ccf1db6c97ad5fbc08fc1a850a48343", null ],
    [ "syscgetvariablef_q", "interfacefortran_1_1syscgetvariablef.xhtml#aa98302cabc43b69aba1ba8e4c4b25b25", null ],
    [ "syscgetvariablef_te", "interfacefortran_1_1syscgetvariablef.xhtml#a500912aab7a473fba9e3b2ef73d0cdc2", null ],
    [ "syscgetvariablef_teq", "interfacefortran_1_1syscgetvariablef.xhtml#a28db29bc33d8fa7aec1ee121dd156485", null ]
];