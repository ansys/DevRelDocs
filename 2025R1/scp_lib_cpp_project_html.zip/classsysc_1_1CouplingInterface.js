var classsysc_1_1CouplingInterface =
[
    [ "CouplingInterface", "classsysc_1_1CouplingInterface.xhtml#a606ddfa3113e3e0bf1ee7eee2b58793d", null ],
    [ "addDataTransfer", "classsysc_1_1CouplingInterface.xhtml#ab1230f4b0c7dc52fff73d1ddcd67f03e", null ],
    [ "addSideOneRegion", "classsysc_1_1CouplingInterface.xhtml#ab7a385065f0fde034baa88a88f274946", null ],
    [ "addSideTwoRegion", "classsysc_1_1CouplingInterface.xhtml#a5afdb8ffa5c06d66fe30e6f150230b67", null ],
    [ "getDataTransfer", "classsysc_1_1CouplingInterface.xhtml#a712f091ef0bb543a6539c32fd6762fa8", null ],
    [ "getName", "classsysc_1_1CouplingInterface.xhtml#a16898e4f25dd40d0e8bc2efec9c4db1d", null ],
    [ "getNumDataTransfers", "classsysc_1_1CouplingInterface.xhtml#a9ac1bf66c466b9567e26fdf5c2108c05", null ],
    [ "getNumSideOneRegions", "classsysc_1_1CouplingInterface.xhtml#a84873c1535d70a88096d44242c97a1b7", null ],
    [ "getNumSideTwoRegions", "classsysc_1_1CouplingInterface.xhtml#a03a32678f212092a83149ea2b0c54f20", null ],
    [ "getSideOneRegion", "classsysc_1_1CouplingInterface.xhtml#a1191a096450bd4569325be7bef6cb1f6", null ],
    [ "getSideTwoRegion", "classsysc_1_1CouplingInterface.xhtml#a2809a5c10d6fc48e7c079fb09deaccd3", null ]
];