var structsysc_1_1ParticipantInfo =
[
    [ "ParticipantInfo", "structsysc_1_1ParticipantInfo.xhtml#a62ca76d7ec19c59606870814aaec771e", null ],
    [ "ParticipantInfo", "structsysc_1_1ParticipantInfo.xhtml#ad36586cda6d30d65c5f38e0df6ff352c", null ],
    [ "ParticipantInfo", "structsysc_1_1ParticipantInfo.xhtml#aeee6c446f5f67d25a4647cd3e6af2208", null ],
    [ "ParticipantInfo", "structsysc_1_1ParticipantInfo.xhtml#a95ef3378c1477c0e378ff6682339a72f", null ],
    [ "buildInformation", "structsysc_1_1ParticipantInfo.xhtml#a04aa25721fcee48f00326f1a48bdf2d4", null ],
    [ "isCosimulation", "structsysc_1_1ParticipantInfo.xhtml#a0cca75649fe3b7c48ae59d115dfdd4f9", null ],
    [ "participantName", "structsysc_1_1ParticipantInfo.xhtml#ab9f7db7947123effd7b51a7c5be378e0", null ],
    [ "scHost", "structsysc_1_1ParticipantInfo.xhtml#a94cf61151b1961e603d2f2e5f9bba836", null ],
    [ "scPort", "structsysc_1_1ParticipantInfo.xhtml#a4e702f37611565ae8dd606d0617a9b1e", null ],
    [ "transcriptFilename", "structsysc_1_1ParticipantInfo.xhtml#afd0f30e3ffc99ebd394966f72869dfbf", null ]
];