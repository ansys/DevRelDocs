var structsysc_1_1NodeData =
[
    [ "NodeData", "structsysc_1_1NodeData.xhtml#a7ed7002dbee2dc944811525ea916815c", null ],
    [ "NodeData", "structsysc_1_1NodeData.xhtml#a31950cfc2da55dd8da96b7f33f90fef0", null ],
    [ "NodeData", "structsysc_1_1NodeData.xhtml#a69294cbb76cbfb7736b77c3b15518407", null ],
    [ "NodeData", "structsysc_1_1NodeData.xhtml#ae5b86f2e6b88d7354620bc6013e7301c", null ],
    [ "NodeData", "structsysc_1_1NodeData.xhtml#acc9254f0f146c5bffc87b4f23aa74507", null ],
    [ "operator=", "structsysc_1_1NodeData.xhtml#a5ab4a36630d10f598a06b7a20dfdef63", null ],
    [ "operator=", "structsysc_1_1NodeData.xhtml#a2da12b3830da1280d59254e4a671aa64", null ],
    [ "nodeCoords", "structsysc_1_1NodeData.xhtml#abdcd98cafd25df6b765a63447f8f31a4", null ],
    [ "nodeIds", "structsysc_1_1NodeData.xhtml#a2b8d2f98597580854d5698d9a600f367", null ]
];