var classsysc_1_1NonFatalError =
[
    [ "NonFatalError", "classsysc_1_1NonFatalError.xhtml#a11fc4107b05f61a8e8bfeb6e70fe3b0f", null ],
    [ "~NonFatalError", "classsysc_1_1NonFatalError.xhtml#a06517a21ef77776d83a580cd53e81585", null ],
    [ "what", "classsysc_1_1NonFatalError.xhtml#a0c8c4306ac5e82f459e1aa4730f36a88", null ]
];