var structsysc_1_1ResultsInfo =
[
    [ "ResultsInfo", "structsysc_1_1ResultsInfo.xhtml#a2e6c0a4ff62fde1317edd3df5752bc78", null ],
    [ "baseFileName", "structsysc_1_1ResultsInfo.xhtml#acc2c96ab4d0c7b8bc630583a814cead4", null ]
];