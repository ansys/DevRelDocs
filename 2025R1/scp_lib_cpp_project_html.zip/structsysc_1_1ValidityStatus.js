var structsysc_1_1ValidityStatus =
[
    [ "ValidityStatus", "structsysc_1_1ValidityStatus.xhtml#a6f7ad1e877aa19ab835c1023164f9c65", null ],
    [ "ValidityStatus", "structsysc_1_1ValidityStatus.xhtml#a11dcd716f4542e1231c0e2ec25ff0d71", null ],
    [ "isValid", "structsysc_1_1ValidityStatus.xhtml#ac45ce7d05d6ab0126511da670f3e10a9", null ],
    [ "message", "structsysc_1_1ValidityStatus.xhtml#ad78928b787427d9c0edf9e7a1e3d857c", null ]
];