var structsysc_1_1SetupInfo =
[
    [ "SetupInfo", "structsysc_1_1SetupInfo.xhtml#ad821c9abdeb9d845889f33dc6cf33a30", null ],
    [ "SetupInfo", "structsysc_1_1SetupInfo.xhtml#a33ac9fc553fff914c295acf695b61efc", null ],
    [ "SetupInfo", "structsysc_1_1SetupInfo.xhtml#ab17e9d12184e6b93080eb71dac25a328", null ],
    [ "SetupInfo", "structsysc_1_1SetupInfo.xhtml#a0808c997023319d5ec2e7eb623a172cd", null ],
    [ "SetupInfo", "structsysc_1_1SetupInfo.xhtml#a2e9ea589149b80ffa4af670fb42defea", null ],
    [ "analysisType", "structsysc_1_1SetupInfo.xhtml#a45906ec4c888b7d0fbd42066f318284b", null ],
    [ "dimension", "structsysc_1_1SetupInfo.xhtml#a9d7c8f147afec2b6269bec443296291d", null ],
    [ "restartsSupported", "structsysc_1_1SetupInfo.xhtml#a46dc0b1c447b1534103f3f05455ee717", null ],
    [ "timeIntegration", "structsysc_1_1SetupInfo.xhtml#a11b9b07a31b9efe30b1ff2472b7a99e2", null ]
];