var classsysc_1_1Region =
[
    [ "Region", "classsysc_1_1Region.xhtml#a9a3643efd6eb393f07a5e0db931dc71d", null ],
    [ "Region", "classsysc_1_1Region.xhtml#a2252ae93ab73cff96e3ba621d9e29171", null ],
    [ "Region", "classsysc_1_1Region.xhtml#ae497ce9374217eaf46630abc28cb8ccf", null ],
    [ "Region", "classsysc_1_1Region.xhtml#a1ef115d09f9dc1c7a1670727b41f9509", null ],
    [ "Region", "classsysc_1_1Region.xhtml#ac7b2a140a74fb4a6b857336316b4dd48", null ],
    [ "addInputVariable", "classsysc_1_1Region.xhtml#a018cbfef9eee8c3d2cd3b20084783390", null ],
    [ "addOutputVariable", "classsysc_1_1Region.xhtml#a96143a5b4d943e47d335d74fa1f827be", null ],
    [ "getDisplayName", "classsysc_1_1Region.xhtml#a11125400c1f87ced8251759d2ff84c1b", null ],
    [ "getInputVariable", "classsysc_1_1Region.xhtml#a724b202ad1c95f18e0c01e9b962c8eed", null ],
    [ "getInputVariable", "classsysc_1_1Region.xhtml#a15d47e3c4989a29033ba306b186e0c50", null ],
    [ "getName", "classsysc_1_1Region.xhtml#a027b247f71dca6060a9d4f8fe029b690", null ],
    [ "getNumInputVariables", "classsysc_1_1Region.xhtml#ac7632c3c0b045c7baf3aef7aaa7a4c86", null ],
    [ "getNumOutputVariables", "classsysc_1_1Region.xhtml#ada5d320ba7226a798ac5683fd878035a", null ],
    [ "getOutputVariable", "classsysc_1_1Region.xhtml#a7ebc9675c1f8e56560409233469e4932", null ],
    [ "getOutputVariable", "classsysc_1_1Region.xhtml#aabcde4869fae1d5f3bed4a4ee7277ef9", null ],
    [ "getRegionDiscretizationType", "classsysc_1_1Region.xhtml#a25fc09a4236bf1cefbac4e5ff4b9736b", null ],
    [ "getTopology", "classsysc_1_1Region.xhtml#a55d078aeaec8518bbe4468e41a053c1c", null ]
];