var structsysc_1_1MeshValidityStatus =
[
    [ "MeshValidityStatus", "structsysc_1_1MeshValidityStatus.xhtml#ad9c263935ed13d2ee2e5e97816c00ef3", null ],
    [ "MeshValidityStatus", "structsysc_1_1MeshValidityStatus.xhtml#ad75cfb4f98778300a21ac1d72efba379", null ],
    [ "isInvalid", "structsysc_1_1MeshValidityStatus.xhtml#a3ee3cb844b3594fb7c3be7fce89a4f62", null ],
    [ "message", "structsysc_1_1MeshValidityStatus.xhtml#ab175079553f6cc1591dbb3d0e74c8ec4", null ]
];