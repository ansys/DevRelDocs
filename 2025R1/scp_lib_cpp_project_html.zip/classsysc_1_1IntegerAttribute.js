var classsysc_1_1IntegerAttribute =
[
    [ "IntegerAttribute", "classsysc_1_1IntegerAttribute.xhtml#afb0787aba682b1564ca5b23d506b264c", null ],
    [ "IntegerAttribute", "classsysc_1_1IntegerAttribute.xhtml#a18a6abf9327ed02ca9c683a7405514d4", null ],
    [ "getName", "classsysc_1_1IntegerAttribute.xhtml#a2e6ac3f7c7a68e88f541b870d9348892", null ],
    [ "getValue", "classsysc_1_1IntegerAttribute.xhtml#a7988b7e0be9211f02cc9c2c27222bddd", null ],
    [ "isModifiable", "classsysc_1_1IntegerAttribute.xhtml#a3160540026ecf02ec23169089c9b1137", null ]
];