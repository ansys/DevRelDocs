var classsysc_1_1DataTransfer =
[
    [ "DataTransfer", "classsysc_1_1DataTransfer.xhtml#a9a4412f47dbd13ece79d35b0876ace13", null ],
    [ "getSideOneVariable", "classsysc_1_1DataTransfer.xhtml#ac9ae876a20ec454c591ae7aac97758c6", null ],
    [ "getSideTwoVariable", "classsysc_1_1DataTransfer.xhtml#a4c9015e16e6fc254ee795254fbbcf8b9", null ],
    [ "getSourceSide", "classsysc_1_1DataTransfer.xhtml#a7788b20c57fe5479500101f705d0aaf8", null ],
    [ "getSourceVariable", "classsysc_1_1DataTransfer.xhtml#aceb91e53a56a9ef07b94c987296ffbcd", null ],
    [ "getTargetSide", "classsysc_1_1DataTransfer.xhtml#a737e25f50bae13a64f047a7b84d5e378", null ],
    [ "getTargetVariable", "classsysc_1_1DataTransfer.xhtml#a7782efd24aafc93df895f2a10ad4fb60", null ]
];