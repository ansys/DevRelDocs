var group__error__handling =
[
    [ "FMOP_getErrnoString", "group__error__handling.xhtml#ga7e820b85d2ef2596b00bc82445dcf650", null ],
    [ "FMOP_getLastErrno", "group__error__handling.xhtml#gac78d83f9f73afd90854e1d07657fc186", null ],
    [ "FMOP_getLastErrnoString", "group__error__handling.xhtml#gaa838a7c375fc1d01d51636ad52a182ad", null ],
    [ "FMOP_getLastErrorString", "group__error__handling.xhtml#ga5e19e7fe152759a80115e908c593245d", null ],
    [ "FMOP_getLastLogString", "group__error__handling.xhtml#gad78d4b2f659d76cce9d16eb7b0e10e2c", null ],
    [ "FMOP_setLogLevel", "group__error__handling.xhtml#gac13c87c4e4d30a83f4d041a908d0a1e7", null ]
];