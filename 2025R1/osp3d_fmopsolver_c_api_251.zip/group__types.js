var group__types =
[
    [ "fmop_dataobject_types", "group__types.xhtml#ga69eb42c1b3b49f22b9e73c6c9869cb75", [
      [ "fmop_node_data", "sos__capi__common_8h.xhtml#ga69eb42c1b3b49f22b9e73c6c9869cb75aaf0fb275c161febc56c4f10e62987049", null ],
      [ "fmop_element_data", "sos__capi__common_8h.xhtml#ga69eb42c1b3b49f22b9e73c6c9869cb75a1ec31fe31f3b8a9fd9dd902b014499ef", null ],
      [ "fmop_scalar_data", "sos__capi__common_8h.xhtml#ga69eb42c1b3b49f22b9e73c6c9869cb75a16a14aa0d55901638e165fb3a39b3870", null ]
    ] ],
    [ "fmop_error_t", "group__types.xhtml#ga4847f3fa2943ffd694eb6cbe169a8bec", [
      [ "fmop_success", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8beca41a0a2e83b0ac20d414f4b015522ce55", null ],
      [ "fmop_invalid_handle", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8becacef5c059b0dd649f97d5404db95c3ccf", null ],
      [ "fmop_exception_occurred", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8becadac3d9086cdab852d265dc924070c198", null ],
      [ "fmop_settings_error", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8beca4040927e4d05d13e93b9f2c7373ca0cd", null ],
      [ "fmop_model_missing", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8becaedda7a6dbd4f5dd3eedecca9ec7dc1e9", null ],
      [ "fmop_license_error", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8becacf8dfe2eaba2eada73a26e487a04f8fe", null ],
      [ "fmop_script_error", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8becab6e0160bb71d6930176d907409618f4d", null ],
      [ "fmop_script_no_object", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8beca749f1c6edf13b1303018d7a3632dc316", null ],
      [ "fmop_script_wrong_type", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8beca32eddc7d860101cdbb8e1571c726ee91", null ],
      [ "fmop_not_implemented", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8beca7fc167a096db0f31209791e0053de2ec", null ],
      [ "fmop_const_max", "group__types.xhtml#gga4847f3fa2943ffd694eb6cbe169a8beca41b2d8995eb66857227a50e49e8f6016", null ]
    ] ],
    [ "fmop_license_t", "group__types.xhtml#gafe21e382a604ef55cba4d683d706422e", [
      [ "fmop_mesh_signal", "sos__capi__common_8h.xhtml#gafe21e382a604ef55cba4d683d706422ea5b9372ca962a29cf37faac2948897143", null ],
      [ "fmop_mesh_all", "sos__capi__common_8h.xhtml#gafe21e382a604ef55cba4d683d706422ea71a41e6fb1935010b6ed34037f7dae8c", null ]
    ] ]
];