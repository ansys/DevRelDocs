var group__license__handling =
[
    [ "FMOP_acquireLicense", "group__license__handling.xhtml#ga1cdd0d44e0ea8172b1f7f1095395da89", null ],
    [ "FMOP_appendLicenseSearchPath", "group__license__handling.xhtml#ga7086f4db3e639526b2b7fe9ce9392a24", null ],
    [ "FMOP_licenseLocked", "group__license__handling.xhtml#ga462a99c932a9b5704aae42a15826e4c3", null ],
    [ "FMOP_releaseLicense", "group__license__handling.xhtml#ga62d038d686a8183e10f52131697bce6c", null ]
];