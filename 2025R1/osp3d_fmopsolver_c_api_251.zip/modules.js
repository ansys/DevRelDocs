var modules =
[
    [ "Data handling", "group__data__handling.xhtml", "group__data__handling" ],
    [ "Query properties", "group__queries.xhtml", "group__queries" ],
    [ "Operations", "group__operations.xhtml", "group__operations" ],
    [ "Types", "group__types.xhtml", "group__types" ],
    [ "License Handling", "group__license__handling.xhtml", "group__license__handling" ],
    [ "Error Handling", "group__error__handling.xhtml", "group__error__handling" ],
    [ "Miscellaneous", "group__misc.xhtml", "group__misc" ],
    [ "Library handling", "group__libhandling.xhtml", "group__libhandling" ]
];