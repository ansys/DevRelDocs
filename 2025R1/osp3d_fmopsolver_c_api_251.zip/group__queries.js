var group__queries =
[
    [ "FMOP_getDataDim", "group__queries.xhtml#ga878106f886ca5f1ce112e6c5e238d80e", null ],
    [ "FMOP_getDataPointCoors", "group__queries.xhtml#ga535bee00c4d200d31fdf4118e49c1f05", null ],
    [ "FMOP_getDataPointIndices", "group__queries.xhtml#gadd2527ad2ad1bf1df141e5fa5b4c2e31", null ],
    [ "FMOP_getElementsAtNode", "group__queries.xhtml#ga8ca72d6a865df21ce5a5180475c71cda", null ],
    [ "FMOP_getElementTypeIdent", "group__queries.xhtml#gade1eac903ae657e448adf1f7c6aa463c", null ],
    [ "FMOP_getModelAvgFCoP", "group__queries.xhtml#ga185c515c2fe8b0528ccb5f95f543a3be", null ],
    [ "FMOP_getModelDim", "group__queries.xhtml#ga24e43563d67cc64bffb7bccddbaada65", null ],
    [ "FMOP_getModelIdent", "group__queries.xhtml#gade959f2a7f6866382b76e32204597220", null ],
    [ "FMOP_getModelIdents", "group__queries.xhtml#ga22d6e807dc869fa28442d26e29ddbc27", null ],
    [ "FMOP_getModelIdentsDim", "group__queries.xhtml#ga600dca69efae1f2eafc63f9f6a0067fc", null ],
    [ "FMOP_getModelParamIdent", "group__queries.xhtml#ga08f0951d2b7615c16e72341e13bad704", null ],
    [ "FMOP_getModelParamIdents", "group__queries.xhtml#ga485827623b3d01cf3157c0a16559908f", null ],
    [ "FMOP_getModelParamIdentsDim", "group__queries.xhtml#gadabef430a391d15eb077fe30e134f368", null ],
    [ "FMOP_getModelTotalAvgFCoP", "group__queries.xhtml#ga1ff6f33cf199015b78c5837e40d90f42", null ],
    [ "FMOP_getNodesAtElement", "group__queries.xhtml#ga03080c2458b8c03eb85ce9eb97926711", null ],
    [ "FMOP_getNumElementsAtNode", "group__queries.xhtml#ga4413f3e2bc5f893b9030631aceb03c54", null ],
    [ "FMOP_getNumNodesAtElement", "group__queries.xhtml#ga031be0f125c4fbeb450f03bb960e207d", null ],
    [ "FMOP_getParamLowerBounds", "group__queries.xhtml#gabaed2ac2af6a304f8356e51b9cb98442", null ],
    [ "FMOP_getParamUpperBounds", "group__queries.xhtml#ga301cfcf26e28ec7ba4b2c730facb679c", null ],
    [ "FMOP_isNodePartOfBoundary", "group__queries.xhtml#ga1ff1451cc5f1c6cefa7a67c6a906d653", null ]
];