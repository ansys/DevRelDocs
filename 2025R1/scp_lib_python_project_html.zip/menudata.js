/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Introduction",url:"index.xhtml"},
{text:"User guide",url:"md_01b_Contents.xhtml",children:[
{text:"System Coupling Participant library capabilities",url:"md_02_ParticipantLibraryCapabilities.xhtml"},
{text:"Concepts overview",url:"md_03_ConceptsAndTerminology.xhtml"},
{text:"Standalone mapping",url:"md_04_ParticipantStepsForMapping.xhtml"},
{text:"Steps to set up and execute the coupled analysis",url:"md_05_StepsToSetupAndExecutedCoupledAnalysis.xhtml"},
{text:"Completing the System Coupling participant setup",url:"md_06_ParticipantSetup.xhtml"},
{text:"Participant steps in a coupled analysis",url:"md_07_ParticipantStepsInCoupledAnalysis.xhtml"},
{text:"Command line arguments for participant solvers",url:"md_08_CommandLineArguments.xhtml"},
{text:"Execution in a parallel environment",url:"md_09_ParallelExecution.xhtml"},
{text:"Access to parameter data",url:"md_10_ParameterDataAccess.xhtml"},
{text:"Access to heavyweight data",url:"md_11_HeavyweightDataAccess.xhtml"},
{text:"Mesh and point cloud data access",url:"md_12_MeshDataAccess.xhtml"},
{text:"Creating restart points and restarting a coupled analysis",url:"md_13_Restarts.xhtml"},
{text:"Multi-region coupling interfaces",url:"md_14_Multiregion.xhtml"},
{text:"Testing and debugging tools",url:"md_15_TestingDebuggingTools.xhtml"},
{text:"Migration guide and known issues",url:"md_16_MigrationGuide.xhtml"},
{text:"Compiling, linking, and executing applications that use the participant library",url:"md_17_CompilingLinkingExecuting.xhtml"},
{text:"Heat transfer in square channel air flow tutorial",url:"md_18_ChannelFlowTutorial.xhtml"},
{text:"Oscillating plate damping tutorial",url:"md_19_PlateDampingTutorial.xhtml"},
{text:"Pipe mapping tutorial",url:"md_20_PipeMappingTutorial.xhtml"}]},
{text:"Python interfaces notes",url:"md_PythonAPIsNotes.xhtml"},
{text:"Changelog",url:"md_21_ReleaseNotes.xhtml"}]}
