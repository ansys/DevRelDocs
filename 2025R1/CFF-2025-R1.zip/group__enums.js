var group__enums =
[
    [ "CffCellType", "group__enums.xhtml#gac0b3f753b9307362895e46aaa1a9f366", [
      [ "CFF_CELL_TYPE_MIN", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a58c00a54277d6ba91303af48841a4754", null ],
      [ "CFF_CELL_TYPE_MIXED", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a1eed460af26c972bc96e5f71e7d124ba", null ],
      [ "CFF_CELL_TYPE_TRI", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a8a3384829eda9260c7124d1a38c0d4d4", null ],
      [ "CFF_CELL_TYPE_TET", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a74e6e7dc814f4bba1306fb57abb298bc", null ],
      [ "CFF_CELL_TYPE_QUAD", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a2cfe72fc4a8e4bcb76ce66d83c29731d", null ],
      [ "CFF_CELL_TYPE_HEX", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a4712808047ad4d1ac0406bac82cac19b", null ],
      [ "CFF_CELL_TYPE_PYRAMID", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366aaf146e35ade74a8677fa3f518000ea86", null ],
      [ "CFF_CELL_TYPE_WEDGE", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a92936a31fa1ba3c57085ac1038a4a879", null ],
      [ "CFF_CELL_TYPE_POLY", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a8fdc2669a6573bea93685b5c254501a3", null ],
      [ "CFF_CELL_TYPE_GHOST", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366ad370376762f10b110048f9b9a68ebe81", null ],
      [ "CELL_TYPE_TET10", "group__enums.xhtml#ggac0b3f753b9307362895e46aaa1a9f366a82d24e1e1d8038831c87210cad47a650", null ]
    ] ],
    [ "CffCellZoneInfoType", "group__enums.xhtml#gaaffda1f82c7b51d603aff684c9ab0cd2", [
      [ "CFF_CELLZONEINFO_MIN", "group__enums.xhtml#ggaaffda1f82c7b51d603aff684c9ab0cd2a3442cca5bc9ae91510f090e1a6cb66f3", null ],
      [ "CFF_CELL_ZONE_CELL_TYPE", "group__enums.xhtml#ggaaffda1f82c7b51d603aff684c9ab0cd2ae307b5717f564f83314c104ac0132440", null ],
      [ "CFF_CELL_ZONE_CHILD_ZONE_ID", "group__enums.xhtml#ggaaffda1f82c7b51d603aff684c9ab0cd2adbc6fee74f7a3ad84f5ed5d3fbeaa55f", null ]
    ] ],
    [ "CffDataCacheMode", "group__enums.xhtml#gab5cfcacaebd813ca2dee1b2eb583ba80", [
      [ "CFF_HEAVY_DATA_CACHE_MIN", "group__enums.xhtml#ggab5cfcacaebd813ca2dee1b2eb583ba80ae548ba5e88585a79e75297c8adc4d709", null ],
      [ "CFF_NO_HEAVY_DATA_CACHE", "group__enums.xhtml#ggab5cfcacaebd813ca2dee1b2eb583ba80ae218f033f922e2da2c19411c8c8accf2", null ],
      [ "CFF_ALLOW_HEAVY_DATA_CACHE", "group__enums.xhtml#ggab5cfcacaebd813ca2dee1b2eb583ba80a11962cbc5ae4f26c3e44a841f9c55dc8", null ]
    ] ],
    [ "CffDataClass", "group__enums.xhtml#gab852cc24891eb831942fb8da764d8ddb", [
      [ "CFF_DATACLASS_MIN", "group__enums.xhtml#ggab852cc24891eb831942fb8da764d8ddba6279bd0863068e855bf5ea459c2e6d78", null ],
      [ "CFF_CASE", "group__enums.xhtml#ggab852cc24891eb831942fb8da764d8ddba6c8b8209348df38321689fb67cd4b331", null ],
      [ "CFF_RESULTS", "group__enums.xhtml#ggab852cc24891eb831942fb8da764d8ddbaacfdbe512195015b6446480e80caf4a4", null ],
      [ "CFF_DATA_CLASS_MAX", "group__enums.xhtml#ggab852cc24891eb831942fb8da764d8ddba81bf10f3c01b686a4f75768490fb7547", null ]
    ] ],
    [ "CffDataPrecisionType", "group__enums.xhtml#ga2ecbf04cb65f31fde87a9c60a5bab3d6", [
      [ "CFF_DATAPRECISION_MIN", "group__enums.xhtml#gga2ecbf04cb65f31fde87a9c60a5bab3d6a122d30197e1a0640f912f070fd5ff4bf", null ],
      [ "CFF_PRECISION_DOUBLE", "group__enums.xhtml#gga2ecbf04cb65f31fde87a9c60a5bab3d6a583d6d67a6ee03f067b1dc6b717de7e6", null ],
      [ "CFF_PRECISION_SINGLE", "group__enums.xhtml#gga2ecbf04cb65f31fde87a9c60a5bab3d6aabd7ed6b83c48e33091ba9170e63f179", null ]
    ] ],
    [ "CffEdgeType", "group__enums.xhtml#ga1782918710d976acec410e7fcc95875f", [
      [ "CFF_EDGE_TYPE_MIN", "group__enums.xhtml#gga1782918710d976acec410e7fcc95875fa4ed0dd9f3459f164c01bf9fed5c95c49", null ],
      [ "CFF_EDGE_TYPE_LINEAR", "group__enums.xhtml#gga1782918710d976acec410e7fcc95875fa94ea4db6da09419de8edd991c25528e3", null ],
      [ "CFF_EDGE_TYPE_LINEAR3", "group__enums.xhtml#gga1782918710d976acec410e7fcc95875fa60d668d862348844a0dc85b7ae8fd463", null ],
      [ "CFF_EDGE_TYPE_N_NODES", "group__enums.xhtml#gga1782918710d976acec410e7fcc95875fab80a41f32384c79281aae076bb85b920", null ]
    ] ],
    [ "CffEdgeZoneInfoType", "group__enums.xhtml#gab5510fa8ae80e1c0e3f4d17207ac2cf8", [
      [ "CFF_EDGEZONEINFO_MIN", "group__enums.xhtml#ggab5510fa8ae80e1c0e3f4d17207ac2cf8a891374baff42ac987c1fa75a52cadbd8", null ],
      [ "CFF_EDGE_ZONE_TYPE", "group__enums.xhtml#ggab5510fa8ae80e1c0e3f4d17207ac2cf8aee47089b31281a95f6b1c875fe77ddda", null ],
      [ "CFF_EDGE_ZONE_EDGE_TYPE", "group__enums.xhtml#ggab5510fa8ae80e1c0e3f4d17207ac2cf8aca207f4cd4e05d5dea844659c77b4761", null ]
    ] ],
    [ "CffEdgeZoneType", "group__enums.xhtml#gac0bfa43991cd91c6cc7045a2596e36bf", [
      [ "CFF_EDGE_ZONE_TYPE_MIN", "group__enums.xhtml#ggac0bfa43991cd91c6cc7045a2596e36bfae6c1956c9b2592c108995dd1b399340d", null ],
      [ "CFF_EDGE_ZONE_INTERIOR", "group__enums.xhtml#ggac0bfa43991cd91c6cc7045a2596e36bfa366ea95bd8a5b534b2a49091fdc998b0", null ],
      [ "CFF_EDGE_ZONE_BOUNDARY", "group__enums.xhtml#ggac0bfa43991cd91c6cc7045a2596e36bfa432872f1b891eb49619f6199bba5d9f8", null ]
    ] ],
    [ "CffFaceType", "group__enums.xhtml#ga32812d6a5501e53b26fd7200472de3fe", [
      [ "CFF_FACE_TYPE_MIN", "group__enums.xhtml#gga32812d6a5501e53b26fd7200472de3fea02409ef4059c9e05a32e2f918032bdef", null ],
      [ "CFF_FACE_TYPE_MIXED", "group__enums.xhtml#gga32812d6a5501e53b26fd7200472de3feadbab786fef5c99ec6d8a7a055c712087", null ],
      [ "CFF_FACE_TYPE_LINEAR", "group__enums.xhtml#gga32812d6a5501e53b26fd7200472de3feaca74db7501db7a17b3f0e8febdb3c38b", null ],
      [ "CFF_FACE_TYPE_TRI", "group__enums.xhtml#gga32812d6a5501e53b26fd7200472de3fea855b38402da1d6d273345d8fa568738d", null ],
      [ "CFF_FACE_TYPE_QUAD", "group__enums.xhtml#gga32812d6a5501e53b26fd7200472de3fea21316961f46dd008950f167f033851af", null ],
      [ "CFF_FACE_TYPE_POLY", "group__enums.xhtml#gga32812d6a5501e53b26fd7200472de3feab80c355ee37c410b32eecc3567fb59c5", null ],
      [ "CFF_FACE_TYPE_TRI6", "group__enums.xhtml#gga32812d6a5501e53b26fd7200472de3fea4bef0306455596f9497e93f04be95d02", null ]
    ] ],
    [ "CffFaceZoneInfoType", "group__enums.xhtml#ga90bd9c961be9a1b7e7d014e9f04588e3", [
      [ "CFF_FACEZONEINFO_MIN", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3a1564c1e4d84d12c9f3560d035fbe08e3", null ],
      [ "CFF_FACE_ZONE_FACE_TYPE", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3a96a4944c9088c0307aefafab1bcfc200", null ],
      [ "CFF_FACE_ZONE_CHILD_ZONE_ID", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3a10eff2aafb191d93e55e74caa015b262", null ],
      [ "CFF_FACE_ZONE_PARENT0_ZONE_ID", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3a50749aaf9480c8d2606caf651f8d390f", null ],
      [ "CFF_FACE_ZONE_PARENT1_ZONE_ID", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3acb49cefef4c1b13c41bdb1fd9210f10b", null ],
      [ "CFF_FACE_ZONE_SHADOW_ZONE_ID", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3ac79d815228e144ab9b7b7d482e68730e", null ],
      [ "CFF_FACE_ZONE_TYPE", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3a2fa7a530982c6473ca2193d43d5c55af", null ],
      [ "CFF_FACE_ZONE_C0_ZONE_ID", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3ad4f11226df9260fc09e0fd97a0dd5da0", null ],
      [ "CFF_FACE_ZONE_C1_ZONE_ID", "group__enums.xhtml#gga90bd9c961be9a1b7e7d014e9f04588e3a7da8ae8776e391b9000808cbebc0bd02", null ]
    ] ],
    [ "CffFaceZonePropType", "group__enums.xhtml#gadf13e7806827f3d0db8ecb550aa50384", [
      [ "CFF_FACEZONEPROP_MIN", "group__enums.xhtml#ggadf13e7806827f3d0db8ecb550aa50384a18830ea5a0d037c36d8f2041452f1b33", null ],
      [ "CFF_FACE_ZONE_PROP_MAJOR", "group__enums.xhtml#ggadf13e7806827f3d0db8ecb550aa50384a5d40e5789dfa861592f1d0352e3df1b4", null ],
      [ "CFF_FACE_ZONE_PROP_MINOR", "group__enums.xhtml#ggadf13e7806827f3d0db8ecb550aa50384ada9e778030da5e6932a5c71a259a7a2d", null ],
      [ "CFF_FACE_ZONE_PROP_WALL", "group__enums.xhtml#ggadf13e7806827f3d0db8ecb550aa50384a0d3f7afef710639de83d77afaf4da151", null ],
      [ "CFF_FACE_ZONE_PROP_NCI_OVERLAP", "group__enums.xhtml#ggadf13e7806827f3d0db8ecb550aa50384a06ecd0d6e7ab268df2e931c988c5321c", null ],
      [ "CFF_FACE_ZONE_PROP_PERIODIC", "group__enums.xhtml#ggadf13e7806827f3d0db8ecb550aa50384a1f0e7fdf4e8a49401c6e868c15088b82", null ],
      [ "CFF_FACE_ZONE_PROP_INTERNAL", "group__enums.xhtml#ggadf13e7806827f3d0db8ecb550aa50384af09607e4249ae63de3de74f8fde11926", null ],
      [ "CFF_FACE_ZONE_PROP_NCI_NONOVERLAP", "group__enums.xhtml#ggadf13e7806827f3d0db8ecb550aa50384a1ebf9842e455b601fb490f2dbd8bd6eb", null ]
    ] ],
    [ "CffFaceZoneType", "group__enums.xhtml#ga13c2dd97c5e14c90a074a2c603ec2bc3", [
      [ "CFF_FACE_ZONE_TYPE_MIN", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3ada4701042d033b2c1e6d8d41f8f7a26d", null ],
      [ "CFF_FACE_ZONE_TYPE_SOLID", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a6b7f4dd0b74b19e94a42c9ff01f549fc", null ],
      [ "CFF_FACE_ZONE_TYPE_FLUID", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a72b697c27374e1fd10b7d70c6ce95194", null ],
      [ "CFF_FACE_ZONE_TYPE_INTERIOR", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a918616c49ea24c67e38e0403aedd99f5", null ],
      [ "CFF_FACE_ZONE_TYPE_RANS_LES_INTERFACE", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3ae7fcb4eb96e92036b906db14638bf21c", null ],
      [ "CFF_FACE_ZONE_TYPE_WALL", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3affa7b842290a6b5303c8449944b64fa3", null ],
      [ "CFF_FACE_ZONE_TYPE_INTAKE_FAN", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a867be1b838c2045660175dfb0f982fe9", null ],
      [ "CFF_FACE_ZONE_TYPE_INLET_VENT", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a6217b133b073b104e7839abf74c8a6e9", null ],
      [ "CFF_FACE_ZONE_TYPE_PRESSURE_INLET", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3abaa837a8d892169343dec72b32697acb", null ],
      [ "CFF_FACE_ZONE_TYPE_EXHAUST_FAN", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a324b1f4f47dabfbc43f1c2541bc6be9d", null ],
      [ "CFF_FACE_ZONE_TYPE_OUTLET_VENT", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a305353671b7e9a3dd5f3bbb6d9344a22", null ],
      [ "CFF_FACE_ZONE_TYPE_PRESSURE_OUTLET", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a3152f0eb556dddd9ea37add66855fcaa", null ],
      [ "CFF_FACE_ZONE_TYPE_SYMMETRY", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3ae1a5720b96eaebf92a74194433841e12", null ],
      [ "CFF_FACE_ZONE_TYPE_DEGASSING", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a46c8b67ee4e672fdef885b80c7ce2009", null ],
      [ "CFF_FACE_ZONE_TYPE_SHADOW", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a5bb01580c8b39051eb4cb0ab3ae0a85c", null ],
      [ "CFF_FACE_ZONE_TYPE_PRESSURE_FAR_FIELD", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a3c9c7c7409df4a9b8cb918e384430ea4", null ],
      [ "CFF_FACE_ZONE_TYPE_VELOCITY_INLET", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a2d057b945ea036e39145bea860bdfd9c", null ],
      [ "CFF_FACE_ZONE_TYPE_PERIODIC", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a6863d5c037c8f634eb2b7075856700bc", null ],
      [ "CFF_FACE_ZONE_TYPE_FAN", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a49e9207f297447e5ef5e0fecfdce553d", null ],
      [ "CFF_FACE_ZONE_TYPE_RADIATOR", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3aabe26a18c56cf2afb5278f2851600e2a", null ],
      [ "CFF_FACE_ZONE_TYPE_POROUS_JUMP", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a264abcc6ee41ee8734d2e595ef1e7525", null ],
      [ "CFF_FACE_ZONE_TYPE_MASS_FLOW_INLET", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3af186449fdbea919a1595bda8be351770", null ],
      [ "CFF_FACE_ZONE_TYPE_RECIRCULATION_OUTLET", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a9e25643020bf8294ab368a87d39c3f90", null ],
      [ "CFF_FACE_ZONE_TYPE_RECIRCULATION_INLET", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a747304c866553386a2032b2733aa5260", null ],
      [ "CFF_FACE_ZONE_TYPE_INTERFACE", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a93c599199668d1551365a6ad1809b3a1", null ],
      [ "CFF_FACE_ZONE_TYPE_OVERSET", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a3221b45f6449d14bbcf60bdba74c708b", null ],
      [ "CFF_FACE_ZONE_TYPE_OUTFLOW", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a26b22ea2f5bd39fb1fa8d8341f3dc5ac", null ],
      [ "CFF_FACE_ZONE_TYPE_AXIS", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3af23ff8bc3f81b2a53912c1b2daceea8f", null ],
      [ "CFF_FACE_ZONE_TYPE_NETWORK", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3ab152c47db1c100b0e538c551bf8bcfec", null ],
      [ "CFF_FACE_ZONE_TYPE_NETWORK_END", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a492dd6b4947221452696de7f52d94454", null ],
      [ "CFF_FACE_ZONE_TYPE_USER_DEFINED", "group__enums.xhtml#gga13c2dd97c5e14c90a074a2c603ec2bc3a69ce6271f144608cd9eaf533f5711e8a", null ]
    ] ],
    [ "CffFileFormatType", "group__enums.xhtml#ga9d98ab88553e163862440763fc91c76a", [
      [ "CFF_Unknown", "group__enums.xhtml#gga9d98ab88553e163862440763fc91c76aa634b960e7a9455ca0ed7ee28a2bd0a77", null ],
      [ "CFF_HDF", "group__enums.xhtml#gga9d98ab88553e163862440763fc91c76aa07723f3ffb199eb4f791d1f74b5ac567", null ],
      [ "CFF_CSV", "group__enums.xhtml#gga9d98ab88553e163862440763fc91c76aa44fe83e6a030b89d95ef3010631951a1", null ],
      [ "CFF_CFX", "group__enums.xhtml#gga9d98ab88553e163862440763fc91c76aaf61631efc8752842e4b085555b28f422", null ]
    ] ],
    [ "CffIOMode", "group__enums.xhtml#ga5820566c2439fe2d74130fb1d323dd6c", [
      [ "CFF_SERIAL_IO", "group__enums.xhtml#gga5820566c2439fe2d74130fb1d323dd6cab21911dbe25047d6340a18ada9147b2d", null ],
      [ "CFF_PARALLEL_IO", "group__enums.xhtml#gga5820566c2439fe2d74130fb1d323dd6cae52eb8c6e5f7177f9cb82ff1b81c3d7c", null ]
    ] ],
    [ "CffMeshSizeType", "group__enums.xhtml#gaf5d669ab21b6699ea497958b17c32002", [
      [ "CFF_MESHSIZE_MIN", "group__enums.xhtml#ggaf5d669ab21b6699ea497958b17c32002a47cc9655ff7b5f8759cb74c65ce61335", null ],
      [ "CFF_MESH_DIMENSION", "group__enums.xhtml#ggaf5d669ab21b6699ea497958b17c32002a79c9861f0c03a03f476e399d0a17917d", null ],
      [ "CFF_MESH_NODE_COUNT", "group__enums.xhtml#ggaf5d669ab21b6699ea497958b17c32002a3697b449f26bbbea1b7248da1f8634db", null ],
      [ "CFF_MESH_EDGE_COUNT", "group__enums.xhtml#ggaf5d669ab21b6699ea497958b17c32002a29f6ee3353045f01c56c538704cdc863", null ],
      [ "CFF_MESH_FACE_COUNT", "group__enums.xhtml#ggaf5d669ab21b6699ea497958b17c32002aeda7214eb896ae699e426d0bbc5b30ab", null ],
      [ "CFF_MESH_CELL_COUNT", "group__enums.xhtml#ggaf5d669ab21b6699ea497958b17c32002ab58756bc6e4e7c3e46f2c53ce722b1ef", null ]
    ] ],
    [ "CffNodeZoneInfoType", "group__enums.xhtml#gacc3f469fa6326c4b75b40d9e4f8313db", [
      [ "CFF_NODEZONEINFO_MIN", "group__enums.xhtml#ggacc3f469fa6326c4b75b40d9e4f8313dba67e2197d109626789cc2931d5f5d12b6", null ],
      [ "CFF_NODE_ZONE_TYPE", "group__enums.xhtml#ggacc3f469fa6326c4b75b40d9e4f8313dba384f737f3ba3fa6542ebff65d18ab5d3", null ]
    ] ],
    [ "CffNodeZoneType", "group__enums.xhtml#gacdbb57644acedc23cecd46a635289471", [
      [ "CFF_NODE_ZONE_TYPE_MIN", "group__enums.xhtml#ggacdbb57644acedc23cecd46a635289471a7dd659c66f0d543d87979338ac680fd9", null ],
      [ "CFF_NODE_ZONE_INTERIOR", "group__enums.xhtml#ggacdbb57644acedc23cecd46a635289471a64230917b389277cfb3b081669ff148d", null ],
      [ "CFF_NODE_ZONE_BOUNDARY", "group__enums.xhtml#ggacdbb57644acedc23cecd46a635289471a07fe3602b59c26e45184f6b0504ab38d", null ]
    ] ],
    [ "CffPlainDataType", "group__enums.xhtml#gaa26eac1911cb4a05854b39ca3d909615", [
      [ "CFF_DATATYPE_MIN", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615aca8442cee9ff64dddc06ce7bb502faaf", null ],
      [ "CFF_DATATYPE_CHAR", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615af867dd62853d5517dcc524d9e454a94f", null ],
      [ "CFF_DATATYPE_UCHAR", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615a3dda1a79dc8b791600f5da58e0f15c13", null ],
      [ "CFF_DATATYPE_SHORT", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615a5eff6001aa6d603e0b0ecfa9922cf95f", null ],
      [ "CFF_DATATYPE_INT", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615ad624b2d08e943c5598b93a25bd730e45", null ],
      [ "CFF_DATATYPE_UINT", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615abff47995b06b896aa7385e5170f0cd67", null ],
      [ "CFF_DATATYPE_LONG", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615ad843c863f154935c3ee7b749d3a24bb1", null ],
      [ "CFF_DATATYPE_FLOAT", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615ad68d74ac0c1834f15f56653733d7256a", null ],
      [ "CFF_DATATYPE_DOUBLE", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615af2d607c8aa0ec559e71676327992909d", null ],
      [ "CFF_DATATYPE_SIZE_T", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615af67af8d6b99802e38a1302e96c9bc2ed", null ],
      [ "CFF_DATATYPE_LLONG", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615a8984a9f1f42492ec14c03162340562ce", null ],
      [ "CFF_DATATYPE_STR", "group__enums.xhtml#ggaa26eac1911cb4a05854b39ca3d909615a76aed71f05d094362fe2e977921e738e", null ]
    ] ],
    [ "CffReadable", "group__enums.xhtml#ga0fb9773918c961ce8187a074481c3069", [
      [ "CFF_READABLE_UNKNOWN", "group__enums.xhtml#gga0fb9773918c961ce8187a074481c3069a023c104927c3e274b49d18ada50d3678", null ],
      [ "CFF_READABLE_OK", "group__enums.xhtml#gga0fb9773918c961ce8187a074481c3069a432a5ec2c43598b6ed50afea7cdfc263", null ],
      [ "CFF_READABLE_WARN", "group__enums.xhtml#gga0fb9773918c961ce8187a074481c3069a37e39ece2680ba58b80a441190a577a5", null ],
      [ "CFF_READABLE_ERROR", "group__enums.xhtml#gga0fb9773918c961ce8187a074481c3069ac589e3635fcb87366ab9c49f2121879f", null ]
    ] ],
    [ "CffTargetCategory", "group__enums.xhtml#ga2bf8717ca5a1d17190dddf5faf6efa5d", [
      [ "CFF_TARGET_CATEGORY_UNKNOWN", "group__enums.xhtml#gga2bf8717ca5a1d17190dddf5faf6efa5da372c46c2ed9c012ea7fe06fbaf2ec59f", null ],
      [ "CFF_RESTART", "group__enums.xhtml#gga2bf8717ca5a1d17190dddf5faf6efa5da5324f9d08717edd9de8d717f9e3d1aa9", null ],
      [ "CFF_POST", "group__enums.xhtml#gga2bf8717ca5a1d17190dddf5faf6efa5da38a97e162e222eea5d33e95b5abed325", null ],
      [ "CFF_PARTITIONED_POST", "group__enums.xhtml#gga2bf8717ca5a1d17190dddf5faf6efa5da2ef818bf7baa7f1964722c18fe44e145", null ]
    ] ],
    [ "CffZoneCategory", "group__enums.xhtml#ga1e26b7f9299129cd1edc8fdf99f2917b", [
      [ "CFF_ZONECATEGORY_MIN", "group__enums.xhtml#gga1e26b7f9299129cd1edc8fdf99f2917ba65f826acf9d0c6f6d24fea26b9f2f7d1", null ],
      [ "CFF_NODE_ZONE", "group__enums.xhtml#gga1e26b7f9299129cd1edc8fdf99f2917ba8ea3a3242fd587dc97ca2cf83dbf61d7", null ],
      [ "CFF_EDGE_ZONE", "group__enums.xhtml#gga1e26b7f9299129cd1edc8fdf99f2917baf550346da426ab4fa297c5343dc2b81a", null ],
      [ "CFF_FACE_ZONE", "group__enums.xhtml#gga1e26b7f9299129cd1edc8fdf99f2917baa6aea3358b01fc54950d21d8af9c01a0", null ],
      [ "CFF_CELL_ZONE", "group__enums.xhtml#gga1e26b7f9299129cd1edc8fdf99f2917ba62b22dd5125249182737df29d52bafbd", null ],
      [ "CFF_PTCK_ZONE", "group__enums.xhtml#gga1e26b7f9299129cd1edc8fdf99f2917bae0ec9f334481ae1853c5eb53969efa13", null ],
      [ "CFF_OTHR_ZONE", "group__enums.xhtml#gga1e26b7f9299129cd1edc8fdf99f2917bab7412e048ad4a8d85d06e801abb28f30", null ]
    ] ],
    [ "CffZoneSizeType", "group__enums.xhtml#ga54ba682a6deedd60cb203d1963a0ac12", [
      [ "CFF_ZONESIZE_MIN", "group__enums.xhtml#gga54ba682a6deedd60cb203d1963a0ac12a0c8bd2f0a9ce8af027309c5371cf3ecd", null ],
      [ "CFF_ZONE_START_ID", "group__enums.xhtml#gga54ba682a6deedd60cb203d1963a0ac12a79d59ca619126744f5dcce0401f2bf00", null ],
      [ "CFF_ZONE_END_ID", "group__enums.xhtml#gga54ba682a6deedd60cb203d1963a0ac12ae1c4a42d14520b1baeaaff14a389556a", null ],
      [ "CFF_ZONE_SIZE", "group__enums.xhtml#gga54ba682a6deedd60cb203d1963a0ac12aa0c5d918dc02f2fc3c7bff5820013b36", null ],
      [ "CFF_ZONE_DIMENSION", "group__enums.xhtml#gga54ba682a6deedd60cb203d1963a0ac12ac797bdd0c993d968d38f0c35b496d207", null ]
    ] ],
    [ "CffZoneStringInfoType", "group__enums.xhtml#ga7fe67117cb23bbcbb4ff2d5b55c3a704", [
      [ "CFF_ZONESTRINGINFO_MIN", "group__enums.xhtml#gga7fe67117cb23bbcbb4ff2d5b55c3a704a0f7bfe5e33af80e75bad2300e1c580af", null ],
      [ "CFF_ZONE_STRING_NAME", "group__enums.xhtml#gga7fe67117cb23bbcbb4ff2d5b55c3a704a3df2bc03cc26299fd9a017226d0fa127", null ],
      [ "CFF_ZONE_STRING_TYPE", "group__enums.xhtml#gga7fe67117cb23bbcbb4ff2d5b55c3a704a7dd4555e422dcca8321082de07732b2e", null ]
    ] ]
];