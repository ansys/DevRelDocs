var classansys_1_1_project_1_1_simulation =
[
    [ "Simulation", "classansys_1_1_project_1_1_simulation.xhtml#a1353fad4a75cc2abe9ca84c4d307c3c4", null ],
    [ "~Simulation", "classansys_1_1_project_1_1_simulation.xhtml#a39c89becbccfc91f156103066588507b", null ],
    [ "getCurrentRun", "classansys_1_1_project_1_1_simulation.xhtml#aa53437d21b9d65376405d5302733b271", null ],
    [ "getData", "classansys_1_1_project_1_1_simulation.xhtml#a08e4de6f33b578b6edbb8127fb398c25", null ],
    [ "getLink", "classansys_1_1_project_1_1_simulation.xhtml#af283d54a6e0ec70ed64ce6bacc4cd192", null ],
    [ "getListOfSubclass", "classansys_1_1_project_1_1_simulation.xhtml#aa623d14ca07c68e510f518a6c51e8951", null ],
    [ "getResult", "classansys_1_1_project_1_1_simulation.xhtml#a34c022fa77e348bd7287a76c0d7871b8", null ],
    [ "getRun", "classansys_1_1_project_1_1_simulation.xhtml#abf2669d8f42be00cdf588e7443caf598", null ],
    [ "getRunGroup", "classansys_1_1_project_1_1_simulation.xhtml#abe2f341b876cdaeaa82737df9eaf428a", null ],
    [ "getRunGroups", "classansys_1_1_project_1_1_simulation.xhtml#a284554c45e7a609f560f4980ad969e72", null ],
    [ "getRuns", "classansys_1_1_project_1_1_simulation.xhtml#a38cc991a7916643a66a0268fb2f755ad", null ],
    [ "hasLink", "classansys_1_1_project_1_1_simulation.xhtml#a2983aaea7346fd047121f263f4c81670", null ],
    [ "isSimulation", "classansys_1_1_project_1_1_simulation.xhtml#a9a500df90203b2a296d5185232dbbc17", null ],
    [ "isValid", "classansys_1_1_project_1_1_simulation.xhtml#ab8c7167e09e88042db12724531150af7", null ],
    [ "newLink", "classansys_1_1_project_1_1_simulation.xhtml#a41ced84b196ab472305df137411131d9", null ],
    [ "newRun", "classansys_1_1_project_1_1_simulation.xhtml#a4eb433d9185e539d85307aa6b869c291", null ],
    [ "newRunGroup", "classansys_1_1_project_1_1_simulation.xhtml#a3c4e9b6a70403ddafdb2dbd93c027aab", null ],
    [ "newRunInFolder", "classansys_1_1_project_1_1_simulation.xhtml#af9cd129be20c02c3be763952a6a8bba3", null ],
    [ "removeRun", "classansys_1_1_project_1_1_simulation.xhtml#a1d4061c3e84cb66b722de5e751feeee1", null ],
    [ "removeRunGroup", "classansys_1_1_project_1_1_simulation.xhtml#a7194248adaf93042eee0e5e60711877b", null ],
    [ "setCurrentRun", "classansys_1_1_project_1_1_simulation.xhtml#a607c98713399c26357da6ae6a92b21ec", null ]
];