# ansys.meshing.prime.ComputeTopoVolumesResults.external_open_topo_faces

#### *property* ComputeTopoVolumesResults.external_open_topo_faces *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Topoface ids that are in external space and not part of any topovolumes.

<!-- !! processed by numpydoc !! -->
