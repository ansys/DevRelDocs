# ansys.meshing.prime.CellStatisticsParams.get_volume

#### *property* CellStatisticsParams.get_volume *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Provides option to compute and get cumulative cell volume.

<!-- !! processed by numpydoc !! -->
