# ansys.meshing.prime.DeleteFringesAndOverlapsParams.overlap_element_count

#### *property* DeleteFringesAndOverlapsParams.overlap_element_count *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Maximum count of overlapping face elements identified as overlap to be deleted.

<!-- !! processed by numpydoc !! -->
