# ansys.meshing.prime.DeleteVolumesParams.volume_limit

#### *property* DeleteVolumesParams.volume_limit *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum volume limit to identify smaller volumes to be deleted.

<!-- !! processed by numpydoc !! -->
