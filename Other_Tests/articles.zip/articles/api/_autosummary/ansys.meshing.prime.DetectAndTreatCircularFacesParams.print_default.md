# ansys.meshing.prime.DetectAndTreatCircularFacesParams.print_default

#### *static* DetectAndTreatCircularFacesParams.print_default()

Print the default values of DetectAndTreatCircularFacesParams.

### Examples

```pycon
>>> DetectAndTreatCircularFacesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
