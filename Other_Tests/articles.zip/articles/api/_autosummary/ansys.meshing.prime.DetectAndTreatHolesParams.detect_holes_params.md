# ansys.meshing.prime.DetectAndTreatHolesParams.detect_holes_params

#### *property* DetectAndTreatHolesParams.detect_holes_params *: [DetectHolesParams](ansys.meshing.prime.DetectHolesParams.md#ansys.meshing.prime.DetectHolesParams)*

Parameters for detect holes operation.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
