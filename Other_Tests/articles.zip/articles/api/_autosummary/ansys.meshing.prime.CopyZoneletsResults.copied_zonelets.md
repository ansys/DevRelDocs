# ansys.meshing.prime.CopyZoneletsResults.copied_zonelets

#### *property* CopyZoneletsResults.copied_zonelets *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Ids of the copied zonelets.

<!-- !! processed by numpydoc !! -->
