# ansys.meshing.prime.AddToZoneResults.error_code

#### *property* AddToZoneResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the failure of operation.

<!-- !! processed by numpydoc !! -->
