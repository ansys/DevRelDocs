# ansys.meshing.prime.DeleteVolumesResults.deleted_volumes

#### *property* DeleteVolumesResults.deleted_volumes *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Ids of deleted volumes.

<!-- !! processed by numpydoc !! -->
