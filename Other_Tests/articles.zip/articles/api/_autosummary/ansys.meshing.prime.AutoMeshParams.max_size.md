# ansys.meshing.prime.AutoMeshParams.max_size

#### *property* AutoMeshParams.max_size *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum cell size.

<!-- !! processed by numpydoc !! -->
