# ansys.meshing.prime.DeleteTopoEntitiesResults.print_default

#### *static* DeleteTopoEntitiesResults.print_default()

Print the default values of DeleteTopoEntitiesResults.

### Examples

```pycon
>>> DeleteTopoEntitiesResults.print_default()
```

<!-- !! processed by numpydoc !! -->
