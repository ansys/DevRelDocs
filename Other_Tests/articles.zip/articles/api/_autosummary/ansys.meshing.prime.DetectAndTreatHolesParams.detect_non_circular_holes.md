# ansys.meshing.prime.DetectAndTreatHolesParams.detect_non_circular_holes

#### *property* DetectAndTreatHolesParams.detect_non_circular_holes *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to detect non-circular holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
