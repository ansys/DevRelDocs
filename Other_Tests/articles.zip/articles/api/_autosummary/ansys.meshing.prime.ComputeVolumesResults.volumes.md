# ansys.meshing.prime.ComputeVolumesResults.volumes

#### *property* ComputeVolumesResults.volumes *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Ids of computed volumes.

<!-- !! processed by numpydoc !! -->
