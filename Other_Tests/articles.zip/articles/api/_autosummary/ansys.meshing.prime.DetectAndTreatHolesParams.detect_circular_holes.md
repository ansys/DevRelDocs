# ansys.meshing.prime.DetectAndTreatHolesParams.detect_circular_holes

#### *property* DetectAndTreatHolesParams.detect_circular_holes *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to detect circular holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
