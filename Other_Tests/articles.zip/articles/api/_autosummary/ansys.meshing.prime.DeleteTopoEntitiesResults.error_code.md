# ansys.meshing.prime.DeleteTopoEntitiesResults.error_code

#### *property* DeleteTopoEntitiesResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with delete topoentities.

<!-- !! processed by numpydoc !! -->
