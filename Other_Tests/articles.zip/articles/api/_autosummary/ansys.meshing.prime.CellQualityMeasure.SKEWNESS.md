# ansys.meshing.prime.CellQualityMeasure.SKEWNESS

#### CellQualityMeasure.SKEWNESS *= 0*

The Skewness metric ranges between 0 (best) and 1 (worst). A value of 0 indicates an equilateral cell (best) and a value of 1 indicates a completely degenerate cell (worst).

<!-- !! processed by numpydoc !! -->
