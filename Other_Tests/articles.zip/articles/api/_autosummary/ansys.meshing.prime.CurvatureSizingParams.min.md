# ansys.meshing.prime.CurvatureSizingParams.min

#### *property* CurvatureSizingParams.min *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Minimum size used for computing edge and face size using curavture size control.

<!-- !! processed by numpydoc !! -->
