# ansys.meshing.prime.CopyZoneletsResults.error_code

#### *property* CopyZoneletsResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with failure of operation.

<!-- !! processed by numpydoc !! -->
