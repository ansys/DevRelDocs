# ansys.meshing.prime.CreateIntersectionEdgeLoopsResults.processing_time

#### *property* CreateIntersectionEdgeLoopsResults.processing_time *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Time taken to extract edges formed by intersecting faces.

<!-- !! processed by numpydoc !! -->
