# ansys.meshing.prime.CreateContactPatchParams.grouping_tolerance

#### *property* CreateContactPatchParams.grouping_tolerance *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Tolerance distance value to group regions for contact patch creation.

<!-- !! processed by numpydoc !! -->
