# ansys.meshing.prime.CheckMeshResults.has_left_handed_faces

#### *property* CheckMeshResults.has_left_handed_faces *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Indicates whether mesh has left handed faces.

<!-- !! processed by numpydoc !! -->
