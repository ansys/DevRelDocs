# ansys.meshing.prime.AutoQuadMesherResults.warning_codes

#### *property* AutoQuadMesherResults.warning_codes *: [List](https://docs.python.org/3.11/library/typing.html#typing.List)[[WarningCode](ansys.meshing.prime.WarningCode.md#ansys.meshing.prime.WarningCode)]*

Warning code if AutoQuadMesher operation is partially successful.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
