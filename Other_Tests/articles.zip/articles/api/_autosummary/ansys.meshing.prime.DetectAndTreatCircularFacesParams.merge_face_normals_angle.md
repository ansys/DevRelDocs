# ansys.meshing.prime.DetectAndTreatCircularFacesParams.merge_face_normals_angle

#### *property* DetectAndTreatCircularFacesParams.merge_face_normals_angle *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Merge faces when the normal angle between the faces is below the provided value.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
