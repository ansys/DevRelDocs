# ansys.meshing.prime.CreateZoneResults.zone_id

#### *property* CreateZoneResults.zone_id *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Id of newly created zone.

<!-- !! processed by numpydoc !! -->
