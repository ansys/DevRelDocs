# ansys.meshing.prime.BoundingBox.ymax

#### *property* BoundingBox.ymax *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximal Y coordinate of the bounding box.

<!-- !! processed by numpydoc !! -->
