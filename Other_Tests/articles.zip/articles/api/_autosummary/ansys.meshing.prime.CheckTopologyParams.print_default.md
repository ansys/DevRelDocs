# ansys.meshing.prime.CheckTopologyParams.print_default

#### *static* CheckTopologyParams.print_default()

Print the default values of CheckTopologyParams.

### Examples

```pycon
>>> CheckTopologyParams.print_default()
```

<!-- !! processed by numpydoc !! -->
