# ansys.meshing.prime.AutoMeshParams.volume_fill_type

#### *property* AutoMeshParams.volume_fill_type *: [VolumeFillType](ansys.meshing.prime.VolumeFillType.md#ansys.meshing.prime.VolumeFillType)*

Option to fill volume.

<!-- !! processed by numpydoc !! -->
