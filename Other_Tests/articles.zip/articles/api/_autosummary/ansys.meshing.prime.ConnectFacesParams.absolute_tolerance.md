# ansys.meshing.prime.ConnectFacesParams.absolute_tolerance

#### *property* ConnectFacesParams.absolute_tolerance *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Absolute distance tolerance between edges or faces for connect faces operation.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
