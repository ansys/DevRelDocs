# ansys.meshing.prime.DetectAndTreatHolesParams.hole_proximity_tolerance

#### *property* DetectAndTreatHolesParams.hole_proximity_tolerance *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Edge proximity tolerance for holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
