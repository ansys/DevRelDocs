# ansys.meshing.prime.DetectAndTreatFeaturesParams.treat_holes_params

#### *property* DetectAndTreatFeaturesParams.treat_holes_params *: [DetectAndTreatHolesParams](ansys.meshing.prime.DetectAndTreatHolesParams.md#ansys.meshing.prime.DetectAndTreatHolesParams)*

Parameters for detect and treat holes operation.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
