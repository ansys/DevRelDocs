# ansys.meshing.prime.DeleteMeshResults.print_default

#### *static* DeleteMeshResults.print_default()

Print the default values of DeleteMeshResults.

### Examples

```pycon
>>> DeleteMeshResults.print_default()
```

<!-- !! processed by numpydoc !! -->
