# ansys.meshing.prime.DetectHolesParams.max_hole_length

#### *property* DetectHolesParams.max_hole_length *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum length of holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
