# ansys.meshing.prime.DefeatureTopologyParams.partial_defeature_params

#### *property* DefeatureTopologyParams.partial_defeature_params *: [PartialDefeatureParams](ansys.meshing.prime.PartialDefeatureParams.md#ansys.meshing.prime.PartialDefeatureParams)*

Parameters for partial defeature operation.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
