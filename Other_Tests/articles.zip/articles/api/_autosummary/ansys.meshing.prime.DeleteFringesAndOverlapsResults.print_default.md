# ansys.meshing.prime.DeleteFringesAndOverlapsResults.print_default

#### *static* DeleteFringesAndOverlapsResults.print_default()

Print the default values of DeleteFringesAndOverlapsResults.

### Examples

```pycon
>>> DeleteFringesAndOverlapsResults.print_default()
```

<!-- !! processed by numpydoc !! -->
