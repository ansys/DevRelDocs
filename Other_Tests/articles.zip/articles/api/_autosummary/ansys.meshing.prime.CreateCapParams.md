<!-- vale off -->

# CreateCapParams

### *class* ansys.meshing.prime.CreateCapParams(model=None, json_data=None, \*\*kwargs)

Parameters to create cap on face zonelets.

<!-- !! processed by numpydoc !! -->

### Methods

| [`CreateCapParams.print_default`](ansys.meshing.prime.CreateCapParams.print_default.md#ansys.meshing.prime.CreateCapParams.print_default)()   | Print the default values of CreateCapParams.   |
|-----------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------|
| [`CreateCapParams.set_default`](ansys.meshing.prime.CreateCapParams.set_default.md#ansys.meshing.prime.CreateCapParams.set_default)()         | Set the default values of CreateCapParams.     |
<!-- vale on -->
