# ansys.meshing.prime.CreateContactPatchResults.part_id

#### *property* CreateContactPatchResults.part_id *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Contact patch part id.

<!-- !! processed by numpydoc !! -->
