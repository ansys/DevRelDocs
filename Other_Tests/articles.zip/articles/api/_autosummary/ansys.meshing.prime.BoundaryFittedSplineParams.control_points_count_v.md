# ansys.meshing.prime.BoundaryFittedSplineParams.control_points_count_v

#### *property* BoundaryFittedSplineParams.control_points_count_v *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Spline control points count in V direction. Used in manual control points selection mode.

<!-- !! processed by numpydoc !! -->
