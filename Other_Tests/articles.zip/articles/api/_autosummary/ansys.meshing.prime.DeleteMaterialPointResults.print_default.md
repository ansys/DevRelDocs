# ansys.meshing.prime.DeleteMaterialPointResults.print_default

#### *static* DeleteMaterialPointResults.print_default()

Print the default values of DeleteMaterialPointResults.

### Examples

```pycon
>>> DeleteMaterialPointResults.print_default()
```

<!-- !! processed by numpydoc !! -->
