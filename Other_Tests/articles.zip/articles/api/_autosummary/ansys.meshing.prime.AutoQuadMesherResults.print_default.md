# ansys.meshing.prime.AutoQuadMesherResults.print_default

#### *static* AutoQuadMesherResults.print_default()

Print the default values of AutoQuadMesherResults.

### Examples

```pycon
>>> AutoQuadMesherResults.print_default()
```

<!-- !! processed by numpydoc !! -->
