# ansys.meshing.prime.CheckMeshResults.error_code

#### *property* CheckMeshResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the check grid operation.

<!-- !! processed by numpydoc !! -->
