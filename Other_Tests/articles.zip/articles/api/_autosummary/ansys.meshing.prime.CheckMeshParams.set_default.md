# ansys.meshing.prime.CheckMeshParams.set_default

#### *static* CheckMeshParams.set_default()

Set the default values of CheckMeshParams.

<!-- !! processed by numpydoc !! -->
