# ansys.meshing.prime.ComputeVolumesParams.create_zones_type

#### *property* ComputeVolumesParams.create_zones_type *: [CreateVolumeZonesType](ansys.meshing.prime.CreateVolumeZonesType.md#ansys.meshing.prime.CreateVolumeZonesType)*

Option to control volume zone creation for volumes.

<!-- !! processed by numpydoc !! -->
