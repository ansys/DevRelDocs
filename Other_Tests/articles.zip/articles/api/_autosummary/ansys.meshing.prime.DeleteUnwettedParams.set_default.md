# ansys.meshing.prime.DeleteUnwettedParams.set_default

#### *static* DeleteUnwettedParams.set_default()

Set the default values of DeleteUnwettedParams.

<!-- !! processed by numpydoc !! -->
