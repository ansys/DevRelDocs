# ansys.meshing.prime.DefeatureTopologyParams.delete_interior_nodes

#### *property* DefeatureTopologyParams.delete_interior_nodes *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to delete interior nodes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
