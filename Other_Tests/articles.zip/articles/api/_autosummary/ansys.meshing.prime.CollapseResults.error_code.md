# ansys.meshing.prime.CollapseResults.error_code

#### *property* CollapseResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the failure of operation.

<!-- !! processed by numpydoc !! -->
