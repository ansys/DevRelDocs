# ansys.meshing.prime.CadRefacetingParams.faceting_resolution

#### *property* CadRefacetingParams.faceting_resolution *: [CadRefacetingResolution](ansys.meshing.prime.CadRefacetingResolution.md#ansys.meshing.prime.CadRefacetingResolution)*

Set the faceting resolution.

<!-- !! processed by numpydoc !! -->
