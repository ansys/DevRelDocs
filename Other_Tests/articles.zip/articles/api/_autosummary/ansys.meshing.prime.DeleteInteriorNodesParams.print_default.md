# ansys.meshing.prime.DeleteInteriorNodesParams.print_default

#### *static* DeleteInteriorNodesParams.print_default()

Print the default values of DeleteInteriorNodesParams.

### Examples

```pycon
>>> DeleteInteriorNodesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
