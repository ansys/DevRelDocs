# ansys.meshing.prime.DeleteVolumesResults.error_code

#### *property* DeleteVolumesResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the volume deletion operation.

<!-- !! processed by numpydoc !! -->
