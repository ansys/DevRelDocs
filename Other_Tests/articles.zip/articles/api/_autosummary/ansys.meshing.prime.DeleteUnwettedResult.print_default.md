# ansys.meshing.prime.DeleteUnwettedResult.print_default

#### *static* DeleteUnwettedResult.print_default()

Print the default values of DeleteUnwettedResult.

### Examples

```pycon
>>> DeleteUnwettedResult.print_default()
```

<!-- !! processed by numpydoc !! -->
