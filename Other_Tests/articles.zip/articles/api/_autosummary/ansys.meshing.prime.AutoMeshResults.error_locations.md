# ansys.meshing.prime.AutoMeshResults.error_locations

#### *property* AutoMeshResults.error_locations *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[float](https://docs.python.org/3.11/library/functions.html#float)]*

Error location coordinates returned when automesh fails.

<!-- !! processed by numpydoc !! -->
