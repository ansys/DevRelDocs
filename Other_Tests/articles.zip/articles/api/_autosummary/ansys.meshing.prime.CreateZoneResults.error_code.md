# ansys.meshing.prime.CreateZoneResults.error_code

#### *property* CreateZoneResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the create zone operation.

<!-- !! processed by numpydoc !! -->
