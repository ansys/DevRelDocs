# ansys.meshing.prime.DeleteTopoEntitiesParams.print_default

#### *static* DeleteTopoEntitiesParams.print_default()

Print the default values of DeleteTopoEntitiesParams.

### Examples

```pycon
>>> DeleteTopoEntitiesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
