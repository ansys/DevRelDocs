# ansys.meshing.prime.AutoNodeMoveParams.n_attempts

#### *property* AutoNodeMoveParams.n_attempts *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Number of attempts to improve specified quality measure by node movement.

<!-- !! processed by numpydoc !! -->
