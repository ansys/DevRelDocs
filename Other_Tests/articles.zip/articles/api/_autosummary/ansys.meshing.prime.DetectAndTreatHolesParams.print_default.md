# ansys.meshing.prime.DetectAndTreatHolesParams.print_default

#### *static* DetectAndTreatHolesParams.print_default()

Print the default values of DetectAndTreatHolesParams.

### Examples

```pycon
>>> DetectAndTreatHolesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
