# ansys.meshing.prime.AutoQuadMesherResults.failed_topo_face_ids

#### *property* AutoQuadMesherResults.failed_topo_face_ids *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Ids of the failed topofaces during topology check.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
