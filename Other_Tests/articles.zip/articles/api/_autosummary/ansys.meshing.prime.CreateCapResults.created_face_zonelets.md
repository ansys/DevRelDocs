# ansys.meshing.prime.CreateCapResults.created_face_zonelets

#### *property* CreateCapResults.created_face_zonelets *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Ids of cap face zonelets created.

<!-- !! processed by numpydoc !! -->
