# ansys.meshing.prime.DefeatureTopologyParams.delete_interior_nodes_params

#### *property* DefeatureTopologyParams.delete_interior_nodes_params *: [DeleteInteriorNodesParams](ansys.meshing.prime.DeleteInteriorNodesParams.md#ansys.meshing.prime.DeleteInteriorNodesParams)*

Parameters for delete interior nodes operation.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
