# ansys.meshing.prime.DefeatureTopologyParams.fillet_spanning_angle

#### *property* DefeatureTopologyParams.fillet_spanning_angle *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Angular threshold for detecting fillets with spanning angles below the provided value.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
