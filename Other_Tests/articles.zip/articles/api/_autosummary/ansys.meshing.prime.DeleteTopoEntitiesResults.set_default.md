# ansys.meshing.prime.DeleteTopoEntitiesResults.set_default

#### *static* DeleteTopoEntitiesResults.set_default(error_code=None)

Set the default values of DeleteTopoEntitiesResults.

* **Parameters:**
  **error_code: ErrorCode, optional**
  : Error code associated with delete topoentities.

<!-- !! processed by numpydoc !! -->
