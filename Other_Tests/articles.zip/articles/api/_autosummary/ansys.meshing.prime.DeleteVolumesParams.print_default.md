# ansys.meshing.prime.DeleteVolumesParams.print_default

#### *static* DeleteVolumesParams.print_default()

Print the default values of DeleteVolumesParams.

### Examples

```pycon
>>> DeleteVolumesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
