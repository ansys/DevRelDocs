# ansys.meshing.prime.CreateBOIParams.wake_scale

#### *property* CreateBOIParams.wake_scale *: [float](https://docs.python.org/3.11/library/functions.html#float)*

BOI flow direction scaling factor.

<!-- !! processed by numpydoc !! -->
