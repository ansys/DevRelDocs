# ansys.meshing.prime.DeleteFringesAndOverlapsResults.n_deleted

#### *property* DeleteFringesAndOverlapsResults.n_deleted *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Number of face elements deleted.

<!-- !! processed by numpydoc !! -->
