<!-- vale off -->

# DeleteUnwettedParams

### *class* ansys.meshing.prime.DeleteUnwettedParams(model=None, json_data=None, \*\*kwargs)

DeleteUnwettedParams defines parameters for delete unwetted surfaces operation.

<!-- !! processed by numpydoc !! -->

### Methods

| [`DeleteUnwettedParams.print_default`](ansys.meshing.prime.DeleteUnwettedParams.print_default.md#ansys.meshing.prime.DeleteUnwettedParams.print_default)()   | Print the default values of DeleteUnwettedParams.   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------|
| [`DeleteUnwettedParams.set_default`](ansys.meshing.prime.DeleteUnwettedParams.set_default.md#ansys.meshing.prime.DeleteUnwettedParams.set_default)()         | Set the default values of DeleteUnwettedParams.     |
<!-- vale on -->
