# ansys.meshing.prime.DetectCircularHolesParams.print_default

#### *static* DetectCircularHolesParams.print_default()

Print the default values of DetectCircularHolesParams.

### Examples

```pycon
>>> DetectCircularHolesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
