# ansys.meshing.prime.ControlPointSelection.MANUAL

#### ControlPointSelection.MANUAL *= 0*

Manual Spline control point selection.

<!-- !! processed by numpydoc !! -->
