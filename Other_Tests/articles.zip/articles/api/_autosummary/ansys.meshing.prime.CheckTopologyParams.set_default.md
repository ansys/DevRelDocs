# ansys.meshing.prime.CheckTopologyParams.set_default

#### *static* CheckTopologyParams.set_default(topo_search_field_mask=None)

Set the default values of CheckTopologyParams.

* **Parameters:**
  **topo_search_field_mask: int, optional**
  : Toposearch field option for topology check.

<!-- !! processed by numpydoc !! -->
