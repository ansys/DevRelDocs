# ansys.meshing.prime.DetectAndTreatHolesParams.offset_holes

#### *property* DetectAndTreatHolesParams.offset_holes *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to offset holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
