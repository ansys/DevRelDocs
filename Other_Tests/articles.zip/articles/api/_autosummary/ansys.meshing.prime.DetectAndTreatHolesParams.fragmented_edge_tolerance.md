# ansys.meshing.prime.DetectAndTreatHolesParams.fragmented_edge_tolerance

#### *property* DetectAndTreatHolesParams.fragmented_edge_tolerance *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Fragmented edge length tolerance for merging edges.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
