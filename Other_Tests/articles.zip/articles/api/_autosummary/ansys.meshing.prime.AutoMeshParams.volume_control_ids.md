# ansys.meshing.prime.AutoMeshParams.volume_control_ids

#### *property* AutoMeshParams.volume_control_ids *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Ids of the volume controls.

<!-- !! processed by numpydoc !! -->
