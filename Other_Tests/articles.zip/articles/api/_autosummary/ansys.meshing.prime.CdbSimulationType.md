<!-- vale off -->

# CdbSimulationType

### *class* ansys.meshing.prime.CdbSimulationType(value)

Simulation Type for CDB export.

<!-- !! processed by numpydoc !! -->

### Attributes

| [`CdbSimulationType.IMPLICIT`](ansys.meshing.prime.CdbSimulationType.IMPLICIT.md#ansys.meshing.prime.CdbSimulationType.IMPLICIT)   | Implicit simulation.   |
|------------------------------------------------------------------------------------------------------------------------------------|------------------------|
| [`CdbSimulationType.EXPLICIT`](ansys.meshing.prime.CdbSimulationType.EXPLICIT.md#ansys.meshing.prime.CdbSimulationType.EXPLICIT)   | Explicit Simulation.   |
<!-- vale on -->
