# ansys.meshing.prime.CellZoneletType.FLUID

#### CellZoneletType.FLUID *= 1*

Cell zonelet type is fluid.

<!-- !! processed by numpydoc !! -->
