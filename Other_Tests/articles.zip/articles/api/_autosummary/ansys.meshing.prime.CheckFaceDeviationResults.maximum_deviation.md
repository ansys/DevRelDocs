# ansys.meshing.prime.CheckFaceDeviationResults.maximum_deviation

#### *property* CheckFaceDeviationResults.maximum_deviation *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum deviation found.

<!-- !! processed by numpydoc !! -->
