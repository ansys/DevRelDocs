# ansys.meshing.prime.DetectAndTreatHolesParams.detect_and_defeature_edges_near_holes

#### *property* DetectAndTreatHolesParams.detect_and_defeature_edges_near_holes *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to detect and defeature edges near all holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
