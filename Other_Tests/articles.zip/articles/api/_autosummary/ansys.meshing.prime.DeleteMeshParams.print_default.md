# ansys.meshing.prime.DeleteMeshParams.print_default

#### *static* DeleteMeshParams.print_default()

Print the default values of DeleteMeshParams.

### Examples

```pycon
>>> DeleteMeshParams.print_default()
```

<!-- !! processed by numpydoc !! -->
