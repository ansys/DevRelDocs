# ansys.meshing.prime.ComputeTopoVolumesResults.error_code

#### *property* ComputeTopoVolumesResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the failure of operation.

<!-- !! processed by numpydoc !! -->
