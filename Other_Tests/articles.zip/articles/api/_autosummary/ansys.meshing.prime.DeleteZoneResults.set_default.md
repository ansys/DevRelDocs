# ansys.meshing.prime.DeleteZoneResults.set_default

#### *static* DeleteZoneResults.set_default(error_code=None)

Set the default values of DeleteZoneResults.

* **Parameters:**
  **error_code: ErrorCode, optional**
  : Error code associated with the delete zone operation.

<!-- !! processed by numpydoc !! -->
