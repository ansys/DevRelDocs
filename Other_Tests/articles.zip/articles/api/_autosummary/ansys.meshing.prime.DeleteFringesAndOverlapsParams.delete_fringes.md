# ansys.meshing.prime.DeleteFringesAndOverlapsParams.delete_fringes

#### *property* DeleteFringesAndOverlapsParams.delete_fringes *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to delete fringes. The default is true.

<!-- !! processed by numpydoc !! -->
