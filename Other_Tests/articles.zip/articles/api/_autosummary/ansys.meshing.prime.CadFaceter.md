<!-- vale off -->

# CadFaceter

### *class* ansys.meshing.prime.CadFaceter(value)

Types of CAD faceter.

<!-- !! processed by numpydoc !! -->

### Attributes

| [`CadFaceter.ACIS`](ansys.meshing.prime.CadFaceter.ACIS.md#ansys.meshing.prime.CadFaceter.ACIS)                | Denotes CAD faceter is Acis.      |
|----------------------------------------------------------------------------------------------------------------|-----------------------------------|
| [`CadFaceter.PARASOLID`](ansys.meshing.prime.CadFaceter.PARASOLID.md#ansys.meshing.prime.CadFaceter.PARASOLID) | Denotes CAD faceter is Parasolid. |
<!-- vale on -->
