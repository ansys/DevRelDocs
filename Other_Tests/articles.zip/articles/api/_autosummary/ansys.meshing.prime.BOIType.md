<!-- vale off -->

# BOIType

### *class* ansys.meshing.prime.BOIType(value)

BOI type for BOI creation.

<!-- !! processed by numpydoc !! -->

### Attributes

| [`BOIType.OFFSETBOX`](ansys.meshing.prime.BOIType.OFFSETBOX.md#ansys.meshing.prime.BOIType.OFFSETBOX)             | Box BOI type for BOI creation.     |
|-------------------------------------------------------------------------------------------------------------------|------------------------------------|
| [`BOIType.OFFSETSURFACE`](ansys.meshing.prime.BOIType.OFFSETSURFACE.md#ansys.meshing.prime.BOIType.OFFSETSURFACE) | Surface BOI type for BOI creation. |
<!-- vale on -->
