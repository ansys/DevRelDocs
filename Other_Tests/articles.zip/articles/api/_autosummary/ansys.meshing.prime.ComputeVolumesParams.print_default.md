# ansys.meshing.prime.ComputeVolumesParams.print_default

#### *static* ComputeVolumesParams.print_default()

Print the default values of ComputeVolumesParams.

### Examples

```pycon
>>> ComputeVolumesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
