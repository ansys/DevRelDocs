# ansys.meshing.prime.BCsVolumetricModality.BOX

#### BCsVolumetricModality.BOX *= 1*

Option to identify nodes enclosed by bounding box as morphable nodes from the input volumetric mesh.

<!-- !! processed by numpydoc !! -->
