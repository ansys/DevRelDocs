# ansys.meshing.prime.DefeatureTopologyParams.partial_defeature

#### *property* DefeatureTopologyParams.partial_defeature *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to partial defeature.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
