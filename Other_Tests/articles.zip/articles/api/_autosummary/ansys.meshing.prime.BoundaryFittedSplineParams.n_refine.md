# ansys.meshing.prime.BoundaryFittedSplineParams.n_refine

#### *property* BoundaryFittedSplineParams.n_refine *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Spline refinement level for rendering.

<!-- !! processed by numpydoc !! -->
