# ansys.meshing.prime.AutoMeshResults.print_default

#### *static* AutoMeshResults.print_default()

Print the default values of AutoMeshResults.

### Examples

```pycon
>>> AutoMeshResults.print_default()
```

<!-- !! processed by numpydoc !! -->
