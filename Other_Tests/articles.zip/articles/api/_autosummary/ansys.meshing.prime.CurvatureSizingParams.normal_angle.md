# ansys.meshing.prime.CurvatureSizingParams.normal_angle

#### *property* CurvatureSizingParams.normal_angle *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum allowable angle at which one element edge may span.

<!-- !! processed by numpydoc !! -->
