# ansys.meshing.prime.AdvancedSurferSetup.WRAPPER

#### AdvancedSurferSetup.WRAPPER *= 1*

Option to define advanced settings for wrapper surfaces.

<!-- !! processed by numpydoc !! -->
