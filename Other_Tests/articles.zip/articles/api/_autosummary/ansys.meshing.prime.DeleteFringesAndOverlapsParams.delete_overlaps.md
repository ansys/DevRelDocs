# ansys.meshing.prime.DeleteFringesAndOverlapsParams.delete_overlaps

#### *property* DeleteFringesAndOverlapsParams.delete_overlaps *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to delete overlaps. The default is false.

<!-- !! processed by numpydoc !! -->
