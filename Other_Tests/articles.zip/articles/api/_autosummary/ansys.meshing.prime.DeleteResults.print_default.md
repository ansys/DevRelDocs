# ansys.meshing.prime.DeleteResults.print_default

#### *static* DeleteResults.print_default()

Print the default values of DeleteResults.

### Examples

```pycon
>>> DeleteResults.print_default()
```

<!-- !! processed by numpydoc !! -->
