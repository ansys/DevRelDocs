# ansys.meshing.prime.CadReaderRoute.NATIVE

#### CadReaderRoute.NATIVE *= 1*

Denotes native CAD reader route.

<!-- !! processed by numpydoc !! -->
