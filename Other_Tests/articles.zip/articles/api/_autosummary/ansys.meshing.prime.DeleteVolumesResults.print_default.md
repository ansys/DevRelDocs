# ansys.meshing.prime.DeleteVolumesResults.print_default

#### *static* DeleteVolumesResults.print_default()

Print the default values of DeleteVolumesResults.

### Examples

```pycon
>>> DeleteVolumesResults.print_default()
```

<!-- !! processed by numpydoc !! -->
