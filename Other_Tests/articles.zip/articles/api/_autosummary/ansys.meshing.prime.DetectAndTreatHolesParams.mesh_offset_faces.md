# ansys.meshing.prime.DetectAndTreatHolesParams.mesh_offset_faces

#### *property* DetectAndTreatHolesParams.mesh_offset_faces *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to mesh the offset holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
