# ansys.meshing.prime.CreateBOIParams.number_of_threads

#### *property* CreateBOIParams.number_of_threads *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Number of threads for multithreading.

<!-- !! processed by numpydoc !! -->
