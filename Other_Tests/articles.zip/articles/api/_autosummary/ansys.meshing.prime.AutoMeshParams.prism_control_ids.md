# ansys.meshing.prime.AutoMeshParams.prism_control_ids

#### *property* AutoMeshParams.prism_control_ids *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Set prism control ids.

<!-- !! processed by numpydoc !! -->
