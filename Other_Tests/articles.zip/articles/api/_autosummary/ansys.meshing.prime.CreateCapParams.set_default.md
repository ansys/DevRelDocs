# ansys.meshing.prime.CreateCapParams.set_default

#### *static* CreateCapParams.set_default()

Set the default values of CreateCapParams.

<!-- !! processed by numpydoc !! -->
