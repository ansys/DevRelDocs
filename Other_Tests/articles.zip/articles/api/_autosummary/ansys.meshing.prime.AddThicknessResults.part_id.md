# ansys.meshing.prime.AddThicknessResults.part_id

#### *property* AddThicknessResults.part_id *: [int](https://docs.python.org/3.11/library/functions.html#int)*

The created thickness part id.

<!-- !! processed by numpydoc !! -->
