# ansys.meshing.prime.BCPair.source_zonelet

#### *property* BCPair.source_zonelet *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Id of source zonelet.

<!-- !! processed by numpydoc !! -->
