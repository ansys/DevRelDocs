# ansys.meshing.prime.DeleteZoneResults.print_default

#### *static* DeleteZoneResults.print_default()

Print the default values of DeleteZoneResults.

### Examples

```pycon
>>> DeleteZoneResults.print_default()
```

<!-- !! processed by numpydoc !! -->
