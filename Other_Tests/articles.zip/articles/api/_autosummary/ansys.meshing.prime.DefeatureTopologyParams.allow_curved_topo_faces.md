# ansys.meshing.prime.DefeatureTopologyParams.allow_curved_topo_faces

#### *property* DefeatureTopologyParams.allow_curved_topo_faces *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to allow curved topofaces.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
