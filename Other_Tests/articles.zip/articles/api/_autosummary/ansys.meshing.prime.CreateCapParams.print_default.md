# ansys.meshing.prime.CreateCapParams.print_default

#### *static* CreateCapParams.print_default()

Print the default values of CreateCapParams.

### Examples

```pycon
>>> CreateCapParams.print_default()
```

<!-- !! processed by numpydoc !! -->
