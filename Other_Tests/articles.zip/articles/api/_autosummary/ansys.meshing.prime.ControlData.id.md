# ansys.meshing.prime.ControlData.id

#### *property* ControlData.id

Get the id of ControlData.

<!-- !! processed by numpydoc !! -->
