# ansys.meshing.prime.DetectAndTreatHolesParams.edge_sharp_corner_angle

#### *property* DetectAndTreatHolesParams.edge_sharp_corner_angle *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Merge edges when the angle between the edges are below the provided value.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
