# ansys.meshing.prime.CreateMaterialPointParams.type

#### *property* CreateMaterialPointParams.type *: [MaterialPointType](ansys.meshing.prime.MaterialPointType.md#ansys.meshing.prime.MaterialPointType)*

Defines the type of material point.

<!-- !! processed by numpydoc !! -->
