# ansys.meshing.prime.CellQualityMeasure.INVERSEORTHOGONAL

#### CellQualityMeasure.INVERSEORTHOGONAL *= 14*

The inverse orthogonal metric ranges between 0 (best) and 1 (worst).

<!-- !! processed by numpydoc !! -->
