# ansys.meshing.prime.CheckMeshParams.print_default

#### *static* CheckMeshParams.print_default()

Print the default values of CheckMeshParams.

### Examples

```pycon
>>> CheckMeshParams.print_default()
```

<!-- !! processed by numpydoc !! -->
