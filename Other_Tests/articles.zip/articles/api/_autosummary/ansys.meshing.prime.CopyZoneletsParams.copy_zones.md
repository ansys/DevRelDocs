# ansys.meshing.prime.CopyZoneletsParams.copy_zones

#### *property* CopyZoneletsParams.copy_zones *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to copy zones of input zonelets to corresponding copied zonelets.

<!-- !! processed by numpydoc !! -->
