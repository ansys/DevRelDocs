# ansys.meshing.prime.BOIType.OFFSETSURFACE

#### BOIType.OFFSETSURFACE *= 2*

Surface BOI type for BOI creation.

<!-- !! processed by numpydoc !! -->
