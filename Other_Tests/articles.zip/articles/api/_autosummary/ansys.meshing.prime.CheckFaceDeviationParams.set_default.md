# ansys.meshing.prime.CheckFaceDeviationParams.set_default

#### *static* CheckFaceDeviationParams.set_default(distance=None)

Set the default values of CheckFaceDeviationParams.

* **Parameters:**
  **distance: float, optional**
  : Distance above which deviated entities are collected.

<!-- !! processed by numpydoc !! -->
