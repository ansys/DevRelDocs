# ansys.meshing.prime.DeleteUnwettedParams.print_default

#### *static* DeleteUnwettedParams.print_default()

Print the default values of DeleteUnwettedParams.

### Examples

```pycon
>>> DeleteUnwettedParams.print_default()
```

<!-- !! processed by numpydoc !! -->
