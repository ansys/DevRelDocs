# ansys.meshing.prime.AddThicknessParams.fix_intersections

#### *property* AddThicknessParams.fix_intersections *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Fix intersections in concave regions.

<!-- !! processed by numpydoc !! -->
