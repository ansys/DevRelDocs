# ansys.meshing.prime.ComputeVolumesResults.warning_codes

#### *property* ComputeVolumesResults.warning_codes *: [List](https://docs.python.org/3.11/library/typing.html#typing.List)[[WarningCode](ansys.meshing.prime.WarningCode.md#ansys.meshing.prime.WarningCode)]*

Warning codes associated with the compute volumes.

<!-- !! processed by numpydoc !! -->
