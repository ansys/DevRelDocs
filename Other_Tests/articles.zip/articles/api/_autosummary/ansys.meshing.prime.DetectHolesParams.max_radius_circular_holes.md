# ansys.meshing.prime.DetectHolesParams.max_radius_circular_holes

#### *property* DetectHolesParams.max_radius_circular_holes *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum radius of circular holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
