# ansys.meshing.prime.CadReaderRoute.PROGRAMCONTROLLED

#### CadReaderRoute.PROGRAMCONTROLLED *= 0*

Denotes program controlled CAD reader route.

<!-- !! processed by numpydoc !! -->
