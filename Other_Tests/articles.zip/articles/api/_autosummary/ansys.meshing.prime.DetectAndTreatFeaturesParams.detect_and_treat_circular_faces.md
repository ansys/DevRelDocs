# ansys.meshing.prime.DetectAndTreatFeaturesParams.detect_and_treat_circular_faces

#### *property* DetectAndTreatFeaturesParams.detect_and_treat_circular_faces *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to detect and treat circular faces.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
