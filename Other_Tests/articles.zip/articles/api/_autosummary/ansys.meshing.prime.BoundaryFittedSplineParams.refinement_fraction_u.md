# ansys.meshing.prime.BoundaryFittedSplineParams.refinement_fraction_u

#### *property* BoundaryFittedSplineParams.refinement_fraction_u *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Fraction of input mesh size that sets the control points size in u direction. This is used in program controlled control points selection mode.

<!-- !! processed by numpydoc !! -->
