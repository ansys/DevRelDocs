# ansys.meshing.prime.CollapseParams.feature_type

#### *property* CollapseParams.feature_type *: [SurfaceFeatureType](ansys.meshing.prime.SurfaceFeatureType.md#ansys.meshing.prime.SurfaceFeatureType)*

Feature type to be preserved when performing collapse.

<!-- !! processed by numpydoc !! -->
