# ansys.meshing.prime.AutoNodeMoveParams.restrict_boundary_nodes_along_surface

#### *property* AutoNodeMoveParams.restrict_boundary_nodes_along_surface *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to restrict the movement of the boundary node to the plane containing the boundary faces sharing the boundary node.

<!-- !! processed by numpydoc !! -->
