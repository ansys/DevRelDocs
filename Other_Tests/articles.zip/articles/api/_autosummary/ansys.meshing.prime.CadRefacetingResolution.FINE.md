# ansys.meshing.prime.CadRefacetingResolution.FINE

#### CadRefacetingResolution.FINE *= 2*

Denotes fine resolution of CAD faceting.

<!-- !! processed by numpydoc !! -->
