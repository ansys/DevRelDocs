# ansys.meshing.prime.CheckMeshResults.has_non_positive_volumes

#### *property* CheckMeshResults.has_non_positive_volumes *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Indicates whether mesh has non positive volumes.

<!-- !! processed by numpydoc !! -->
