# ansys.meshing.prime.CollapseParams.collapse_ratio

#### *property* CollapseParams.collapse_ratio *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum ratio of shortest face edge length to longest face edge length.

<!-- !! processed by numpydoc !! -->
