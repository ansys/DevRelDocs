# ansys.meshing.prime.DetectAndTreatHolesParams.offset_distance

#### *property* DetectAndTreatHolesParams.offset_distance *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Offset distance for creating offset edge.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
