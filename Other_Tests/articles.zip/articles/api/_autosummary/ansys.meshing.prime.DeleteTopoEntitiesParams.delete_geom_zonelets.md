# ansys.meshing.prime.DeleteTopoEntitiesParams.delete_geom_zonelets

#### *property* DeleteTopoEntitiesParams.delete_geom_zonelets *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to delete geometry zonelets of topology.

<!-- !! processed by numpydoc !! -->
