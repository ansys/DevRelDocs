# ansys.meshing.prime.DetectAndTreatHolesParams.detect_circular_holes_params

#### *property* DetectAndTreatHolesParams.detect_circular_holes_params *: [DetectCircularHolesParams](ansys.meshing.prime.DetectCircularHolesParams.md#ansys.meshing.prime.DetectCircularHolesParams)*

Parameters for detect circular holes operation.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
