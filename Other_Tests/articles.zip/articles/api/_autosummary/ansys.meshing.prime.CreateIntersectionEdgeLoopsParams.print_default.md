# ansys.meshing.prime.CreateIntersectionEdgeLoopsParams.print_default

#### *static* CreateIntersectionEdgeLoopsParams.print_default()

Print the default values of CreateIntersectionEdgeLoopsParams.

### Examples

```pycon
>>> CreateIntersectionEdgeLoopsParams.print_default()
```

<!-- !! processed by numpydoc !! -->
