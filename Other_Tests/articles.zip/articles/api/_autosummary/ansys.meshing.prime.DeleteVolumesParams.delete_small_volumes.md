# ansys.meshing.prime.DeleteVolumesParams.delete_small_volumes

#### *property* DeleteVolumesParams.delete_small_volumes *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to delete only volumes smaller than provided volume limit.

<!-- !! processed by numpydoc !! -->
