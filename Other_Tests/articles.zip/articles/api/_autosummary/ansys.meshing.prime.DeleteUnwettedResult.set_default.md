# ansys.meshing.prime.DeleteUnwettedResult.set_default

#### *static* DeleteUnwettedResult.set_default(error_code=None)

Set the default values of DeleteUnwettedResult.

* **Parameters:**
  **error_code: ErrorCode, optional**
  : Error code associated with delete unwetted surfaces operation.

<!-- !! processed by numpydoc !! -->
