# ansys.meshing.prime.CreateIntersectionEdgeLoopsParams.set_default

#### *static* CreateIntersectionEdgeLoopsParams.set_default(label_name=None)

Set the default values of CreateIntersectionEdgeLoopsParams.

* **Parameters:**
  **label_name: str, optional**
  : Label name to be assigned to extracted features.

<!-- !! processed by numpydoc !! -->
