# ansys.meshing.prime.BCPair.type

#### *property* BCPair.type *: [BCPairType](ansys.meshing.prime.BCPairType.md#ansys.meshing.prime.BCPairType)*

Option to specify boundary condition pair type.

<!-- !! processed by numpydoc !! -->
