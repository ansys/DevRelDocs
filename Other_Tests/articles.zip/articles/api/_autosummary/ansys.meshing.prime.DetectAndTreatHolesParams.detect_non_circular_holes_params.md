# ansys.meshing.prime.DetectAndTreatHolesParams.detect_non_circular_holes_params

#### *property* DetectAndTreatHolesParams.detect_non_circular_holes_params *: [DetectNonCircularHolesParams](ansys.meshing.prime.DetectNonCircularHolesParams.md#ansys.meshing.prime.DetectNonCircularHolesParams)*

Parameters for detect non circular holes operation.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
