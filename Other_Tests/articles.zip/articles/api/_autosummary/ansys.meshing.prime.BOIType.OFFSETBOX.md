# ansys.meshing.prime.BOIType.OFFSETBOX

#### BOIType.OFFSETBOX *= 1*

Box BOI type for BOI creation.

<!-- !! processed by numpydoc !! -->
