# ansys.meshing.prime.AutoMeshParams.size_field_type

#### *property* AutoMeshParams.size_field_type *: [SizeFieldType](ansys.meshing.prime.SizeFieldType.md#ansys.meshing.prime.SizeFieldType)*

Type of sizing to be used to generate volume mesh.

<!-- !! processed by numpydoc !! -->
