# ansys.meshing.prime.AutoMeshResults.error_code

#### *property* AutoMeshResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Provides error message when automesh fails.

<!-- !! processed by numpydoc !! -->
