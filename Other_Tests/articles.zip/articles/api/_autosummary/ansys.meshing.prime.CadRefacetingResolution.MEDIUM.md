# ansys.meshing.prime.CadRefacetingResolution.MEDIUM

#### CadRefacetingResolution.MEDIUM *= 1*

Denotes medium resolution of CAD faceting.

<!-- !! processed by numpydoc !! -->
