# ansys.meshing.prime.AutoQuadMesherResults.error_code

#### *property* AutoQuadMesherResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code if AutoQuadMesher operation is unsuccessful.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
