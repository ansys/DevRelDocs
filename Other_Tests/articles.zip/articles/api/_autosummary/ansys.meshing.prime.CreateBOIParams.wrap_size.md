# ansys.meshing.prime.CreateBOIParams.wrap_size

#### *property* CreateBOIParams.wrap_size *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Set wrap size greater than the largest gap size in the input when performing_initial_wrap is true.

<!-- !! processed by numpydoc !! -->
