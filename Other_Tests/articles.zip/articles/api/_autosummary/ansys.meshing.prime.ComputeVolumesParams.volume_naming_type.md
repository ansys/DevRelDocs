# ansys.meshing.prime.ComputeVolumesParams.volume_naming_type

#### *property* ComputeVolumesParams.volume_naming_type *: [VolumeNamingType](ansys.meshing.prime.VolumeNamingType.md#ansys.meshing.prime.VolumeNamingType)*

Indicates source type used to compute zone name for volumes.

<!-- !! processed by numpydoc !! -->
