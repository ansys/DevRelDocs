# ansys.meshing.prime.DeleteZoneResults.error_code

#### *property* DeleteZoneResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the delete zone operation.

<!-- !! processed by numpydoc !! -->
