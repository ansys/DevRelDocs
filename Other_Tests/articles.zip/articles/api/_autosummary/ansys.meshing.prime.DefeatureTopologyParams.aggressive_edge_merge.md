# ansys.meshing.prime.DefeatureTopologyParams.aggressive_edge_merge

#### *property* DefeatureTopologyParams.aggressive_edge_merge *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Indicate whether to allow aggressive edge merge while performing partial defeature.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
