# ansys.meshing.prime.ContactPatchAxis.X

#### ContactPatchAxis.X *= 1*

Flow or wake inflation in the X direction for BOI creation.

<!-- !! processed by numpydoc !! -->
