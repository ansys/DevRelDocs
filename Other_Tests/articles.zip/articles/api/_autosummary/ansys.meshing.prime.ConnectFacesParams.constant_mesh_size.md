# ansys.meshing.prime.ConnectFacesParams.constant_mesh_size

#### *property* ConnectFacesParams.constant_mesh_size *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Constant size used for surface meshing.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
