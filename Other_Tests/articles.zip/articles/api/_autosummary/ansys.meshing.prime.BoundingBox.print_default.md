# ansys.meshing.prime.BoundingBox.print_default

#### *static* BoundingBox.print_default()

Print the default values of BoundingBox.

### Examples

```pycon
>>> BoundingBox.print_default()
```

<!-- !! processed by numpydoc !! -->
