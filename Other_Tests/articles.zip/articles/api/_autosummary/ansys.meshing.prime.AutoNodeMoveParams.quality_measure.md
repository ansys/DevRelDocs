# ansys.meshing.prime.AutoNodeMoveParams.quality_measure

#### *property* AutoNodeMoveParams.quality_measure *: [CellQualityMeasure](ansys.meshing.prime.CellQualityMeasure.md#ansys.meshing.prime.CellQualityMeasure)*

Specify cell quality measure to be used for volume mesh improvement. The default value for cell quality measure is skewness.

<!-- !! processed by numpydoc !! -->
