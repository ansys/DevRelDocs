# ansys.meshing.prime.AddThicknessParams.reverse_face_normal

#### *property* AddThicknessParams.reverse_face_normal *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

To assign the direction of inflation.

<!-- !! processed by numpydoc !! -->
