# ansys.meshing.prime.DeleteUnwettedResult.error_code

#### *property* DeleteUnwettedResult.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with delete unwetted surfaces operation.

<!-- !! processed by numpydoc !! -->
