# ansys.meshing.prime.ContactPreventionParams.print_default

#### *static* ContactPreventionParams.print_default()

Print the default values of ContactPreventionParams.

### Examples

```pycon
>>> ContactPreventionParams.print_default()
```

<!-- !! processed by numpydoc !! -->
