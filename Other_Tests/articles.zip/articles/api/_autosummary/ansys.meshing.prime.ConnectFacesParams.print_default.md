# ansys.meshing.prime.ConnectFacesParams.print_default

#### *static* ConnectFacesParams.print_default()

Print the default values of ConnectFacesParams.

### Examples

```pycon
>>> ConnectFacesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
