# ansys.meshing.prime.Client.run_on_server

#### Client.run_on_server(recipe)

Run a recipe on the server.

* **Parameters:**
  **recipe: str**
  : Recipe to run. This must be a valid Python script.

<!-- !! processed by numpydoc !! -->
