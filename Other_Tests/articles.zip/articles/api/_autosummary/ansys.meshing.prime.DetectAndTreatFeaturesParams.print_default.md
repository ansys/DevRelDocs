# ansys.meshing.prime.DetectAndTreatFeaturesParams.print_default

#### *static* DetectAndTreatFeaturesParams.print_default()

Print the default values of DetectAndTreatFeaturesParams.

### Examples

```pycon
>>> DetectAndTreatFeaturesParams.print_default()
```

<!-- !! processed by numpydoc !! -->
