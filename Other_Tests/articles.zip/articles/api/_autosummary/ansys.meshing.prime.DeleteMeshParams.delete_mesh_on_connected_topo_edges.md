# ansys.meshing.prime.DeleteMeshParams.delete_mesh_on_connected_topo_edges

#### *property* DeleteMeshParams.delete_mesh_on_connected_topo_edges *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to delete mesh on topoedges connected only to provided topoentities.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
