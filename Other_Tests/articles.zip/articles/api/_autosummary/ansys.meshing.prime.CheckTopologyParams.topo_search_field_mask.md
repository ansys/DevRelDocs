# ansys.meshing.prime.CheckTopologyParams.topo_search_field_mask

#### *property* CheckTopologyParams.topo_search_field_mask *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Toposearch field option for topology check.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
