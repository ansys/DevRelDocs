# ansys.meshing.prime.AddLabelResults.print_default

#### *static* AddLabelResults.print_default()

Print the default values of AddLabelResults.

### Examples

```pycon
>>> AddLabelResults.print_default()
```

<!-- !! processed by numpydoc !! -->
