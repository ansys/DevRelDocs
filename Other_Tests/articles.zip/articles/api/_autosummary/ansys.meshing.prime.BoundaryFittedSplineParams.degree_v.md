# ansys.meshing.prime.BoundaryFittedSplineParams.degree_v

#### *property* BoundaryFittedSplineParams.degree_v *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Degree of spline in v direction.

<!-- !! processed by numpydoc !! -->
