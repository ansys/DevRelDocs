# ansys.meshing.prime.DeleteFringesAndOverlapsParams.fringe_element_count

#### *property* DeleteFringesAndOverlapsParams.fringe_element_count *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Maximum count of free face elements identified as fringe to be deleted.

<!-- !! processed by numpydoc !! -->
