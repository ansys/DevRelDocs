# ansys.meshing.prime.ContactPatchAxis.Y

#### ContactPatchAxis.Y *= 2*

Flow or wake inflation in the Y direction for BOI creation.

<!-- !! processed by numpydoc !! -->
