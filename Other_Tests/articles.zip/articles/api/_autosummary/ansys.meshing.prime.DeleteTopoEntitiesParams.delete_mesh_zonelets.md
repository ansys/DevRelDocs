# ansys.meshing.prime.DeleteTopoEntitiesParams.delete_mesh_zonelets

#### *property* DeleteTopoEntitiesParams.delete_mesh_zonelets *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to delete mesh zonelets of topology.

<!-- !! processed by numpydoc !! -->
