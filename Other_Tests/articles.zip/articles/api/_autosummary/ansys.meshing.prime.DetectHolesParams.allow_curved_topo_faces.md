# ansys.meshing.prime.DetectHolesParams.allow_curved_topo_faces

#### *property* DetectHolesParams.allow_curved_topo_faces *: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to allow holes in curved topoface.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
