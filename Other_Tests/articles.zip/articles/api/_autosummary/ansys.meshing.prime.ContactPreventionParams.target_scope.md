# ansys.meshing.prime.ContactPreventionParams.target_scope

#### *property* ContactPreventionParams.target_scope *: [ScopeDefinition](ansys.meshing.prime.ScopeDefinition.md#ansys.meshing.prime.ScopeDefinition)*

Target scope used for contact prevention control.

<!-- !! processed by numpydoc !! -->
