# ansys.meshing.prime.CellStatisticsResults.volume

#### *property* CellStatisticsResults.volume *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Cumulative volume of all the cell elements of selected entities.

<!-- !! processed by numpydoc !! -->
