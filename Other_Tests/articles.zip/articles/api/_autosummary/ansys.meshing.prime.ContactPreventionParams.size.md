# ansys.meshing.prime.ContactPreventionParams.size

#### *property* ContactPreventionParams.size *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Minimum gap size (gap/4) to resolve contact between source and target.

<!-- !! processed by numpydoc !! -->
