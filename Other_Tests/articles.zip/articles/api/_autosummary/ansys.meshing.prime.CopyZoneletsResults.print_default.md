# ansys.meshing.prime.CopyZoneletsResults.print_default

#### *static* CopyZoneletsResults.print_default()

Print the default values of CopyZoneletsResults.

### Examples

```pycon
>>> CopyZoneletsResults.print_default()
```

<!-- !! processed by numpydoc !! -->
