# ansys.meshing.prime.DetectAndTreatCircularFacesParams.surface_mesh_constant_size

#### *property* DetectAndTreatCircularFacesParams.surface_mesh_constant_size *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Constant size used for surface meshing.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
