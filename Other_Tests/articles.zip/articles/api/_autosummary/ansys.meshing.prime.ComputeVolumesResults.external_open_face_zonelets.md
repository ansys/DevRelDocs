# ansys.meshing.prime.ComputeVolumesResults.external_open_face_zonelets

#### *property* ComputeVolumesResults.external_open_face_zonelets *: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Face zonelet ids that are in external space and not part of any computed volumes.

<!-- !! processed by numpydoc !! -->
