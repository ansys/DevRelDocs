# ansys.meshing.prime.DetectCircularHolesParams.min_radius_circular_holes

#### *property* DetectCircularHolesParams.min_radius_circular_holes *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Minimum radius of circular holes.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
