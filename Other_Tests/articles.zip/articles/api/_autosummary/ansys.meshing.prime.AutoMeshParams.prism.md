# ansys.meshing.prime.AutoMeshParams.prism

#### *property* AutoMeshParams.prism *: [PrismParams](ansys.meshing.prime.PrismParams.md#ansys.meshing.prime.PrismParams)*

Prism control parameters.

<!-- !! processed by numpydoc !! -->
