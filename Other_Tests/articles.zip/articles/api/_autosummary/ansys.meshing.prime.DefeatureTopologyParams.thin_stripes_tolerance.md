# ansys.meshing.prime.DefeatureTopologyParams.thin_stripes_tolerance

#### *property* DefeatureTopologyParams.thin_stripes_tolerance *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Topoface width tolerance to detect thin faces below the provided value.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
