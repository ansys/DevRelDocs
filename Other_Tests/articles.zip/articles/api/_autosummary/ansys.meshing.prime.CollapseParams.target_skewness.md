# ansys.meshing.prime.CollapseParams.target_skewness

#### *property* CollapseParams.target_skewness *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Skewness limit used as target to preserve quality. Better quality elements are skipped for collapse.

<!-- !! processed by numpydoc !! -->
