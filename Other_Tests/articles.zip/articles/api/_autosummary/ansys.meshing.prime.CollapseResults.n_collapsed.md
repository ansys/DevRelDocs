# ansys.meshing.prime.CollapseResults.n_collapsed

#### *property* CollapseResults.n_collapsed *: [int](https://docs.python.org/3.11/library/functions.html#int)*

Number of face elements collapsed.

<!-- !! processed by numpydoc !! -->
