# ansys.meshing.prime.DetectAndTreatFeaturesParams.treat_circular_faces_params

#### *property* DetectAndTreatFeaturesParams.treat_circular_faces_params *: [DetectAndTreatCircularFacesParams](ansys.meshing.prime.DetectAndTreatCircularFacesParams.md#ansys.meshing.prime.DetectAndTreatCircularFacesParams)*

Parameters for detect and treat circular faces operation.
This parameter is a Beta. Parameter behavior and name may change in future.

<!-- !! processed by numpydoc !! -->
