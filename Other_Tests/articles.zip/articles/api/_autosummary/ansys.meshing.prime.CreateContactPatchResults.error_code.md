# ansys.meshing.prime.CreateContactPatchResults.error_code

#### *property* CreateContactPatchResults.error_code *: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the contact patch creation operation.

<!-- !! processed by numpydoc !! -->
