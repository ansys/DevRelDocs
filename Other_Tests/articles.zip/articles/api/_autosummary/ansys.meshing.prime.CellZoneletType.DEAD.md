# ansys.meshing.prime.CellZoneletType.DEAD

#### CellZoneletType.DEAD *= 0*

Cell zonelet type is dead.

<!-- !! processed by numpydoc !! -->
