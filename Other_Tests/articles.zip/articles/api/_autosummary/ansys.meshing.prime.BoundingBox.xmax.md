# ansys.meshing.prime.BoundingBox.xmax

#### *property* BoundingBox.xmax *: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximal X coordinate of the bounding box.

<!-- !! processed by numpydoc !! -->
