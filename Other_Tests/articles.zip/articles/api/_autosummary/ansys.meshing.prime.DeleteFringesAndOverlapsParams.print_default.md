# ansys.meshing.prime.DeleteFringesAndOverlapsParams.print_default

#### *static* DeleteFringesAndOverlapsParams.print_default()

Print the default values of DeleteFringesAndOverlapsParams.

### Examples

```pycon
>>> DeleteFringesAndOverlapsParams.print_default()
```

<!-- !! processed by numpydoc !! -->
