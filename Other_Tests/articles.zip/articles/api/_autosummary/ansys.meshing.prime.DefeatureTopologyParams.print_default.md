# ansys.meshing.prime.DefeatureTopologyParams.print_default

#### *static* DefeatureTopologyParams.print_default()

Print the default values of DefeatureTopologyParams.

### Examples

```pycon
>>> DefeatureTopologyParams.print_default()
```

<!-- !! processed by numpydoc !! -->
