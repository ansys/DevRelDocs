# ansys.meshing.prime.ConnectResults.print_default

#### *static* ConnectResults.print_default()

Print the default values of ConnectResults.

### Examples

```pycon
>>> ConnectResults.print_default()
```

<!-- !! processed by numpydoc !! -->
