<!-- vale off -->

# CheckMeshParams

### *class* ansys.meshing.prime.CheckMeshParams(model=None, json_data=None, \*\*kwargs)

Parameters used to check mesh.

<!-- !! processed by numpydoc !! -->

### Methods

| [`CheckMeshParams.print_default`](ansys.meshing.prime.CheckMeshParams.print_default.md#ansys.meshing.prime.CheckMeshParams.print_default)()   | Print the default values of CheckMeshParams.   |
|-----------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------|
| [`CheckMeshParams.set_default`](ansys.meshing.prime.CheckMeshParams.set_default.md#ansys.meshing.prime.CheckMeshParams.set_default)()         | Set the default values of CheckMeshParams.     |
<!-- vale on -->
