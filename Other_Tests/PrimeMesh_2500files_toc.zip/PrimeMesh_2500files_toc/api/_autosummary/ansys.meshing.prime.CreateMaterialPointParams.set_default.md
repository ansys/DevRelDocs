# ansys.meshing.prime.CreateMaterialPointParams.set_default

#### *static* CreateMaterialPointParams.set_default(type=None)

Set the default values of CreateMaterialPointParams.

* **Parameters:**
  **type: MaterialPointType, optional**
  : Defines the type of material point.

<!-- !! processed by numpydoc !! -->
