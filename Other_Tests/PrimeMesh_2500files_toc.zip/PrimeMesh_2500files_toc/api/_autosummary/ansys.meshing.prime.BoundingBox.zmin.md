# ansys.meshing.prime.BoundingBox.zmin

#### *property* BoundingBox.zmin*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Minimal Z coordinate of the bounding box.

<!-- !! processed by numpydoc !! -->
