# ansys.meshing.prime.CurvatureSizingParams.print_default

#### *static* CurvatureSizingParams.print_default()

Print the default values of CurvatureSizingParams.

### Examples

```pycon
>>> CurvatureSizingParams.print_default()
```

<!-- !! processed by numpydoc !! -->
