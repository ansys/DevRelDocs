# ansys.meshing.prime.CreateVolumeZonesType.PERVOLUME

#### CreateVolumeZonesType.PERVOLUME *= 1*

Option to create volume zone per volume. Suffix is added to volume zone name, if same name is identified for different volumes using face zonelets.

<!-- !! processed by numpydoc !! -->
