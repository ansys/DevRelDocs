# ansys.meshing.prime.CadRefacetingParams.max_edge_size

#### *property* CadRefacetingParams.max_edge_size*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Set maximum edge size of the facets.

<!-- !! processed by numpydoc !! -->
