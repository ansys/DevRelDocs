# ansys.meshing.prime.CreateMaterialPointParams.print_default

#### *static* CreateMaterialPointParams.print_default()

Print the default values of CreateMaterialPointParams.

### Examples

```pycon
>>> CreateMaterialPointParams.print_default()
```

<!-- !! processed by numpydoc !! -->
