# ansys.meshing.prime.BOIType.conjugate

#### BOIType.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
