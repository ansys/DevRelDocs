# ansys.meshing.prime.CheckFaceDeviationParams.print_default

#### *static* CheckFaceDeviationParams.print_default()

Print the default values of CheckFaceDeviationParams.

### Examples

```pycon
>>> CheckFaceDeviationParams.print_default()
```

<!-- !! processed by numpydoc !! -->
