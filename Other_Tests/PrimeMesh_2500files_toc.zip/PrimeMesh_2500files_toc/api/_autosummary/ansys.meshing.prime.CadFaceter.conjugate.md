# ansys.meshing.prime.CadFaceter.conjugate

#### CadFaceter.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
