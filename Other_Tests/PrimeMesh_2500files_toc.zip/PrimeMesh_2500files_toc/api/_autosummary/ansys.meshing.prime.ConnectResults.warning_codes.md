# ansys.meshing.prime.ConnectResults.warning_codes

#### *property* ConnectResults.warning_codes*: [List](https://docs.python.org/3.11/library/typing.html#typing.List)[[WarningCode](ansys.meshing.prime.WarningCode.md#ansys.meshing.prime.WarningCode)]*

Warning codes associated with the operation.

<!-- !! processed by numpydoc !! -->
