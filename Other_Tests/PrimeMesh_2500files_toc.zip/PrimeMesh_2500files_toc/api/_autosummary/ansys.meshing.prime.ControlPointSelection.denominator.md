# ansys.meshing.prime.ControlPointSelection.denominator

#### ControlPointSelection.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
