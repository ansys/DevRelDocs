# ansys.meshing.prime.CopyZoneletsParams.set_default

#### *static* CopyZoneletsParams.set_default(copy_zones=None)

Set the default values of CopyZoneletsParams.

* **Parameters:**
  **copy_zones: bool, optional**
  : Option to copy zones of input zonelets to corresponding copied zonelets.

<!-- !! processed by numpydoc !! -->
