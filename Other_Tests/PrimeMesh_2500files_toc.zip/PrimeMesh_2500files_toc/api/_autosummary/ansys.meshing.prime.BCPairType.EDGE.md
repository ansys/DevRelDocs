# ansys.meshing.prime.BCPairType.EDGE

#### BCPairType.EDGE *= 2*

Option to specify edge zonelet as boundary condition pair.

<!-- !! processed by numpydoc !! -->
