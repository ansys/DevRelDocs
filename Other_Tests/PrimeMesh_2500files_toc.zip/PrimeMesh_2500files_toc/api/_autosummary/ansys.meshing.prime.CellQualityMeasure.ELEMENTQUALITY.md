# ansys.meshing.prime.CellQualityMeasure.ELEMENTQUALITY

#### CellQualityMeasure.ELEMENTQUALITY *= 50*

The Element Quality metric ranges between 0 (worst) and 1 (best). A value of 1 indicates a perfect cube or square (best) while a value of 0 indicates that the element has a zero or negative volume (worst).

<!-- !! processed by numpydoc !! -->
