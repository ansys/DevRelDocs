# ansys.meshing.prime.CadFaceter.real

#### CadFaceter.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
