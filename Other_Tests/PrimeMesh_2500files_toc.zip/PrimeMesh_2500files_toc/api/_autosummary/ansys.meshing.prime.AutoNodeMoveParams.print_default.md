# ansys.meshing.prime.AutoNodeMoveParams.print_default

#### *static* AutoNodeMoveParams.print_default()

Print the default values of AutoNodeMoveParams.

### Examples

```pycon
>>> AutoNodeMoveParams.print_default()
```

<!-- !! processed by numpydoc !! -->
