# ansys.meshing.prime.CreateMaterialPointResults.assigned_name

#### *property* CreateMaterialPointResults.assigned_name*: [str](https://docs.python.org/3.11/library/stdtypes.html#str)*

Assigned name of the material point created.

<!-- !! processed by numpydoc !! -->
