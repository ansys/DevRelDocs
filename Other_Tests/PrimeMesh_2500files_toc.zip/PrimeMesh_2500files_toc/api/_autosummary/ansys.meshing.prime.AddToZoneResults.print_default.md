# ansys.meshing.prime.AddToZoneResults.print_default

#### *static* AddToZoneResults.print_default()

Print the default values of AddToZoneResults.

### Examples

```pycon
>>> AddToZoneResults.print_default()
```

<!-- !! processed by numpydoc !! -->
