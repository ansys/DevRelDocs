# ansys.meshing.prime.CdbSimulationType.EXPLICIT

#### CdbSimulationType.EXPLICIT *= 1*

Explicit Simulation.

<!-- !! processed by numpydoc !! -->
