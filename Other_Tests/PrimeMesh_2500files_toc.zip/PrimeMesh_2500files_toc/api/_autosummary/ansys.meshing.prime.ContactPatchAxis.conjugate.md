# ansys.meshing.prime.ContactPatchAxis.conjugate

#### ContactPatchAxis.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
