# ansys.meshing.prime.CreateMaterialPointResults.warning_codes

#### *property* CreateMaterialPointResults.warning_codes*: [List](https://docs.python.org/3.11/library/typing.html#typing.List)[[WarningCode](ansys.meshing.prime.WarningCode.md#ansys.meshing.prime.WarningCode)]*

Warning codes associated with create material point operation.

<!-- !! processed by numpydoc !! -->
