# ansys.meshing.prime.CheckFaceDeviationResults.set_default

#### *static* CheckFaceDeviationResults.set_default(n_deviated=None, maximum_deviation=None)

Set the default values of CheckFaceDeviationResults.

* **Parameters:**
  **n_deviated: int, optional**
  : Number of faces with deviation.

  **maximum_deviation: float, optional**
  : Maximum deviation found.

<!-- !! processed by numpydoc !! -->
