# ansys.meshing.prime.CreateBOIParams.flow_dir

#### *property* CreateBOIParams.flow_dir*: [FlowDirection](ansys.meshing.prime.FlowDirection.md#ansys.meshing.prime.FlowDirection)*

Assigns the offset direction of inflation.

<!-- !! processed by numpydoc !! -->
