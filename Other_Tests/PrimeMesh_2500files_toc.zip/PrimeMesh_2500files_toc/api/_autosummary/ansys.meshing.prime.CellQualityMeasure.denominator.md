# ansys.meshing.prime.CellQualityMeasure.denominator

#### CellQualityMeasure.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
