# ansys.meshing.prime.BOIType.denominator

#### BOIType.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
