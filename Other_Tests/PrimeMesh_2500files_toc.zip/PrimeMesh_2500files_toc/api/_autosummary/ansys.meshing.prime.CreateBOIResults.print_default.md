# ansys.meshing.prime.CreateBOIResults.print_default

#### *static* CreateBOIResults.print_default()

Print the default values of CreateBOIResults.

### Examples

```pycon
>>> CreateBOIResults.print_default()
```

<!-- !! processed by numpydoc !! -->
