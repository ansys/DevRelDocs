# ansys.meshing.prime.AddLabelResults.error_code

#### *property* AddLabelResults.error_code*: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the add label operation.

<!-- !! processed by numpydoc !! -->
