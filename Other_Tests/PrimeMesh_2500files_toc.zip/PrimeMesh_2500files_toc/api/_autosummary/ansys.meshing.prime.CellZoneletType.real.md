# ansys.meshing.prime.CellZoneletType.real

#### CellZoneletType.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
