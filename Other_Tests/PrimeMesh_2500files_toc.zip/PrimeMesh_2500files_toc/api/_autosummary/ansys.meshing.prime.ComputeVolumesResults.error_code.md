# ansys.meshing.prime.ComputeVolumesResults.error_code

#### *property* ComputeVolumesResults.error_code*: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the failure of operation.

<!-- !! processed by numpydoc !! -->
