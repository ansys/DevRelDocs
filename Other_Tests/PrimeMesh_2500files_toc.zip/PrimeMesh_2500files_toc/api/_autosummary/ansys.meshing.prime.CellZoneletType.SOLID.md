# ansys.meshing.prime.CellZoneletType.SOLID

#### CellZoneletType.SOLID *= 17*

Cell zonelet type is solid.

<!-- !! processed by numpydoc !! -->
