# ansys.meshing.prime.CreateZoneResults.print_default

#### *static* CreateZoneResults.print_default()

Print the default values of CreateZoneResults.

### Examples

```pycon
>>> CreateZoneResults.print_default()
```

<!-- !! processed by numpydoc !! -->
