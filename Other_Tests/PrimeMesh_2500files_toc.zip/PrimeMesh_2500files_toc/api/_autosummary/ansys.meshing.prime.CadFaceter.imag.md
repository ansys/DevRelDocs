# ansys.meshing.prime.CadFaceter.imag

#### CadFaceter.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
