# ansys.meshing.prime.BCsVolumetricModality.denominator

#### BCsVolumetricModality.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
