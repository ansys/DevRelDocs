# ansys.meshing.prime.CheckMeshResults.has_invalid_shape

#### *property* CheckMeshResults.has_invalid_shape*: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Indicates whether mesh has invalid shape.

<!-- !! processed by numpydoc !! -->
