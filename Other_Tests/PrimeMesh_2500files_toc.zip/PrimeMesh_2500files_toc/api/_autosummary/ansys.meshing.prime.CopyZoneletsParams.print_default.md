# ansys.meshing.prime.CopyZoneletsParams.print_default

#### *static* CopyZoneletsParams.print_default()

Print the default values of CopyZoneletsParams.

### Examples

```pycon
>>> CopyZoneletsParams.print_default()
```

<!-- !! processed by numpydoc !! -->
