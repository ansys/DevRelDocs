# ansys.meshing.prime.BCPair.print_default

#### *static* BCPair.print_default()

Print the default values of BCPair.

### Examples

```pycon
>>> BCPair.print_default()
```

<!-- !! processed by numpydoc !! -->
