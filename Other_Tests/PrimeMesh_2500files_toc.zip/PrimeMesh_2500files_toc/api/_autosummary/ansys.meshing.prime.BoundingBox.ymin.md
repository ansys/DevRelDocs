# ansys.meshing.prime.BoundingBox.ymin

#### *property* BoundingBox.ymin*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Minimal Y coordinate of the bounding box.

<!-- !! processed by numpydoc !! -->
