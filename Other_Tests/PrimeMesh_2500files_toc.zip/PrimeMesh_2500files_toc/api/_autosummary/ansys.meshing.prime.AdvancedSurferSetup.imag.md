# ansys.meshing.prime.AdvancedSurferSetup.imag

#### AdvancedSurferSetup.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
