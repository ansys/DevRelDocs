# ansys.meshing.prime.AdvancedSurferSetup.conjugate

#### AdvancedSurferSetup.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
