# ansys.meshing.prime.BCsVolumetricModality.imag

#### BCsVolumetricModality.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
