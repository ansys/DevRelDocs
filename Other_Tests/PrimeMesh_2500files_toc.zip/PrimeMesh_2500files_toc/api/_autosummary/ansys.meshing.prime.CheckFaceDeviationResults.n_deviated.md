# ansys.meshing.prime.CheckFaceDeviationResults.n_deviated

#### *property* CheckFaceDeviationResults.n_deviated*: [int](https://docs.python.org/3.11/library/functions.html#int)*

Number of faces with deviation.

<!-- !! processed by numpydoc !! -->
