# ansys.meshing.prime.CadRefacetingParams.print_default

#### *static* CadRefacetingParams.print_default()

Print the default values of CadRefacetingParams.

### Examples

```pycon
>>> CadRefacetingParams.print_default()
```

<!-- !! processed by numpydoc !! -->
