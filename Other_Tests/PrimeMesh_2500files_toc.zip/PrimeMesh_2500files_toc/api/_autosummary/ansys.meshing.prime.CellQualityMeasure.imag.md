# ansys.meshing.prime.CellQualityMeasure.imag

#### CellQualityMeasure.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
