# ansys.meshing.prime.CreateMaterialPointResults.error_code

#### *property* CreateMaterialPointResults.error_code*: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with create material point operation.

<!-- !! processed by numpydoc !! -->
