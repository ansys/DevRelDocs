# ansys.meshing.prime.CadFaceter.bit_length

#### CadFaceter.bit_length(/)

Number of bits necessary to represent self in binary.

```pycon
>>> bin(37)
'0b100101'
>>> (37).bit_length()
6
```

<!-- !! processed by numpydoc !! -->
