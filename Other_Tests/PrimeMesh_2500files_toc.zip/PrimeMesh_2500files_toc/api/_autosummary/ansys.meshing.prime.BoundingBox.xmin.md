# ansys.meshing.prime.BoundingBox.xmin

#### *property* BoundingBox.xmin*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Minimal X coordinate of the bounding box.

<!-- !! processed by numpydoc !! -->
