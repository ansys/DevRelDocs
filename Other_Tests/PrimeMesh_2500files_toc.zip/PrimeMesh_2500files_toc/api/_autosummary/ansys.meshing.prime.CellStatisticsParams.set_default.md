# ansys.meshing.prime.CellStatisticsParams.set_default

#### *static* CellStatisticsParams.set_default(get_volume=None)

Set the default values of CellStatisticsParams.

* **Parameters:**
  **get_volume: bool, optional**
  : Provides option to compute and get cumulative cell volume.

<!-- !! processed by numpydoc !! -->
