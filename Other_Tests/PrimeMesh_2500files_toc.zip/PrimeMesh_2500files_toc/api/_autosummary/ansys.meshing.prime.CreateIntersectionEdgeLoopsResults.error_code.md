# ansys.meshing.prime.CreateIntersectionEdgeLoopsResults.error_code

#### *property* CreateIntersectionEdgeLoopsResults.error_code*: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code returned by edge extraction function.

<!-- !! processed by numpydoc !! -->
