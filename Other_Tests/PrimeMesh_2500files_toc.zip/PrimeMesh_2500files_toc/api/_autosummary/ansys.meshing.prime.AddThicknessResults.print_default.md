# ansys.meshing.prime.AddThicknessResults.print_default

#### *static* AddThicknessResults.print_default()

Print the default values of AddThicknessResults.

### Examples

```pycon
>>> AddThicknessResults.print_default()
```

<!-- !! processed by numpydoc !! -->
