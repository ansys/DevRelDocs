# ansys.meshing.prime.CreateBOIParams.print_default

#### *static* CreateBOIParams.print_default()

Print the default values of CreateBOIParams.

### Examples

```pycon
>>> CreateBOIParams.print_default()
```

<!-- !! processed by numpydoc !! -->
