# ansys.meshing.prime.AddThicknessParams.print_default

#### *static* AddThicknessParams.print_default()

Print the default values of AddThicknessParams.

### Examples

```pycon
>>> AddThicknessParams.print_default()
```

<!-- !! processed by numpydoc !! -->
