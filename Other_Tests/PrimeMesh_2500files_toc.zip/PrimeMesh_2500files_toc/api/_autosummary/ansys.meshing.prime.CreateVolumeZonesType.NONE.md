# ansys.meshing.prime.CreateVolumeZonesType.NONE

#### CreateVolumeZonesType.NONE *= 0*

Option to not create volume zones.

<!-- !! processed by numpydoc !! -->
