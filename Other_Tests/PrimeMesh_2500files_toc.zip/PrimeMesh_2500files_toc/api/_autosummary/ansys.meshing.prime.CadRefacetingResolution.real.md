# ansys.meshing.prime.CadRefacetingResolution.real

#### CadRefacetingResolution.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
