# ansys.meshing.prime.CheckMeshResults.warning_codes

#### *property* CheckMeshResults.warning_codes*: [List](https://docs.python.org/3.11/library/typing.html#typing.List)[[WarningCode](ansys.meshing.prime.WarningCode.md#ansys.meshing.prime.WarningCode)]*

Warning codes associated with the check grid operation.

<!-- !! processed by numpydoc !! -->
