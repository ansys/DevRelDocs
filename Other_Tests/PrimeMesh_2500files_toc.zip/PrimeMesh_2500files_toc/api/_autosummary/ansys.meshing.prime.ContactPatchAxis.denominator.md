# ansys.meshing.prime.ContactPatchAxis.denominator

#### ContactPatchAxis.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
