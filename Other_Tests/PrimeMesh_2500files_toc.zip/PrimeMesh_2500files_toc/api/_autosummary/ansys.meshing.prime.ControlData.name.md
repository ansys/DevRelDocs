# ansys.meshing.prime.ControlData.name

#### *property* ControlData.name

Get the name of ControlData.

<!-- !! processed by numpydoc !! -->
