# ansys.meshing.prime.CollapseResults.print_default

#### *static* CollapseResults.print_default()

Print the default values of CollapseResults.

### Examples

```pycon
>>> CollapseResults.print_default()
```

<!-- !! processed by numpydoc !! -->
