# ansys.meshing.prime.AddThicknessParams.suggested_part_name

#### *property* AddThicknessParams.suggested_part_name*: [str](https://docs.python.org/3.11/library/stdtypes.html#str)*

Suggested part name for created patching surfaces.

<!-- !! processed by numpydoc !! -->
