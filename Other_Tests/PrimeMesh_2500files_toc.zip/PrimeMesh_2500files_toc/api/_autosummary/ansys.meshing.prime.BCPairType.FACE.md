# ansys.meshing.prime.BCPairType.FACE

#### BCPairType.FACE *= 1*

Option to specify face zonelet as boundary condition pair.

<!-- !! processed by numpydoc !! -->
