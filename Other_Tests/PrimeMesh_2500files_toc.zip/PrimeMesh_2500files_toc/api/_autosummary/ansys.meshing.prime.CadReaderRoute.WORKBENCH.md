# ansys.meshing.prime.CadReaderRoute.WORKBENCH

#### CadReaderRoute.WORKBENCH *= 2*

Denotes WorkBench as CAD reader route.

<!-- !! processed by numpydoc !! -->
