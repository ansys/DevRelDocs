# ansys.meshing.prime.CellQualityMeasure.numerator

#### CellQualityMeasure.numerator

the numerator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
