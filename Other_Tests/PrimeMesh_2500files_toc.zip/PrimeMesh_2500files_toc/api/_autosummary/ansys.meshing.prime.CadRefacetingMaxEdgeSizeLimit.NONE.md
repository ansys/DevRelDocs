# ansys.meshing.prime.CadRefacetingMaxEdgeSizeLimit.NONE

#### CadRefacetingMaxEdgeSizeLimit.NONE *= 0*

Denotes no maximum edge size limit for CAD faceting.

<!-- !! processed by numpydoc !! -->
