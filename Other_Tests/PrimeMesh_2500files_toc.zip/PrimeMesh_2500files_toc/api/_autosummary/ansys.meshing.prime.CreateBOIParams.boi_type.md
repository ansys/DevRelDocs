# ansys.meshing.prime.CreateBOIParams.boi_type

#### *property* CreateBOIParams.boi_type*: [BOIType](ansys.meshing.prime.BOIType.md#ansys.meshing.prime.BOIType)*

Type of BOI offsetting.

<!-- !! processed by numpydoc !! -->
