# ansys.meshing.prime.CreateVolumeZonesType.PERNAMESOURCE

#### CreateVolumeZonesType.PERNAMESOURCE *= 2*

Option to create zone per name computed from face zonelets of volume. Single zone is created for multiple volumes if same zone name is identified using face zonelets for the volumes.

<!-- !! processed by numpydoc !! -->
