# ansys.meshing.prime.CreateContactPatchParams.suggested_label_prefix

#### *property* CreateContactPatchParams.suggested_label_prefix*: [str](https://docs.python.org/3.11/library/stdtypes.html#str)*

Suggested label name for created contact patch surfaces.

<!-- !! processed by numpydoc !! -->
