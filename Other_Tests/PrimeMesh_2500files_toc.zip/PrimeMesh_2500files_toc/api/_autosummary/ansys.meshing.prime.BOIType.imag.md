# ansys.meshing.prime.BOIType.imag

#### BOIType.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
