# ansys.meshing.prime.CadRefacetingParams.cad_faceter

#### *property* CadRefacetingParams.cad_faceter*: [CadFaceter](ansys.meshing.prime.CadFaceter.md#ansys.meshing.prime.CadFaceter)*

Specify the available choices for faceter. The available options are Acis, Parasolid.

<!-- !! processed by numpydoc !! -->
