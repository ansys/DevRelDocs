# ansys.meshing.prime.CreateIntersectionEdgeLoopsResults.print_default

#### *static* CreateIntersectionEdgeLoopsResults.print_default()

Print the default values of CreateIntersectionEdgeLoopsResults.

### Examples

```pycon
>>> CreateIntersectionEdgeLoopsResults.print_default()
```

<!-- !! processed by numpydoc !! -->
