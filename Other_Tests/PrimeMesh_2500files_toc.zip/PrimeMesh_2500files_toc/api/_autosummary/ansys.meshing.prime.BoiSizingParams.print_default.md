# ansys.meshing.prime.BoiSizingParams.print_default

#### *static* BoiSizingParams.print_default()

Print the default values of BoiSizingParams.

### Examples

```pycon
>>> BoiSizingParams.print_default()
```

<!-- !! processed by numpydoc !! -->
