# ansys.meshing.prime.AddThicknessParams.thickness

#### *property* AddThicknessParams.thickness*: [float](https://docs.python.org/3.11/library/functions.html#float)*

To assign the offset distance of inflation.

<!-- !! processed by numpydoc !! -->
