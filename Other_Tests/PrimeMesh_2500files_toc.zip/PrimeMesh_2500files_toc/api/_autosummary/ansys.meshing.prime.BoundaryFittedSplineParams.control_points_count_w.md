# ansys.meshing.prime.BoundaryFittedSplineParams.control_points_count_w

#### *property* BoundaryFittedSplineParams.control_points_count_w*: [int](https://docs.python.org/3.11/library/functions.html#int)*

Spline control points count in W direction. Used in manual control points selection mode.

<!-- !! processed by numpydoc !! -->
