# ansys.meshing.prime.CellZoneletType.conjugate

#### CellZoneletType.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
