# ansys.meshing.prime.CreateMaterialPointResults.print_default

#### *static* CreateMaterialPointResults.print_default()

Print the default values of CreateMaterialPointResults.

### Examples

```pycon
>>> CreateMaterialPointResults.print_default()
```

<!-- !! processed by numpydoc !! -->
