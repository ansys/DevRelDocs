# ansys.meshing.prime.CadRefacetingResolution.COARSE

#### CadRefacetingResolution.COARSE *= 0*

Denotes coarse resolution of CAD faceting.

<!-- !! processed by numpydoc !! -->
