# ansys.meshing.prime.CellStatisticsParams.print_default

#### *static* CellStatisticsParams.print_default()

Print the default values of CellStatisticsParams.

### Examples

```pycon
>>> CellStatisticsParams.print_default()
```

<!-- !! processed by numpydoc !! -->
