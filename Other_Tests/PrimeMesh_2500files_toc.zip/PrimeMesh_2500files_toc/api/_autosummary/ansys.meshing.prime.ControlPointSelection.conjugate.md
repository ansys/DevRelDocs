# ansys.meshing.prime.ControlPointSelection.conjugate

#### ControlPointSelection.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
