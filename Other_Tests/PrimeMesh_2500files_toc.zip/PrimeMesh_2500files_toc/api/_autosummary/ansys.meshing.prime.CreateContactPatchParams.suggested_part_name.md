# ansys.meshing.prime.CreateContactPatchParams.suggested_part_name

#### *property* CreateContactPatchParams.suggested_part_name*: [str](https://docs.python.org/3.11/library/stdtypes.html#str)*

Suggested part name for created contact patch surfaces.

<!-- !! processed by numpydoc !! -->
