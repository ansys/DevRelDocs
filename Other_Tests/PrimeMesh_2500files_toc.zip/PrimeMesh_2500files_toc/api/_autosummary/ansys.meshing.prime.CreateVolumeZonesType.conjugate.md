# ansys.meshing.prime.CreateVolumeZonesType.conjugate

#### CreateVolumeZonesType.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
