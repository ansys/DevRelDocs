# ansys.meshing.prime.CadRefacetingResolution.CUSTOM

#### CadRefacetingResolution.CUSTOM *= 3*

Denotes custom resolution of CAD faceting.

<!-- !! processed by numpydoc !! -->
