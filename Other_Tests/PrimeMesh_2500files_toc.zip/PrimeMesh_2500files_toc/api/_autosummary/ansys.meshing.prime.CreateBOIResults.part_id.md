# ansys.meshing.prime.CreateBOIResults.part_id

#### *property* CreateBOIResults.part_id*: [int](https://docs.python.org/3.11/library/functions.html#int)*

The BOI part id.

<!-- !! processed by numpydoc !! -->
