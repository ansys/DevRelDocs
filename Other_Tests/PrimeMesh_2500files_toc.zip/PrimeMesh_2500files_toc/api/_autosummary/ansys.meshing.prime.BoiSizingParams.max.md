# ansys.meshing.prime.BoiSizingParams.max

#### *property* BoiSizingParams.max*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum size used for computing edge and face size using boi size control.

<!-- !! processed by numpydoc !! -->
