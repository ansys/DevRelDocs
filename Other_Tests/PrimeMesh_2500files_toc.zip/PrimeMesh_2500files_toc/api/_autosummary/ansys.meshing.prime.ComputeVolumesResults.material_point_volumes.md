# ansys.meshing.prime.ComputeVolumesResults.material_point_volumes

#### *property* ComputeVolumesResults.material_point_volumes*: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Ids of computed volumes enclosing material points.

<!-- !! processed by numpydoc !! -->
