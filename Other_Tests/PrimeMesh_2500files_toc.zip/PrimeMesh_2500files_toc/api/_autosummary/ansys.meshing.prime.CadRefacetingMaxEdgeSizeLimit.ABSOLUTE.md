# ansys.meshing.prime.CadRefacetingMaxEdgeSizeLimit.ABSOLUTE

#### CadRefacetingMaxEdgeSizeLimit.ABSOLUTE *= 1*

Denotes absolute maximum edge size limit for CAD faceting.

<!-- !! processed by numpydoc !! -->
