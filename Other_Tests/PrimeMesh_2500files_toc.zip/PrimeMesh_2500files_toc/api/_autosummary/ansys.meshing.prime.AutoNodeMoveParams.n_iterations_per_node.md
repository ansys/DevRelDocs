# ansys.meshing.prime.AutoNodeMoveParams.n_iterations_per_node

#### *property* AutoNodeMoveParams.n_iterations_per_node*: [int](https://docs.python.org/3.11/library/functions.html#int)*

Number of iterations per node to be moved.

<!-- !! processed by numpydoc !! -->
