# ansys.meshing.prime.CheckFaceDeviationParams.distance

#### *property* CheckFaceDeviationParams.distance*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Distance above which deviated entities are collected.

<!-- !! processed by numpydoc !! -->
