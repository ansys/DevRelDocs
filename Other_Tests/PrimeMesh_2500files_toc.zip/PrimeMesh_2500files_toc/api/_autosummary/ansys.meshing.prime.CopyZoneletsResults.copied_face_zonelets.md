# ansys.meshing.prime.CopyZoneletsResults.copied_face_zonelets

#### *property* CopyZoneletsResults.copied_face_zonelets*: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[int](https://docs.python.org/3.11/library/functions.html#int)]*

Ids of the copied bounding faces of cell zonelets.

<!-- !! processed by numpydoc !! -->
