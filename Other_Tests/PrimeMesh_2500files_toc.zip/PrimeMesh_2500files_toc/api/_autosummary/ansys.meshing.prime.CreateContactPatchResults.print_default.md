# ansys.meshing.prime.CreateContactPatchResults.print_default

#### *static* CreateContactPatchResults.print_default()

Print the default values of CreateContactPatchResults.

### Examples

```pycon
>>> CreateContactPatchResults.print_default()
```

<!-- !! processed by numpydoc !! -->
