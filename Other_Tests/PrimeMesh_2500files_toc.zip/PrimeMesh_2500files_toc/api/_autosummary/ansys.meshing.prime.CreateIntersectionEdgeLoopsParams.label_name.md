# ansys.meshing.prime.CreateIntersectionEdgeLoopsParams.label_name

#### *property* CreateIntersectionEdgeLoopsParams.label_name*: [str](https://docs.python.org/3.11/library/stdtypes.html#str)*

Label name to be assigned to extracted features.

<!-- !! processed by numpydoc !! -->
