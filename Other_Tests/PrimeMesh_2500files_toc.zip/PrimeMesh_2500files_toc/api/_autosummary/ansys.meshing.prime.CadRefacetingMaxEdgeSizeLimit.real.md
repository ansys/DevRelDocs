# ansys.meshing.prime.CadRefacetingMaxEdgeSizeLimit.real

#### CadRefacetingMaxEdgeSizeLimit.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
