# ansys.meshing.prime.ControlPointSelection.real

#### ControlPointSelection.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
