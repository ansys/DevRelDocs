# ansys.meshing.prime.CreateVolumeZonesType.imag

#### CreateVolumeZonesType.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
