# ansys.meshing.prime.CdbSimulationType.conjugate

#### CdbSimulationType.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
