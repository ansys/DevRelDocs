# ansys.meshing.prime.CadFaceter.numerator

#### CadFaceter.numerator

the numerator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
