# ansys.meshing.prime.AutoMeshParams.hexcore

#### *property* AutoMeshParams.hexcore*: [HexCoreParams](ansys.meshing.prime.HexCoreParams.md#ansys.meshing.prime.HexCoreParams)*

Parameters to control hexahedral mesh generation.

<!-- !! processed by numpydoc !! -->
