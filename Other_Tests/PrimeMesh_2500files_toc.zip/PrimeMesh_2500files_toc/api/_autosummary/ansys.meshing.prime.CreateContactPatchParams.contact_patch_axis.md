# ansys.meshing.prime.CreateContactPatchParams.contact_patch_axis

#### *property* CreateContactPatchParams.contact_patch_axis*: [ContactPatchAxis](ansys.meshing.prime.ContactPatchAxis.md#ansys.meshing.prime.ContactPatchAxis)*

Assigns the contact patch direction.

<!-- !! processed by numpydoc !! -->
