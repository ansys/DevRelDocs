# ansys.meshing.prime.ComputeTopoVolumesResults.error_locations

#### *property* ComputeTopoVolumesResults.error_locations*: [Iterable](https://docs.python.org/3.11/library/typing.html#typing.Iterable)[[float](https://docs.python.org/3.11/library/functions.html#float)]*

Coordinates of problematic locations in the surface mesh.

<!-- !! processed by numpydoc !! -->
