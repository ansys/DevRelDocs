# ansys.meshing.prime.CurvatureSizingParams.max

#### *property* CurvatureSizingParams.max*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximum size used for computing edge and face size using curavture size control.

<!-- !! processed by numpydoc !! -->
