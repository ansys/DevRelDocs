# ansys.meshing.prime.AdvancedSurferSetup.denominator

#### AdvancedSurferSetup.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
