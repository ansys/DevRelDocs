# ansys.meshing.prime.CreateContactPatchParams.offset_distance

#### *property* CreateContactPatchParams.offset_distance*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Source offset distance value.

<!-- !! processed by numpydoc !! -->
