# ansys.meshing.prime.CurvatureSizingParams.growth_rate

#### *property* CurvatureSizingParams.growth_rate*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Growth rate used for transitioning from one element size to neighbor element size.

<!-- !! processed by numpydoc !! -->
