# ansys.meshing.prime.CadRefacetingResolution.conjugate

#### CadRefacetingResolution.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
