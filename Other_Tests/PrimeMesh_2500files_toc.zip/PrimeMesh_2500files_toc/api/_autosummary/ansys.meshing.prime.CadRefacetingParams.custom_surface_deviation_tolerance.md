# ansys.meshing.prime.CadRefacetingParams.custom_surface_deviation_tolerance

#### *property* CadRefacetingParams.custom_surface_deviation_tolerance*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Set custom tolerance for surface deviation in specified length unit.

<!-- !! processed by numpydoc !! -->
