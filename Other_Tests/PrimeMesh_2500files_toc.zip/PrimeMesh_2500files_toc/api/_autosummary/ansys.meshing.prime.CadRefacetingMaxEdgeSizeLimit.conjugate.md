# ansys.meshing.prime.CadRefacetingMaxEdgeSizeLimit.conjugate

#### CadRefacetingMaxEdgeSizeLimit.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
