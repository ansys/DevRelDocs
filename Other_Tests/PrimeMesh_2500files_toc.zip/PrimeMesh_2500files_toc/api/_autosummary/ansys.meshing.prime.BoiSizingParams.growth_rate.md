# ansys.meshing.prime.BoiSizingParams.growth_rate

#### *property* BoiSizingParams.growth_rate*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Growth rate used for transitioning from one element size to neighbor element size.

<!-- !! processed by numpydoc !! -->
