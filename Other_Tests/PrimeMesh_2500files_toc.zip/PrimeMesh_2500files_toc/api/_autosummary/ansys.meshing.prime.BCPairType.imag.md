# ansys.meshing.prime.BCPairType.imag

#### BCPairType.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
