# ansys.meshing.prime.ComputeVolumesResults.print_default

#### *static* ComputeVolumesResults.print_default()

Print the default values of ComputeVolumesResults.

### Examples

```pycon
>>> ComputeVolumesResults.print_default()
```

<!-- !! processed by numpydoc !! -->
