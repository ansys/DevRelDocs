# ansys.meshing.prime.CadReaderRoute.imag

#### CadReaderRoute.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
