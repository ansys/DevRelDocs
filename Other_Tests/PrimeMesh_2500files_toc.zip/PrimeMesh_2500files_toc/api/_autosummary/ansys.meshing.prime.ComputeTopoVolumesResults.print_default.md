# ansys.meshing.prime.ComputeTopoVolumesResults.print_default

#### *static* ComputeTopoVolumesResults.print_default()

Print the default values of ComputeTopoVolumesResults.

### Examples

```pycon
>>> ComputeTopoVolumesResults.print_default()
```

<!-- !! processed by numpydoc !! -->
