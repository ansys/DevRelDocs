# ansys.meshing.prime.AddToZoneResults.warning_codes

#### *property* AddToZoneResults.warning_codes*: [List](https://docs.python.org/3.11/library/typing.html#typing.List)[[WarningCode](ansys.meshing.prime.WarningCode.md#ansys.meshing.prime.WarningCode)]*

Warning codes associated with the add to zone operation.

<!-- !! processed by numpydoc !! -->
