# ansys.meshing.prime.CdbSimulationType.IMPLICIT

#### CdbSimulationType.IMPLICIT *= 0*

Implicit simulation.

<!-- !! processed by numpydoc !! -->
