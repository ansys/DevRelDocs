# ansys.meshing.prime.ContactPatchAxis.real

#### ContactPatchAxis.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
