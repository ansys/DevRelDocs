# ansys.meshing.prime.AutoMeshParams.print_default

#### *static* AutoMeshParams.print_default()

Print the default values of AutoMeshParams.

### Examples

```pycon
>>> AutoMeshParams.print_default()
```

<!-- !! processed by numpydoc !! -->
