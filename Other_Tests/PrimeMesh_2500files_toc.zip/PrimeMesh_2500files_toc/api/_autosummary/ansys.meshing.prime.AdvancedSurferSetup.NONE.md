# ansys.meshing.prime.AdvancedSurferSetup.NONE

#### AdvancedSurferSetup.NONE *= 0*

Option to define no advanced settings.

<!-- !! processed by numpydoc !! -->
