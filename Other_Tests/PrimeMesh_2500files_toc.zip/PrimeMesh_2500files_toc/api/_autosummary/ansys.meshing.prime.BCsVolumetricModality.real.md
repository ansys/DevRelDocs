# ansys.meshing.prime.BCsVolumetricModality.real

#### BCsVolumetricModality.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
