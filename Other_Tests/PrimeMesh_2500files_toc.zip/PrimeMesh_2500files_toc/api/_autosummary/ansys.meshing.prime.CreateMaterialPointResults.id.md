# ansys.meshing.prime.CreateMaterialPointResults.id

#### *property* CreateMaterialPointResults.id*: [int](https://docs.python.org/3.11/library/functions.html#int)*

Id of the material point created.

<!-- !! processed by numpydoc !! -->
