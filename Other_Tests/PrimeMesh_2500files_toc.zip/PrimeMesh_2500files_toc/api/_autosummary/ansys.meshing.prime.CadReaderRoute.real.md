# ansys.meshing.prime.CadReaderRoute.real

#### CadReaderRoute.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
