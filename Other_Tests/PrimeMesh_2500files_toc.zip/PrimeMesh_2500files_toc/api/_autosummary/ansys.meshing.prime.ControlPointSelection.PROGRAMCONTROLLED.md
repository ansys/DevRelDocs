# ansys.meshing.prime.ControlPointSelection.PROGRAMCONTROLLED

#### ControlPointSelection.PROGRAMCONTROLLED *= 1*

Program controlled spline control point selection.

<!-- !! processed by numpydoc !! -->
