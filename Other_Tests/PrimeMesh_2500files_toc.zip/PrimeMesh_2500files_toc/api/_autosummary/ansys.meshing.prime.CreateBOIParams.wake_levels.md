# ansys.meshing.prime.CreateBOIParams.wake_levels

#### *property* CreateBOIParams.wake_levels*: [int](https://docs.python.org/3.11/library/functions.html#int)*

BOI levels.

<!-- !! processed by numpydoc !! -->
