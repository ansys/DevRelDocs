# ansys.meshing.prime.CollapseResults.n_splits

#### *property* CollapseResults.n_splits*: [int](https://docs.python.org/3.11/library/functions.html#int)*

Number of face elements split.

<!-- !! processed by numpydoc !! -->
