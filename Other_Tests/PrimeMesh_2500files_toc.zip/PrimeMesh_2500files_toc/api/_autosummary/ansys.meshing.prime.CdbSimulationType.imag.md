# ansys.meshing.prime.CdbSimulationType.imag

#### CdbSimulationType.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
