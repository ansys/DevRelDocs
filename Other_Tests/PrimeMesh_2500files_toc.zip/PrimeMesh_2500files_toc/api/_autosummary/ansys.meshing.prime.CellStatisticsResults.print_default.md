# ansys.meshing.prime.CellStatisticsResults.print_default

#### *static* CellStatisticsResults.print_default()

Print the default values of CellStatisticsResults.

### Examples

```pycon
>>> CellStatisticsResults.print_default()
```

<!-- !! processed by numpydoc !! -->
