# ansys.meshing.prime.CadRefacetingResolution.denominator

#### CadRefacetingResolution.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
