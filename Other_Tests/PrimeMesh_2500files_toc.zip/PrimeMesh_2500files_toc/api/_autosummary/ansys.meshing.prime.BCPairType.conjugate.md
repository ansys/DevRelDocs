# ansys.meshing.prime.BCPairType.conjugate

#### BCPairType.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
