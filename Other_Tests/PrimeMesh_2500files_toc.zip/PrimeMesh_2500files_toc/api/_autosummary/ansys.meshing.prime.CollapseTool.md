<!-- vale off -->

# CollapseTool

### *class* ansys.meshing.prime.CollapseTool(model)

Performs various collapse operations. For example, split and collapse on face zonelets.

<!-- !! processed by numpydoc !! -->

### Methods

| [`CollapseTool.split_and_collapse_on_zonelets`](ansys.meshing.prime.CollapseTool.split_and_collapse_on_zonelets.md#ansys.meshing.prime.CollapseTool.split_and_collapse_on_zonelets)(...)   | Split and collapse elements on face zonelets with the specified register id.   |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------|
<!-- vale on -->
