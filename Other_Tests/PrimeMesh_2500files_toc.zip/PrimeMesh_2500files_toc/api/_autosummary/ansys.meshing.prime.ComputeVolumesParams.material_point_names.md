# ansys.meshing.prime.ComputeVolumesParams.material_point_names

#### *property* ComputeVolumesParams.material_point_names*: [List](https://docs.python.org/3.11/library/typing.html#typing.List)[[str](https://docs.python.org/3.11/library/stdtypes.html#str)]*

Material point names provided to identify volumes. Material point names will have precedence over the volume names.

<!-- !! processed by numpydoc !! -->
