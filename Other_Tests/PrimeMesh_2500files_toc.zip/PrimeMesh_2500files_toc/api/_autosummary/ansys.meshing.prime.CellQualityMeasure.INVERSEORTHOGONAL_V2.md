# ansys.meshing.prime.CellQualityMeasure.INVERSEORTHOGONAL_V2

#### CellQualityMeasure.INVERSEORTHOGONAL_V2 *= 25*

The advanced inverse orthogonal metric ranges between 0 (best) and 1 (worst).

<!-- !! processed by numpydoc !! -->
