# ansys.meshing.prime.AddLabelResults.set_default

#### *static* AddLabelResults.set_default(error_code=None)

Set the default values of AddLabelResults.

* **Parameters:**
  **error_code: ErrorCode, optional**
  : Error code associated with the add label operation.

<!-- !! processed by numpydoc !! -->
