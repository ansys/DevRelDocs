# ansys.meshing.prime.BCPairType.denominator

#### BCPairType.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
