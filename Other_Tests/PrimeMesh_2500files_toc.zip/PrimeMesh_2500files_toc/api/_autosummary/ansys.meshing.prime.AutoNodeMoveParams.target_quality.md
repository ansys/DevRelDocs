# ansys.meshing.prime.AutoNodeMoveParams.target_quality

#### *property* AutoNodeMoveParams.target_quality*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Specify target quality used for the mesh improvement based on specified quality measure.

<!-- !! processed by numpydoc !! -->
