# ansys.meshing.prime.CdbSimulationType.real

#### CdbSimulationType.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
