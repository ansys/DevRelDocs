# ansys.meshing.prime.CheckMeshResults.print_default

#### *static* CheckMeshResults.print_default()

Print the default values of CheckMeshResults.

### Examples

```pycon
>>> CheckMeshResults.print_default()
```

<!-- !! processed by numpydoc !! -->
