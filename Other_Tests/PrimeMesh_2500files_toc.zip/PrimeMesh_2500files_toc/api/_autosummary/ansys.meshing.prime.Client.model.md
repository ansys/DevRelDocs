# ansys.meshing.prime.Client.model

#### *property* Client.model

Get model associated with the client.

<!-- !! processed by numpydoc !! -->
