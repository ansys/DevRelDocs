# ansys.meshing.prime.BOIType.real

#### BOIType.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
