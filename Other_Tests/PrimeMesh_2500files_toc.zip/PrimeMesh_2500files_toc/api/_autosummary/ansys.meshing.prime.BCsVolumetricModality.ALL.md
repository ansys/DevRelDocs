# ansys.meshing.prime.BCsVolumetricModality.ALL

#### BCsVolumetricModality.ALL *= 2*

Option to identify all nodes expect fixed nodes as morphable nodes from the input volumetric mesh.

<!-- !! processed by numpydoc !! -->
