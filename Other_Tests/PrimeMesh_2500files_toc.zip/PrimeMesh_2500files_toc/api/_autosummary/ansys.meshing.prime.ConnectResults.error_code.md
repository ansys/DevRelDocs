# ansys.meshing.prime.ConnectResults.error_code

#### *property* ConnectResults.error_code*: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error Code associated with failure of operation.

<!-- !! processed by numpydoc !! -->
