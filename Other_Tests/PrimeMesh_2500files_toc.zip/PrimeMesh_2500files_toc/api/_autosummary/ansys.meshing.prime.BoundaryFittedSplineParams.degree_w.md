# ansys.meshing.prime.BoundaryFittedSplineParams.degree_w

#### *property* BoundaryFittedSplineParams.degree_w*: [int](https://docs.python.org/3.11/library/functions.html#int)*

Degree of spline in w direction.

<!-- !! processed by numpydoc !! -->
