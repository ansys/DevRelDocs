# ansys.meshing.prime.CadRefacetingMaxEdgeSizeLimit.RELATIVE

#### CadRefacetingMaxEdgeSizeLimit.RELATIVE *= 2*

Denotes relative maximum edge size limit for CAD faceting.

<!-- !! processed by numpydoc !! -->
