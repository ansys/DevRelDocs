# ansys.meshing.prime.CadFaceter.ACIS

#### CadFaceter.ACIS *= 0*

Denotes CAD faceter is Acis.

<!-- !! processed by numpydoc !! -->
