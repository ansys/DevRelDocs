# ansys.meshing.prime.AutoNodeMoveParams.dihedral_angle

#### *property* AutoNodeMoveParams.dihedral_angle*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Dihedral angle used to mantain features of boundary face zonelets.

<!-- !! processed by numpydoc !! -->
