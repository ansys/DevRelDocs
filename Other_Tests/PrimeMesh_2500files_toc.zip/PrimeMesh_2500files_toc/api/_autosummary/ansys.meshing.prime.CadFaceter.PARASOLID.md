# ansys.meshing.prime.CadFaceter.PARASOLID

#### CadFaceter.PARASOLID *= 1*

Denotes CAD faceter is Parasolid.

<!-- !! processed by numpydoc !! -->
