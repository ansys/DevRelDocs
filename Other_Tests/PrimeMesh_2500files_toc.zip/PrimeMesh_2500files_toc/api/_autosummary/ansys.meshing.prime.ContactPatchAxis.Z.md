# ansys.meshing.prime.ContactPatchAxis.Z

#### ContactPatchAxis.Z *= 3*

Flow or wake inflation in the Z direction for BOI creation.

<!-- !! processed by numpydoc !! -->
