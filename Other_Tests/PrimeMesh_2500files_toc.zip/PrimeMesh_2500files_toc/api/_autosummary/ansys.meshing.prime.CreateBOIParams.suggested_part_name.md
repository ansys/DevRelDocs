# ansys.meshing.prime.CreateBOIParams.suggested_part_name

#### *property* CreateBOIParams.suggested_part_name*: [str](https://docs.python.org/3.11/library/stdtypes.html#str)*

Suggested part name for created BOI surfaces.

<!-- !! processed by numpydoc !! -->
