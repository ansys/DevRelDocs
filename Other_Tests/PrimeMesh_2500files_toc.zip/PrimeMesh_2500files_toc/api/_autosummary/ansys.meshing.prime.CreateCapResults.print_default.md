# ansys.meshing.prime.CreateCapResults.print_default

#### *static* CreateCapResults.print_default()

Print the default values of CreateCapResults.

### Examples

```pycon
>>> CreateCapResults.print_default()
```

<!-- !! processed by numpydoc !! -->
