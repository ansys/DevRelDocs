# ansys.meshing.prime.CreateVolumeZonesType.numerator

#### CreateVolumeZonesType.numerator

the numerator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
