# ansys.meshing.prime.CreateBOIParams.side_scale

#### *property* CreateBOIParams.side_scale*: [float](https://docs.python.org/3.11/library/functions.html#float)*

BOI side scaling factor.

<!-- !! processed by numpydoc !! -->
