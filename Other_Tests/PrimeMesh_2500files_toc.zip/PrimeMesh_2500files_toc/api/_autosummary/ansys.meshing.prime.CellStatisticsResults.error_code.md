# ansys.meshing.prime.CellStatisticsResults.error_code

#### *property* CellStatisticsResults.error_code*: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with the cell statistics function.

<!-- !! processed by numpydoc !! -->
