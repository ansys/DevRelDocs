# ansys.meshing.prime.CellQualityMeasure.conjugate

#### CellQualityMeasure.conjugate()

Returns self, the complex conjugate of any int.

<!-- !! processed by numpydoc !! -->
