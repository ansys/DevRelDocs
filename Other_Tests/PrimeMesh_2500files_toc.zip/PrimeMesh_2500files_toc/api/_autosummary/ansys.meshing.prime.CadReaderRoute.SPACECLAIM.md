# ansys.meshing.prime.CadReaderRoute.SPACECLAIM

#### CadReaderRoute.SPACECLAIM *= 3*

Denotes SpaceClaim as CAD reader route.

<!-- !! processed by numpydoc !! -->
