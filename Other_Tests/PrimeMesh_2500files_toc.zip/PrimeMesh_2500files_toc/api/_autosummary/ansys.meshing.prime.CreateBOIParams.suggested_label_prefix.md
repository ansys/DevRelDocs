# ansys.meshing.prime.CreateBOIParams.suggested_label_prefix

#### *property* CreateBOIParams.suggested_label_prefix*: [str](https://docs.python.org/3.11/library/stdtypes.html#str)*

Suggested label name for created BOI surfaces.

<!-- !! processed by numpydoc !! -->
