# ansys.meshing.prime.AutoMeshParams.tet

#### *property* AutoMeshParams.tet*: [TetParams](ansys.meshing.prime.TetParams.md#ansys.meshing.prime.TetParams)*

Parameters to control tetrahedral mesh generation.

<!-- !! processed by numpydoc !! -->
