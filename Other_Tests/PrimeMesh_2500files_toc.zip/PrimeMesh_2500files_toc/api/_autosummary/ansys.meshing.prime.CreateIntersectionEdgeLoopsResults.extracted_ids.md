# ansys.meshing.prime.CreateIntersectionEdgeLoopsResults.extracted_ids

#### *property* CreateIntersectionEdgeLoopsResults.extracted_ids*: [List](https://docs.python.org/3.11/library/typing.html#typing.List)[[ExtractedFeatureIds](ansys.meshing.prime.ExtractedFeatureIds.md#ansys.meshing.prime.ExtractedFeatureIds)]*

List of ExtractedFeatureIds that contains ids of extracted edges.

<!-- !! processed by numpydoc !! -->
