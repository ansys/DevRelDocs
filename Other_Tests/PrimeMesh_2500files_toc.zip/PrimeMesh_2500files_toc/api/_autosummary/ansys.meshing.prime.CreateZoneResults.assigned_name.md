# ansys.meshing.prime.CreateZoneResults.assigned_name

#### *property* CreateZoneResults.assigned_name*: [str](https://docs.python.org/3.11/library/stdtypes.html#str)*

Assigned name of newly created zone.

<!-- !! processed by numpydoc !! -->
