# ansys.meshing.prime.BoundaryFittedSplineParams.control_point_selection_type

#### *property* BoundaryFittedSplineParams.control_point_selection_type*: [ControlPointSelection](ansys.meshing.prime.ControlPointSelection.md#ansys.meshing.prime.ControlPointSelection)*

Spline control points selection type.

<!-- !! processed by numpydoc !! -->
