# ansys.meshing.prime.CadRefacetingParams.custom_normal_angle_tolerance

#### *property* CadRefacetingParams.custom_normal_angle_tolerance*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Set custom tolerance for normal angle in degree.

<!-- !! processed by numpydoc !! -->
