# ansys.meshing.prime.CurvatureSizingParams.use_cad_curvature

#### *property* CurvatureSizingParams.use_cad_curvature*: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Option to enable use of CAD curvature for computing edge and face size.

<!-- !! processed by numpydoc !! -->
