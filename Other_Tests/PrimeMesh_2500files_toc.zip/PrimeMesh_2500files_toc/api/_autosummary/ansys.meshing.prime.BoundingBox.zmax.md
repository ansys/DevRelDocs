# ansys.meshing.prime.BoundingBox.zmax

#### *property* BoundingBox.zmax*: [float](https://docs.python.org/3.11/library/functions.html#float)*

Maximal Z coordinate of the bounding box.

<!-- !! processed by numpydoc !! -->
