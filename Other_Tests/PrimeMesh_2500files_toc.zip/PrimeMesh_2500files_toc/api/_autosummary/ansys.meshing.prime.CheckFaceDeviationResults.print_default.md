# ansys.meshing.prime.CheckFaceDeviationResults.print_default

#### *static* CheckFaceDeviationResults.print_default()

Print the default values of CheckFaceDeviationResults.

### Examples

```pycon
>>> CheckFaceDeviationResults.print_default()
```

<!-- !! processed by numpydoc !! -->
