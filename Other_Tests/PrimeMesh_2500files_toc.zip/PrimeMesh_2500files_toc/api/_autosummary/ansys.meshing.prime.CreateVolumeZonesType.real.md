# ansys.meshing.prime.CreateVolumeZonesType.real

#### CreateVolumeZonesType.real

the real part of a complex number

<!-- !! processed by numpydoc !! -->
