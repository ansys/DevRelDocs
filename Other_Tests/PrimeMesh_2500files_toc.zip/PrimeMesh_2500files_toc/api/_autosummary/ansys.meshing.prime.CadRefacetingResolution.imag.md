# ansys.meshing.prime.CadRefacetingResolution.imag

#### CadRefacetingResolution.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
