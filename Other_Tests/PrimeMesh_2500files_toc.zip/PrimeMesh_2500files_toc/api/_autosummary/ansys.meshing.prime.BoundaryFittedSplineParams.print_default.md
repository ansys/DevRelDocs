# ansys.meshing.prime.BoundaryFittedSplineParams.print_default

#### *static* BoundaryFittedSplineParams.print_default()

Print the default values of BoundaryFittedSplineParams.

### Examples

```pycon
>>> BoundaryFittedSplineParams.print_default()
```

<!-- !! processed by numpydoc !! -->
