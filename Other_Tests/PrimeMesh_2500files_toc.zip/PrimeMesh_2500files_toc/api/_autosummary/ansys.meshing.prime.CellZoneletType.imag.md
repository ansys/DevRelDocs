# ansys.meshing.prime.CellZoneletType.imag

#### CellZoneletType.imag

the imaginary part of a complex number

<!-- !! processed by numpydoc !! -->
