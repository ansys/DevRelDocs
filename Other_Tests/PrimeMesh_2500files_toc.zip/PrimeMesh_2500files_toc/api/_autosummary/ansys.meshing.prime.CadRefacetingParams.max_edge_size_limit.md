# ansys.meshing.prime.CadRefacetingParams.max_edge_size_limit

#### *property* CadRefacetingParams.max_edge_size_limit*: [CadRefacetingMaxEdgeSizeLimit](ansys.meshing.prime.CadRefacetingMaxEdgeSizeLimit.md#ansys.meshing.prime.CadRefacetingMaxEdgeSizeLimit)*

Specify maximum edge size limit for faceting.

<!-- !! processed by numpydoc !! -->
