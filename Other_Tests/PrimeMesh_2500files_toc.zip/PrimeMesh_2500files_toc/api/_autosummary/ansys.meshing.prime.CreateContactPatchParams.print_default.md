# ansys.meshing.prime.CreateContactPatchParams.print_default

#### *static* CreateContactPatchParams.print_default()

Print the default values of CreateContactPatchParams.

### Examples

```pycon
>>> CreateContactPatchParams.print_default()
```

<!-- !! processed by numpydoc !! -->
