# ansys.meshing.prime.CellZoneletType.denominator

#### CellZoneletType.denominator

the denominator of a rational number in lowest terms

<!-- !! processed by numpydoc !! -->
