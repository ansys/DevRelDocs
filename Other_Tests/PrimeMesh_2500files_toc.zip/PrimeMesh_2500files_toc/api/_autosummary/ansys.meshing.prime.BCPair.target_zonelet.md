# ansys.meshing.prime.BCPair.target_zonelet

#### *property* BCPair.target_zonelet*: [int](https://docs.python.org/3.11/library/functions.html#int)*

Id of target zonelet.

<!-- !! processed by numpydoc !! -->
