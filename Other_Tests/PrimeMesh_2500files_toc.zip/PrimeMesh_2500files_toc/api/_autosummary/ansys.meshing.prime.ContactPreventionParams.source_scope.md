# ansys.meshing.prime.ContactPreventionParams.source_scope

#### *property* ContactPreventionParams.source_scope*: [ScopeDefinition](ansys.meshing.prime.ScopeDefinition.md#ansys.meshing.prime.ScopeDefinition)*

Source scope used for contact prevention control.

<!-- !! processed by numpydoc !! -->
