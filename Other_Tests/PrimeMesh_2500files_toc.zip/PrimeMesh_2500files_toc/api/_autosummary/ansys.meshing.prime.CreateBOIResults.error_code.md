# ansys.meshing.prime.CreateBOIResults.error_code

#### *property* CreateBOIResults.error_code*: [ErrorCode](ansys.meshing.prime.ErrorCode.md#ansys.meshing.prime.ErrorCode)*

Error code associated with failure of operation.

<!-- !! processed by numpydoc !! -->
