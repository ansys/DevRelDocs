# ansys.meshing.prime.CellQualityMeasure.ASPECTRATIO

#### CellQualityMeasure.ASPECTRATIO *= 5*

The Aspect Ratio metric is greater than 1. A value of 1 indicates an equilateral cell (best) and a value of 20(e.g) indicates a stretched cell (worst).

<!-- !! processed by numpydoc !! -->
