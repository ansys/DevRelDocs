# ansys.meshing.prime.CadReaderRoute.bit_length

#### CadReaderRoute.bit_length(/)

Number of bits necessary to represent self in binary.

```pycon
>>> bin(37)
'0b100101'
>>> (37).bit_length()
6
```

<!-- !! processed by numpydoc !! -->
