# ansys.meshing.prime.CollapseParams.print_default

#### *static* CollapseParams.print_default()

Print the default values of CollapseParams.

### Examples

```pycon
>>> CollapseParams.print_default()
```

<!-- !! processed by numpydoc !! -->
