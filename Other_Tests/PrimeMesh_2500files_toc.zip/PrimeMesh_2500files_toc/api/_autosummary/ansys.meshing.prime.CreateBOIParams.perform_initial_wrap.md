# ansys.meshing.prime.CreateBOIParams.perform_initial_wrap

#### *property* CreateBOIParams.perform_initial_wrap*: [bool](https://docs.python.org/3.11/library/functions.html#bool)*

Perform an initial wrap to create a BOI if BOI type is OFFSETSURFACE.

<!-- !! processed by numpydoc !! -->
