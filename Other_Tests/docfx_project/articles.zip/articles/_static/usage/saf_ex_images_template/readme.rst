Template images folder for SAF usage examples







    .. # Images:
      Create an image folder using this convention:  doc/source/_static/usage/example_name
      If using `figure` instead of ``image``, be sure to update the placeholder caption.
