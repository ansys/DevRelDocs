<a id="dev-prepare"></a>

<a id="prepare"></a>

# Prepare

> ##### Summary
> 
> To prepare for solution development, generate a solution project, set up the solution development environment, and execute the solution application.
<br/>

Generate a solution application project using the solution template.

Create the Python ecosystem required for solution development.

Execute the solution using the `saf-run` command.

<!-- Definitions of interpreted text roles (classes) for S5/HTML data. -->
<!-- This data file has been placed in the public domain. -->
<!-- Colours
======= -->
<!-- Text Sizes
========== -->
<!-- Display in Slides (Presentation Mode) Only
========================================== -->
<!-- Display in Outline Mode Only
============================ -->
<!-- Display in Print Only
===================== -->
<!-- Display in Handout Mode Only
============================ -->
<!-- Incremental Display
=================== -->
