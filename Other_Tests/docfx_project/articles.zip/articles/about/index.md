<a id="saf-about-index"></a>

<a id="solutions-overview"></a>

# Solutions overview

> ##### Summary
> 
> Learn about solution applications, the Ansys Solution Applications Framework (SAF), and the Ansys Developer portal.
<br/>

Learn solution application basics: what they are and why to create them.

Get a high-level introduction to Ansys SAF, our low-code framework for solution development.

Join the Ansys development community and connect with other solution developers.

<!-- Definitions of interpreted text roles (classes) for S5/HTML data. -->
<!-- This data file has been placed in the public domain. -->
<!-- Colours
======= -->
<!-- Text Sizes
========== -->
<!-- Display in Slides (Presentation Mode) Only
========================================== -->
<!-- Display in Outline Mode Only
============================ -->
<!-- Display in Print Only
===================== -->
<!-- Display in Handout Mode Only
============================ -->
<!-- Incremental Display
=================== -->
