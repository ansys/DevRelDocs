<a id="getting-started-index"></a>

<a id="getting-started"></a>

# Getting started

> ##### Summary
> 
> Get started developing a solution application immediately.
<br/>

Get ready to start your solution development journey.

Quickly create, set up, and run a minimal solution application.

<!-- Definitions of interpreted text roles (classes) for S5/HTML data. -->
<!-- This data file has been placed in the public domain. -->
<!-- Colours
======= -->
<!-- Text Sizes
========== -->
<!-- Display in Slides (Presentation Mode) Only
========================================== -->
<!-- Display in Outline Mode Only
============================ -->
<!-- Display in Print Only
===================== -->
<!-- Display in Handout Mode Only
============================ -->
<!-- Incremental Display
=================== -->
