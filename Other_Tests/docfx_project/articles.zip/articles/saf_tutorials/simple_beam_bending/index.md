<a id="simple-beam-bending-tutorial-index"></a>

<a id="simple-beam-bending"></a>

# Simple beam bending

Setup for the development environment

Definition of the engineering problem to be solved

Identification of Shared Technology Components

Initialization and setup of the solution.

Customization of the solution

<!-- Definitions of interpreted text roles (classes) for S5/HTML data. -->
<!-- This data file has been placed in the public domain. -->
<!-- Colours
======= -->
<!-- Text Sizes
========== -->
<!-- Display in Slides (Presentation Mode) Only
========================================== -->
<!-- Display in Outline Mode Only
============================ -->
<!-- Display in Print Only
===================== -->
<!-- Display in Handout Mode Only
============================ -->
<!-- Incremental Display
=================== -->
