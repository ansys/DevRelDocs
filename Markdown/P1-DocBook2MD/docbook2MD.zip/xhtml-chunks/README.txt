This output is from Docbook.
We do a XHTML publication of Docbook to resolve all external references and variables. Then we use Turndown to convert XHTML to MD.
The tables seems to be incorrectly converted. 
This is why I'm also having XHTML files here in case yo uwant to try HTML tables insertion in the MD automatically.