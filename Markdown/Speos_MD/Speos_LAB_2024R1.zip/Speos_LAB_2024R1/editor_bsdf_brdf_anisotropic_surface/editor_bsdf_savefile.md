# SaveFile 

## Description 

Saves a file. Returns 1 if the call has succeeded, 0 otherwise.

## Syntax 

*object*.SaveFile\(BSTR bstrFileName\) As Short

- *object*: BSDF - BRDF Anisotropic Viewer, Eulumdat Viewer, IES Viewer, User Material Editor, Virtual Photometric Lab or Virtual Human Vision Lab object

- *bstrFileName*: filename string including path



