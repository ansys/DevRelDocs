# Operations on maps

- [OptisVRMerge](labvr_optisvrmerge.md)
- [OptisVRCombineLayers](labvr_optisvrcombinelayers.md)
- [CreateImmersiveView](labvr_createimmersiveview.md)
- [CreateObserverView](labvr_createobserverview.md)