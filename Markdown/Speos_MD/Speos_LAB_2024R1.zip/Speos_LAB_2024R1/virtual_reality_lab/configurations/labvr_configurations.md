# Configurations

- [GetNbConfigurations](labvr_getnbconfigurations.md)
- [SetConfigurationById](labvr_setconfigurationbyid.md)
- [SetConfigurationByName](labvr_setconfigurationbyname.md)
- [CreateConfig](labvr_createconfig.md)
- [GetConfigName](labvr_getconfigname.md)
- [SetConfigName](labvr_setconfigname.md)