# Human vision

- [ActivateHumanVision](labvr_activatehumanvision.md)
- [SetAdaptationType](labvr_setadaptationtype.md)
- [SetLocalAdaptationLuminance](labvr_setlocaladaptationluminance.md)
- [SetLocalAdaptationLuminanceMax](labvr_setlocaladaptationluminancemax.md)
- [ActivateLocalAdaptationAutomatic](labvr_activatelocaladaptationautomatic.md)
- [SetLocalAdaptationDefaultLuminance](labvr_setlocaladaptationdefaultluminance.md)
- [ActivateTemporalAdaptation](labvr_activatetemporaladaptation.md)
- [ActivateVisionModeEvaluationTypeAverage](labvr_activatevisionmodeevaluationtypeaverage.md)
- [ActivateGlare](labvr_activateglare.md)
- [SetObserverAge](labvr_setobserverage.md)
- [HumanVisionMode](labvr_humanvisionmode.md)