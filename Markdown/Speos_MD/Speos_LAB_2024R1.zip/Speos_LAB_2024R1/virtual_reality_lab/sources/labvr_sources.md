# Sources

- [GetSourceNameExt](labvr_getsourcenameext.md)
- [SetSourceName](labvr_setsourcename.md)
- [GetNbSources](labvr_getnbsources.md)
- [SetSourcePowerById](labvr_setsourcepowerbyid.md)
- [SetSourcePowerByName](labvr_setsourcepowerbyname.md)
- [SetSourceRatioById](labvr_setsourceratiobyid.md)
- [SetSourceRatioByName](labvr_setsourceratiobyname.md)