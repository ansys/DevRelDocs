# Exporting data

- [ExportCurrentViewToXM](labvr_exportcurrentviewtoxmp.md)
- [ExportObserverImage](labvr_exportobserverimage.md)
- [ExportAllObserverImages](labvr_exportallobserverimages.md)