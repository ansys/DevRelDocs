# Other methods

- [ActivateFiltering](labvr_activatefiltering.md)
- [SetLuminanceMax](labvr_setluminancemax.md)
- [SetColorSpaceConversion](labvr_setcolorspaceconversion.md)
- [SetFalseColor](labvr_setfalsecolor.md)