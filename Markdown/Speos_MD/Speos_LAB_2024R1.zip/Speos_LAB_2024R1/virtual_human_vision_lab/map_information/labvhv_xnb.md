# XNb 

## Description 

Gets the number of pixels along the horizontal axis.

## Syntax 

*object*.XNb\(\) As Short

*object*: Virtual Photometric Lab or Virtual Human Vision Lab object


