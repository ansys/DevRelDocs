# YNb 

## Description 

Gets the number of pixels along the vertical axis.

## Syntax 

*object*.YNb\(\) As Short

*object*: Virtual Photometric Lab or Virtual Human Vision Lab object


