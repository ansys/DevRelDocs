# Surface calculation on map

- [SurfaceLineExportTXT](labvhv_surfacelineexporttxt.md)
- [SurfacePolylineExportTXT](labvhv_surfacepolylineexporttxt.md)
- [GetMagnitude](labvhv_getmagnitude.md)
- [SetMagnitude](labvhv_setmagnitude.md)
- [MeasuresExportTXT](labvhv_measuresexporttxt.md)
- [SurfaceRectangleExportSpectrum](labvhv_surfacerectangleexportspectrum.md)
- [SurfaceEllipseExportSpectrum](labvhv_surfaceellipseexportspectrum.md)
- [SurfaceLineExportSpectrum](labvhv_surfacelineexportspectrum.md)
- [SurfacePointExportSpectrum](labvhv_surfacepointexportspectrum.md)
- [SurfacePolygonExportSpectrum](labvhv_surfacepolygonexportspectrum.md)
- [SurfacePolylineExportSpectrum](labvhv_surfacepolylineexportspectrum.md)