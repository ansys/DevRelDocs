# Filtering data

- [Filtering](labvhv_filtering.md)
- [FilteringRemoveHighestPeaks](labvhv_filteringremovehighestpeaks.md)