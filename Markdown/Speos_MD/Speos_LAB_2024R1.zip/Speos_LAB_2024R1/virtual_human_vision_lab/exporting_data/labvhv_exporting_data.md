# Exporting data

- [AnimationLocalAdaptation](labvhv_animationlocaladaptation.md)
- [AnimationTimeAdaptation](labvhv_animationtimeadaptation.md)
- [ExportXMPtoHDRI](labvhv_exportxmptohdri.md)
- [ExportXMPImage](labvhv_exportxmpimage.md)
- [ExportXMPtoResizedImage](labvhv_exportxmptoresizedimage.md)