# ExtendedSetActiveConfig 

## Description 

Sets the active configuration for the Layers Operations.

## Syntax 

*object*.ExtendedSetActiveConfig\(int nConfig\) As Short

- *object*: Virtual Photometric Lab or Virtual Human Vision Lab object

- *nConfig*: configuration index



