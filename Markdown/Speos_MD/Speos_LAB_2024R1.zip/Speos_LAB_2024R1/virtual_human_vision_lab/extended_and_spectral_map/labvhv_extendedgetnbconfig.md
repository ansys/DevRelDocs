# ExtendedGetNbConfig 

## Description 

Returns the number of configurations defined for the Layers Operations.

## Syntax 

*object*.ExtendedGetNbConfig\(\) As Integer

- *object*: Virtual Photometric Lab or Virtual Human Vision Lab object



