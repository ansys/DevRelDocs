# ExtendedGetNbSource 

## Description 

Returns the number of sources of an extended or a spectral map \(0 if the map is not an extended or a spectral map\).

## Syntax 

*object*.ExtendedGetNbSource\(\) As Short

- *object*: Virtual Photometric Lab or Virtual Human Vision Lab object



