# GetSelectedLayersUser 

## Description 

Gets selected layers of a multi layer map. Returns a value different than 0 if no error occurred.

## Syntax 

*object*.GetSelectedLayersUser\(VARIANT\* ovLayerIndexes\) As Short

- *object*: Virtual Photometric Lab or Virtual Human Vision Lab object

- *ovLayerIndex*: an array of VARIANT of the indexes of all active layers



