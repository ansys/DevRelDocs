# Aperture 

## Description 

Sets the aperture. Returns 0 if no error has occurred, 1 otherwise.

## Syntax 

*object*.Aperture\(double dAperture\) As Short

- *object*: Virtual Human Vision Lab object

- *dAperture*: new aperture value.



