# GetDepth 

## Description 

Returns the depth of a point located at given coordinates.

## Syntax 

*object*.GetDepth\(short iX, short iY\) As Double

- *object*: Virtual Human Vision Lab object

- *iX*: horizontal coordinate

- *iY*: vertical coordinate



