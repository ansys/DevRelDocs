# DOF 

## Description 

Modifies the depth of field state. Returns 0 if no error has occurred, 1 otherwise.

## Syntax 

*object*.DOF\(short nDOF\) As Short

- *object*: Virtual Human Vision Lab object

- *nDOF*: Depth of field state.



