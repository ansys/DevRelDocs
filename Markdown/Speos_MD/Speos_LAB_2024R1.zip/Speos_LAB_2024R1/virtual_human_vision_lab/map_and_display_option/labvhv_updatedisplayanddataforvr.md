# UpdateDisplayAndDataForVR 

## Description 

Update all the display and the data according to new options. The maximum luminance value is not replaced by the maximum luminance value on the map.

## Syntax 

*object*.UpdateDisplayAndDataForVR\(\) As Double

- *object*: Virtual Human Vision Lab object



