# AdaptationType 

## Description 

Sets the adaptation type and returns a value different from 0 if no error has occurred.

## Syntax 

*object*.AdaptationType\(short nAdaptationType\) As Short

- *object*: Virtual Human Vision Lab object

- *nAdaptationType*: 0 for Dynamic, 1 for Local



