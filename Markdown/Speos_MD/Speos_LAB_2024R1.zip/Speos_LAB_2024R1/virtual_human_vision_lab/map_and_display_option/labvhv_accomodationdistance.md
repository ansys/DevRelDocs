# AccomodationDistance 

## Description 

Sets the accomodation distance. Returns 0 if no error has occurred, 1 otherwise.

## Syntax 

*object*.AccomodationDistance\(double dAccomodationDistance\) As Short

- *object*: Virtual Human Vision Lab object

- *dAccomodationDistance*: accomodation distance value.



