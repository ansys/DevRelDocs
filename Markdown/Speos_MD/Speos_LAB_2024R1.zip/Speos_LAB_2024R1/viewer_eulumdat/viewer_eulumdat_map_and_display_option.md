# Map and display option

- [Caption](viewer_eulumdat_caption.md)
- [GetDownwardFluxFraction](viewer_eulumdat_getdownwardfluxfraction.md)
- [GetLuminaireName](viewer_eulumdat_getluminairename.md)
- [GetNumberOfSets](viewer_eulumdat_getnumberofsets.md)
- [GetPID](viewer_eulumdat_getpid.md)
- [GetTotalLuminousFlux](viewer_eulumdat_gettotalluminousflux.md)
- [Show](viewer_eulumdat_show.md)