# Basic methods

- [Filename](viewer_eulumdat_filename.md)
- [OpenFile](viewer_eulumdat_openfile.md)
- [SaveFile](viewer_eulumdat_savefile.md)
- [SavePolarCurve](viewer_eulumdat_savepolarcurve.md)