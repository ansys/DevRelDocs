# SavePolarCurve 

## Description 

Saves the picture of the polar curve in a JPG file.

## Syntax 

*object*.SavePolarCurve\(BSTR bstrPolarFileName\)

- *object*: Eulumdat Viewer or IES Viewer object

- *bstrPolarFileName*: JPG file name string



