# GetLuminaireName 

## Description 

Gets the luminaire name.

## Syntax 

*object*.GetLuminaireName\(\) As String

- *object*: Eulumdat Viewer object



