# GetNumberOfSets 

## Description 

Gets the number of standard sets of lamps.

## Syntax 

*object*.GetNumberOfSets\(\) As Long

- *object*: Eulumdat Viewer object



