# GetDownwardFluxFraction 

## Description 

Gets the downward flux fraction \(DFF\).

## Syntax 

*object*.GetDownwardFluxFraction\(\) As Double

- *object*: Eulumdat Viewer or IES Viewer object



