# Map and display option

- [Caption](viewer_iesna_lm63_caption.md)
- [GetDownwardFluxFraction](viewer_iesna_lm63_getdownwardfluxfraction.md)
- [GetLumenPerLamp](viewer_iesna_lm63_getlumenperlamp.md)
- [GetLuminaireDescription](viewer_iesna_lm63_getluminairedescription.md)
- [GetNumberOfLamps](viewer_iesna_lm63_getnumberoflamps.md)
- [GetPID](viewer_iesna_lm63_getpid.md)
- [Show](viewer_iesna_lm63_show.md)