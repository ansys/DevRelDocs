# Basic methods

- [Filename](viewer_iesna_lm63_filename.md)
- [OpenFile](viewer_iesna_lm63_openfile.md)
- [SaveFile](viewer_iesna_lm63_savefile.md)
- [SavePolarCurve](viewer_iesna_lm63_savepolarcurve.md)
- [XMP file export type](viewer_iesna_lm63_xmp_file_export_type.md)