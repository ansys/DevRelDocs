# GetNumberOfLamps 

## Description 

Gets the number of lamps.

## Syntax 

*object*.GetNumberOfLamps\(\) As Long

- *object*: IES Viewer object



