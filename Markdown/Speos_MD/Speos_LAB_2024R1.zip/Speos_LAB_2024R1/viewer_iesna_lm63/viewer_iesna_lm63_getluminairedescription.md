# GetLuminaireDescription 

## Description 

Gets the luminaire description.

## Syntax 

*object*.GetLuminaireDescription\(\) As String

- *object*: IES Viewer object



