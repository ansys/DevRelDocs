# GetLumenPerLamp 

## Description 

Gets the lumen value per lamp.

## Syntax 

*object*.GetLumenPerLamp\(\) As Double

- *object*: IES Viewer object



