# User concentration

- [GetUserConcentration](editor_user_material_getuserconcentration.md)
- [SetUserConcentration](editor_user_material_setuserconcentration.md)