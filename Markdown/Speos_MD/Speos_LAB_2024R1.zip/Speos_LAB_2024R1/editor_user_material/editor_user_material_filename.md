# Filename 

## Description 

Gets the file name of a file.

## Syntax 

*object*.FileName\(\) As String

- *object*: Eulumdat Viewer, IES Viewer, User Material Editor, Virtual Photometric Lab or Virtual Human Vision Lab object



