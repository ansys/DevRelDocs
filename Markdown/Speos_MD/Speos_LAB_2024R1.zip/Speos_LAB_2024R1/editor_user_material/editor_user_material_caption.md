# Caption 

## Description 

Returns the caption title of the viewer/editor.

## Syntax 

*object*.Caption\(\) As String

- *object*: Eulumdat Viewer, IES Viewer, User Material Editor, Virtual Photometric Lab or Virtual Human Vision Lab object



