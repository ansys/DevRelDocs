# ProcessEnergyMax 

## Description 

Adjusts the relative energy of each ray of the specified .ray file. The ray with the highest energy becomes 1 and all other rays are multiplied according to the first ray.

## Syntax 

*object*.ProcessEnergyMax\(LPCTSTR strOutFileName\) As Short

- *strOutFileName*: .ray



