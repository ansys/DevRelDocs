# RandomizeRayFile 

## Description 

Completes the specified .ray file with random data.

## Syntax 

*object*.RandomizeRayFile\(LPCTSTR strOutFileName\) As Short

- *strOutFileName*: .ray



