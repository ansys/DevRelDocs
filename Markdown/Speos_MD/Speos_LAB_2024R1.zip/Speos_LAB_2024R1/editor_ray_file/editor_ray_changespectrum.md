# ChangeSpectrum 

## Description 

Adds a .spectrum file and saves it in the defined .ray file.

## Syntax 

*object*.ChangeSpectrum\(LPCTSTR strInFileName, LPCTSTR strOutFileName\) As Short

- *strInFileName*: .spectrum

- *strOutFileName*: .ray



