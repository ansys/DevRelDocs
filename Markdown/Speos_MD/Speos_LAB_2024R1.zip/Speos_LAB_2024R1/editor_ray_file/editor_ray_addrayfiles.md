# AddRayFiles 

## Description 

Adds a .ray file to another specified .ray file.

## Syntax 

*object*.AddRayFiles\(LPCTSTR strAddFileName, LPCTSTR strOutFileName\) As Short

- *strAddFileName*: .ray

- *strOutFileName*: .ray



