# OpenFile 

## Description 

Opens a file. Returns 1 if the call has succeeded, 0 otherwise.

## Syntax 

*object*.OpenFile\(LPCTSTR strFileName\) As Short

- *object*: Ray File Editor object

- *strFileName*: filename string including path \(input\)



