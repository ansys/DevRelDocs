# ImportRayFile 

## Description 

Imports a .txt or .dis file to save it as a .ray file.

## Syntax 

*object*.ImportRayFile\(LPCTSTR strInFileName, LPCTSTR strOutFileName\) As Short

- *strInFileName*: .txt, .dis

- *strOutFileName*: .ray



