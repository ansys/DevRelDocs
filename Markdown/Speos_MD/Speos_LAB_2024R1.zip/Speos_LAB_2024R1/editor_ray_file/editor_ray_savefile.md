# SaveFile 

## Description 

Saves a file. Returns 1 if the call has succeeded, 0 otherwise.

## Syntax 

*object*.SaveFile\(LPCTSTR strFileName\) As Short

- *object*: Ray File Editor object

- *strFileName*: filename string \(input\)



