# InvertDirectionOfRay 

## Description 

Inverts the directions of all rays in the specified .ray file.

## Syntax 

*object*.InvertDirectionOfRay\(LPCTSTR strOutFileName\) As Short

- *strOutFileName*: .ray



