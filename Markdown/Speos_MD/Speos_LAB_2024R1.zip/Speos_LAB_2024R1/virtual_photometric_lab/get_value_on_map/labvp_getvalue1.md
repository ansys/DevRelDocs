# GetValue1 

## Description 

Gets the value at the given position. Returns 0 if the position is outside the map.

## Syntax 

*object*.GetValue1\(double dX, double dY\) As Double

- *object*: Virtual Photometric Lab object

- *dX*: horizontal coordinate

- *dY*: vertical coordinate



