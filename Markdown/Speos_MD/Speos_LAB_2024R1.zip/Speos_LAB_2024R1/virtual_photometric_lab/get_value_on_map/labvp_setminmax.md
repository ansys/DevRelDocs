# SetMinMax 

## Description 

Sets the minimum and maximum values of the level. Returns 1 if the call has succeeded, 0 otherwise.

## Syntax 

*object*.SetMinMax\(double dMin, double dMax\) As Short

- *object*: Virtual Photometric Lab object

- *dMin*: minimum

- *dMax*: maximum



