# Color rendering index

- [GetSampleCRI](labvp_getsamplecri.md)
- [SurfaceRectangleSampleCRI](labvp_surfacerectanglesamplecri.md)
- [SurfaceEllipseSampleCRI](labvp_surfaceellipsesamplecri.md)
- [SurfacePolygonSampleCRI](labvp_surfacepolygonsamplecri.md)