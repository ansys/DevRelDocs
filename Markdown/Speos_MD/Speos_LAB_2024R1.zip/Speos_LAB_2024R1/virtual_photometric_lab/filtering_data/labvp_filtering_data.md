# Filtering data

- [Filtering](labvp_filtering.md)
- [FilteringRemoveHighestPeaks](labvp_filteringremovehighestpeaks.md)