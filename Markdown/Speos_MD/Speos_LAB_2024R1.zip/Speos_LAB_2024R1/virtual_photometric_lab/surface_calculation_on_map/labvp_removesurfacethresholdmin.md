# RemoveSurfaceThresholdMin 

## Description 

Removes the applied minimum threshold value for surface calculations. Returns 1 if no error has occurred, 0 otherwise.

## Syntax 

*object*.RemoveSurfaceThresholdMin\(\) As Short

- *object*: Virtual Photometric Lab object



