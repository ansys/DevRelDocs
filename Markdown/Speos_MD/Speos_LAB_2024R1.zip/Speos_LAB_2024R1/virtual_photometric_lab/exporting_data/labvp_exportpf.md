# ExportPF 

## Description 

Saves the map data in a pf file. Returns a value different from 0 if no error has occurred.

## Syntax 

*object*.ExportPF\(BSTR bstrFileName\) As Short

- *object*: Virtual Photometric Lab object

- *bstrFileName*: filename to save the pf file



