# Exporting data

- [ExportChart3D](labvp_exportchart3d.md)
- [ExportChart3D3D](labvp_exportchart3d3d.md)
- [ExportTXT](labvp_exporttxt.md)
- [ExportPF](labvp_exportpf.md)
- [ExportXMP](labvp_exportxmp.md)
- [ExportXMPtoIntensity](labvp_exportxmptointensity.md)
- [ExportXMPImage](labvp_exportxmpimage.md)
- [ExportXMPtoResizedImage](labvp_exportxmptoresizedimage.md)
- [ExportXMPIso](labvp_exportxmpiso.md)
- [ExportXMPtoHDRI](labvp_exportxmptohdri.md)