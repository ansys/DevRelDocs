# ImportTXT 

## Description 

Imports the text file and returns 1 if the call succeeds, 0 otherwise.

## Syntax 

*object*.ImportTXT\(BSTR bstrFileName\) As Short

- *object*: Virtual Photometric Lab object

- *bstrFileName*: text file name



