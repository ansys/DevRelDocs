# SetYMin 

## Description 

Return value: sets the vertical coordinate of the bottom edge of the map and returns 0.

## Syntax 

*object*.SetYMin\(double dYMin\) As Short

- *object*: Virtual Photometric Lab object

- *dYMin*: value to set



