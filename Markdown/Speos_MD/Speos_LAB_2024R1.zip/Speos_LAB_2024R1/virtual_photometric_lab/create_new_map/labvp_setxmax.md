# SetXMax 

## Description 

Sets the horizontal coordinate of the right edge of the map and returns 0.

## Syntax 

*object*.SetXMax\(double dXMax\) As Short

- *object*: Virtual Photometric Lab object

- *dXMax*: value to set



