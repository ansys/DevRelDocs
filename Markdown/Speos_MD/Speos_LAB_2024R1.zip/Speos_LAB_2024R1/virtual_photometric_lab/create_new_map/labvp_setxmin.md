# SetXMin 

## Description 

Sets the horizontal coordinate of the left edge of the map and returns 0.

## Syntax 

*object*.SetXMin\(double dXMin\) As Short

- *object*: Virtual Photometric Lab object

- *dXMin*: value to set



