# SetYMax 

## Description 

Return value: sets the vertical coordinate of the top edge of the map and returns 0.

## Syntax 

*object*.SetYMax\(double dYMax\) As Short

- *object*: Virtual Photometric Lab object

- *dYMax*: value to set



