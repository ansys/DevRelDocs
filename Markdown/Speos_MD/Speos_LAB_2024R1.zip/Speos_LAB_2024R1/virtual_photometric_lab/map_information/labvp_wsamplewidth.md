# WSampleWidth 

## Description 

Gets the size of the wavelength sampling \(0 if the map is not a spectral map\).

## Syntax 

*object*.WSampleWidth\(\) As Double

*object*: Virtual Photometric Lab object


