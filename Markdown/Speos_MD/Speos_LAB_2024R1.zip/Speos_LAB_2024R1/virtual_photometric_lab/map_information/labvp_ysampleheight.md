# YSampleHeight 

## Description 

Gets the vertical height of each pixel of the map.

## Syntax 

*object*.YSampleHeight\(\) As Double

*object*: Virtual Photometric Lab object


