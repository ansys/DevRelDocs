# WNb 

## Description 

Gets the number of wavelengths of the map \(0 if the map is not a spectral map\).

## Syntax 

*object*.WNb\(\) As Short

*object*: Virtual Photometric Lab object


