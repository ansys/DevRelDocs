# Ymin 

## Description 

Gets the vertical coordinate of the bottom edge of the map.

## Syntax 

*object*.YMin\(\) As Double

*object*: Virtual Photometric Lab object


