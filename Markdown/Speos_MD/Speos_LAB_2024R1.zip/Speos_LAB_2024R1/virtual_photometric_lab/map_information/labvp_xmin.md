# XMin 

## Description 

Gets the horizontal coordinate of the map left edge.

## Syntax 

*object*.XMin\(\) As Double

*object*: Virtual Photometric Lab object


