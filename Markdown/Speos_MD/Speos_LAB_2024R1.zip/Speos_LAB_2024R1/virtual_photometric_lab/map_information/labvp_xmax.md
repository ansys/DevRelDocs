# XMax 

## Description 

Gets the horizontal coordinate of the map right edge.

## Syntax 

*object*.XMax\(\) As Double

*object*: Virtual Photometric Lab object


