# YHeight 

## Description 

Gets the vertical height of the map.

## Syntax 

*object*.YHeight\(\) As Double

*object*: Virtual Photometric Lab object


