# XSampleWidth 

## Description 

Gets the horizontal width of each pixel of the map.

## Syntax 

*object*.XSampleWidth\(\) As Short

*object*: Virtual Photometric Lab object


