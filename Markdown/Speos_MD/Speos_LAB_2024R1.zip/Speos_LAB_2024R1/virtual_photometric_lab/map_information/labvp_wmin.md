# WMin 

## Description 

Gets the minimal wavelength of the map \(0 if the map is not a spectral map\).

## Syntax 

*object*.WMin\(\) As Double

*object*: Virtual Photometric Lab object


