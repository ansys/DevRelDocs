# WMax 

## Description 

Gets the maximal wavelength of the map \(0 if the map is not a spectral map\).

## Syntax 

*object*.WMax\(\) As Double

*object*: Virtual Photometric Lab object


