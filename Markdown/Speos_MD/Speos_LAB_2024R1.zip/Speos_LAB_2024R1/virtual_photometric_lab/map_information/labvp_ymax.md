# YMax 

## Description 

Gets the vertical coordinate of the top edge of the map.

## Syntax 

*object*.YMax\(\) As Double

*object*: Virtual Photometric Lab object


