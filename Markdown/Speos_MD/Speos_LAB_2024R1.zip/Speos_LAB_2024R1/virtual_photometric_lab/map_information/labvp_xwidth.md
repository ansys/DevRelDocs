# XWidth 

## Description 

Gets the horizontal width of the map.

## Syntax 

*object*.XWidth\(\) As Double

*object*: Virtual Photometric Lab object


