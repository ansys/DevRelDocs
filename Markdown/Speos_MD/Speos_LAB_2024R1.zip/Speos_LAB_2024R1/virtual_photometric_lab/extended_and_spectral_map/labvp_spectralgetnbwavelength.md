# SpectralGetNbWavelength 

## Description 

Returns the number of wavelength of a spectral map. Returns 0 if the map is not a spectral map.

## Syntax 

*object*.SpectralGetNbWavelength\(\) As Short

- *object*: Virtual Photometric Lab object



