# SetComment 

## Description 

Sets the text comment of the map and returns 0.

## Syntax 

*object*.SetComment\(BSTR bstrComment\) As Short

- *object*: Virtual Photometric Lab object

- *bstrComment*: Text comment to set



