# FillBackground 

## Description 

Fills the background of the Virtual Photometric Lab viewer with white to analyze isocurves and returns 1.

## Syntax 

*object*.FillBackground\(short bState\) As Short

- *object*: Virtual Photometric Lab object

- *bState*: 0 to keep the background unchanged, 1 to fill the background with white.



