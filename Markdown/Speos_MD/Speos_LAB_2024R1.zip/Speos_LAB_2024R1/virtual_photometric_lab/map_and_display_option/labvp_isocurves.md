# IsoCurves 

## Description 

Displays or hides ISO curves and returns 1.

## Syntax 

*object*.IsoCurves\(short bState\) As Short

- *object*: Virtual Photometric Lab object

- *bState*: 0 to hide, 1 to display iso curves



