# GetComment 

## Description 

Not supported.

## Syntax 

*object*.GetComment\(\) As Short


