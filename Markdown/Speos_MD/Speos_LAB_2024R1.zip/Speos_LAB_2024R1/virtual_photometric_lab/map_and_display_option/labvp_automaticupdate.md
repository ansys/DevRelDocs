# AutomaticUpdate 

## Description 

Modifies the automatic update flag and returns 1.

## Syntax 

*object*.AutomaticUpdate\(short bAutomaticUpdate\) As Short

- *object*: Virtual Photometric Lab object

- *bAutomaticUpdate*: automatic update flag



