# SetLogScale 

## Description 

Activates the linear scale or the logarithmic one.

## Syntax 

*object*.SetLogScale\(bool bScale\) As Short

- *object*: Virtual Photometric Lab

- *bScale*: True to activate the Logarithmic scale, false to activate the Linear scale



