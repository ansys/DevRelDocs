# AxisSymetry 

## Description 

Makes a symmetry axis of the map.

## Syntax 

*object*.AxisSymetry\(short nMode\) As Short

- *object*: Virtual Photometric Lab object

- *nMode*: axis, 0 for vertical axis, 1 for horizontal axis.



