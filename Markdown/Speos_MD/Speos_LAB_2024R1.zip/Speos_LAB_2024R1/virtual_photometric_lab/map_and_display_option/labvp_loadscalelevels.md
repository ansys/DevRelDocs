# LoadScaleLevels 

## Description 

Load scale Levels. Returns 1 if the call has succeeded, 0 otherwise.

## Syntax 

*object*.LoadScaleLevels\(LPCSTR strFileName\) As Short

- *object*: Virtual Photometric Lab object

- *strFileName*: scale file name



