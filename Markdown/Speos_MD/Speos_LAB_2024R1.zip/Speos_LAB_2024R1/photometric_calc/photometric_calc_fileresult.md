# FileResult 

## Description 

Defines the name of the result file. Returns 0 if the call has succeeded, 1 otherwise.

## Syntax 

*object*.FileResult\(BSTR bstrFileResult\) As Short

- *object*: Photometric Calc object

- *bstrFileResult*: result filename string



