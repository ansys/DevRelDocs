# Process 

## Description 

Process the operation. Returns 0 if the call has succeeded, 1 otherwise.

## Syntax 

*object*.Process\(\) As Short

- *object*: Photometric Calc object



