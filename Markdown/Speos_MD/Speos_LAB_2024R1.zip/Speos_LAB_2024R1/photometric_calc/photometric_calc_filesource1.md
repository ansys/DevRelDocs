# FileSource1 

## Description 

Defines the name of the first source file. Returns 0 if the call has succeeded, 1 otherwise.

## Syntax 

*object*.FileSource1\(BSTR bstrFileSource1\) As Short

- *object*: Photometric Calc object

- *bFileSource1*: first source name string



