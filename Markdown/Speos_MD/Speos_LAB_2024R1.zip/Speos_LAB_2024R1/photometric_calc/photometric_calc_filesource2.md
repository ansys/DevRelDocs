# FileSource2 

## Description 

Defines the name of the second source file. Returns 0 if the call has succeeded, 1 otherwise.

## Syntax 

*object*.FileSource2\(BSTR bstrFileSource2\) As Short

- *object*: Photometric Calc object

- *bFileSource1*: second source name string



