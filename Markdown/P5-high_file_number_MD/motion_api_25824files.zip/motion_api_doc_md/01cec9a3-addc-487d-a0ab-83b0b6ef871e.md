# BuilderUnite Constructor (Builder, Builder)
 

Initializes a new instance of the <a href="f3cf73ea-1db1-20ce-2af8-e6c160b6c546">BuilderUnite</a> class

**Namespace:**&nbsp;<a href="bdeeb71e-08d7-cd91-e11a-795ab9385ff7">VM.Managed.CAD</a><br />**Assembly:**&nbsp;VMAppCore (in VMAppCore.dll) Version: 24.1.23299.31577

## Syntax

**C#**<br />
``` C#
public BuilderUnite(
	Builder builderTarget,
	Builder builderTool
)
```

**VB**<br />
``` VB
Public Sub New ( 
	builderTarget As Builder,
	builderTool As Builder
)
```

**C++**<br />
``` C++
public:
BuilderUnite(
	Builder^ builderTarget, 
	Builder^ builderTool
)
```

**F#**<br />
``` F#
new : 
        builderTarget : Builder * 
        builderTool : Builder -> BuilderUnite
```


#### Parameters
&nbsp;<dl><dt>builderTarget</dt><dd>Type: <a href="bc9c2fe1-a752-bc29-651e-38f354ac77a9">VM.Managed.CAD.Builder</a><br />The target build.</dd><dt>builderTool</dt><dd>Type: <a href="bc9c2fe1-a752-bc29-651e-38f354ac77a9">VM.Managed.CAD.Builder</a><br />The tool build.</dd></dl>

## See Also


#### Reference
<a href="f3cf73ea-1db1-20ce-2af8-e6c160b6c546">BuilderUnite Class</a><br /><a href="4433a57a-975a-62a1-ee9c-61b77d9ba99c">BuilderUnite Overload</a><br /><a href="bdeeb71e-08d7-cd91-e11a-795ab9385ff7">VM.Managed.CAD Namespace</a><br />