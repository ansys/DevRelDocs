# PropertyCoupler Methods
 

The <a href="448b1474-6083-5231-352e-7db3997afa23">PropertyCoupler</a> type exposes the following members.


## Methods
&nbsp;<table><tr><th></th><th>Name</th><th>Description</th></tr><tr><td>![Public method](media/pubmethod.gif "Public method")</td><td><a href="7755c72a-724b-c950-ffbf-409bebefeff2">Initialize</a></td><td>
Initializes member through unit convert factor.
 (Overrides <a href="9f61ac5b-8378-887f-561c-aa39a8a58682">PropertyCouplerBase.Initialize(ConvertFactor)</a>.)</td></tr></table>&nbsp;
<a href="#propertycoupler-methods">Back to Top</a>

## See Also


#### Reference
<a href="448b1474-6083-5231-352e-7db3997afa23">PropertyCoupler Class</a><br /><a href="b5e7d154-f6c2-cdc8-0dc3-9407b97f82b2">VM.Managed.DAFUL.Constraints Namespace</a><br />