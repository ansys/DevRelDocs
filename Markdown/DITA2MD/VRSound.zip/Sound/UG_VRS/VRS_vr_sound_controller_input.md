# 3D Input Streams {#topicID5Input}

The following window allows you to control an audio stream in the audio sound card input:

![](images/img(22).png)

The control of the input channel source is similar to the control of 3D sources except that there is no control of the playback speed and no loop capability, as the input is a real-time audio stream.

The ![](images/img(23).png) button allows you to choose the sound card input on which the audio stream is routed.

