# Communication {#jpkgae}

-   **[OSC Protocol](../../Sound/UG_VRS/VRS_communication_osc.md)**  

-   **[Messages List](../../Sound/UG_VRS/VRS_communication_messages_list.md)**  

-   **[Sound Playback Process](../../Sound/UG_VRS/VRS_communication_sound.md)**  

-   **[Messages Format](../../Sound/UG_VRS/VRS_communication_messages.md)**  

-   **[State of the Sound Generator](../../Sound/UG_VRS/VRS_communication_state.md)**  


