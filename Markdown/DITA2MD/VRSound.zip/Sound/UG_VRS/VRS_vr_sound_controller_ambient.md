# Ambiance Sources {#topicID5Ambient}

Two elements allow you to control the ambient sources, as shown below:

![](images/img(21).png)

The control of ambient sources is similar to the control of 3D sources except that there is no spatialization \(the signal is directly delivered to the headphones\).

