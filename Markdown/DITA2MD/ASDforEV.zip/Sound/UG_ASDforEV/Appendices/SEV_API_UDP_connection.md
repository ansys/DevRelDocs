# UDP Connection {#SEV_API_UDP_connection .reference}

Both communication modes are carried out on distinct UDP ports:

-   Messages **sent** to ASDforEV: Port **7450**
-   Messages **received** from ASDforEV: Port **7460**

**Parent topic:**[Ansys Sound: ASDforEV API Messages](../../../Sound/UG_ASDforEV/Appendices/SEV_API_SEV_Driving.md)

