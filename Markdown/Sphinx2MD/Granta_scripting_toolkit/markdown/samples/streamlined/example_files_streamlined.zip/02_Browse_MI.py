# # Browse Granta MI
# Use various methods to get records from Granta MI.

# This notebook shows three methods of browsing for records in Granta MI:
#
# * Get records by internal Granta MI identifier
# * Get records by an exact match on a short text attribute value
# * Get records by navigating the tree structure

# ## Connect to MI

from GRANTA_MIScriptingToolkit import granta as mpy
mi = mpy.connect('http://my.server.name/mi_servicelayer', autologon=True)
db = mi.get_db(db_key='MI_Training')

# ## Access a record by specifying an internal ID
# Get a record with a specific identifier, for example history GUID or history identity.

record_by_guid = db.get_record_by_id(hguid='bf5e6054-6cad-4c9d-ad7a-adfa124c504b')
record_by_guid

record_by_identity = db.get_record_by_id(history_identity=8925)
record_by_identity

# ## Access a record by specifying a unique short text value
# Get a record with a unique short-text attribute value using the `Table.get_record_by_lookup_value()` method.

tensile_test_data = db.get_table('Tensile Test Data')
record_by_value = tensile_test_data.get_record_by_lookup_value('Specimen ID', 'MTS-615722')
record_by_value

# **Note:** This method can only return a single record; if multiple records have the same value an exception is raised. Uncomment the line below to see the error.

# tensile_test_data.get_record_by_lookup_value('Testing Standards', 'ASTM E8')

# ## Browse for records by navigating the tree structure
# The following examples show two methods of browsing the Granta MI tree structure in Python. These examples use the
# *MaterialUniverse* table.

material_universe = db.get_table('MaterialUniverse')

# ### Iterative browsing
# Browse iteratively by getting the immediate children of each record in turn. First, get the top-level folders of the table with the `Table.children` property:

material_universe_folders = material_universe.children
["Name: {}, Type: {}".format(child.name, child.type) for child in material_universe_folders]

# Then filter for a specific folder and access the `Record.children` property to find its children:

ceramics_and_glasses = [child for child in material_universe_folders if child.short_name == 'Ceramics and glasses'][0]
["Name: {}, Type: {}".format(child.name, child.type) for child in ceramics_and_glasses.children]

# Repeat the process to navigate the tree structure until you reach your records of interest.

glasses = [child for child in ceramics_and_glasses.children if child.short_name == 'Glasses'][0]
alumino_silicate = [child for child in glasses.children if child.short_name == 'Alumino silicate'][0]
["Name: {}, Type: {}".format(child.name, child.type) for child in alumino_silicate.children]

# ### Access a tree location directly
#
# The `table.get_records_from_path()` method returns all the records at the end of a specified path.
# It accepts wildcards at any level.

# Get all records that are great-grandchildren of folders with the short name *Ceramics and glasses* and also have a
# parent with the short name *Baryta*.

recs = material_universe.get_records_from_path(None,
                                               ['Ceramics and glasses', None, 'Baryta'],
                                               use_short_names=True)
recs

# Get all records that are great-grandchildren of the folder *Ceramics and glasses*.

recs = material_universe.get_records_from_path(ceramics_and_glasses, [None, None])
recs

# ### Access all descendant records within a folder
# Use the `Record.all_children()` method to retrieve all records that are a descendant of the specified record
# in a single step.

all_ceramics_and_glasses = ceramics_and_glasses.all_children()
all_ceramics_and_glasses

# Print the results and whether the object is a record or folder.

print('{:^30.30} | {:^30.30} | {:^30.30}'.format('Record Name', 'Short Name', 'Record / Folder?'))
print('-'*96)
for r in all_ceramics_and_glasses:
    print('{:^30.30} | {:^30.30} | {:^30.30}'.format(str(r.name), r.short_name, r.type))
