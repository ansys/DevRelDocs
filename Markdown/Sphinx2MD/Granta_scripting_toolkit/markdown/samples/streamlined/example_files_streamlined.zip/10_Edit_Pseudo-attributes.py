# # Edit Pseudo-attributes
# View the pseudo-attributes (properties) of a record, and edit a record's color.

# ## Connect to MI
# Specify a database and table.

from GRANTA_MIScriptingToolkit import granta as mpy

mi = mpy.connect('http://my.server.name/mi_servicelayer', autologon=True)
db = mi.get_db(db_key='MI_Training')
tab = db.get_table('Training Exercise for Import')

# ## Find a record and view its pseudo-attributes
# Search for a record (use the first result returned).

recs = tab.search_for_records_by_name('Ti')
record = recs[0]
record

# Examine the pseudo-attributes on the record.

for name, pa in record.pseudo_attributes.items():
    print('{} = {}'.format(name, str(pa.value)))

# ## Change the record color
# Pseudo-attribute values can only be changed via the properties on the **Record** class.

record.color = mpy.RecordColor.White
record.color

# Write your changes to MI (pseudo-attributes do not need to be flagged for update using `set_attribute()`).

mi.update([record])
