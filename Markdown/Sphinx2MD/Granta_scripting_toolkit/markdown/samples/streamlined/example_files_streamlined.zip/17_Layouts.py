# # Layouts
#
# This notebook shows how to access layouts through the Streamlined API.

# ## Connect to Granta MI

from GRANTA_MIScriptingToolkit import granta as mpy
mi = mpy.connect('http://my.server.name/mi_servicelayer', autologon=True)
db = mi.get_db(db_key='MI_Training')

# ## Access a layout and inspect its properties
#
# The `Table.layouts` property contains a **dict** of all layouts in the table, indexed by the layout name.

tab = db.get_table('MaterialUniverse')
tab.layouts

# Select a particular **Layout** object and view the categories and attributes within the layout.

polymers_layout = tab.layouts['Polymers']
polymers_layout.categories

# The `attributes_by_category` property contains a **dict** of attributes indexed by their category.

polymers_layout.attributes_by_category
