# # Get Attributes
# Find out about the database schema by accessing the `attributes` property of the **Table** object.

# ## Connect to MI

from GRANTA_MIScriptingToolkit import granta as mpy

mi = mpy.connect('http://my.server.name/mi_servicelayer', autologon=True)

# ## Get table 
# Get a database, then set the unit system for the **Database** object.

db = mi.get_db(db_key='MI_Training')
db.set_unit_system('Metric')
db.unit_system

# Get a table from the database.

tab = db.get_table('Training Exercise for Import')
tab

# ## Access the attribute definitions 
# These are associated with the **Table** object through the `attributes` property,
# which returns a dictionary of **AttributeDefinition** objects.

print('{:30.30} - {:^10.10} - {:^10.10} - {:^10.10}'.format('Name', 'Type', 'Unit', 'Meta?'))
print('-'*70)
for name, att in tab.attributes.items():
    output = '{:30.30} - {:^10.10} - {:^10.10} - {:^10.10}'.format(name, att.type, att.unit, str(att.is_meta))
    print(output)
