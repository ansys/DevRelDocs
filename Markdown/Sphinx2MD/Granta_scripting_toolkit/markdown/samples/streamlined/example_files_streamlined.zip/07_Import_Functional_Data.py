# -*- coding: utf-8 -*-
# # Import Functional Data
# Import CSV data into a functional attribute and update the parameters and header units.

# ## Import required libraries
# Connect to MI and specify a table.

from datetime import datetime
import csv
from GRANTA_MIScriptingToolkit import granta as mpy

mi = mpy.connect('http://my.server.name/mi_servicelayer', autologon=True)
db = mi.get_db(db_key='MI_Training')
tab = db.get_table('Design Data')

# ## Create a new record to store your data
# Define names for a new record, and an attribute on that record.

now = datetime.now().strftime("%c")
recordName = 'STK Example 7:{}'.format(now)
funcAttributeName = 'Tensile Stress/Strain, L'

# Create the new **Record** object.

rec = tab.create_record(recordName, subsets={'Design Data'})
rec

# Get the unpopulated functional attribute for the new record, so we can populate it.

func = rec.attributes[funcAttributeName]
func

# ## Import test data
# The tensile test data to import is stored in `example.csv`.
# Read in each row of the CSV data, and add the data to the functional attribute point-by-point.

with open('example.csv') as csvfile:
    reader = csv.DictReader(csvfile, delimiter=',')
    for row in reader:
        func.add_point({'y': float(row['Tensile Stress [ksi]']),
                        'Strain': float(row['Strain [%]']),
                        'Temperature': float(row['Temperature [Celsius]']),
                        'Stress/Strain Curve Type': str(row['Curve Type']),
                        'Estimated?': bool(row['Estimated?'])})

# Access the `func.value` property to see the underlying data structure of the attribute represented as a list of lists.
# `func.data` shows all parameters supported by the attribute. Parameters that were not populated during the import have
# been set to **None**.

func.value

# The example data uses Celsius for temperature, but the database default is Kelvin.
# Change the parameter unit before import to take account of this.

func.parameters['Temperature'].unit = '°C'

# After changing the units, it is good practice to update the header units in `func.data` so that the units displayed in
# MI applications are correct.

func.update_header_units()

# ## Write your changes to MI

rec.set_attributes([func])
mi.update([rec])
