# # Fetch Attribute Data in Bulk
# By default, all attribute values are dynamically retrieved from the server when `Record.attributes` is accessed. When
# operating on many records, this can result in poor performance, as unnecessary data might be exported for each record
# and as export requests are performed for each individual record.
# By grouping records into fewer requests through batching, and allowing the export of only a subset of attributes,
# `bulk_fetch()` can be used to enhance performance.

# ## Connect to MI 
# Specify a database and table.

from GRANTA_MIScriptingToolkit import granta as mpy

mi = mpy.connect('http://my.server.name/mi_servicelayer', autologon=True)
db = mi.get_db(db_key='MI_Training')
db.set_unit_system('Metric', absolute_temperatures=True)
tab = db.get_table('MaterialUniverse')

# ## Define a list of records to fetch
# For example, by Record GUID.

guids = ['00001192-000e-4fff-8fff-dd92ffff0000',
         '00001194-000e-4fff-8fff-dd92ffff0000',
         '0000119b-000e-4fff-8fff-dd92ffff0000',
         '00000e38-000e-4fff-8fff-dd92ffff0000',
         '00000e41-000e-4fff-8fff-dd92ffff0000',
         '000009cb-000e-4fff-8fff-dd92ffff0000']

# Get each record using its Record GUID, using the `get_records_by_ids` method.

records = tab.get_records_by_ids([{"vguid": guid} for guid in guids])
records

# ## Fetch attribute data values 
# Fetch the *Base*, *Density* and *Young's modulus* attribute values for each record, and print the results.
# Default units can be overridden before export using the `table.set_display_unit()` method.

tab.set_display_unit("Young's modulus", "ksi")
tab.bulk_fetch(records=records, attributes=["Base", "Density", "Young's modulus"])

density_unit = tab.attributes['Density'].unit
youngs_mod_unit = tab.attributes["Young's modulus"].unit
print('{:50.50} | {:^21} | {:^21} | {:^18}'.format('Name',
                                                   'Density / ' + density_unit,
                                                   "Young's modulus / " + youngs_mod_unit,
                                                   'Base'))
print('-'*120)
for record in records:
    output = '{:50.50} | {:^10.2f}-{:^10.2f} | {:^10.2f}-{:^10.2f} | {:^20}'.format(record.name,
        record.attributes['Density'].value['low'],
        record.attributes['Density'].value['high'],
        record.attributes["Young's modulus"].value['low'],
        record.attributes["Young's modulus"].value['high'],
        str(record.attributes['Base'].value))
    print(output)

# ## Fetch meta-attributes data values
# Meta-attributes can be included in a bulk export operation by specifying their `AttributeDefinition`, which can be
# obtained from the parent attribute definition.
# Accessing a meta-attribute that has not been exported will raise an error, even if the parent attribute has been
# exported.
# Fetch the attribute *Food contact* and associated meta-attribute *Notes* for each record and print the results.

import textwrap

food_contact = tab.attributes['Food contact']
food_contact_notes = food_contact.meta_attributes['Notes']

tab.bulk_fetch(records=records, attributes=[food_contact, food_contact_notes])

print('{:50.50} | {:^18} | {:^42}'.format(
    'Name', 'Food contact', 'Notes')
)
print('-'*120)
for record in records:
    output = '{:50.50} | {:^18} | {:^42}'.format(
        record.name,
        record.attributes['Food contact'].value,
        textwrap.shorten(str(record.attributes['Food contact'].meta_attributes['Notes'].value), width=42),
    )
    print(output)
