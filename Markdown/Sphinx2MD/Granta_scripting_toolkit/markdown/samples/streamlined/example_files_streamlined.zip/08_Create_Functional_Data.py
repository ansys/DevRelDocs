# # Create Functional Data
# Populate a functional attribute with data fitted using the Python `numpy` library.

# ## Import libraries and define a polynomial fit function
# This example populates a functional attribute for *Ultimate Tensile Strength vs Temperature* in one table from a polynomial fit of the individual attributes in another table.

from datetime import datetime
import numpy as np
from GRANTA_MIScriptingToolkit import granta as mpy

def My4degPolyFitFunc(x, a, b, c, d, e):
    return a*np.power(x, 4) + b*np.power(x, 3) + c*np.power(x, 2) + d*x + e


# ## Specify database and table
# The source data will come from the *Tensile Statistical Data* table.

mi = mpy.connect('http://my.server.name/mi_servicelayer', autologon=True)

db = mi.get_db(db_key='MI_Training')
db.set_unit_system('Metric', absolute_temperatures=True)

table = db.get_table('Tensile Statistical Data')

# ## Export test data
# Find *High Alloy Steel* > *AMS 6520* > *Plate* records in which both the *Ultimate Tensile Strength* and *Test Temperature* attributes are populated.

records = table.get_records_from_path(None, ["High Alloy Steel", "AMS 6520", "Plate"])

# Extract the attribute values from the returned records into x and y values.

table.bulk_fetch(records, attributes=['Test Temperature', 'Ultimate Tensile Strength'])
populated_records = [
    r for r in records
    if not r.attributes['Test Temperature'].is_empty()
    and not r.attributes['Ultimate Tensile Strength'].is_empty()
]

x_values = [r.attributes['Test Temperature'].value for r in populated_records]
y_values = [r.attributes['Ultimate Tensile Strength'].value for r in populated_records]

# ## Fit the test data
# Fit a fourth-order polynomial to your x and y data.

coeffs = np.polyfit(x_values, y_values, 4)

# Generate x and y values for the fitted equation, using the function you defined at the start.

x_fit = np.linspace(np.amin(x_values), np.amax(x_values), 20)
y_fit = My4degPolyFitFunc(x_fit, *coeffs)

# ## Create a record to store the data in 
# The resulting functional data will be written into the *Design Data* table, using the same unit system.

designdata = db.get_table('Design Data')

# Create a new record to store your functional data.

now = datetime.now().strftime("%c")
recordName = 'STK Example 8:{}'.format(now)
record = designdata.create_record(recordName, subsets={'Metals'})
record.color = mpy.RecordColor.Green

# Access the (empty) functional attribute, and view its column headers.

func = record.attributes['Tens. Ult. Stress (L-dir) with Temp.']
func.column_headers

# ## Populate the functional attribute
# Add the test data to the functional attribute point-by-point, then view the attribute data. Column headers can be
# omitted if they aren't required to represent the data.

for x, y in zip(x_values, y_values):
    func.add_point({'Temperature': x, 'y': y, 'Data Type Lab': 'Test Data'})
func.value

# Then add the fitted data to the functional attribute point-by-point, and view the attribute data with series number as an extra column.

for x, y in zip(x_fit, y_fit):
    func.add_point({'Temperature': x, 'y': y, 'Data Type Lab': 'Fitted Data'})
func.data_with_series_number

# Adjust the series linestyles (`series_linestyles` is a dictionary, indexed with integers).

func.series_linestyles[1] = 'Markers'
func.series_linestyles[2] = 'Lines'
func.series_linestyles

# ## Write your changes to MI
# Set the attributes you've modified to update, and write the new record to the server.

record.set_attributes([func])
mi.update([record])
