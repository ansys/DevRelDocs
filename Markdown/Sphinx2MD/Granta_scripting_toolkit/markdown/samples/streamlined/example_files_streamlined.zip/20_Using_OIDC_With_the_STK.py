# # Using OpenID Connect with MI Scripting Toolkit
#
# Please contact Ansys Granta Technical Support for information on supported OpenID Connect Identity Providers, and for configuration and setup documentation.
#
# ## Access Granta MI using OpenID Connect
#
# In version 2.2 onwards of MI Scripting Toolkit, OIDC authentication is exposed through the Session class in the same way as other authentication options. For interactive use, this is as simple as setting `oidc=True` in the constructor.

from GRANTA_MIScriptingToolkit import granta as mpy

# Connect to MI using OpenID Connect; this will open a browser and prompt the user to log in.
# Access MI and list the available databases.
mi = mpy.connect('https://my.server.name/mi_servicelayer', oidc=True)
print(mi.dbs)

# ## Unattended use
# For unattended use, OIDC tokens can be stored securely in the OS credential manager. For Windows this is the Windows
# Credential Locker, for linux this may be Freedesktop Secret Service or the dbus KWallet. Tokens can be persisted with
# the `Session.persist_oidc_token()` method.

# We can access the tokens provided by the OpenID identity provider using a private property of the session object.
print(mi._Session__auth_token)

mi.persist_oidc_token()

# Clear the current Session
del(mi)

# OpenID Connect tokens can then be extracted from the store and used to create a new Session object with no user interaction.

mi = mpy.Session("https://my.server.name/mi_servicelayer", oidc=True, use_stored_token=True)

print(mi._Session__auth_token)

print(mi.dbs)
