# # Exporting data
#
# Export the values of Ultimate tensile strength, Modulus, Baseline fiber volume, and Poisson's ratio for a set of records from the MI Training database.
#
# This example demonstrates:
#
# * Retrieving a list of databases from a Granta MI server
# * Browsing the tables of a Granta MI database
# * Searching a Granta MI database using the *CriteriaSearch* operation
# * Retrieving values for attributes of a record
#
# ## Create a Granta MI Session
#
# Import the GRANTA_MIScriptingToolkit package, and create a connection to a Granta MI server.

import GRANTA_MIScriptingToolkit as gdl

session = gdl.GRANTA_MISession('http://my.server.name/mi_servicelayer', autoLogon=True)

# ## Get the Databases
#
# Access the browse service from the session and execute the *GetDatabases* method.

browseService = session.browseService
databases = browseService.GetDatabases().databases

print("Found {0} databases on the Granta MI Server".format(len(databases)))
for d in databases:
    print("Database key: {0.DBKey}, Database name: {0.volumeName}".format(d))

# Use pandas to display the available databases.

import pandas as pd

df = pd.DataFrame({'DBKey': [db.DBKey for db in databases],
                  'DBName': [db.volumeName for db in databases]})
df

# ## Get the tables in a database
#
# Use the *GetTables* method from the browse service to see what tables are available in the MI Training database.

dbKey = "MI_Training"

tables = browseService.GetTables(gdl.GetTables(DBKey=dbKey)).tableDetails

print("Found {0} tables in database {1}".format(len(tables), dbKey))
for t in tables:
    print("Table name: {0}".format(t.tableReference.name))

# ## Searching a database
#
# Search MI Training for all records in the Tensile Test Data table which have a defined *Young's modulus (11-axis) (normalized)*

table = 'Tensile Test Data'
attribute = "Young's modulus (11-axis) (normalized)"

tableRef = gdl.PartialTableReference(tableName=table)
attrRef = gdl.AttributeReference(name=attribute, DBKey=dbKey, partialTableReference=tableRef)
searchCriterion = gdl.RecordSearchCriterion(searchAttribute=attrRef, existsSearchValue=gdl.ExistsSearchValue())
request = gdl.CriteriaSearch(DBKey=dbKey, searchCriteria=[searchCriterion])

searchResults = session.searchService.CriteriaSearch(request).searchResults

# Print the *shortName* and *longName* of each of the records returned by the search.

df2 = pd.DataFrame({'ShortName': [r.shortName for r in searchResults],
                     'LongName': [r.longName  for r in searchResults]})
df2

# ## Export data from records
#
# Create attribute references for the attributes you want to export and export data from all records.

attributes = ["Young's Modulus (11-axis) (normalized)", "Ultimate tensile strength (normalized)",
              "Baseline fiber volume", "Elastic Poisson's Ratio (12-plane)"]

attrRefs = [gdl.AttributeReference(name=a, DBKey=dbKey, partialTableReference=tableRef) for a in attributes]
recordRefs = [r.recordReference for r in searchResults]
request = gdl.GetRecordAttributesByRefRequest(recordReferences=recordRefs, attributeReferences=attrRefs)
       
recordData = session.dataExportService.GetRecordAttributesByRef(request).recordData

# Print the values of the attributes from the exported records. Note that some records may not have values for all attributes.

s = [None]*len(df2)
for attribute in attributes:
    for idx, record in enumerate(recordData):
        attrValue = next((x for x in record.attributeValues if x.attributeName == attribute), None)
        s[idx] = attrValue.pointDataType.points[0].value if attrValue else None
    df2[attribute] = s
    
df2

# Create a plot of the exported values

import matplotlib

df2.plot.scatter(x="Ultimate tensile strength (normalized)", y="Young's Modulus (11-axis) (normalized)", loglog=False,
                 c="Elastic Poisson's Ratio (12-plane)", colormap="afmhot", norm=matplotlib.colors.LogNorm(),
                 grid=True, figsize=(10, 7))
