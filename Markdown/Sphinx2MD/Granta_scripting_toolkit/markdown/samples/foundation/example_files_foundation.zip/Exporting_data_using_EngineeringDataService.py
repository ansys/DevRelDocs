# # Exporting data using the Engineering Data Service

# Find a list of FEA exporters for a record in a Granta MI database, and export relevant parameter values.
#
# This example demonstrates:
#
# - Retrieving a list of available exporters
# - Retrieving a list exporters applicable to a specific record in a Granta MI database
# - Get the parameters that can be exported for a specific exporter and record combination
# - Run the FEA exporter on the specific record

# ## Create a Granta MI Session
#
# Import the GRANTA_MIScriptingToolkit package, and create a connection to a Granta MI server.

import GRANTA_MIScriptingToolkit as gdl

session = gdl.GRANTA_MISession('http://my.server.name/mi_servicelayer', autoLogon=True)

# ## List the available exporters
# Retrieve the list of FEA exporters that will export data from the database MI_Training into Ansys Workbench format.

dbKey = "MI_Training"
request = gdl.GetAvailableExportersRequest(DBKey=dbKey, package="ANSYS Workbench", matchDB=True)

print("\nOutput of available Exporters for Ansys Workbench")
response = session.engineeringDataService.GetAvailableExporters(request)

for exporter in response.exporters:
    print("{0} ({1}) - {2}".format(exporter.name, exporter.package, exporter.description))

# Get a record by name.

req = gdl.RecordNameSearchRequest(
    recordName="Nickel alloys, Inconel 718, Forging",
    table=gdl.TableReference(DBKey=dbKey, name="Design Data"),
    searchShortNames=True
)
resp = session.searchService.RecordNameSearch(req)
print("Found {0} record(s)".format(len(resp.searchResults)))
rec = resp.searchResults[0].recordReference


# ## Get exporters for a specific record
# Use the engineering data service to find valid FEA exporters for Inconel 718.

request = gdl.ExportersForRecordsRequest(records=[rec])
resp = session.engineeringDataService.ExportersForRecords(request)
print("\nOutput of exporters for Inconel 718")
for  exporter in resp.records[0].exporters:
    print("{0} ({1}) - {2}".format(exporter.name, 
                                   exporter.package, 
                                   exporter.description))


# ## Get a list of parameters that can be exported
# Get the parameters that can be exported from Inconel 718 using an exporter that supports them.

exporter = resp.records[0].exporters[7]
req = gdl.GetExporterParametersRequest(records=[rec], exporterKey=exporter.key)
expParams = session.engineeringDataService.GetExporterParameters(req)
for attrib in expParams.records[0].attributes:
    print(attrib.attribute.name)
    for param in attrib.parameters:
        print("\t" + param.name)


# ## Perform an FEA Export
# Get all applicable attributes for this record.

req = gdl.GetRecordAttributesRequest(recordReferences=[rec])
attribs = session.browseService.GetRecordAttributes(req)

# If exporting a functional data attribute, you also need to define a parameter value to evaluate the attribute at. Here, a parameter is fixed at 1.337.

myParam = expParams.records[0].attributes[0].parameters[0]
pwv = gdl.ParameterReferenceAndValue(parameterValue=gdl.ParameterValue(numericValue=1.337),
                                     parameter=myParam.parameterReference)

pv = gdl.UnittedParameterValue(unitSymbol=myParam.unit.unitSymbol, 
                               parameterWithValues=pwv)

# Run the FEA exporter, and print the output.

expReq = gdl.ExportRecordDataRequest(
    attributeReferences=[a.attribute.attribute for a in attribs.recordAttributes], 
    records=[rec], 
    exporterKey=exporter.key,
    parameterValues=[pv]
)


resp = session.engineeringDataService.ExportRecordData(expReq)

print(resp.text[:200] + "...")

# Write the output to file.

with open("some_output.xml", "wb") as f:
    f.write(resp.text.encode("utf-8"))
