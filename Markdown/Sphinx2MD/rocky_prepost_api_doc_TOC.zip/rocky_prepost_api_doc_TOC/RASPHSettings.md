# RASPHSettings

<!-- Make "generated" the current module for all API classes so that we can cross-reference them
without adding the full package path. -->
<!-- The empty parenthesis is to suppress documenting the constructor (API classes generally aren't
instantiated by the user). -->

### *class* RASPHSettings

Rocky API wrapper for SPH Settings properties.

This wrapper corresponds to the “SPH” item on a project’s data tree. Access it from
the [`RAStudy`](RAStudy.md#generated.RAStudy) with:

```python
sph_settings = study.GetSphSettings()
sph_settings = study.GetElement('SPH')
```

**Methods:**

| [`AddCurve`](#generated.RASPHSettings.AddCurve)(curve_name, timesteps, values, unit)                                   | Add a curve to the element with a time-steps domain                                                                                                                                                                                                                                                                                                                                                                         |
|------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| [`AddGridFunction`](#generated.RASPHSettings.AddGridFunction)(grid_function_name, ...[, ...])                          | Adds a grid function to the grid.                                                                                                                                                                                                                                                                                                                                                                                           |
| [`CreateCurveOutputVariable`](#generated.RASPHSettings.CreateCurveOutputVariable)(curve_name[, ...])                   | Used to create an output variable based on a curve which doesn't change at each new timestep (i.e.: a curve with a single value for each time).                                                                                                                                                                                                                                                                             |
| [`CreateGridFunction`](#generated.RASPHSettings.CreateGridFunction)(values[, location, time_step])                     | Create a grid function from the given values, location and time-step.                                                                                                                                                                                                                                                                                                                                                       |
| [`CreateGridFunctionArrayOnCells`](#generated.RASPHSettings.CreateGridFunctionArrayOnCells)([time_step])               | Creates a numpy array with the number of elements based on the cells and returns it.                                                                                                                                                                                                                                                                                                                                        |
| [`CreateGridFunctionStatisticOutputVariable`](#generated.RASPHSettings.CreateGridFunctionStatisticOutputVariable)(...) | Used to create an output variable based on a grid function statistic (i.e.: will get a grid function, compute its statistic based on statistic_operation and then based on the statistic values will apply the operation to get a single scalar).                                                                                                                                                                           |
| [`CreateTransientCurveOutputVariable`](#generated.RASPHSettings.CreateTransientCurveOutputVariable)(curve_name)        | Used to create an output variable based on a curve for which there's a completely new representation for each time step -- such as Power : Impact X Belt Width (i.e.: will get the curve multiple times based on the time range, compute a value for each time based on the operation, to convert the multiple curves into a single curve and then will apply the time_operation to get a single scalar from those values). |
| [`DisableEulerianSolution`](#generated.RASPHSettings.DisableEulerianSolution)()                                        | Set the value of "Eulerian Solution" to False.                                                                                                                                                                                                                                                                                                                                                                              |
| [`EnableEulerianSolution`](#generated.RASPHSettings.EnableEulerianSolution)()                                          | Set the value of "Eulerian Solution" to True.                                                                                                                                                                                                                                                                                                                                                                               |
| [`GetActivesArray`](#generated.RASPHSettings.GetActivesArray)([time_step])                                             | Get an array representing the cells' "active" status.                                                                                                                                                                                                                                                                                                                                                                       |
| [`GetAvailableFluidMaterials`](#generated.RASPHSettings.GetAvailableFluidMaterials)()                                  | Get all available Fluid Materials.                                                                                                                                                                                                                                                                                                                                                                                          |
| [`GetBackgroundPressure`](#generated.RASPHSettings.GetBackgroundPressure)([unit])                                      | Get the value of "Background Pressure".                                                                                                                                                                                                                                                                                                                                                                                     |
| [`GetBoundingBox`](#generated.RASPHSettings.GetBoundingBox)([unit, time_step])                                         | Get the element's bounding box.                                                                                                                                                                                                                                                                                                                                                                                             |
| [`GetCS`](#generated.RASPHSettings.GetCS)()                                                                            | Get the value of "C S".                                                                                                                                                                                                                                                                                                                                                                                                     |
| [`GetCellAreaAsArray`](#generated.RASPHSettings.GetCellAreaAsArray)([time_step])                                       | Get an array containing the area of each cell.                                                                                                                                                                                                                                                                                                                                                                              |
| [`GetCellCenterAsArray`](#generated.RASPHSettings.GetCellCenterAsArray)([time_step])                                   | Get an array containing the center coordinates of each cell.                                                                                                                                                                                                                                                                                                                                                                |
| [`GetCellDzAsArray`](#generated.RASPHSettings.GetCellDzAsArray)([time_step])                                           | Get an array containing the thickness (in Z) of each cell.                                                                                                                                                                                                                                                                                                                                                                  |
| [`GetCellFromIJK`](#generated.RASPHSettings.GetCellFromIJK)(i, j, k[, time_step])                                      | Creates a grid cell handle from the current I, J, K indexes                                                                                                                                                                                                                                                                                                                                                                 |
| [`GetCellIJK`](#generated.RASPHSettings.GetCellIJK)(cell_handle[, time_step])                                          | Converts the given cell handle to it's I, J, K indexes                                                                                                                                                                                                                                                                                                                                                                      |
| [`GetCellNumberOfVertices`](#generated.RASPHSettings.GetCellNumberOfVertices)(cell[, time_step])                       | Get an array containing the number of vertices of each cell.                                                                                                                                                                                                                                                                                                                                                                |
| [`GetCellPointsAsFunction`](#generated.RASPHSettings.GetCellPointsAsFunction)([time_step])                             | Get a function for the points (vertices) of each cell.                                                                                                                                                                                                                                                                                                                                                                      |
| [`GetCellVolumeAsArray`](#generated.RASPHSettings.GetCellVolumeAsArray)([time_step])                                   | Get an array with the volume of each cell.                                                                                                                                                                                                                                                                                                                                                                                  |
| [`GetClearyFactor`](#generated.RASPHSettings.GetClearyFactor)()                                                        | Get the value of "Cleary Factor".                                                                                                                                                                                                                                                                                                                                                                                           |
| [`GetCurve`](#generated.RASPHSettings.GetCurve)(curve_name[, simulation_name, ...])                                    | Override base class method to check for a request of a grid function statistic.                                                                                                                                                                                                                                                                                                                                             |
| [`GetCurveNames`](#generated.RASPHSettings.GetCurveNames)([simulation_name])                                           | @param simulation_name: unicode                                                                                                                                                                                                                                                                                                                                                                                             |
| [`GetCurveNamesAssociation`](#generated.RASPHSettings.GetCurveNamesAssociation)([simulation_name])                     | Get this element's curve names.                                                                                                                                                                                                                                                                                                                                                                                             |
| [`GetDensityDevMinus`](#generated.RASPHSettings.GetDensityDevMinus)()                                                  | Get the value of "Density Dev Minus".                                                                                                                                                                                                                                                                                                                                                                                       |
| [`GetDensityDevPlus`](#generated.RASPHSettings.GetDensityDevPlus)()                                                    | Get the value of "Density Dev Plus".                                                                                                                                                                                                                                                                                                                                                                                        |
| [`GetDissFactor`](#generated.RASPHSettings.GetDissFactor)()                                                            | Get the value of "Diss Factor".                                                                                                                                                                                                                                                                                                                                                                                             |
| [`GetDistFactorNorm`](#generated.RASPHSettings.GetDistFactorNorm)()                                                    | Get the value of "Dist Factor Norm".                                                                                                                                                                                                                                                                                                                                                                                        |
| [`GetDistFactorTang`](#generated.RASPHSettings.GetDistFactorTang)()                                                    | Get the value of "Dist Factor Tang".                                                                                                                                                                                                                                                                                                                                                                                        |
| [`GetElementCurve`](#generated.RASPHSettings.GetElementCurve)(element_name, curve_name[, ...])                         | Return the curves for the given element and name.                                                                                                                                                                                                                                                                                                                                                                           |
| [`GetEulerianSolutionEnabled`](#generated.RASPHSettings.GetEulerianSolutionEnabled)()                                  | Get the value of "Eulerian Solution Enabled".                                                                                                                                                                                                                                                                                                                                                                               |
| [`GetFluidMaterial`](#generated.RASPHSettings.GetFluidMaterial)()                                                      | Get the "Fluid Material".                                                                                                                                                                                                                                                                                                                                                                                                   |
| [`GetFreeSurfaceDivergenceLimit`](#generated.RASPHSettings.GetFreeSurfaceDivergenceLimit)()                            | Get the value of "Free Surface Divergence Limit".                                                                                                                                                                                                                                                                                                                                                                           |
| [`GetGeometryQuantity`](#generated.RASPHSettings.GetGeometryQuantity)()                                                | Get the quantity corresponding to the grid's geometry.                                                                                                                                                                                                                                                                                                                                                                      |
| [`GetGeometryUnit`](#generated.RASPHSettings.GetGeometryUnit)()                                                        | Get the grid's geometry's unit.                                                                                                                                                                                                                                                                                                                                                                                             |
| [`GetGridFunction`](#generated.RASPHSettings.GetGridFunction)(grid_function_name[, ...])                               | Gets a grid function given its name.                                                                                                                                                                                                                                                                                                                                                                                        |
| [`GetGridFunctionNames`](#generated.RASPHSettings.GetGridFunctionNames)([translated, context])                         | Get a list of the available grid functions for this grid.                                                                                                                                                                                                                                                                                                                                                                   |
| [`GetKernelDistFactor`](#generated.RASPHSettings.GetKernelDistFactor)()                                                | Get the value of "Kernel Dist Factor".                                                                                                                                                                                                                                                                                                                                                                                      |
| [`GetKernelType`](#generated.RASPHSettings.GetKernelType)()                                                            | Get "Kernel Type" as a string.                                                                                                                                                                                                                                                                                                                                                                                              |
| [`GetMinDistFactor`](#generated.RASPHSettings.GetMinDistFactor)()                                                      | Get the value of "Min Dist Factor".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`GetNumCellSteps`](#generated.RASPHSettings.GetNumCellSteps)()                                                        | Get the value of "Num Cell Steps".                                                                                                                                                                                                                                                                                                                                                                                          |
| [`GetNumberOfCells`](#generated.RASPHSettings.GetNumberOfCells)([time_step])                                           | Get the total number of cells.                                                                                                                                                                                                                                                                                                                                                                                              |
| [`GetNumberOfNodes`](#generated.RASPHSettings.GetNumberOfNodes)([time_step])                                           | Get the total number of nodes (vertices).                                                                                                                                                                                                                                                                                                                                                                                   |
| [`GetNumberOfSteps`](#generated.RASPHSettings.GetNumberOfSteps)()                                                      | Get the value of "Number of Steps".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`GetNumpyCurve`](#generated.RASPHSettings.GetNumpyCurve)(curve_name[, unit, realization])                             | Returns a curve as a tuple of numpy arrays (time, property) for the given element and name.                                                                                                                                                                                                                                                                                                                                 |
| [`GetOutputVariableValue`](#generated.RASPHSettings.GetOutputVariableValue)(variable_name)                             | Get the value of a previously-created output variable.                                                                                                                                                                                                                                                                                                                                                                      |
| [`GetPosCorrectionType`](#generated.RASPHSettings.GetPosCorrectionType)()                                              | Get "Pos Correction Type" as a string.                                                                                                                                                                                                                                                                                                                                                                                      |
| [`GetPressureDeg`](#generated.RASPHSettings.GetPressureDeg)()                                                          | Get the value of "Pressure Deg".                                                                                                                                                                                                                                                                                                                                                                                            |
| [`GetShiftingFactor`](#generated.RASPHSettings.GetShiftingFactor)()                                                    | Get the value of "Shifting Factor".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`GetSize`](#generated.RASPHSettings.GetSize)([unit])                                                                  | Get the value of "Size".                                                                                                                                                                                                                                                                                                                                                                                                    |
| [`GetStabilityDegree`](#generated.RASPHSettings.GetStabilityDegree)()                                                  | Get the value of "Stability Degree".                                                                                                                                                                                                                                                                                                                                                                                        |
| [`GetStabilityNegFactor`](#generated.RASPHSettings.GetStabilityNegFactor)()                                            | Get the value of "Stability Neg Factor".                                                                                                                                                                                                                                                                                                                                                                                    |
| [`GetStabilityPosFactor`](#generated.RASPHSettings.GetStabilityPosFactor)()                                            | Get the value of "Stability Pos Factor".                                                                                                                                                                                                                                                                                                                                                                                    |
| [`GetStiffFactor`](#generated.RASPHSettings.GetStiffFactor)()                                                          | Get the value of "Stiff Factor".                                                                                                                                                                                                                                                                                                                                                                                            |
| [`GetSurfaceTensionBoundaryAngle`](#generated.RASPHSettings.GetSurfaceTensionBoundaryAngle)([unit])                    | Get the value of "Surface Tension Boundary Angle".                                                                                                                                                                                                                                                                                                                                                                          |
| [`GetSurfaceTensionBoundaryFraction`](#generated.RASPHSettings.GetSurfaceTensionBoundaryFraction)()                    | Get the value of "Surface Tension Boundary Fraction".                                                                                                                                                                                                                                                                                                                                                                       |
| [`GetSurfaceTensionCoefficient`](#generated.RASPHSettings.GetSurfaceTensionCoefficient)([unit])                        | Get the value of "Surface Tension Coefficient".                                                                                                                                                                                                                                                                                                                                                                             |
| [`GetSurfaceTensionType`](#generated.RASPHSettings.GetSurfaceTensionType)()                                            | Get "Surface Tension Type" as a string.                                                                                                                                                                                                                                                                                                                                                                                     |
| [`GetTimeSet`](#generated.RASPHSettings.GetTimeSet)()                                                                  | Get the list of time-steps associated to the grid.                                                                                                                                                                                                                                                                                                                                                                          |
| [`GetTimeStatistics`](#generated.RASPHSettings.GetTimeStatistics)()                                                    | Get the object responsible for handling time-statistics grid functions for this process.                                                                                                                                                                                                                                                                                                                                    |
| [`GetTimeStep`](#generated.RASPHSettings.GetTimeStep)(time_step[, accept_global])                                      | Get the timestep corresponding to the given time.                                                                                                                                                                                                                                                                                                                                                                           |
| [`GetTimestepFactor`](#generated.RASPHSettings.GetTimestepFactor)()                                                    | Get the value of "Timestep Factor".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`GetTopologyShape`](#generated.RASPHSettings.GetTopologyShape)([time_step])                                           | Get the shape of the topology (similar to the shape of numpy arrays).                                                                                                                                                                                                                                                                                                                                                       |
| [`GetTurbDistanceFraction`](#generated.RASPHSettings.GetTurbDistanceFraction)()                                        | Get the value of "Turb Distance Fraction".                                                                                                                                                                                                                                                                                                                                                                                  |
| [`GetTurbulenceType`](#generated.RASPHSettings.GetTurbulenceType)()                                                    | Get "Turbulence Type" as a string.                                                                                                                                                                                                                                                                                                                                                                                          |
| [`GetUpdateCoupledDensity`](#generated.RASPHSettings.GetUpdateCoupledDensity)()                                        | Get the value of "Update Coupled Density".                                                                                                                                                                                                                                                                                                                                                                                  |
| [`GetUseParticlesNeighborsList`](#generated.RASPHSettings.GetUseParticlesNeighborsList)()                              | Get the value of "Use Particles Neighbors List".                                                                                                                                                                                                                                                                                                                                                                            |
| [`GetValidKernelTypeValues`](#generated.RASPHSettings.GetValidKernelTypeValues)()                                      | Get a list of all possible values for "Kernel Type".                                                                                                                                                                                                                                                                                                                                                                        |
| [`GetValidPosCorrectionTypeValues`](#generated.RASPHSettings.GetValidPosCorrectionTypeValues)()                        | Get a list of all possible values for "Pos Correction Type".                                                                                                                                                                                                                                                                                                                                                                |
| [`GetValidSurfaceTensionTypeValues`](#generated.RASPHSettings.GetValidSurfaceTensionTypeValues)()                      | Get a list of all possible values for "Surface Tension Type".                                                                                                                                                                                                                                                                                                                                                               |
| [`GetValidTurbulenceTypeValues`](#generated.RASPHSettings.GetValidTurbulenceTypeValues)()                              | Get a list of all possible values for "Turbulence Type".                                                                                                                                                                                                                                                                                                                                                                    |
| [`GetValidViscosityTypeValues`](#generated.RASPHSettings.GetValidViscosityTypeValues)()                                | Get a list of all possible values for "Viscosity Type".                                                                                                                                                                                                                                                                                                                                                                     |
| [`GetViscosityType`](#generated.RASPHSettings.GetViscosityType)()                                                      | Get "Viscosity Type" as a string.                                                                                                                                                                                                                                                                                                                                                                                           |
| [`GetXsphFactor`](#generated.RASPHSettings.GetXsphFactor)()                                                            | Get the value of "Xsph Factor".                                                                                                                                                                                                                                                                                                                                                                                             |
| [`HasGridFunction`](#generated.RASPHSettings.HasGridFunction)(grid_function_name)                                      | Whether the grid has the given grid function.                                                                                                                                                                                                                                                                                                                                                                               |
| [`IsCellActive`](#generated.RASPHSettings.IsCellActive)(i, j, k[, time_step])                                          | Checks if the given cell is active or not                                                                                                                                                                                                                                                                                                                                                                                   |
| [`IsEulerianSolutionEnabled`](#generated.RASPHSettings.IsEulerianSolutionEnabled)()                                    | Check if the "Eulerian Solution" is enabled.                                                                                                                                                                                                                                                                                                                                                                                |
| [`IterCellVertices`](#generated.RASPHSettings.IterCellVertices)(cell[, time_step])                                     | Iterate on the vertices of active grid cells at the given time.                                                                                                                                                                                                                                                                                                                                                             |
| [`IterCells`](#generated.RASPHSettings.IterCells)([time_step])                                                         | Iterate on the active grid cells at the given time.                                                                                                                                                                                                                                                                                                                                                                         |
| [`Modified`](#generated.RASPHSettings.Modified)(\*args, \*\*kwargs)                                                    | Resets all the cache information after a change in the subject being tracked.                                                                                                                                                                                                                                                                                                                                               |
| [`RemoveOutputVariable`](#generated.RASPHSettings.RemoveOutputVariable)(variable_name)                                 | Removes some output variable.                                                                                                                                                                                                                                                                                                                                                                                               |
| [`RemoveProcess`](#generated.RASPHSettings.RemoveProcess)()                                                            | Removes the process from the project.                                                                                                                                                                                                                                                                                                                                                                                       |
| [`SetBackgroundPressure`](#generated.RASPHSettings.SetBackgroundPressure)(value[, unit])                               | Set the value of "Background Pressure".                                                                                                                                                                                                                                                                                                                                                                                     |
| [`SetCS`](#generated.RASPHSettings.SetCS)(value)                                                                       | Set the value of "C S".                                                                                                                                                                                                                                                                                                                                                                                                     |
| [`SetClearyFactor`](#generated.RASPHSettings.SetClearyFactor)(value)                                                   | Set the value of "Cleary Factor".                                                                                                                                                                                                                                                                                                                                                                                           |
| [`SetCurrentTimeStep`](#generated.RASPHSettings.SetCurrentTimeStep)(time_step)                                         | Sets the current time step.                                                                                                                                                                                                                                                                                                                                                                                                 |
| [`SetDensityDevMinus`](#generated.RASPHSettings.SetDensityDevMinus)(value)                                             | Set the value of "Density Dev Minus".                                                                                                                                                                                                                                                                                                                                                                                       |
| [`SetDensityDevPlus`](#generated.RASPHSettings.SetDensityDevPlus)(value)                                               | Set the value of "Density Dev Plus".                                                                                                                                                                                                                                                                                                                                                                                        |
| [`SetDissFactor`](#generated.RASPHSettings.SetDissFactor)(value)                                                       | Set the value of "Diss Factor".                                                                                                                                                                                                                                                                                                                                                                                             |
| [`SetDistFactorNorm`](#generated.RASPHSettings.SetDistFactorNorm)(value)                                               | Set the value of "Dist Factor Norm".                                                                                                                                                                                                                                                                                                                                                                                        |
| [`SetDistFactorTang`](#generated.RASPHSettings.SetDistFactorTang)(value)                                               | Set the value of "Dist Factor Tang".                                                                                                                                                                                                                                                                                                                                                                                        |
| [`SetEulerianSolutionEnabled`](#generated.RASPHSettings.SetEulerianSolutionEnabled)(value)                             | Set the value of "Eulerian Solution Enabled".                                                                                                                                                                                                                                                                                                                                                                               |
| [`SetFluidMaterial`](#generated.RASPHSettings.SetFluidMaterial)(value)                                                 | Set the "Fluid Material".                                                                                                                                                                                                                                                                                                                                                                                                   |
| [`SetFreeSurfaceDivergenceLimit`](#generated.RASPHSettings.SetFreeSurfaceDivergenceLimit)(value)                       | Set the value of "Free Surface Divergence Limit".                                                                                                                                                                                                                                                                                                                                                                           |
| [`SetKernelDistFactor`](#generated.RASPHSettings.SetKernelDistFactor)(value)                                           | Set the value of "Kernel Dist Factor".                                                                                                                                                                                                                                                                                                                                                                                      |
| [`SetKernelType`](#generated.RASPHSettings.SetKernelType)(value)                                                       | Set the value of "Kernel Type".                                                                                                                                                                                                                                                                                                                                                                                             |
| [`SetMinDistFactor`](#generated.RASPHSettings.SetMinDistFactor)(value)                                                 | Set the value of "Min Dist Factor".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`SetNumCellSteps`](#generated.RASPHSettings.SetNumCellSteps)(value)                                                   | Set the value of "Num Cell Steps".                                                                                                                                                                                                                                                                                                                                                                                          |
| [`SetNumberOfSteps`](#generated.RASPHSettings.SetNumberOfSteps)(value)                                                 | Set the value of "Number of Steps".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`SetPosCorrectionType`](#generated.RASPHSettings.SetPosCorrectionType)(value)                                         | Set the value of "Pos Correction Type".                                                                                                                                                                                                                                                                                                                                                                                     |
| [`SetPressureDeg`](#generated.RASPHSettings.SetPressureDeg)(value)                                                     | Set the value of "Pressure Deg".                                                                                                                                                                                                                                                                                                                                                                                            |
| [`SetShiftingFactor`](#generated.RASPHSettings.SetShiftingFactor)(value)                                               | Set the value of "Shifting Factor".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`SetSize`](#generated.RASPHSettings.SetSize)(value[, unit])                                                           | Set the value of "Size".                                                                                                                                                                                                                                                                                                                                                                                                    |
| [`SetStabilityDegree`](#generated.RASPHSettings.SetStabilityDegree)(value)                                             | Set the value of "Stability Degree".                                                                                                                                                                                                                                                                                                                                                                                        |
| [`SetStabilityNegFactor`](#generated.RASPHSettings.SetStabilityNegFactor)(value)                                       | Set the value of "Stability Neg Factor".                                                                                                                                                                                                                                                                                                                                                                                    |
| [`SetStabilityPosFactor`](#generated.RASPHSettings.SetStabilityPosFactor)(value)                                       | Set the value of "Stability Pos Factor".                                                                                                                                                                                                                                                                                                                                                                                    |
| [`SetStiffFactor`](#generated.RASPHSettings.SetStiffFactor)(value)                                                     | Set the value of "Stiff Factor".                                                                                                                                                                                                                                                                                                                                                                                            |
| [`SetSurfaceTensionBoundaryAngle`](#generated.RASPHSettings.SetSurfaceTensionBoundaryAngle)(value[, unit])             | Set the value of "Surface Tension Boundary Angle".                                                                                                                                                                                                                                                                                                                                                                          |
| [`SetSurfaceTensionBoundaryFraction`](#generated.RASPHSettings.SetSurfaceTensionBoundaryFraction)(value)               | Set the value of "Surface Tension Boundary Fraction".                                                                                                                                                                                                                                                                                                                                                                       |
| [`SetSurfaceTensionCoefficient`](#generated.RASPHSettings.SetSurfaceTensionCoefficient)(value[, unit])                 | Set the value of "Surface Tension Coefficient".                                                                                                                                                                                                                                                                                                                                                                             |
| [`SetSurfaceTensionType`](#generated.RASPHSettings.SetSurfaceTensionType)(value)                                       | Set the value of "Surface Tension Type".                                                                                                                                                                                                                                                                                                                                                                                    |
| [`SetTimestepFactor`](#generated.RASPHSettings.SetTimestepFactor)(value)                                               | Set the value of "Timestep Factor".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`SetTurbDistanceFraction`](#generated.RASPHSettings.SetTurbDistanceFraction)(value)                                   | Set the value of "Turb Distance Fraction".                                                                                                                                                                                                                                                                                                                                                                                  |
| [`SetTurbulenceType`](#generated.RASPHSettings.SetTurbulenceType)(value)                                               | Set the value of "Turbulence Type".                                                                                                                                                                                                                                                                                                                                                                                         |
| [`SetUpdateCoupledDensity`](#generated.RASPHSettings.SetUpdateCoupledDensity)(value)                                   | Set the value of "Update Coupled Density".                                                                                                                                                                                                                                                                                                                                                                                  |
| [`SetUseParticlesNeighborsList`](#generated.RASPHSettings.SetUseParticlesNeighborsList)(value)                         | Set the value of "Use Particles Neighbors List".                                                                                                                                                                                                                                                                                                                                                                            |
| [`SetViscosityType`](#generated.RASPHSettings.SetViscosityType)(value)                                                 | Set the value of "Viscosity Type".                                                                                                                                                                                                                                                                                                                                                                                          |
| [`SetXsphFactor`](#generated.RASPHSettings.SetXsphFactor)(value)                                                       | Set the value of "Xsph Factor".                                                                                                                                                                                                                                                                                                                                                                                             |

#### AddCurve(curve_name, timesteps, values, unit, realization=None, timesteps_unit=None, initial_date=None)

Add a curve to the element with a time-steps domain

* **Parameters:**
  * **curve_name** (*unicode* *or* *SemanticAssociation*) – The curve’s name or semantic association
  * **timesteps** (*list**(**TimeStep**) or* *list**(**float**) or* *TimeSet*) – The list of time-steps, in such case a initial date can be provided
    The list of elapsed time as floats, in such case a timesteps_units can be
    provide or days will be used
    The curve’s TimeSet
  * **values** (*list**(**float**)*) – The list of curve image values
  * **unit** (*unicode* *or* *Quantity*) – The curve image unit or quantity
  * **realization** (*unicode*) – An additional keyword to identify the curve realization
  * **timesteps_units** (*unicode*) – The elapsed time values unit
    It should be given if a list of floats is used to define the time-set
    If not given days are assumed
  * **initial_date** (*tuple**(**int**,* *int**,* *int**,* *int**,* *int**,* *int**) or* *TimeStep*) – The initial date for the time-steps given
    A tuple with the year, month, day, hour, minute and seconds
    Or a TimeStep

#### AddGridFunction(grid_function_name, grid_function, unit='<unknown>', location='cell', realization='user_generated', time_step=None)

Adds a grid function to the grid.

* **Parameters:**
  * **grid_function_name** (*unicode* *or* *SemanticAssociation*) – The name of the grid function to be stored in this grid or the semantic association
    representing the grid function.
  * **grid_function** (*list**(**double**) or* *numpy array*) – The values of the grid function to be added.
  * **unit** (*unicode* *or* *IQuantity*) – The unit (or quantity) in which the grid function is being given.
  * **location** (*unicode*) – The location of the grid function (currently only ‘cell’ is accepted).
  * **realization** (*unicode*) – The realization used to identify the grid function among other grid functions. If None,
    this information is ignored.
  * **time_step** (*None**,* *unicode**,* *ITimeStep* *or* *int*) – if None if given a static grid function will be created otherwise a transient grid
    function is created and the given array associated with this time-step

#### SEE ALSO
KAContextDependentElement.GetTimeStep

#### CreateCurveOutputVariable(curve_name: str, operation: str = 'max', time_range: str = 'all', initial_time_range: float = 0.0, final_time_range: float = 0.0)

Used to create an output variable based on a curve which doesn’t change at each new timestep
(i.e.: a curve with a single value for each time).

* **See:**
  CreateTransientCurveOutputVariable for dealing with curves that are transient.
* **Parameters:**
  * **curve_name** – The name of the curve for which the output variable is wanted.
  * **operation** – 

    The operation we want to do to convert the curve into a single value.
    Valid operations:
    : ’min’
      ‘max’
      ‘sum’
      ‘sum_squared’
      ‘average’
      ‘variance’
      ‘standard_deviation’
  * **time_range** – 

    Defines the time range for the curve to be gathered for creating the output
    variable (depending on which time range is chosen, the initial_time_range and the
    final_time_range may be used to get the actual times for computing the statistics).
    Valid time ranges:
    : ’app_time_filter’:
      : Uses the application time filter to get the relevant times.
      <br/>
      ’all’
      : Uses all the times in the simulation.
      <br/>
      ’last_output’
      : Uses only the last time in the simulation.
      <br/>
      ’absolute’
      : Defines a time range using the initial_time_range and final_time_range.
      <br/>
      ’single’
      : Defines a single time to be used as the time range specified as the
        initial_time_range.
      <br/>
      ’absolute_only_start’
      : Defines a time range using all the values after the given initial_time_range.
      <br/>
      ’relative_to_end’
      : Uses all the values considering initial_time_range as a delta from the end of
        the simulation.
  * **initial_time_range** – A value in seconds (whose actual meaning depends on the defined time_range).
  * **final_time_range** – A value in seconds (whose actual meaning depends on the defined time_range).
* **Return type:**
  str
* **Returns:**
  Returns the name of the variable to be used later on to reference the output variable.

#### CreateGridFunction(values, location='cell', time_step='current')

Create a grid function from the given values, location and time-step.

* **Parameters:**
  * **values** (*list**(**double**) or* *numpy array*) – The values of the grid function to be added.
  * **time_step** – 

#### SEE ALSO
KAContextDependentElement.GetTimeStep

#### CreateGridFunctionArrayOnCells(time_step='current')

Creates a numpy array with the number of elements based on the cells and returns it. A
different time may be specified to create the grid function based on a different time.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to create the array
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  numpy.array
* **Returns:**
  Returns a numpy float32 array with the number of elements equal to the number of cells.

#### CreateGridFunctionStatisticOutputVariable(grid_function_name: str, operation: str = 'max', statistic_operation: str = 'max', time_range: str = 'last_output', initial_time_range: float = 0.0, final_time_range: float = 0.0)

Used to create an output variable based on a grid function statistic (i.e.: will get a
grid function, compute its statistic based on statistic_operation and then based on
the statistic values will apply the operation to get a single scalar).

* **Parameters:**
  * **grid_function_name** – The name of the grid function for which the output variable is wanted.
  * **operation** – 

    The operation used to select which value to get based on the statistic values obtained.
    Valid operations:
    : ’min’
      ‘max’
      ‘sum’
      ‘sum_squared’
      ‘average’
      ‘variance’
      ‘standard_deviation’
  * **statistic_operation** – 

    The statistic operation which should be applied to the grid function for each time to
    obtain a single value for each time.
    Valid operations:
    : ’min’
      ‘max’
      ‘sum’
      ‘sum_squared’
      ‘average’
      ‘variance’
      ‘standard_deviation’
  * **time_range** – 

    Defines the time range for the grid functions to be gathered for creating the output
    variable (depending on which time range is chosen, the initial_time_range and the
    final_time_range may be used to get the actual times for computing the statistics).
    Valid time ranges:
    : ’app_time_filter’:
      : Uses the application time filter to get the relevant times.
      <br/>
      ’all’
      : Uses all the times in the simulation.
      <br/>
      ’last_output’
      : Uses only the last time in the simulation.
      <br/>
      ’absolute’
      : Defines a time range using the initial_time_range and final_time_range.
      <br/>
      ’single’
      : Defines a single time to be used as the time range specified as the
        initial_time_range.
      <br/>
      ’absolute_only_start’
      : Defines a time range using all the values after the given initial_time_range.
      <br/>
      ’relative_to_end’
      : Uses all the values considering initial_time_range as a delta from the end of
        the simulation.
  * **initial_time_range** – A value in seconds (whose actual meaning depends on the defined time_range).
  * **final_time_range** – A value in seconds (whose actual meaning depends on the defined time_range).
* **Returns:**
  Returns the name of the variable to be used later on to reference the output variable.

#### CreateTransientCurveOutputVariable(curve_name: str, operation: str = 'max', time_operation: str = 'max', time_range: str = 'last_output', initial_time_range: float = 0.0, final_time_range: float = 0.0, domain_range: str = 'all', initial_domain_range: float = 0.0, final_domain_range: float = 0.0, domain_unit: Optional[str] = None)

Used to create an output variable based on a curve for which there’s a completely new
representation for each time step – such as Power : Impact X Belt Width
(i.e.: will get the curve multiple times based on the time range, compute a value for each
time based on the operation, to convert the multiple curves into a single curve and then
will apply the time_operation to get a single scalar from those values).

* **Parameters:**
  * **curve_name** – The name of the transient curve for which the output variable is wanted.
  * **operation** – 

    The operation we want to do at the curve in each time (i.e.: go from transient curve
    to a regular curve).
    Valid operations:
    : ’min’
      ‘max’
      ‘sum’
      ‘sum_squared’
      ‘average’
      ‘variance’
      ‘standard_deviation’
  * **time_operation** – 

    The operation that we want to do at the curve when the curve is already converted to
    a regular time-based curve (by applying the ‘operation’ at each time).
    Valid operations:
    : ’min’
      ‘max’
      ‘sum’
      ‘sum_squared’
      ‘average’
      ‘variance’
      ‘standard_deviation’
  * **time_range** – 

    Defines the time range for the curve to be gathered for creating the output
    variable (depending on which time range is chosen, the initial_time_range and the
    final_time_range may be used to get the actual times for computing the statistics).
    Valid time ranges:
    : ’app_time_filter’:
      : Uses the application time filter to get the relevant times.
      <br/>
      ’all’
      : Uses all the times in the simulation.
      <br/>
      ’last_output’
      : Uses only the last time in the simulation.
      <br/>
      ’absolute’
      : Defines a time range using the initial_time_range and final_time_range.
      <br/>
      ’single’
      : Defines a single time to be used as the time range specified as the
        initial_time_range.
      <br/>
      ’absolute_only_start’
      : Defines a time range using all the values after the given initial_time_range.
      <br/>
      ’relative_to_end’
      : Uses all the values considering initial_time_range as a delta from the end of
        the simulation.
  * **initial_time_range** – A value in seconds (whose actual meaning depends on the defined time_range).
  * **final_time_range** – A value in seconds (whose actual meaning depends on the defined time_range).
  * **domain_range** – 

    Define the domain range for the curve to create the output variable
    Valid domain_range:
    : ’all’
      : Uses all the domain in the simulation
      <br/>
      ’single’
      : Defines a single time to be used as the time range specified as the initial_domain_range
      <br/>
      ’absolute’
      : Defines a domain range using the initial_domain_range and final_domain_range.
  * **initial_domain_range** – A value for the beginning of the domain (whose actual meaning depends on the defined domain_range).
  * **final_domain_range** – A value for the end of the domain (whose actual meaning depends on the defined domain_range).
  * **domain_unit** – A unit for the domain_range
* **Return type:**
  str
* **Returns:**
  Returns the name of the variable to be used later on to reference the output variable.

#### DisableEulerianSolution()

Set the value of “Eulerian Solution” to False.

#### EnableEulerianSolution()

Set the value of “Eulerian Solution” to True.

#### GetActivesArray(time_step='current')

Get an array representing the cells’ “active” status.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the actives array
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  numpy array
* **Returns:**
  Returns a numpy array with booleans where True means the cell is active and False
  means it’s not active.

#### GetAvailableFluidMaterials()

Get all available Fluid Materials.

* **Return type:**
  List[[`RAFluidMaterial`](RAFluidMaterial.md#generated.RAFluidMaterial)]
  A list of [`RAFluidMaterial`](RAFluidMaterial.md#generated.RAFluidMaterial).

#### GetBackgroundPressure(unit: Optional[str] = None)

Get the value of “Background Pressure”.

* **Parameters:**
  **unit** – The unit for the returned value. If no unit is provided, the returned value will be in “Pa”.

#### GetBoundingBox(unit=None, time_step='current')

Get the element’s bounding box.

* **Parameters:**
  * **unit** (*unicode*) – The unit in which the bounding box should be gotten (by default it uses the same
    unit of the geometry).
  * **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
    or an ITimeStep identifying the time to get the bounding box
    or an int identifying the time step index to be used based on the global time set
* **Return type:**
  tuple(tuple(float, float, float), tuple(float, float, float))
* **Returns:**
  THe minimum and maximum geometry coordinates of the grid or None if the
  time step is not available at the requested time.

#### GetCS()

Get the value of “C S”.

#### GetCellAreaAsArray(time_step='current')

Get an array containing the area of each cell.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the cell volume
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  numpy.array
* **Returns:**
  An array with the cell area (the unit will be the geometry unit \*\* 2)

#### GetCellCenterAsArray(time_step='current')

Get an array containing the center coordinates of each cell.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the cell center
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  numpy.array
* **Returns:**
  An array with the cell center coordinates (each element will be a point to the center of
  the cell).

#### GetCellDzAsArray(time_step='current')

Get an array containing the thickness (in Z) of each cell.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the cell dz
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  numpy.array
* **Returns:**
  An array with cell thicknesses computed in the Z direction.

#### GetCellFromIJK(i, j, k, time_step='current')

Creates a grid cell handle from the current I, J, K indexes

* **Parameters:**
  * **i** (*int*) – The topological I cell index
  * **j** (*int*) – The topological J cell index
  * **k** (*int*) – The topological K cell index
  * **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
    or an ITimeStep identifying the time to get the cell from the i, j, k
    or an int identifying the time step index to be used based on the global time set
* **Return type:**
  int or None
* **Returns:**
  Returns the cell handle to be used for the given I, J, K indexes.
  Or None if the given I, J and K indexes are invalid or refer to an inactive cell
* **Raises:**
  **IndexError** – An IndexError is raised if the cell is inactive or out of range.

#### GetCellIJK(cell_handle, time_step='current')

Converts the given cell handle to it’s I, J, K indexes

* **Parameters:**
  * **cell_handle** (*int*) – The cell handle
  * **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
    or an ITimeStep identifying the time to get the i, j, k from the cell.
    or an int identifying the time step index to be used based on the global time set
* **Return type:**
  tuple( i, j, k )
* **Returns:**
  The cell I, J, K indexes

#### GetCellNumberOfVertices(cell, time_step='current')

Get an array containing the number of vertices of each cell.

* **Parameters:**
  * **cell_handle** (*int*) – The cell handle
  * **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
    or an ITimeStep identifying the time to get the number of vertices for the given cell
    or an int identifying the time step index to be used based on the global time set
* **Return type:**
  int
* **Returns:**
  The total number of vertices on the given cell

#### GetCellPointsAsFunction(time_step='current')

Get a function for the points (vertices) of each cell.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the cell points
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  PointsFunction
* **Returns:**
  A function that provides access to the points of a cell (i.e.: vertices).

#### NOTE
Each point from a cell must be accessed by a tuple(cell_handle, point_id). In a
reservoir grid, the point id is a value from 0 to 7.

@usage:

```default
#To get vertex 0 of a cell:
points_function = grid.GetCellPointsAsFunction()
cell = grid.GetCellFromIJK(0, 0, 0)
x, y, z = points_function[(cell, 0)]

#To iterate over all the vertices of a cell:
points_function = grid.GetCellPointsAsFunction()
cell = grid.GetCellFromIJK(0, 0, 0)
for vertex in grid.IterCellVertices(cell):
    x, y, z = points_function[vertex]
```

#### GetCellVolumeAsArray(time_step='current')

Get an array with the volume of each cell.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the cell volume
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  numpy.array
* **Returns:**
  An array with the cell volume (the unit will be the geometry unit \*\* 3)

#### GetClearyFactor()

Get the value of “Cleary Factor”.

#### GetCurve(curve_name, simulation_name=None, realization=None, time_step=None)

Override base class method to check for a request of a grid function statistic.

#### GetCurveNames(simulation_name=None)

@param simulation_name: unicode
: An optional parameter for defining the simulation to get the curve from.

* **Returns:**
  list(str)
  The list of curve names

#### GetCurveNamesAssociation(simulation_name=None)

Get this element’s curve names.

* **Parameters:**
  **simulation_name** (*unicode*) – The name of the simulation to query the curve names
  If None is given the current element simulation will be used
* **Return type:**
  dict(unicode, ISemanticAssociation)
* **Returns:**
  The curve names for this element in the given simulation name

#### GetDensityDevMinus()

Get the value of “Density Dev Minus”.

#### GetDensityDevPlus()

Get the value of “Density Dev Plus”.

#### GetDissFactor()

Get the value of “Diss Factor”.

#### GetDistFactorNorm()

Get the value of “Dist Factor Norm”.

#### GetDistFactorTang()

Get the value of “Dist Factor Tang”.

#### GetElementCurve(element_name, curve_name, simulation_name=None, realization=None, time_step=None)

Return the curves for the given element and name.

* **Parameters:**
  * **element_name** (*unicode*) – The name of the element
  * **curve_name** (*unicode*) – The name of the curve
  * **simulation_name** (*unicode*) – An optional parameter for defining the simulation to get the curve from.
  * **realization** (*unicode*) – An additional keyword to identify the curve realization
  * **time_step** (*TimeStep*) – For transient curves a time-step must be given.

#### GetEulerianSolutionEnabled()

Get the value of “Eulerian Solution Enabled”.

#### GetFluidMaterial()

Get the “Fluid Material”.

* **Return type:**
  [`RAFluidMaterial`](RAFluidMaterial.md#generated.RAFluidMaterial)

#### GetFreeSurfaceDivergenceLimit()

Get the value of “Free Surface Divergence Limit”.

#### GetGeometryQuantity()

Get the quantity corresponding to the grid’s geometry.

* **Return type:**
  IQuantity
* **Returns:**
  The grid geometry quantity

#### GetGeometryUnit()

Get the grid’s geometry’s unit.

* **Return type:**
  unicode
* **Returns:**
  The unit for the grid geometry

#### GetGridFunction(grid_function_name, simulation_name=None, translated=False)

Gets a grid function given its name. It provides a representation that’s valid for all times,
so, one can do: grid.GetGridFunction(‘Pressure’).GetMax()

To get the values of a given time, use:

```default
time_set = grid.GetTimeSet()
grid.GetGridFunction('Temperature').GetArray(unit='degC', time_step=time_set[10])
```

#### NOTE
if it’s used without a time parameter, it’ll get the array at the current application time.

* **Parameters:**
  * **grid_function_name** (*unicode*) – The name of the grid function to be gotten in this grid.
  * **simulation_name** (*unicode*) – An optional parameter for defining the simulation to get the grid function from.
  * **translated** (*bool*) – If False, the internal names of the grid functions will be returned, otherwise, the
    name returned will be the translated name (based on the settings chosen on how
    to see grid functions – i.e.: Cognitive, ECLIPSE, IMEX).
* **Return type:**
  KAGridFunction
* **Returns:**
  The grid function found
* **Raises:**
  **ValueError** – if the grid function is not found.

#### GetGridFunctionNames(translated=False, context=None)

Get a list of the available grid functions for this grid.

* **Parameters:**
  * **translated** (*bool*) – If False, the internal names of the grid functions will be returned, otherwise, the
    name returned will be the translated name (based on the settings chosen on how
    to see grid functions – i.e.: Cognitive, ECLIPSE, IMEX).
  * **context** (*'all'**,* *'static'* *or* *'transient'*) – Which names should be returned
    ‘all’ all grid function names
    ‘static’ only the static grid function names
    ‘transient’ only the transient grid function names
* **Return type:**
  list(unicode)
* **Returns:**
  Returns a list with the grid functions available.

#### GetKernelDistFactor()

Get the value of “Kernel Dist Factor”.

#### GetKernelType()

Get “Kernel Type” as a string.

* **Returns:**
  The returned value will be one of [‘cubic’, ‘quintic’, ‘wendland’].

#### GetMinDistFactor()

Get the value of “Min Dist Factor”.

#### GetNumCellSteps()

Get the value of “Num Cell Steps”.

#### GetNumberOfCells(time_step='current')

Get the total number of cells.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the number of cells
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  int
* **Returns:**
  The total number of cells

#### GetNumberOfNodes(time_step='current')

Get the total number of nodes (vertices).

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the number of cells
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  int
* **Returns:**
  The total number of nodes/vertices

#### GetNumberOfSteps()

Get the value of “Number of Steps”.

#### GetNumpyCurve(curve_name, unit=None, realization=None)

Returns a curve as a tuple of numpy arrays (time, property) for the given element and name.

#### GetOutputVariableValue(variable_name: str)

Get the value of a previously-created output variable.

* **Parameters:**
  **variable_name** (*unicode*) – The variable name whose value we want.
* **Returns:**
  Returns a scalar with the value and unit for the given variable_name or None if no
  variable was found with the given name or if it couldn’t be computed.

#### GetPosCorrectionType()

Get “Pos Correction Type” as a string.

* **Returns:**
  The returned value will be one of [‘none’, ‘xsph’, ‘shift’].

#### GetPressureDeg()

Get the value of “Pressure Deg”.

#### GetShiftingFactor()

Get the value of “Shifting Factor”.

#### GetSize(unit: Optional[str] = None)

Get the value of “Size”.

* **Parameters:**
  **unit** – The unit for the returned value. If no unit is provided, the returned value will be in “m”.

#### GetStabilityDegree()

Get the value of “Stability Degree”.

#### GetStabilityNegFactor()

Get the value of “Stability Neg Factor”.

#### GetStabilityPosFactor()

Get the value of “Stability Pos Factor”.

#### GetStiffFactor()

Get the value of “Stiff Factor”.

#### GetSurfaceTensionBoundaryAngle(unit: Optional[str] = None)

Get the value of “Surface Tension Boundary Angle”.

* **Parameters:**
  **unit** – The unit for the returned value. If no unit is provided, the returned value will be in “dega”.

#### GetSurfaceTensionBoundaryFraction()

Get the value of “Surface Tension Boundary Fraction”.

#### GetSurfaceTensionCoefficient(unit: Optional[str] = None)

Get the value of “Surface Tension Coefficient”.

* **Parameters:**
  **unit** – The unit for the returned value. If no unit is provided, the returned value will be in “N/m”.

#### GetSurfaceTensionType()

Get “Surface Tension Type” as a string.

* **Returns:**
  The returned value will be one of [‘none’, ‘CSF’, ‘CSS’, ‘custom’].

#### GetTimeSet()

Get the list of time-steps associated to the grid.

* **Return type:**
  ITimeSet
* **Returns:**
  The list of time-steps associated to the grid

#### GetTimeStatistics()

Get the object responsible for handling time-statistics grid functions for this process.
This call will return None if the process doesn’t support time statistics.

#### GetTimeStep(time_step, accept_global=False)

Get the timestep corresponding to the given time.

* **Parameters:**
  * **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a string with
    : ’current’ identifying the current time step
      ‘global’ identifying that the global limits should be gotten
      (note that if accept_global=False and ‘global’ is passed, an error is raised).

    or an ITimeStep identifying the time to get the limits

    or an int identifying the time step index to be used based on the global time set
  * **accept_global** (*bool*) – If True, a global time step is accepted (and returns None), otherwise, an error is
    raised if ‘global’ is passed.
* **Return type:**
  ITimeStep
* **Returns:**
  Returns the time step to be used or None if accept_global == True and the time
  step passed is ‘global’.

#### GetTimestepFactor()

Get the value of “Timestep Factor”.

#### GetTopologyShape(time_step='current')

Get the shape of the topology (similar to the shape of numpy arrays).

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get the topology shape
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  tuple of ints
* **Returns:**
  The grid shape as a tuple of the grid size in each topological dimension.

#### GetTurbDistanceFraction()

Get the value of “Turb Distance Fraction”.

#### GetTurbulenceType()

Get “Turbulence Type” as a string.

* **Returns:**
  The returned value will be one of [‘laminar’, ‘les’].

#### GetUpdateCoupledDensity()

Get the value of “Update Coupled Density”.

#### GetUseParticlesNeighborsList()

Get the value of “Use Particles Neighbors List”.

#### GetValidKernelTypeValues()

Get a list of all possible values for “Kernel Type”.

* **Returns:**
  The returned list is [‘cubic’, ‘quintic’, ‘wendland’].

#### GetValidPosCorrectionTypeValues()

Get a list of all possible values for “Pos Correction Type”.

* **Returns:**
  The returned list is [‘none’, ‘xsph’, ‘shift’].

#### GetValidSurfaceTensionTypeValues()

Get a list of all possible values for “Surface Tension Type”.

* **Returns:**
  The returned list is [‘none’, ‘CSF’, ‘CSS’, ‘custom’].

#### GetValidTurbulenceTypeValues()

Get a list of all possible values for “Turbulence Type”.

* **Returns:**
  The returned list is [‘laminar’, ‘les’].

#### GetValidViscosityTypeValues()

Get a list of all possible values for “Viscosity Type”.

* **Returns:**
  The returned list is [‘cleary’, ‘morris’].

#### GetViscosityType()

Get “Viscosity Type” as a string.

* **Returns:**
  The returned value will be one of [‘cleary’, ‘morris’].

#### GetXsphFactor()

Get the value of “Xsph Factor”.

#### HasGridFunction(grid_function_name)

Whether the grid has the given grid function.

* **Parameters:**
  **grid_function_name** (*unicode*) – The name of the grid function to be checked.
* **Return type:**
  bool
* **Returns:**
  Returns True if the grid function exists and False otherwise.

#### IsCellActive(i, j, k, time_step='current')

Checks if the given cell is active or not

@param i, j, k: int
: The cell i, j, k

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to get if the cell is active
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  bool
* **Returns:**
  True if the cell is active

#### IsEulerianSolutionEnabled()

Check if the “Eulerian Solution” is enabled.

#### IterCellVertices(cell, time_step='current')

Iterate on the vertices of active grid cells at the given time.

* **Parameters:**
  * **cell_handle** (*int*) – The cell handle
  * **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
    or an ITimeStep identifying the time to iterate the vertices of a cell
    or an int identifying the time step index to be used based on the global time set
* **Return type:**
  vertex_handle
* **Returns:**
  The iterator over all the cell’s vertices.

#### IterCells(time_step='current')

Iterate on the active grid cells at the given time.

* **Parameters:**
  **time_step** (*unicode**,* *ITimeStep* *or* *int*) – Either a ‘current’ string with meaning the current time step
  or an ITimeStep identifying the time to iterate the cells
  or an int identifying the time step index to be used based on the global time set
* **Return type:**
  iterator
* **Returns:**
  The iterator over all the active grid cells for the given time.

#### Modified(\*args, \*\*kwargs)

Resets all the cache information after a change in the subject being tracked.

#### RemoveOutputVariable(variable_name: str)

Removes some output variable.

* **Parameters:**
  **variable_name** – The name of the variable to be removed.

#### RemoveProcess()

Removes the process from the project.

#### SetBackgroundPressure(value: Union[str, float], unit: Optional[str] = None)

Set the value of “Background Pressure”.

* **Parameters:**
  * **value** – The value to set. This value can be an expression with input variables or float type.
  * **unit** – The unit for value. If no unit is provided, value is assumed to be in “Pa”.

#### SetCS(value: Union[str, float])

Set the value of “C S”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetClearyFactor(value: Union[str, float])

Set the value of “Cleary Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetCurrentTimeStep(time_step)

Sets the current time step.

* **Parameters:**
  **time_step** (*ITimeStep*) – The time step to be considered the ‘current’ time step.

#### SetDensityDevMinus(value: Union[str, float])

Set the value of “Density Dev Minus”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetDensityDevPlus(value: Union[str, float])

Set the value of “Density Dev Plus”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetDissFactor(value: Union[str, float])

Set the value of “Diss Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetDistFactorNorm(value: Union[str, float])

Set the value of “Dist Factor Norm”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetDistFactorTang(value: Union[str, float])

Set the value of “Dist Factor Tang”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetEulerianSolutionEnabled(value: bool)

Set the value of “Eulerian Solution Enabled”.

* **Parameters:**
  **value** – The value to set.

#### SetFluidMaterial(value)

Set the “Fluid Material”.

:param unicode, [`RAFluidMaterial`](RAFluidMaterial.md#generated.RAFluidMaterial) value:
: Either the API object wrapping the desired entity or its name.

#### SetFreeSurfaceDivergenceLimit(value: Union[str, float])

Set the value of “Free Surface Divergence Limit”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetKernelDistFactor(value: Union[str, float])

Set the value of “Kernel Dist Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetKernelType(value: str)

Set the value of “Kernel Type”.

* **Parameters:**
  **value** – The value to set. Must be one of [‘cubic’, ‘quintic’, ‘wendland’].
* **Raises:**
  **RockyApiError** – If value is not a valid “Kernel Type” option.

#### SetMinDistFactor(value: Union[str, float])

Set the value of “Min Dist Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetNumCellSteps(value: Union[str, int])

Set the value of “Num Cell Steps”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or int type.

#### SetNumberOfSteps(value: Union[str, int])

Set the value of “Number of Steps”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or int type.

#### SetPosCorrectionType(value: str)

Set the value of “Pos Correction Type”.

* **Parameters:**
  **value** – The value to set. Must be one of [‘none’, ‘xsph’, ‘shift’].
* **Raises:**
  **RockyApiError** – If value is not a valid “Pos Correction Type” option.

#### SetPressureDeg(value: Union[str, int])

Set the value of “Pressure Deg”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or int type.

#### SetShiftingFactor(value: Union[str, float])

Set the value of “Shifting Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetSize(value: Union[str, float], unit: Optional[str] = None)

Set the value of “Size”.

* **Parameters:**
  * **value** – The value to set. This value can be an expression with input variables or float type.
  * **unit** – The unit for value. If no unit is provided, value is assumed to be in “m”.

#### SetStabilityDegree(value: Union[str, int])

Set the value of “Stability Degree”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or int type.

#### SetStabilityNegFactor(value: Union[str, float])

Set the value of “Stability Neg Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetStabilityPosFactor(value: Union[str, float])

Set the value of “Stability Pos Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetStiffFactor(value: Union[str, float])

Set the value of “Stiff Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetSurfaceTensionBoundaryAngle(value: Union[str, float], unit: Optional[str] = None)

Set the value of “Surface Tension Boundary Angle”.

* **Parameters:**
  * **value** – The value to set. This value can be an expression with input variables or float type.
  * **unit** – The unit for value. If no unit is provided, value is assumed to be in “dega”.

#### SetSurfaceTensionBoundaryFraction(value: Union[str, float])

Set the value of “Surface Tension Boundary Fraction”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetSurfaceTensionCoefficient(value: Union[str, float], unit: Optional[str] = None)

Set the value of “Surface Tension Coefficient”.

* **Parameters:**
  * **value** – The value to set. This value can be an expression with input variables or float type.
  * **unit** – The unit for value. If no unit is provided, value is assumed to be in “N/m”.

#### SetSurfaceTensionType(value: str)

Set the value of “Surface Tension Type”.

* **Parameters:**
  **value** – The value to set. Must be one of [‘none’, ‘CSF’, ‘CSS’, ‘custom’].
* **Raises:**
  **RockyApiError** – If value is not a valid “Surface Tension Type” option.

#### SetTimestepFactor(value: Union[str, float])

Set the value of “Timestep Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetTurbDistanceFraction(value: Union[str, float])

Set the value of “Turb Distance Fraction”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.

#### SetTurbulenceType(value: str)

Set the value of “Turbulence Type”.

* **Parameters:**
  **value** – The value to set. Must be one of [‘laminar’, ‘les’].
* **Raises:**
  **RockyApiError** – If value is not a valid “Turbulence Type” option.

#### SetUpdateCoupledDensity(value: bool)

Set the value of “Update Coupled Density”.

* **Parameters:**
  **value** – The value to set.

#### SetUseParticlesNeighborsList(value: bool)

Set the value of “Use Particles Neighbors List”.

* **Parameters:**
  **value** – The value to set.

#### SetViscosityType(value: str)

Set the value of “Viscosity Type”.

* **Parameters:**
  **value** – The value to set. Must be one of [‘cleary’, ‘morris’].
* **Raises:**
  **RockyApiError** – If value is not a valid “Viscosity Type” option.

#### SetXsphFactor(value: Union[str, float])

Set the value of “Xsph Factor”.

* **Parameters:**
  **value** – The value to set. This value can be an expression with input variables or float type.
