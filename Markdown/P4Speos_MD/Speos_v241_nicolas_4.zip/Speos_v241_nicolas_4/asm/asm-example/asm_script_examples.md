# SpeosAsm script examples

The following section provides you with a list of script samples to help you create your own script.

 - CADUpdate – [Importing a geometry](method_cadupdate_importing_geometry.md)
 - CADUpdate – [Updating a geometry](method_cadupdate_updating_geometry.md)
