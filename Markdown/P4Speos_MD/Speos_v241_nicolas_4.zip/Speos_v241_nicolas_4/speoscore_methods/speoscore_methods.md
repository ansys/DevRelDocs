# Speos Core methods

This section provides you with the Speos Core methods and a list of useful command lines.

 - [OpenFile](methods_openfile.md)
 - [RunSimulation](methods_runsimulation.md)
 - [ShowWindow](methods_showwindow.md)
 - [Speos Core command lines](methods_command_lines.md)