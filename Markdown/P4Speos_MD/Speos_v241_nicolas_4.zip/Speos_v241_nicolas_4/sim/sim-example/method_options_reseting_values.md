# Options – Reseting values

The following script sample shows you an example on how to reset values.

```ironpython
SpeosSim.Options.Reset()
optionsDefault = SpeosSim.Options.Get()
```