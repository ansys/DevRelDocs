# Cross-Functional methods

This section gathers standard methods that can be used across almost any Speos feature.

 - [Common methods](common_methods.md)
 - [Geometry selection methods](geometry_selection_methods.md)
 - [List (Enum) parameters](list_enum_parameters.md)
 - [ConvertToScriptVersion](converttoscriptversion_method.md)