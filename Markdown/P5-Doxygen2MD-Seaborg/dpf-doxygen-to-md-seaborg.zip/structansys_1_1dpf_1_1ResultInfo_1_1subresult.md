<a id="structansys_1_1dpf_1_1ResultInfo_1_1subresult"></a>
# Structure ansys::dpf::ResultInfo::subresult

![][C++]
![][private]

**Definition**: `dpf\_api.h` (line 318)





## Members

* [description](structansys_1_1dpf_1_1ResultInfo_1_1subresult.md#structansys_1_1dpf_1_1ResultInfo_1_1subresult_1a629140089d410523aaf83be5ba7ff11d)
* [name](structansys_1_1dpf_1_1ResultInfo_1_1subresult.md#structansys_1_1dpf_1_1ResultInfo_1_1subresult_1a398bb881b0f0a76094a4830daf0f3496)
* [opname](structansys_1_1dpf_1_1ResultInfo_1_1subresult.md#structansys_1_1dpf_1_1ResultInfo_1_1subresult_1a4a1cb9245e3641e1d27165e003773363)
* [subresult](structansys_1_1dpf_1_1ResultInfo_1_1subresult.md#structansys_1_1dpf_1_1ResultInfo_1_1subresult_1ab8295462d3fa3360d21e3947ecf0c7fa)

## Public attributes

<a id="structansys_1_1dpf_1_1ResultInfo_1_1subresult_1a398bb881b0f0a76094a4830daf0f3496"></a>
### Variable name

![][public]

**Definition**: `dpf\_api.h` (line 320)

```cpp
std::string ansys::dpf::ResultInfo::subresult::name
```







**Type**: std::string

<a id="structansys_1_1dpf_1_1ResultInfo_1_1subresult_1a4a1cb9245e3641e1d27165e003773363"></a>
### Variable opname

![][public]

**Definition**: `dpf\_api.h` (line 321)

```cpp
std::string ansys::dpf::ResultInfo::subresult::opname
```







**Type**: std::string

<a id="structansys_1_1dpf_1_1ResultInfo_1_1subresult_1a629140089d410523aaf83be5ba7ff11d"></a>
### Variable description

![][public]

**Definition**: `dpf\_api.h` (line 322)

```cpp
std::string ansys::dpf::ResultInfo::subresult::description
```







**Type**: std::string

## Public functions

<a id="structansys_1_1dpf_1_1ResultInfo_1_1subresult_1ab8295462d3fa3360d21e3947ecf0c7fa"></a>
### Function subresult

![][public]

```cpp
ansys::dpf::ResultInfo::subresult::subresult()
```







**Return type**: 

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)