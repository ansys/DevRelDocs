<a id="group__group__1__get__started"></a>
# Starting to use DPF



* Diverse way to get started with DPF in an easy manner.

## Submodules

* [Creating a DPF custom operator's library](group__group__06__2.md#group__group__06__2)
* [Using DPF capabilities in an existing project](group__group__06__1.md#group__group__06__1)

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)
[Markdown]: https://img.shields.io/badge/language-Markdown-blue (Markdown)