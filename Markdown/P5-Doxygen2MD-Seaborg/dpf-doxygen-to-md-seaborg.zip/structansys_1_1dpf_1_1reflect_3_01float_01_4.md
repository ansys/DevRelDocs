<a id="structansys_1_1dpf_1_1reflect_3_01float_01_4"></a>
# Structure ansys::dpf::reflect\< float \>

![][C++]
![][public]

**Definition**: `dpf\_api\_base.h` (line 1623)







## Members

* [type\_name](structansys_1_1dpf_1_1reflect_3_01float_01_4.md#structansys_1_1dpf_1_1reflect_3_01float_01_4_1aecb934371848ee00b201d9ee3009bc9a)

## Public static functions

<a id="structansys_1_1dpf_1_1reflect_3_01float_01_4_1aecb934371848ee00b201d9ee3009bc9a"></a>
### Function type\_name

![][public]
![][static]

```cpp
static std::string ansys::dpf::reflect< float >::type_name()
```







**Return type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)