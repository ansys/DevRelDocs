<a id="structansys_1_1dpf_1_1spec_1_1plugin"></a>
# Structure ansys::dpf::spec::plugin

![][C++]
![][public]

**Definition**: `dpf\_api\_base.h` (line 876)





## Members

* [sPlugin](structansys_1_1dpf_1_1spec_1_1plugin.md#structansys_1_1dpf_1_1spec_1_1plugin_1abb5beeb92e7e00ea15c0c0e04dc4ecf0)

## Public static attributes

<a id="structansys_1_1dpf_1_1spec_1_1plugin_1abb5beeb92e7e00ea15c0c0e04dc4ecf0"></a>
### Variable sPlugin

![][public]
![][static]

**Definition**: `dpf\_api\_base.h` (line 878)

```cpp
std::string ansys::dpf::spec::plugin::sPlugin
```







**Type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)