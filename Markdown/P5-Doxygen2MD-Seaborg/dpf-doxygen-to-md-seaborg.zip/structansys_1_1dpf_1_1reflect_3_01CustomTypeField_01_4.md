<a id="structansys_1_1dpf_1_1reflect_3_01CustomTypeField_01_4"></a>
# Structure ansys::dpf::reflect\< CustomTypeField \>

![][C++]
![][public]

**Definition**: `dpf\_api.h` (line 5114)







## Members

* [type\_name](structansys_1_1dpf_1_1reflect_3_01CustomTypeField_01_4.md#structansys_1_1dpf_1_1reflect_3_01CustomTypeField_01_4_1a59b3816c38885db68b91d89bc80c7b4d)

## Public static functions

<a id="structansys_1_1dpf_1_1reflect_3_01CustomTypeField_01_4_1a59b3816c38885db68b91d89bc80c7b4d"></a>
### Function type\_name

![][public]
![][static]

```cpp
static std::string ansys::dpf::reflect< CustomTypeField >::type_name()
```







**Return type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)