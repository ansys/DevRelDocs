<a id="md_cpp_doc_03_Ways_of_Using"></a>
# 03_Ways_of_Using



/**

**TODO**:

* location {"type":"element","name":"location","attributes":{"file":"cpp_doc/03_Ways_of_Using.md"},"children":[]}

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)
[Markdown]: https://img.shields.io/badge/language-Markdown-blue (Markdown)