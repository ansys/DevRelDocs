<a id="structansys_1_1dpf_1_1reflect_3_01StringField_01_4"></a>
# Structure ansys::dpf::reflect\< StringField \>

![][C++]
![][public]

**Definition**: `dpf\_api.h` (line 5110)







## Members

* [type\_name](structansys_1_1dpf_1_1reflect_3_01StringField_01_4.md#structansys_1_1dpf_1_1reflect_3_01StringField_01_4_1afa74df053af1332330ad636dc2d2a9af)

## Public static functions

<a id="structansys_1_1dpf_1_1reflect_3_01StringField_01_4_1afa74df053af1332330ad636dc2d2a9af"></a>
### Function type\_name

![][public]
![][static]

```cpp
static std::string ansys::dpf::reflect< StringField >::type_name()
```







**Return type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)