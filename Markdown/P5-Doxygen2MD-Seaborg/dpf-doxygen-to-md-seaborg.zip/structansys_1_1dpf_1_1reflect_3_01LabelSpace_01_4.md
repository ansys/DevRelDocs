<a id="structansys_1_1dpf_1_1reflect_3_01LabelSpace_01_4"></a>
# Structure ansys::dpf::reflect\< LabelSpace \>

![][C++]
![][public]

**Definition**: `dpf\_api.h` (line 5118)







## Members

* [type\_name](structansys_1_1dpf_1_1reflect_3_01LabelSpace_01_4.md#structansys_1_1dpf_1_1reflect_3_01LabelSpace_01_4_1af92df638704a64e0e01c85d0fdc63d4b)

## Public static functions

<a id="structansys_1_1dpf_1_1reflect_3_01LabelSpace_01_4_1af92df638704a64e0e01c85d0fdc63d4b"></a>
### Function type\_name

![][public]
![][static]

```cpp
static std::string ansys::dpf::reflect< LabelSpace >::type_name()
```







**Return type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)