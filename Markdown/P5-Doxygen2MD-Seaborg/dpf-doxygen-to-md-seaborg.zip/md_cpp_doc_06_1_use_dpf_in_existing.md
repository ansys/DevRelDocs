<a id="md_cpp_doc_06_1_use_dpf_in_existing"></a>
# 06_1_use_dpf_in_existing



/**

**TODO**:

* location {"type":"element","name":"location","attributes":{"file":"cpp_doc/06_1_use_dpf_in_existing.md"},"children":[]}

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)
[Markdown]: https://img.shields.io/badge/language-Markdown-blue (Markdown)