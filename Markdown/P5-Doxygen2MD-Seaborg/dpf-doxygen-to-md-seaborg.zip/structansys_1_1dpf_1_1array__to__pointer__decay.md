<a id="structansys_1_1dpf_1_1array__to__pointer__decay"></a>
# Structure ansys::dpf::array\_to\_pointer\_decay

![][C++]
![][public]

**Definition**: `dpf\_api.h` (line 104)





**Template parameters**:

* class T

## Members

* [type](structansys_1_1dpf_1_1array__to__pointer__decay.md#structansys_1_1dpf_1_1array__to__pointer__decay_1a7ad60100cc79e1448ce174fe7847581d)

## Public types

<a id="structansys_1_1dpf_1_1array__to__pointer__decay_1a7ad60100cc79e1448ce174fe7847581d"></a>
### Typedef type

![][public]

**Definition**: `dpf\_api.h` (line 106)

```cpp
typedef T ansys::dpf::array_to_pointer_decay< T >::type
```







**Return type**: T

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)