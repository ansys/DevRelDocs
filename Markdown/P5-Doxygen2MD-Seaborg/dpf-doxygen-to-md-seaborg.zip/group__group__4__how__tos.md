<a id="group__group__4__how__tos"></a>
# How-tos



* Description of various capabilities.

## Submodules

* [Debugging in DPF](group__group__06.md#group__group__06)
* [Using DPF Context](group__group__11.md#group__group__11)
* [Using DPF XML Files](group__group__07.md#group__group__07)
* [Using collections and labels](group__group__12.md#group__group__12)
* [Writing a DPF operator](group__group__09.md#group__group__09)

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)
[Markdown]: https://img.shields.io/badge/language-Markdown-blue (Markdown)