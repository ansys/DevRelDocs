<a id="structansys_1_1dpf_1_1reflect_3_01size__t_01_4"></a>
# Structure ansys::dpf::reflect\< size\_t \>

![][C++]
![][public]

**Definition**: `dpf\_api\_base.h` (line 1611)







## Members

* [type\_name](structansys_1_1dpf_1_1reflect_3_01size__t_01_4.md#structansys_1_1dpf_1_1reflect_3_01size__t_01_4_1a93a3eb7ab21c60a9571c17c5cbc13569)

## Public static functions

<a id="structansys_1_1dpf_1_1reflect_3_01size__t_01_4_1a93a3eb7ab21c60a9571c17c5cbc13569"></a>
### Function type\_name

![][public]
![][static]

```cpp
static std::string ansys::dpf::reflect< size_t >::type_name()
```







**Return type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)