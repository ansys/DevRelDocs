<a id="namespaceansys_1_1dpf_1_1so"></a>
# Namespace ansys::dpf::so

![][C++]

**Definition**: `dpf\_api\_base.h` (line 27)





## Variables

<a id="dpf__api__base_8h_1a60e6c3be08c573fb53b989c60c79ee96"></a>
### Variable \_api

![][public]
![][static]

**Definition**: `dpf\_api\_base.h` (line 30)

```cpp
API* ansys::dpf::so::_api =nullptr
```







**Type**: API *

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)