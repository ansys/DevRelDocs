<a id="structansys_1_1dpf_1_1spec_1_1license"></a>
# Structure ansys::dpf::spec::license

![][C++]
![][public]

**Definition**: `dpf\_api\_base.h` (line 881)





## Members

* [sDpf](structansys_1_1dpf_1_1spec_1_1license.md#structansys_1_1dpf_1_1spec_1_1license_1a790b051668c0a8b90352f6580fd4a285)
* [sLicense](structansys_1_1dpf_1_1spec_1_1license.md#structansys_1_1dpf_1_1spec_1_1license_1a3797de3b42ef8e593a6a5f8fd55e244e)

## Public static attributes

<a id="structansys_1_1dpf_1_1spec_1_1license_1a3797de3b42ef8e593a6a5f8fd55e244e"></a>
### Variable sLicense

![][public]
![][static]

**Definition**: `dpf\_api\_base.h` (line 883)

```cpp
std::string ansys::dpf::spec::license::sLicense
```







**Type**: std::string

<a id="structansys_1_1dpf_1_1spec_1_1license_1a790b051668c0a8b90352f6580fd4a285"></a>
### Variable sDpf

![][public]
![][static]

**Definition**: `dpf\_api\_base.h` (line 884)

```cpp
std::string ansys::dpf::spec::license::sDpf
```







**Type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)