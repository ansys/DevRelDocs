<a id="structansys_1_1dpf_1_1reflect_3_01DataTree_01_4"></a>
# Structure ansys::dpf::reflect\< DataTree \>

![][C++]
![][public]

**Definition**: `dpf\_api.h` (line 5090)







## Members

* [type\_name](structansys_1_1dpf_1_1reflect_3_01DataTree_01_4.md#structansys_1_1dpf_1_1reflect_3_01DataTree_01_4_1acb88ffe0e64b6f1b194d525d0ffe32e8)

## Public static functions

<a id="structansys_1_1dpf_1_1reflect_3_01DataTree_01_4_1acb88ffe0e64b6f1b194d525d0ffe32e8"></a>
### Function type\_name

![][public]
![][static]

```cpp
static std::string ansys::dpf::reflect< DataTree >::type_name()
```







**Return type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)