<a id="deprecated"></a>
# Deprecated List



<b>Global [ansys::dpf::LibraryHandle::LibraryHandle](classansys_1_1dpf_1_1LibraryHandle.md#classansys_1_1dpf_1_1LibraryHandle_1a0651cd01e74e2cb90f320435bc7fc87a)  (std::string const &key, std::string const &shared_object_root_name, ApiType api_type, LoadType load_type=[LoadType::try\_load](namespaceansys_1_1dpf.md#namespaceansys_1_1dpf_1ac4f1380f00170887891b5cf54d8c94b3a6d450e9598ea0dffeaff74fbcccb116f), std::string const &dpf_client_api="DPFClientAPI")</b>:

<a id="deprecated_1_deprecated000001"></a>
This call is deprecated. usage is not maintained.

**TODO**:

* location {"type":"element","name":"location","attributes":{"file":"deprecated"},"children":[]}

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)
[Markdown]: https://img.shields.io/badge/language-Markdown-blue (Markdown)