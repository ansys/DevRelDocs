<a id="group__group__2__concepts"></a>
# Concepts and terms



* Learn about DPF concepts and terms.

## Submodules

* [Concepts and Terminology](group__group__02.md#group__group__02)
* [Using DPF: Step by Step](group__group__05.md#group__group__05)
* [Ways of Using DPF](group__group__03.md#group__group__03)

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)
[Markdown]: https://img.shields.io/badge/language-Markdown-blue (Markdown)