<a id="classansys_1_1dpf_1_1LibraryHolder"></a>
# Class ansys::dpf::LibraryHolder

![][C++]
![][public]

**Definition**: `dpf\_api\_base.h` (line 1585)





**Template parameters**:

* typename T

**Inherits from**:

* [T](undefined.md#undefined)

## Members

* [\_handle](classansys_1_1dpf_1_1LibraryHolder.md#classansys_1_1dpf_1_1LibraryHolder_1a31482a89a064e0644c5599350ac0854a)
* [LibraryHolder](classansys_1_1dpf_1_1LibraryHolder.md#classansys_1_1dpf_1_1LibraryHolder_1a9e3f921d5170e5107fd29b170556642d)
* [~LibraryHolder](classansys_1_1dpf_1_1LibraryHolder.md#classansys_1_1dpf_1_1LibraryHolder_1a9b5ff8d6f40681096895370c00644451)

## Private attributes

<a id="classansys_1_1dpf_1_1LibraryHolder_1a31482a89a064e0644c5599350ac0854a"></a>
### Variable \_handle

![][private]

**Definition**: `dpf\_api\_base.h` (line 1588)

```cpp
LibraryHandle ansys::dpf::LibraryHolder< T >::_handle
```







**Type**: [LibraryHandle](classansys_1_1dpf_1_1LibraryHandle.md#classansys_1_1dpf_1_1LibraryHandle)

## Public functions

<a id="classansys_1_1dpf_1_1LibraryHolder_1a9e3f921d5170e5107fd29b170556642d"></a>
### Function LibraryHolder

![][public]

```cpp
ansys::dpf::LibraryHolder< T >::LibraryHolder()
```







**Return type**: 

<a id="classansys_1_1dpf_1_1LibraryHolder_1a9b5ff8d6f40681096895370c00644451"></a>
### Function ~LibraryHolder

![][public]

```cpp
virtual ansys::dpf::LibraryHolder< T >::~LibraryHolder()
```







**Return type**: 

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)