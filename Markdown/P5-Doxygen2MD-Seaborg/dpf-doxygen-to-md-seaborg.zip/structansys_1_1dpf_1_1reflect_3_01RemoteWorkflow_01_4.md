<a id="structansys_1_1dpf_1_1reflect_3_01RemoteWorkflow_01_4"></a>
# Structure ansys::dpf::reflect\< RemoteWorkflow \>

![][C++]
![][public]

**Definition**: `dpf\_api.h` (line 5106)







## Members

* [type\_name](structansys_1_1dpf_1_1reflect_3_01RemoteWorkflow_01_4.md#structansys_1_1dpf_1_1reflect_3_01RemoteWorkflow_01_4_1a4ebb2100c6ade8127e0b06a5e7c828e0)

## Public static functions

<a id="structansys_1_1dpf_1_1reflect_3_01RemoteWorkflow_01_4_1a4ebb2100c6ade8127e0b06a5e7c828e0"></a>
### Function type\_name

![][public]
![][static]

```cpp
static std::string ansys::dpf::reflect< RemoteWorkflow >::type_name()
```







**Return type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)