<a id="structansys_1_1dpf_1_1reflect"></a>
# Structure ansys::dpf::reflect

![][C++]
![][public]

**Definition**: `dpf\_api\_base.h` (line 58)





**Template parameters**:

* typename DpfTypeT

## Members

* [type\_name](structansys_1_1dpf_1_1reflect.md#structansys_1_1dpf_1_1reflect_1a11b504a62655742daf4ed79b1d9f403a)

## Public static functions

<a id="structansys_1_1dpf_1_1reflect_1a11b504a62655742daf4ed79b1d9f403a"></a>
### Function type\_name

![][public]
![][static]

```cpp
static std::string ansys::dpf::reflect< DpfTypeT >::type_name()
```







**Return type**: std::string

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)
[private]: https://img.shields.io/badge/-private-red (private)
[const]: https://img.shields.io/badge/-const-lightblue (const)
[static]: https://img.shields.io/badge/-static-lightgrey (static)