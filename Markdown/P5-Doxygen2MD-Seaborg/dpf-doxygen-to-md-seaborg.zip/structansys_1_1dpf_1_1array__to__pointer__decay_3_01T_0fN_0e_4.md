<a id="structansys_1_1dpf_1_1array__to__pointer__decay_3_01T_0fN_0e_4"></a>
# Structure ansys::dpf::array\_to\_pointer\_decay\< T[N]\>

![][C++]
![][public]

**Definition**: `dpf\_api.h` (line 110)





**Template parameters**:

* class T
* Nstd::size_t **N**

## Members

* [type](structansys_1_1dpf_1_1array__to__pointer__decay_3_01T_0fN_0e_4.md#structansys_1_1dpf_1_1array__to__pointer__decay_3_01T_0fN_0e_4_1a8c9df5f0c061b399c3d8f5a006f49c00)

## Public types

<a id="structansys_1_1dpf_1_1array__to__pointer__decay_3_01T_0fN_0e_4_1a8c9df5f0c061b399c3d8f5a006f49c00"></a>
### Typedef type

![][public]

**Definition**: `dpf\_api.h` (line 112)

```cpp
typedef const T* ansys::dpf::array_to_pointer_decay< T[N]>::type
```







**Return type**: const T *

[public]: https://img.shields.io/badge/-public-brightgreen (public)
[C++]: https://img.shields.io/badge/language-C%2B%2B-blue (C++)