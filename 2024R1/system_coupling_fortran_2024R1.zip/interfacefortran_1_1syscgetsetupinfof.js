var interfacefortran_1_1syscgetsetupinfof =
[
    [ "syscgetsetupinfof", "interfacefortran_1_1syscgetsetupinfof.xhtml#a73374df2183a799e03180e006525fcfe", null ],
    [ "syscgetsetupinfof_a", "interfacefortran_1_1syscgetsetupinfof.xhtml#a58bcb1256d3ecb3eb57483e07be85646", null ],
    [ "syscgetsetupinfof_ar", "interfacefortran_1_1syscgetsetupinfof.xhtml#a6fa355e1a61155b4f9199dfbf10d9ccf", null ],
    [ "syscgetsetupinfof_ard", "interfacefortran_1_1syscgetsetupinfof.xhtml#a3e01c7e9d24d8ed1d10c771cde749a53", null ]
];