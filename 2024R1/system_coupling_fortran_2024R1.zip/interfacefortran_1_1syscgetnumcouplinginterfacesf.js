var interfacefortran_1_1syscgetnumcouplinginterfacesf =
[
    [ "syscgetnumcouplinginterfacesf", "interfacefortran_1_1syscgetnumcouplinginterfacesf.xhtml#a2a24e1563f8a02b14c341aad569cffce", null ]
];