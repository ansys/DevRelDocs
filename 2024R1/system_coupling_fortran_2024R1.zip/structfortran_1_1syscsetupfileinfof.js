var structfortran_1_1syscsetupfileinfof =
[
    [ "restartssupported", "structfortran_1_1syscsetupfileinfof.xhtml#a2758579ead626ca02c0c38e9d0407056", null ],
    [ "setupfilename", "structfortran_1_1syscsetupfileinfof.xhtml#ab4e2b5c783a6f184674e32cfaaa4f09e", null ]
];