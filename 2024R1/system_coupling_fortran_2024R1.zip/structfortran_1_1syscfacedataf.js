var structfortran_1_1syscfacedataf =
[
    [ "faceids", "structfortran_1_1syscfacedataf.xhtml#ac15be376d8a7d00e486707ac0269056e", null ],
    [ "facenodecounts", "structfortran_1_1syscfacedataf.xhtml#a2abe8c3dbc5763c1d6a59c79a2e14e79", null ],
    [ "facetypes", "structfortran_1_1syscfacedataf.xhtml#acb27a555d3934aa9aac98ece4c77b167", null ]
];