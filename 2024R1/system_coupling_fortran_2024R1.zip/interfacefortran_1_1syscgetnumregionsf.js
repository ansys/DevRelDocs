var interfacefortran_1_1syscgetnumregionsf =
[
    [ "syscgetnumregionsf", "interfacefortran_1_1syscgetnumregionsf.xhtml#a613fec21ec06b65230ec11bbba18470c", null ]
];