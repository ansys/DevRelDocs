var structfortran_1_1syscresultsinfof =
[
    [ "basefilename", "structfortran_1_1syscresultsinfof.xhtml#ab87a2b05cc2fa1114379c39b325438b4", null ]
];