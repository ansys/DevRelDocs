var interfacefortran_1_1syscgetvariablef =
[
    [ "syscgetvariablef", "interfacefortran_1_1syscgetvariablef.xhtml#a8dd21e666858e69c69343a8a1145ceeb", null ],
    [ "syscgetvariablef_dtelqd", "interfacefortran_1_1syscgetvariablef.xhtml#ad77ffe80eaeed67dcb5c207189543a80", null ],
    [ "syscgetvariablef_q", "interfacefortran_1_1syscgetvariablef.xhtml#a0665e5454c9b7df4205539b6c07476e4", null ],
    [ "syscgetvariablef_te", "interfacefortran_1_1syscgetvariablef.xhtml#a889fefd03b86f60b08c74a5a28475cf2", null ],
    [ "syscgetvariablef_teq", "interfacefortran_1_1syscgetvariablef.xhtml#ae20d858d6873e2c82a6bd385c0f08a13", null ]
];