var a00832 =
[
    [ "blue", "a00832.xhtml#ad984ffbc4817fa2ef9bcd5e1501675c6", null ],
    [ "green", "a00832.xhtml#a31dabee08f7e01c88c3ff7b156bf4183", null ],
    [ "red", "a00832.xhtml#a76695eecc36bb9564d05b17279a02385", null ]
];