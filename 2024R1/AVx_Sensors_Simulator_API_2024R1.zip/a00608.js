var a00608 =
[
    [ "max_value", "a00608.xhtml#a1f5a1a9c49729fe50c26c706a06e3f54", null ],
    [ "min_value", "a00608.xhtml#ac923871a79a7af8604f8db33f9993e71", null ],
    [ "size", "a00608.xhtml#ad475923a68bfa553b206984b757253fb", null ]
];