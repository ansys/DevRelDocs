var a00452 =
[
    [ "pitch", "a00452.xhtml#add04f3a1b9c487ae403850139fe38ba3", null ],
    [ "roll", "a00452.xhtml#a17c6d048a0e5d7f9c6cc2de289361d6c", null ],
    [ "yaw", "a00452.xhtml#a888cc94a5a110bb79ed09b08349171b4", null ]
];