var a00436 =
[
    [ "weightings", "a00436.xhtml#a4fe3f228d4ce34d0fc8f0b57c8cb78b2", null ]
];