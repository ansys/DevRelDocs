var a00716 =
[
    [ "camera_ground_truth_parameters", "a00716.xhtml#aa7ac28d7cce9662677f4335e546a3579", null ],
    [ "gpu_name", "a00716.xhtml#aec4e7559b96ff5ea6be89c3a93c1c231", null ],
    [ "rendering_parameters", "a00716.xhtml#a4b3f9e42de87f91ee618833755083c1e", null ]
];