var a00444 =
[
    [ "imaginary_part", "a00444.xhtml#a164dbdfb32d52e3f149efe4b8c114444", null ],
    [ "real_part", "a00444.xhtml#a41053839b3886eebf476f0787220dd87", null ]
];