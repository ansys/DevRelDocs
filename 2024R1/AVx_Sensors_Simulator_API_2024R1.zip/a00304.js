var a00304 =
[
    [ "lens_system", "a00304.xhtml#a1d65910e3bdf6f69c22b238e5fbc9299", null ],
    [ "photo_detector", "a00304.xhtml#ab15b5a6299e3b08ebff5eb4d48d0b086", null ],
    [ "processor", "a00304.xhtml#ac4b4ff5c509cf093466dfed1bb2b895b", null ],
    [ "resolution_in_pixels", "a00304.xhtml#a99f3342a135f634b4553905e2248004e", null ]
];