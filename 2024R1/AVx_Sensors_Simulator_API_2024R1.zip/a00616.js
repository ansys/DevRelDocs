var a00616 =
[
    [ "data", "a00616.xhtml#adef8aaaf5f83e18feaf1caece4ee5dcd", null ],
    [ "multiplexing", "a00616.xhtml#a1d957607b1acb9deec5a5a0cb5c7a064", null ],
    [ "number_of_samples", "a00616.xhtml#af57e5d33172c6edc2117feca983bc6b6", null ],
    [ "rx_identifiers", "a00616.xhtml#a89c04f03545d824ea2e9d8aebc429684", null ],
    [ "tx_identifiers", "a00616.xhtml#af393b7384097cb93cd72ae03ee50a581", null ]
];