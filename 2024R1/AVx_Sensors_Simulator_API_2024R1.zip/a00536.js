var a00536 =
[
    [ "label", "a00536.xhtml#a35978cb1369d7362b667b7e143eb76f6", null ],
    [ "tag_name", "a00536.xhtml#afa5af2af615a8a9c2b0b45867cc52596", null ],
    [ "x_center", "a00536.xhtml#a89ea85e8dcba0b92181d99d006d9ab5b", null ],
    [ "x_max", "a00536.xhtml#ace517783b0848a95a83fef9e596b3d2b", null ],
    [ "x_min", "a00536.xhtml#af777b5808f48501cfa848e7c139fe105", null ],
    [ "y_center", "a00536.xhtml#a5d4f63ad6ae59513420eff9614ab0a3e", null ],
    [ "y_max", "a00536.xhtml#ae494cfe0fefb6a8f9366867e8202baeb", null ],
    [ "y_min", "a00536.xhtml#a0652fc37fbd303b61a183813eb2cc292", null ],
    [ "z_center", "a00536.xhtml#ada5dc5f88c1d659b0ba3dfbfba73ad73", null ]
];