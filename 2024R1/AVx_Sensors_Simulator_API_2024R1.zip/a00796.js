var a00796 =
[
    [ "resource_identifier", "a00796.xhtml#aef069f6bd46cea43ac09d1880b09577a", null ]
];