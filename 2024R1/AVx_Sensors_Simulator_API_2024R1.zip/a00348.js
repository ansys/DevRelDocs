var a00348 =
[
    [ "modes", "a00348.xhtml#ad77d8926fd6106eb50aae6bfdb1de3d3", null ],
    [ "rx_antennas", "a00348.xhtml#ab1d99b824434b4b33863c29d85d42b6d", null ],
    [ "tx_antennas", "a00348.xhtml#a4870c53387ea59d4f825c2ba4ce7e64a", null ]
];