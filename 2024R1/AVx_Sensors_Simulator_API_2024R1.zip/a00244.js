var a00244 =
[
    [ "bits", "a00244.xhtml#aedd8692bd6865f78aa22a5ba2800c31a", null ],
    [ "demosaicing", "a00244.xhtml#a45de18d129920475990a6579dd79c900", null ],
    [ "gain", "a00244.xhtml#ae1e4387fed5de7de8a378f7a1ba49fc5", null ],
    [ "injection", "a00244.xhtml#ac47aed54fc49758e0962b013f96b3c5b", null ]
];