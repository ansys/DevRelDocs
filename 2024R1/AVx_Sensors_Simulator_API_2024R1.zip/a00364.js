var a00364 =
[
    [ "flat_window", "a00364.xhtml#aca7f0d5f5aec81d999e03d4e5893dfeb", null ],
    [ "hamming_window", "a00364.xhtml#a560b1d02bcfd0f334162307b353a2f71", null ],
    [ "hann_window", "a00364.xhtml#a5799c79f955cbfcfb930aeb72f814120", null ],
    [ "taylor_window", "a00364.xhtml#a6ef7bba259ae415cab9b445b3f21ada5", null ]
];