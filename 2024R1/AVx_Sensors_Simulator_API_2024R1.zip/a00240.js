var a00240 =
[
    [ "dark_current_average_value", "a00240.xhtml#ad57972e361cbcda79719bf16296211c6", null ]
];