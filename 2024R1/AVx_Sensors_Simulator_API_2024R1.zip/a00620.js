var a00620 =
[
    [ "data", "a00620.xhtml#ac3cbb883d5187a7eb797bd08f77a33ef", null ],
    [ "is_complex_valued", "a00620.xhtml#a46c81a85ec3ae56890fa10dbdf7c76e2", null ],
    [ "multiplexing", "a00620.xhtml#a8189dbaf23432da3355d04e5194181af", null ],
    [ "number_of_samples", "a00620.xhtml#a6b6915e6ddc7b2d28144342abe931f54", null ],
    [ "rx_identifiers", "a00620.xhtml#a1327a96468cbeb719f78c3b53a2120fa", null ],
    [ "tx_identifiers", "a00620.xhtml#a48846f68c92ac876758b0d291a1adbb2", null ]
];