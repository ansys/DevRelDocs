var a00140 =
[
    [ "formats", "a00140.xhtml#af9e966b36073e1f8409e60599ec5c6b3", null ],
    [ "resolution", "a00140.xhtml#a0b83adf75865305ce39ac56c74d94886", null ]
];