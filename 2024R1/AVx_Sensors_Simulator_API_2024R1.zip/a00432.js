var a00432 =
[
    [ "weightings_by_pulses_or_chirps", "a00432.xhtml#a7ce108c7a90e1706e207a39e74062fe7", null ],
    [ "weightings_by_transmitter", "a00432.xhtml#ac99192275bface7eb42742c52220912a", null ]
];