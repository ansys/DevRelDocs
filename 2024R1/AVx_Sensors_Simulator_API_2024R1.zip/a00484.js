var a00484 =
[
    [ "material_path", "a00484.xhtml#aaceb40631c9f8ebf46ec816d67aac87e", null ],
    [ "mesh_name", "a00484.xhtml#a5d3659bb9ff92e18a27f0b2c8ec31e5c", null ],
    [ "mesh_part_name", "a00484.xhtml#a33b485a1c16a89ed529e1041f2bcd804", null ]
];