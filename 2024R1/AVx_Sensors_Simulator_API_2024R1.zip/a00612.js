var a00612 =
[
    [ "data", "a00612.xhtml#af7bdb8ce080eebc3f3e8186ad240aad8", null ],
    [ "number_of_pulses_or_chirps", "a00612.xhtml#a6510a8548af7eba09974f7f856ca70eb", null ],
    [ "number_of_samples", "a00612.xhtml#a3bf05d7f85edff4ed6c238dc5972235b", null ],
    [ "number_of_values_per_sample", "a00612.xhtml#ae67537d0410d0c11be4eb152d7f51060", null ],
    [ "tx_identifiers", "a00612.xhtml#a59c845c9c5e1235844a0704c451064b6", null ]
];