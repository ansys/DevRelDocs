var a00396 =
[
    [ "pulse_sequence", "a00396.xhtml#a4789354ccd9bb3cb8cb0d60be6240afe", null ]
];