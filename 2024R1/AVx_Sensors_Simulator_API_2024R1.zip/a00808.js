var a00808 =
[
    [ "key", "a00808.xhtml#ae480582299740aa9970da095b26ab8b6", null ],
    [ "kinematic_properties", "a00808.xhtml#ae33ce42e8de567683f8344a2731186f4", null ],
    [ "state", "a00808.xhtml#a2b8e0e68303ad7b18e21aced628d3eaa", null ]
];