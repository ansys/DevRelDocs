var a00532 =
[
    [ "camera_data", "a00532.xhtml#a856edccad58aacacc4bcba672c8e5311", null ],
    [ "camera_format", "a00532.xhtml#a7a78fc4287404ef30766c24e8ba1669b", null ]
];