var a00224 =
[
    [ "exposure_time", "a00224.xhtml#a826cd98fc2ba21eda6e2df02eda3c6aa", null ],
    [ "readout_noise", "a00224.xhtml#a2790980dd907d35e6d373c0aa75b9767", null ],
    [ "resolution", "a00224.xhtml#a24c0cc687084682a0b17a8d9e39e9a48", null ],
    [ "thermal_noise_advanced", "a00224.xhtml#a1ad7a9928988258953faffe76185bf52", null ],
    [ "thermal_noise_simple", "a00224.xhtml#a6b9387584e1c832d15b0651e89e33c7d", null ]
];