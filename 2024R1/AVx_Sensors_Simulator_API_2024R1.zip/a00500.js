var a00500 =
[
    [ "lighting_system_name", "a00500.xhtml#af4214546b2593d8c06cb1b0d50bf3114", null ],
    [ "projectors_state", "a00500.xhtml#a22d6468f660ecb67ea5a1983ff33ab85", null ]
];