var a00380 =
[
    [ "side_lobe_level", "a00380.xhtml#add310bfcc457aa85ce5fc742791ec420", null ]
];