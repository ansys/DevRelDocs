var a00144 =
[
    [ "image_height", "a00144.xhtml#a82ffcb3d6c6dbdb55268527e3ffeb4eb", null ],
    [ "image_width", "a00144.xhtml#ad65de0aa84a0ad2841b1b5ab2015bc7a", null ],
    [ "mode_identifier", "a00144.xhtml#a84a44e7ce5b20986ade128c3cb610be7", null ],
    [ "pixel_format", "a00144.xhtml#a3079096520acc17bdf10e8fe6fefad6c", null ]
];