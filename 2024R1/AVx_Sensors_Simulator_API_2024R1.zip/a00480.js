var a00480 =
[
    [ "label", "a00480.xhtml#a9d6036c2e792ddbe4308218eb3f76988", null ],
    [ "tag", "a00480.xhtml#ad06585b0252b2d5c431a333dd89b1b3f", null ]
];