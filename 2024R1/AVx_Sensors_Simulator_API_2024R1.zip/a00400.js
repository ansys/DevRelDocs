var a00400 =
[
    [ "bandwidth", "a00400.xhtml#ad1dddd94dd3723fe6e0e2545238c13a8", null ],
    [ "center_frequency", "a00400.xhtml#a7e7d8d59dcf300872c8057707ef5baa9", null ],
    [ "number_of_frequency_samples_per_pulse", "a00400.xhtml#af6bf636cec3a5bfc0dbfb425c94deeb6", null ],
    [ "pulse_interval", "a00400.xhtml#a204737194787b3ecbdb74bca4f383c90", null ]
];