var a00568 =
[
    [ "data", "a00568.xhtml#ace2e1c0e5eee75a3245447ed2e8f1948", null ],
    [ "waveform_length", "a00568.xhtml#a996e4b3405c200f73d0761573fea1e62", null ]
];