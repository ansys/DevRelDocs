var a00388 =
[
    [ "arbitrary_system_pulse_doppler_waveform", "a00388.xhtml#a66431a870b8d2861ff25c1a739878d42", null ],
    [ "performance_pulse_doppler_waveform", "a00388.xhtml#a8164682119ac5e6c366eefcdec948fec", null ],
    [ "system_pulse_doppler_waveform", "a00388.xhtml#ad05b00c3fb4dc12daffe5ec59fc71fb4", null ]
];