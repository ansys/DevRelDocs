var a00472 =
[
    [ "asset_path", "a00472.xhtml#adccf72dc2450928b75e29867d26ed83c", null ],
    [ "instance_name", "a00472.xhtml#a7b99ca6d7d96d1d22cd46f4a03770329", null ]
];