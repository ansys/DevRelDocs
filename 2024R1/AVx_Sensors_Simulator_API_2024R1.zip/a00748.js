var a00748 =
[
    [ "gpu_memory_quota", "a00748.xhtml#a13bce1150714582c1224822348c6f7b8", null ],
    [ "gpu_quotas", "a00748.xhtml#ad5f7c92a370197c4a63f9d69df164822", null ],
    [ "max_number_of_ray_batches", "a00748.xhtml#a9b4158e52e07f95a4470f896079fdb2d", null ]
];