var a00580 =
[
    [ "identity", "a00580.xhtml#ac7c1ac9a858949a9f035216f703d034c", null ],
    [ "weight", "a00580.xhtml#a5baed38044eb5d59ea465ea8b2368639", null ]
];