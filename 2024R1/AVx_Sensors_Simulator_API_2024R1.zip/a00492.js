var a00492 =
[
    [ "Get", "a00492.xhtml#a350f4512f37143a5c7d4430212d092b9", null ],
    [ "Set", "a00492.xhtml#afd712cf0f68936c1f76224dfdfc78b20", null ]
];