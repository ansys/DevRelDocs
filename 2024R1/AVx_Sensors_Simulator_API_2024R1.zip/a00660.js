var a00660 =
[
    [ "resource", "a00660.xhtml#a818d180c25de4f265b90bf3bd61e756f", null ],
    [ "vss_identity", "a00660.xhtml#a035279d4d82f4b566ca00f77dcb66499", null ]
];