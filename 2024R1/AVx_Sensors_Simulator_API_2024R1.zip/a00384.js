var a00384 =
[
    [ "frequency_modulated_continuous_waveform", "a00384.xhtml#ab36d87024ca30ccb546aa2d26e448747", null ],
    [ "pulse_doppler_waveform", "a00384.xhtml#ae5075acb9d557c07671746ffa4da18e9", null ]
];