var a00640 =
[
    [ "bounding_box_2d", "a00640.xhtml#a510dd0a2c542c13388e1fb6fcaac67bf", null ],
    [ "camera_custom_data_output", "a00640.xhtml#ab5192e3f348800a501794b6a50b9889c", null ],
    [ "camera_lens_output", "a00640.xhtml#a9da54cf42b40927d38ade678c07ff424", null ],
    [ "ground_truth_data", "a00640.xhtml#a0a0c93a3a466e38b6ec65ebcf1fa766b", null ],
    [ "image_data", "a00640.xhtml#aa475a93b866b131642639183d77fc0be", null ]
];