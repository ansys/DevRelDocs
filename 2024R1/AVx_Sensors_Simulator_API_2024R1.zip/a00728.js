var a00728 =
[
    [ "RealTimeParameters", "a00732.xhtml", "a00732" ],
    [ "antialiasing_factor", "a00728.xhtml#a605b9f16152b40e3b2f96bbd4fe7245d", null ],
    [ "borderless", "a00728.xhtml#a2417bdf1f7d38eb12e8ca30f6f9fa81b", null ],
    [ "camera_far_plane", "a00728.xhtml#a8656ad82a8121af563da4df1d395c97c", null ],
    [ "camera_near_plane", "a00728.xhtml#ab1079b5e0ac8426c4f23a62cba776b2d", null ],
    [ "enable_alpha_channel", "a00728.xhtml#abdf78d46e29058ebf631ae16756ddd65", null ],
    [ "enable_asynchronous_readback", "a00728.xhtml#ae141dfc7416640a294095e6bc9f0936e", null ],
    [ "real_time_parameters", "a00728.xhtml#a23ac17870fccac097d3778e9d6c39ca0", null ],
    [ "shadow_quality", "a00728.xhtml#a8a6e06da7ce13460d212701c8f21d7ab", null ],
    [ "texture_quality", "a00728.xhtml#a1dcea248e7b738f9e72248414a7441fe", null ],
    [ "vertical_sync", "a00728.xhtml#a538847812285ed697366fe55fc87fc54", null ]
];