var a00724 =
[
    [ "generate_temperature_map", "a00724.xhtml#a6e1be23850501ac656f78deb0e1f189b", null ],
    [ "gpu_name", "a00724.xhtml#ab33756971829091d1ea8c1d57fdf8064", null ],
    [ "rendering_parameters", "a00724.xhtml#afb9e1af5e39a600dda8fa5b05c0f8f3d", null ]
];