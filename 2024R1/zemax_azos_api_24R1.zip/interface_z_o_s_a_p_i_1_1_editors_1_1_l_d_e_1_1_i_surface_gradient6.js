var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient6 =
[
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient6.xhtml#ae87af6f2cea65acb6097115819c9e927", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient6.xhtml#aa5903d4e312d5a7a98376888c4d58f43", null ]
];