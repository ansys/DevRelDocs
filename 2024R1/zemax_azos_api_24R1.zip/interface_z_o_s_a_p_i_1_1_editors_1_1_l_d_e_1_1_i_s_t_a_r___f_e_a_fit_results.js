var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results =
[
    [ "FitAccuracy", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results.xhtml#a6ad0b1304fd591b559e6c08886d15928", null ],
    [ "FitAverage", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results.xhtml#a882ebc7a5f7f65cd3b36bef630c04a81", null ],
    [ "FitFill", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results.xhtml#aa137b4fab351cad55435d9f2ed3b3095", null ],
    [ "FitLevels", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results.xhtml#a326b59bc95a510f72373d540664650bf", null ],
    [ "FitNorm", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results.xhtml#a6950c9b795d1a1805d8f1425182b63b6", null ],
    [ "FitPV", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results.xhtml#ab4ad2ac84215c686dcb08e9667bb9504", null ],
    [ "FitRMS", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results.xhtml#a7928d64c332ae9c13d959b3a8b4cf50b", null ],
    [ "Points", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_results.xhtml#af56d71e7135eec809d4a3838e89b75b8", null ]
];