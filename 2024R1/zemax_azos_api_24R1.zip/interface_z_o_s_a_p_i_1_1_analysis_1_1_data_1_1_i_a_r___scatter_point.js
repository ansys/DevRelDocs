var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___scatter_point =
[
    [ "Value", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___scatter_point.xhtml#ad635e52ed7fce1244c6114c2b1834119", null ],
    [ "X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___scatter_point.xhtml#aa9bbc60d9789e2797a11cb43ea624a38", null ],
    [ "Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___scatter_point.xhtml#a635b4030b80cecd915099f7c73582ab4", null ]
];