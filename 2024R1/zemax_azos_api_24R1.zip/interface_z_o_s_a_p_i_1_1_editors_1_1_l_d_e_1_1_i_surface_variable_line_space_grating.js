var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating =
[
    [ "CosineAlpha", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#ada94ec7e24b8d33d20acad9d1fed8f20", null ],
    [ "CosineAlphaCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#a3d2ec73511f9e7ebe7de9175c8322b09", null ],
    [ "CosineBeta", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#a795493c77002962bb09a8f29bda512d7", null ],
    [ "CosineBetaCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#a21ba0c757d95adda00e02fe2d80229a7", null ],
    [ "DiffractOrder", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#ae7f2867edbb7016213a8927f8bf237dd", null ],
    [ "DiffractOrderCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#ab830b2d4d84af21d9f8a22cd9960c2e7", null ],
    [ "FocalRadius_L", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#a3a5d3761ae307a0ceb4ce9abc987f8eb", null ],
    [ "FocalRadius_L_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#af5bcbf8a07b9806a478a6694b1747a62", null ],
    [ "LambdaZero", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#a851a4de80de58f5ac41e716c9d60bba8", null ],
    [ "LambdaZeroCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_variable_line_space_grating.xhtml#a06681e557ee8c8d9634d135803f5c871", null ]
];