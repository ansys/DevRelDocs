var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s__ =
[
    [ "Load", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s__.xhtml#a233390b15755feb10db900149fb97e76", null ],
    [ "LoadFrom", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s__.xhtml#a62cf3f062ab2e3015ffca22e5173d650", null ],
    [ "ModifySettings", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s__.xhtml#a0bd90efa9aecf2f0f3dc7f8e9ad6f309", null ],
    [ "Reset", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s__.xhtml#a7928f2305168474181938609be36c277", null ],
    [ "Save", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s__.xhtml#a7e7874f49a22e3762c632821669532ca", null ],
    [ "SaveTo", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s__.xhtml#a3c196d30f275d5d8e17363b3b702bed7", null ],
    [ "Verify", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s__.xhtml#a2fe8bcba3de86b96ca2c2f6fa9e1f75e", null ]
];