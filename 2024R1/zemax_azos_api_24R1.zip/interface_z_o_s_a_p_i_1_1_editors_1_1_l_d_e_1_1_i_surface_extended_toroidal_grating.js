var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating =
[
    [ "DiffractionOrder", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating.xhtml#a6b1ac74df08924ecebb6891628344f07", null ],
    [ "DiffractionOrderCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating.xhtml#a1bb2057d28c2a8ee0cbd93b06e6ff625", null ],
    [ "LinesPerMicroMeter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating.xhtml#a6ec1a91ed287aedb26fc0f0184fe5188", null ],
    [ "LinesPerMicroMeterCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating.xhtml#a66a57bd026cc558bddccbe2a82523259", null ],
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating.xhtml#ab0f6009867e47f2c85daf350b1825465", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating.xhtml#a9313bb3d83462d9dacf00a62adb9b44c", null ],
    [ "RadiusOfRotation", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating.xhtml#af5dea6941e4f7e155eafe2e20f3792af", null ],
    [ "RadiusOfRotationCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_toroidal_grating.xhtml#a56409b86d9f454b16582b8b3d1d77f31", null ]
];