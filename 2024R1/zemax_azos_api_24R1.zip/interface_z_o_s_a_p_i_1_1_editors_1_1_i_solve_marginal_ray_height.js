var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_marginal_ray_height =
[
    [ "Height", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_marginal_ray_height.xhtml#a592f43c4106f934261111f82459f0b19", null ],
    [ "PupilZone", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_marginal_ray_height.xhtml#a127953320e32cb4d86623b6ee3e8f7e8", null ]
];