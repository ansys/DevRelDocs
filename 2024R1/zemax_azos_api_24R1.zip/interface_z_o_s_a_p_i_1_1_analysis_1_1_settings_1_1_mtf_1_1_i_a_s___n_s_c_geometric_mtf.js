var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___n_s_c_geometric_mtf =
[
    [ "Detector", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___n_s_c_geometric_mtf.xhtml#a529c749af823c26f539665bca6de7d8b", null ],
    [ "Filter", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___n_s_c_geometric_mtf.xhtml#a18767de53bd9b5527e7267007918f9d3", null ],
    [ "MaximumFrequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___n_s_c_geometric_mtf.xhtml#ad3507d0f8a328c3bd388c20debf069ce", null ],
    [ "MaximumPlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___n_s_c_geometric_mtf.xhtml#a07e1aa5b169092d802e1049315860f8c", null ],
    [ "MinimumPlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___n_s_c_geometric_mtf.xhtml#a8a9c3dda9b9c45d67e967a70f4b937e2", null ],
    [ "RayDatabaseFilename", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___n_s_c_geometric_mtf.xhtml#a73b3bebeb2b90d5dbedc919f598ab8ca", null ]
];