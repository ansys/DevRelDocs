var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength =
[
    [ "Glass1", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#a8b251eae2b988cc19ca2a159b2c9d455", null ],
    [ "Glass2", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#ac9244d82028da644575f74472040a978", null ],
    [ "Glass3", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#a8e81a0cd0c6a54220c638b23771b3681", null ],
    [ "Glass4", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#a372b27fd90028cdea26e281cf4d53184", null ],
    [ "MaximumTransmission", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#aa5f32a647c4ecf2dfa01d3ad7e898ef0", null ],
    [ "MaximumWave", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#aa7784fe3617d47cd9ef726ce217d977b", null ],
    [ "MinimumTransmission", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#ada6c6a5e3b4c7c99f3d9f227ffa63370", null ],
    [ "MinimumWave", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#a78d82b5de5ee00674526171415355934", null ],
    [ "Thickness", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___internal_transmissionvs_wavelength.xhtml#a61a9460407e997ca5191747c6cb9a7a5", null ]
];