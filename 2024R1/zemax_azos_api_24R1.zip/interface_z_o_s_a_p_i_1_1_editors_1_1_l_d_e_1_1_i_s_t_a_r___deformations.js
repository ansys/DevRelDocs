var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations =
[
    [ "IsDataLocalCS", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations.xhtml#a1c8b0c3670e35711cdd6fec74df28a61", null ],
    [ "SetDataIsGlobal", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations.xhtml#ac98f64036cd4b6a0e587af9cca8476b8", null ],
    [ "SetDataIsLocal", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations.xhtml#a974e26de594499c630a43809cd2b81eb", null ],
    [ "CoordinateTransform", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations.xhtml#acbd6e535d3e662cfd8d3a12c531cade0", null ],
    [ "FEAData", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations.xhtml#a7db23d4067ec2dcd0db4a1e5afd62b1c", null ],
    [ "Fits", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations.xhtml#acd1bea0e3bbeb0a4e1ef8a54c2f0dff4", null ],
    [ "RBMs", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations.xhtml#a400929cbaa52b6420a64f1dea639943a", null ],
    [ "SurfaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___deformations.xhtml#a4c03b07903c6b57c05e590b06c62a6ab", null ]
];