var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_b_s_d_f =
[
    [ "GetAvailableFileNames", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_b_s_d_f.xhtml#af1aeb712dceedf6c49f33732d6e3a7e6", null ],
    [ "Angle", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_b_s_d_f.xhtml#a05ae8b8a80586fbab9fe715303f3305a", null ],
    [ "FileName", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_b_s_d_f.xhtml#ac31aab08aefc9d44fe3538c51dd121a5", null ],
    [ "ScatterFraction", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_b_s_d_f.xhtml#a8c88a68cf5d33a9b8e25f3f87e605c9e", null ]
];