var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan =
[
    [ "CheckApertures", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#ab2a8e27517ae2d8abe749a1c44fc0cbc", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#abe35038fd68b4e52a6c5442679d46254", null ],
    [ "NumberOfRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#a8aa3af0adda058be2690c83f78507302", null ],
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#a5012e19fc32b913041ae2e6715f6887c", null ],
    [ "Sagittal", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#a51869b44a436cc7146ba4418a929c50a", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#ada8e651ebcf1ea9ce6b0fee86268b5da", null ],
    [ "Tangential", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#a297e998fcb5142eb86c6619ca7ed316d", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#aa8fd29db3f5f46cf1b475f0fc7797213", null ],
    [ "VignettedPupil", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#ad2f4bb7a19ef368c06ae30a6000925c7", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_fans_1_1_i_a_s___fan.xhtml#a1970c1bcfd0088cd316bbab86deb6529", null ]
];