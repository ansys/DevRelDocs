var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion =
[
    [ "DisplayAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#acd0e1764a962f5dd08bbd248654802a7", null ],
    [ "Distortion", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#a95e914b84b262428896ef45f33163733", null ],
    [ "FieldAspectRatio", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#ab5d5bbd18935ff60df261e96c394ad1d", null ],
    [ "IgnoreVignette", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#a5cc60e768f8d6ae3fb3e403b8e12ddf0", null ],
    [ "MaximumCurvature", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#af0aef716ca608a8886a4d257f3ba9655", null ],
    [ "MaximumDistortion", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#a9987caea12a5f3da7bb4ca7ce6459a31", null ],
    [ "ReferenceField", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#ada50f1e42cc022dea3fc8106632f9e68", null ],
    [ "ScanType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#a774283a560b3798dc5fecbfeda899f45", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#a13a8fb7b9bcd5469437f7664b7cdd22c", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___field_curvature_and_distortion.xhtml#a0203793add198f851213ba943f39a8bb", null ]
];