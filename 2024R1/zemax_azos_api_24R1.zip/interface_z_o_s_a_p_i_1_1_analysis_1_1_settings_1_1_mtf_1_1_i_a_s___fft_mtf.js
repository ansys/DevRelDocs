var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#aac108d43f406d60f36e7df9fb350d7ef", null ],
    [ "MaximumFrequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#a2aef906da5aea48d04beff6510d54680", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#af01f96026dfe472d74f562c04c8c7bce", null ],
    [ "ShowDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#a6d7ac77d0929c66e92f7a52f7cd367e4", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#a413eb905caec3ee59b55d840e1ce5c6d", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#ae95968514036320e8d708e77b7bf7979", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#aeea79417352bd13a51b9f0d3b586f29c", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#acf8f62f06236b95c57fde78db8127e66", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf.xhtml#aaf22d256cb23a57b0bdf26cd8d7632a8", null ]
];