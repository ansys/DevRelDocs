var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_even_power =
[
    [ "Coeff_R_NthEvenPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_even_power.xhtml#aa73156a7b20e120c5c44b3d3bb03c95a", null ],
    [ "GetCoeff_R_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_even_power.xhtml#ac24565c4bf20c118ee018bca3fda9906", null ],
    [ "SetCoeff_R_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_even_power.xhtml#a801dc5fde7832d17f7995648ed3a22e4", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_even_power.xhtml#af8364aa7da16c139d683f8e5267717c6", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_even_power.xhtml#a305a7e2326e67b8a1e1a42585fee56a5", null ]
];