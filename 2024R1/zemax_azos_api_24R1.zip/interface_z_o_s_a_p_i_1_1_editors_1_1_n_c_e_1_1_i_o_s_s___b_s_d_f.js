var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___b_s_d_f =
[
    [ "GetAvailableFileNames", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___b_s_d_f.xhtml#a520119ae6db4ee2946d0e3fc6dec35aa", null ],
    [ "Angle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___b_s_d_f.xhtml#a3052a45785b3fab81d5eced178b3a748", null ],
    [ "ReflectFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___b_s_d_f.xhtml#af9fd41cd276f76a6dd0c956a3e4699e1", null ],
    [ "ScatterFraction", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___b_s_d_f.xhtml#a360ef670cd7eada84d3dc721af0cbb1d", null ],
    [ "TransmitFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___b_s_d_f.xhtml#a36673211fa9cf757045ade0fe0f279ed", null ]
];