var interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator =
[
    [ "GetRGB", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#aa5d14ea81d809063619a08a0a6c153d7", null ],
    [ "GetRGB2DFloatSafe", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a0b36d81f9352abf4088f6d8c79c57e86", null ],
    [ "GetRGB2DSafe", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a4b20453818c4c4b372eb8906add1538f", null ],
    [ "GetRGBFloat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a9010ced3e61de39972f73c98f080c507", null ],
    [ "GetRGBFloatSafe", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a5476c54205198e51f807e01b4665e2a4", null ],
    [ "GetRGBSafe", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#af0f5944d210a50d7fa0d4be0794d12f1", null ],
    [ "GetSingleRGB", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a117d92c44cca34d4b9101a0357c4498d", null ],
    [ "GetSingleRGBFloat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a3dec9a0ab1a33fe408c0863e3447dd47", null ],
    [ "CanConvertSingleValue", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#ada8bec509cf2c048176d58d1a111ab13", null ],
    [ "IsAutoScaled", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a6793e5f435aabde6a775558ad32b572e", null ],
    [ "IsInversePalette", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#ab67bb17d96627e58e62856a317148aaf", null ],
    [ "IsLog", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#abb0df3d9b29e4bf312f9c2b9c2cbe861", null ],
    [ "LogBase", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a53b50e8a5bd8cb8eddd48601d7323736", null ],
    [ "MaxValue", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a467b23ec6169d7d8cdf629b9adcf1185", null ],
    [ "MinValue", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a586df35d2d3c08bb708392f15e70b171", null ],
    [ "NumberOfShades", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#aebcce14bc32705e50a925df49f86a095", null ],
    [ "Palette", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_color_translator.xhtml#a3092c4da8aaddc9a3293d12dafbd9f7d", null ]
];