var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar =
[
    [ "MaxAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#a2fbf9627a1ec44a68535074081bb00af", null ],
    [ "MaxAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#a0928e4818314d1c8b85e756d2af98590", null ],
    [ "Mirroring", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#a02e97528b8447008559c76bed28a614e", null ],
    [ "MirroringCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#a2df1aa39602813f47c852c11359cb0bb", null ],
    [ "NumberAPixels", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#ad4fedb4c70b53e3417765dde20788a05", null ],
    [ "NumberAPixelsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#abfc886a6ca80abdf234e27ebf9a09789", null ],
    [ "NumberPPixels", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#a3903c3486538a7793a538b40abd5b2e1", null ],
    [ "NumberPPixelsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#a23cf446d4aae0b61e918aed6702bf2d2", null ],
    [ "RadialSize", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#a054988eb6d2812af567aad53c6c91f77", null ],
    [ "RadialSizeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector_polar.xhtml#a0af0cf9c654654cfee348d9ecb759d4b", null ]
];