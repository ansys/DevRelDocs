var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_power =
[
    [ "Coeff_P_NthPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_power.xhtml#acf499d389014800d85886c79314195da", null ],
    [ "GetCoeff_P_NthPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_power.xhtml#af0e115ceafc37f15fa1182e55f9680c8", null ],
    [ "SetCoeff_P_NthPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_power.xhtml#af70128f043dc7451569a0cb2737708d6", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_power.xhtml#a8bfe6a98904feb5f6015cf380f525064", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_power.xhtml#a27edc07fa96a6cc1af8e66141d292ef1", null ]
];