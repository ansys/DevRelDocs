var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power =
[
    [ "Coeff_Y_NthEvenPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power.xhtml#a04510feb3cdb067a193a0611e196cac6", null ],
    [ "GetCoeff_Y_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power.xhtml#affd4dca1c4e7bc6c039267349d2e21f7", null ],
    [ "SetCoeff_Y_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power.xhtml#a9b505b2b219f9cfdff87d828212f4f6e", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power.xhtml#afa5ceb23569e6408f97f03adb43a1a51", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power.xhtml#ac3f22a48772c053b5495c325cc557f6a", null ]
];