var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector =
[
    [ "GetColCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector.xhtml#a9db84b1fe0cc5166ed51be0a0cb6de29", null ],
    [ "GetDetectorDimensions", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector.xhtml#a624cdebed327f488fd5c0f30064de837", null ],
    [ "GetDetectorSize", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector.xhtml#a7dc21f673e8230037930dbc414ff5c98", null ],
    [ "GetRowCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_detector.xhtml#a59c7a76a0bf7aeb27bab961a81d91eac", null ]
];