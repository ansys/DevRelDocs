var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope =
[
    [ "BestFitSphereOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#a5bdbd03dc5c618293f3e0867d07f5e94", null ],
    [ "ConsiderOffAxisAperture", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#ab9b137e57b2a306ef6f28c8c49992279", null ],
    [ "ContourFormat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#a4fb11561c803be6e3879986bfd9e4a53", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#a79302f1df65170402cc7b49423eba256", null ],
    [ "RemoveOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#a66131c5cc38aecee71b900c7e3864f9d", null ],
    [ "ReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#afd290483342c09db2ce64d12b00537f3", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#a7ad1352622f3929855ce03a8a899684f", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#ad3cb99294c961be5eb31972b437e4eae", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope.xhtml#a3b1d5c9ace358788d193305c0ffe353c", null ]
];