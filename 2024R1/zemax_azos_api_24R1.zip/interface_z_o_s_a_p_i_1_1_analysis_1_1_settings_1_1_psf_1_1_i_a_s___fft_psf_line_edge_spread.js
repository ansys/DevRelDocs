var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread.xhtml#a1ad468ddf33bdb0277f0d5a4ebd392f3", null ],
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread.xhtml#a2afd105db760702f38cb70ffa4e2deab", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread.xhtml#a8baec1c22058955dd474c1b4a67943c3", null ],
    [ "Spread", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread.xhtml#a447a37e76f5f1f3cf7c192ba8ea76420", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread.xhtml#a099aebaa287170ff52ac4256c9c8d6bd", null ],
    [ "UseCoherentPSF", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread.xhtml#ab82ed57cea73870e5aa527cdca51f1be", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread.xhtml#aabb517a471097b6ad8f636d6fd306e46", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_line_edge_spread.xhtml#a59948a08eb6e33a59930b3e53841fdb4", null ]
];