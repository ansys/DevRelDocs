var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_grat =
[
    [ "DiffractionOrder", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_grat.xhtml#a71091dcf3776bdf65ed7f5ddb3acaf75", null ],
    [ "DiffractionOrderCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_grat.xhtml#a60b30e2c53cd3a9d6a7fa25f8ce47d4d", null ],
    [ "LinesPerMicroMeter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_grat.xhtml#a1f14cadffee8fd076d7d9c5b859d54e9", null ],
    [ "LinesPerMicroMeterCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_grat.xhtml#a2ef4bf8ec4f1e91db03e5ed5979b4baf", null ],
    [ "RadiusOfRotation", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_grat.xhtml#adcd1e2d0bd22c08b9e26aead62d4f899", null ],
    [ "RadiusOfRotationCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_grat.xhtml#acf6390bc089acd16262e6441f46177a6", null ]
];