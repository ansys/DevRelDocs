var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_material_catalog_data =
[
    [ "AddCatalog", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_material_catalog_data.xhtml#ae348d808484e0c5a4193b164ce0a802a", null ],
    [ "GetAvailableCatalogs", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_material_catalog_data.xhtml#a3c634e2aea8f3363c2caf2794f6b0476", null ],
    [ "GetCatalogsInUse", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_material_catalog_data.xhtml#a72c181444c526b904a8d1abba2281032", null ],
    [ "GetMaterialsInCatalog", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_material_catalog_data.xhtml#af29ed53ab8e9fca76d5d3534ee1a4946", null ],
    [ "IsCatalogInUse", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_material_catalog_data.xhtml#a1634409f659a85391617fdf7ca19eb96", null ],
    [ "RemoveCatalog", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_material_catalog_data.xhtml#a97c9ef7850795c75aeb80366dbc75383", null ]
];