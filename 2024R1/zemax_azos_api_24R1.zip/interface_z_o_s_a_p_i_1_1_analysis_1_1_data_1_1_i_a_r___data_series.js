var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series =
[
    [ "ConvertToRGB", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series.xhtml#ae05c830c2332bff629754e742a3d3116", null ],
    [ "Description", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series.xhtml#ad7fd4acd6bd70abdb69741489d3188e0", null ],
    [ "NumSeries", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series.xhtml#ac086af8710a8becef9ceac167adb511a", null ],
    [ "SeriesLabels", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series.xhtml#a7f371dc440fbd9ace5f1d4d8e0073448", null ],
    [ "XData", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series.xhtml#a83aaff0e2b0dd0794b9c6f22e5c89f3d", null ],
    [ "XLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series.xhtml#a6784c37a725a15e80d2c2cde413bd7c2", null ],
    [ "YData", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series.xhtml#a7724e43c32625fdb176d9130f20ce5ee", null ]
];