var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coat_scatter_data =
[
    [ "CopySettingsToAllFaces", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coat_scatter_data.xhtml#aae3465d6ffb89d65f72e049b9643c4ab", null ],
    [ "GetFaceData", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coat_scatter_data.xhtml#a784337a7b51eb6c4b283972986aa8039", null ],
    [ "IsCoatScatterAvailable", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coat_scatter_data.xhtml#a9b14e1bc208ec1476c8a1874b4d81e18", null ],
    [ "NumberOfFaces", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coat_scatter_data.xhtml#afb46afe0d2e368b6ef9ab4a0a70589b7", null ]
];