var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_index_model_settings =
[
    [ "_S_Birefringent", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_index_model_settings.xhtml#ae986b80a48a2284c014daf5a53253a35", null ],
    [ "_S_GRIN", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_index_model_settings.xhtml#a952de466387e9f237e44c61269b21538", null ],
    [ "_S_Isotropic", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_index_model_settings.xhtml#a8e297b491b6fa3f904e9cf0adb5289f9", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_index_model_settings.xhtml#a7e1688b2df4b1ad87969733983e374d3", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_index_model_settings.xhtml#a559868ec6b7c59016065ad36d837c030", null ]
];