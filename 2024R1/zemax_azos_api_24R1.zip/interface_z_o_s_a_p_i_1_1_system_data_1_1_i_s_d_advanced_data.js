var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data =
[
    [ "DontPrintCoordinateBreakData", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#a5dcd72c5edb07d9449d57ae47913d85c", null ],
    [ "FNumMethod", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#a21d14486155f63e11cd1e133e7ebeda3", null ],
    [ "HuygensIntegralMethod", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#a20bec63ef62922dbcd134ad41dcfd915", null ],
    [ "IncludeCalculatedDataInSessionFile", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#a3e9d53a6d54e4ca874f53669af981707", null ],
    [ "IncludeToleranceDataInSessionFile", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#a7927efe5c4aa38fbe7096d860ed82eeb", null ],
    [ "OPDModulo2PI", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#a8620948ed70d321fc52f02f372e4d454", null ],
    [ "ParaxialRays", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#ac7ad86311ec2557009b53574e2ad28b0", null ],
    [ "ReferenceOPD", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#ac59f1c90d8666801d283222389a8e141", null ],
    [ "TurnOffThreading", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_advanced_data.xhtml#a77d999fc81dab2a601d1a7682e35bc4c", null ]
];