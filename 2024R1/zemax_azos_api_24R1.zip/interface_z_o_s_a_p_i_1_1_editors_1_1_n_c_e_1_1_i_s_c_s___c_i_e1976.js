var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1976 =
[
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1976.xhtml#a3cdb1936d4df167ccba3956ad2bdb08f", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1976.xhtml#af43b3395320f2d70814e1152f00e8669", null ],
    [ "u", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1976.xhtml#a7c4c6aaa7b8adcf68f92565d3c9152e0", null ],
    [ "v", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1976.xhtml#a944ab95502cce20f101b21f97e8f0c20", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1976.xhtml#a539d32acc22be7cef033518090549ba6", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1976.xhtml#af5b3ffd556331ee949d6a8a68549297f", null ]
];