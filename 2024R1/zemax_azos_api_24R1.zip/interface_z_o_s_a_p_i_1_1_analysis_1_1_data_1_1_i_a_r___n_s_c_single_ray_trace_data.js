var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___n_s_c_single_ray_trace_data =
[
    [ "ReadSegmentFull", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___n_s_c_single_ray_trace_data.xhtml#a1cf2d44a4a01fc516b73fa352c49899f", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___n_s_c_single_ray_trace_data.xhtml#a0eccade29a190a127c5f70e1d07c68a0", null ],
    [ "NumberOfSegments", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___n_s_c_single_ray_trace_data.xhtml#a5647d9316cd7e6e61dda55e81e5765c5", null ],
    [ "WaveIndex", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___n_s_c_single_ray_trace_data.xhtml#afe43e9504cf1761b4414984890607ad9", null ],
    [ "WavelengthUM", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___n_s_c_single_ray_trace_data.xhtml#a7f7d853df42f67196a720952201a9a55", null ],
    [ "ZRDFile", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___n_s_c_single_ray_trace_data.xhtml#a82553449c5822a5f156256747c0c8d71", null ]
];