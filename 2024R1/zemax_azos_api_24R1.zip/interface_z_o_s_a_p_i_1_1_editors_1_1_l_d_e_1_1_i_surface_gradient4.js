var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4 =
[
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#ae5ff580a139ae9d7ea012d1cf22bf990", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#ae5c6ec4806729bb7f687a9ec7bf45b3d", null ],
    [ "n0", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#a1329619e4646d46cca05f7d435b3bdc8", null ],
    [ "n0Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#ae794d77ae9416556d4cb46736296ef48", null ],
    [ "Nx1", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#a97a56b2d585f8f4efb04b89bd1a9370e", null ],
    [ "Nx1Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#a26ada6964aa13b79777db7f257962b1b", null ],
    [ "Nx2", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#ab181f65498c1bf58a007216123f09a6b", null ],
    [ "Nx2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#aff2d4207f045311092e2726226a46403", null ],
    [ "Ny1", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#ae6509a291bd0980dca5a9062fdafe2d6", null ],
    [ "Ny1Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#ad2f9514d238d26bfac2ef6c17cfff5e2", null ],
    [ "Ny2", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#a53f3a4839787a43199217c1c7703ec2b", null ],
    [ "Ny2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#ac898769cc8da92770846e59e29f57c3b", null ],
    [ "Nz1", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#a028edb71d7ea0570944f12f766780689", null ],
    [ "Nz1Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#a349217d2fc84fe81bce7fc1731238616", null ],
    [ "Nz2", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#a8fcefaa61365db8bffc237a4d9641530", null ],
    [ "Nz2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient4.xhtml#a77bfdb00ea8240fc4356ab21fd8b343e", null ]
];