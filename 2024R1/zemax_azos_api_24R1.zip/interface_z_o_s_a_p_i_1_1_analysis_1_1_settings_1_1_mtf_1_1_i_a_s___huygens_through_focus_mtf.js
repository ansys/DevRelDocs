var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf =
[
    [ "Configuration", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#a15e2eb7df73f731a3bcdb66eb49cc0fc", null ],
    [ "DeltaFocus", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#a2c3fa0d31a91bba7d11d8a1ce2615747", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#a74edbde5f9c16833ced425adee2fc65b", null ],
    [ "Frequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#ac0058c8876f5f70b37070cdb182ae1b7", null ],
    [ "ImageDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#a178f48bc849d138e2a6a75eb0504d277", null ],
    [ "ImageSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#a7e9539c73d79100b6c9b52330c5a457d", null ],
    [ "NumberOfSteps", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#a780018dae1239e5bcae35a4c9817745f", null ],
    [ "PupilSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#a07da0bacbefe5456dacec46923d2b9d8", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#a1e1b94c6c130e71cb6428cc53175b27b", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#adc5a2277fe4bcd85fbe45316254ff5a9", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#ad4acb3dc013681bbed042194fb61f9a6", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_through_focus_mtf.xhtml#acef2069b1570f15557d451004ac45008", null ]
];