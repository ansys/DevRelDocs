var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume =
[
    [ "RadiusR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume.xhtml#a7ff38b3c7381e267f7a4df6f5b13abaa", null ],
    [ "RadiusRCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume.xhtml#adc615dcdba1c1a5dc0244a9c808cf881", null ],
    [ "RotationR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume.xhtml#a144ec290dc89796389f526e53252dd77", null ],
    [ "RotationRCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume.xhtml#a4f6a72b7ebce6808c82996d9ed40c41f", null ],
    [ "StartAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume.xhtml#a90e6ffb31520d26fe6caed8c8040f62b", null ],
    [ "StartAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume.xhtml#acf6d45fda7a09d8c129c7296df9db115", null ],
    [ "StopAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume.xhtml#aa51e7da9deadbd6e3e833a03cbe0ba09", null ],
    [ "StopAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_volume.xhtml#a106bed1129da76e14ccecf222c914006", null ]
];