var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power =
[
    [ "Coeff_X_NthEvenPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power.xhtml#a9c3a1c19b53b63f5a698d9aa8cf69a25", null ],
    [ "GetCoeff_X_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power.xhtml#aebcbf3f82a79768a98cc3a1db43dd57a", null ],
    [ "SetCoeff_X_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power.xhtml#a740178dae74cc86429eded77324fa833", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power.xhtml#aa1d3f1ddb3d5735ac7736ad89ea51f8b", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power.xhtml#aef4a3c10da229fb0cc11629d6753af13", null ]
];