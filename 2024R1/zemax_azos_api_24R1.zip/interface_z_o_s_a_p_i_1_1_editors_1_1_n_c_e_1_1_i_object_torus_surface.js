var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface =
[
    [ "RadiusR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface.xhtml#a3a2e2d4da665dac6d6bca0ff3471907e", null ],
    [ "RadiusRCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface.xhtml#a69953d404a9c9c5076db63a1b8324ccc", null ],
    [ "RotationR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface.xhtml#a8ffadeeb34f6c83375815d87877894d1", null ],
    [ "RotationRCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface.xhtml#a15600d11c2315f27ee36fe0d568a6706", null ],
    [ "StartAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface.xhtml#a5d7f4aff17aab8b2fe4322d39fa7dd10", null ],
    [ "StartAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface.xhtml#a106fa978d856d4a48b470ca08a720b03", null ],
    [ "StopAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface.xhtml#a5ff9186459e018f35dd0f58e4a0eae01", null ],
    [ "StopAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_torus_surface.xhtml#a665874b6f45eeeb2405d2bd1f96474f1", null ]
];