var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_even_power =
[
    [ "Coeff_P_NthEvenPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_even_power.xhtml#a7dc47cb70294f62b4c98e52d93a50635", null ],
    [ "GetCoeff_P_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_even_power.xhtml#a0f893c51cce9595f79014e4b28ff10c5", null ],
    [ "SetCoeff_P_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_even_power.xhtml#af2476068a2f8d70a81ba2456d70fee74", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_even_power.xhtml#a98e8413ba6a5aea3bb938b10f4e01097", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___p___nth_even_power.xhtml#a30baeef00262c2fd11fbc6ab2ee8b17c", null ]
];