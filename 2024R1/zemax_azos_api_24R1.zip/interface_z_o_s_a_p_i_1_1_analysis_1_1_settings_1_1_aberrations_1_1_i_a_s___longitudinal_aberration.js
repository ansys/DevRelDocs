var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___longitudinal_aberration =
[
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___longitudinal_aberration.xhtml#aef4a7a8f4838dfbc4a3866ce7e2b1b42", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___longitudinal_aberration.xhtml#a83ed30f0b4e6ce0e6062fea060e5b2b7", null ]
];