var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_generalized_fresnel =
[
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_generalized_fresnel.xhtml#a9ce255ae4266f7bacc597da290f95664", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_generalized_fresnel.xhtml#a68e5e8916ebb50a95282dbe2cb4adf45", null ]
];