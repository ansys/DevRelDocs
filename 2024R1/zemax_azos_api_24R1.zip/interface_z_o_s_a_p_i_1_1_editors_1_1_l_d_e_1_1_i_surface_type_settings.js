var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_type_settings =
[
    [ "GetFileNames", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_type_settings.xhtml#aca5bf7c2e8282b41856be9fe40f8a3cd", null ],
    [ "Filename", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_type_settings.xhtml#a2bd7f4a88e2b7f6522d754d5c82f4144", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_type_settings.xhtml#a6f67d76fde90ff677e30e6f81b69e51b", null ],
    [ "RequiresFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_type_settings.xhtml#aba9e75225cbebd1d341529da7da3399a", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_type_settings.xhtml#a6902a9206bcb3ec146239136ae56c383", null ]
];