var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_elliptical =
[
    [ "ApertureXDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_elliptical.xhtml#ac1efab8617f8fb36d9eb667aa77d8d8f", null ],
    [ "ApertureYDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_elliptical.xhtml#ae13fc5f64e86e3ba5d02223a43a7a612", null ],
    [ "XHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_elliptical.xhtml#a67e7dbcacebfcf39843dfec7d35adcee", null ],
    [ "YHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_elliptical.xhtml#a43a7e5109cc35c4d86067c59d8da6ebd", null ]
];