var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___seidel_diagram =
[
    [ "IgnoreChromatic", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___seidel_diagram.xhtml#a8f45b5b08a8830d4f5b85ebeb9ee0a07", null ],
    [ "IgnoreDistortion", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___seidel_diagram.xhtml#a3580a4406d5dda248d66b0eb60d9112d", null ],
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___seidel_diagram.xhtml#acd1a6cfa427abfb9383022b546b40347", null ],
    [ "SuppressFrame", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___seidel_diagram.xhtml#a6f29527c970c208181fccc3112378489", null ]
];