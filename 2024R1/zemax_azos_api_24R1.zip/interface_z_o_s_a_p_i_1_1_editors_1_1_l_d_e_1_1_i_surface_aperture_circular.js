var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_circular =
[
    [ "ApertureXDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_circular.xhtml#adee03ee4eaeb6ad620b2cebf1b04ab3e", null ],
    [ "ApertureYDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_circular.xhtml#a7a6abb27a9f4c1c7db47eeae8a1d2380", null ],
    [ "MaximumRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_circular.xhtml#a0cb1c42aa31365abe83fcaffc4b8d8bb", null ],
    [ "MinimumRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_circular.xhtml#a643dafb4660a5eae4e74e85e5d71f6d0", null ]
];