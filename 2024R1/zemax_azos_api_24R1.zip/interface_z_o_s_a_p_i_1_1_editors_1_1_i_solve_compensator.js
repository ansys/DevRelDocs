var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_compensator =
[
    [ "RefSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_compensator.xhtml#a5f183fc6fb5991449e7d3495022e1842", null ],
    [ "Sum", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_compensator.xhtml#a5f0e8e50c8f5717c02848b56224c4fb9", null ]
];