var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_periodic =
[
    [ "Amplitude", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_periodic.xhtml#af99f48d57ab36af16fa6b89c8b30d57a", null ],
    [ "AmplitudeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_periodic.xhtml#a770167886e2770f6027824c7b7fc1156", null ],
    [ "X_Frequency", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_periodic.xhtml#abc8ee0e3aee5357c7a1b64f45a629d9a", null ],
    [ "X_FrequencyCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_periodic.xhtml#afa83c70094aa00d2a52f69bfb4fc221d", null ],
    [ "Y_Frequency", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_periodic.xhtml#ad26b2a63e8cf83a7893024f578f73952", null ],
    [ "Y_FrequencyCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_periodic.xhtml#acff8957c3dea540477913619839d7ecd", null ]
];