var interface_z_o_s_a_p_i_1_1_i_z_a_p_i___base_object =
[
    [ "AddChild", "interface_z_o_s_a_p_i_1_1_i_z_a_p_i___base_object.xhtml#a0061325019cda2247b5089459715d1c7", null ],
    [ "Disconnect", "interface_z_o_s_a_p_i_1_1_i_z_a_p_i___base_object.xhtml#ade8bc05dee163372eef49a9c0c8535a6", null ],
    [ "RemoveChild", "interface_z_o_s_a_p_i_1_1_i_z_a_p_i___base_object.xhtml#a603afece28e1a008bb7d7e8e8efcedab", null ],
    [ "Parent", "interface_z_o_s_a_p_i_1_1_i_z_a_p_i___base_object.xhtml#a20e56bcb7d49f1d5535a4047f758ddee", null ]
];