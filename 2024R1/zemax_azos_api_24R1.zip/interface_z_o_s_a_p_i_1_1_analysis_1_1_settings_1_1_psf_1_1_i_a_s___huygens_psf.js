var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf =
[
    [ "Configuration", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#a22bcf9673a7794601b9a1566d6633bfe", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#a4b20a2e8c363e0151eb4a0e38251aa5c", null ],
    [ "ImageDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#ac37758abd80fd19ad6ea4a303817105e", null ],
    [ "ImageSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#ace860300e3553c7c5f0cc2a263e70847", null ],
    [ "Normalize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#ae4422c65075450c93f9624551a00df45", null ],
    [ "PupilSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#ac6875e7b17159ee8df8e93a6e2d1c655", null ],
    [ "Rotation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#af7c20505a73d253c7536ce53f50b3e6a", null ],
    [ "ShowAsType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#a9bd8a49e109793ef2a479556f2fbb0f1", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#a0e64e000a5459f0ef0ce755f94ac167d", null ],
    [ "UseCentroid", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#a81897f26c048800bb9f52d7dca872c9f", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#a1d452863f7f8fafb59e4d11a5a6f1cba", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf.xhtml#a34a949ac748bff6e3fa25d6410e07144", null ]
];