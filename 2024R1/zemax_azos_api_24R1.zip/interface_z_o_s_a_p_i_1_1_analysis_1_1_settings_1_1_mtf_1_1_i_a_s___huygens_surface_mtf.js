var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf =
[
    [ "Configuration", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#aac0c9f02bbeb74f80c3e247b5fbe7825", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#a7141f4ffef489fca5a21e69e0625241c", null ],
    [ "ImageDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#a0a3c194e98b092be0e9d95268d0cf995", null ],
    [ "ImageSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#a549a3b35045fd56e1765566f818f5828", null ],
    [ "PupilSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#aaed80040ac833cdb8e22496f0bc947d8", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#a525e6d350aceae6dcf0722d22dc2ae10", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#a7fe9f84c5b40a3b93d6d19f78f471332", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#ab0e1170260b3aeb67976d66e03bba164", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_surface_mtf.xhtml#aae8f381c5a427c0f1741cb5f3d769a8a", null ]
];