var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_volume_physics_model_settings =
[
    [ "_S_AngleScattering", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_volume_physics_model_settings.xhtml#a0d6315e8c4490ccb8a2cf5ce52475f7c", null ],
    [ "_S_DLLDefinedScattering", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_volume_physics_model_settings.xhtml#a91d7f75ed8ff7548eda882ad739bcef5", null ],
    [ "_S_None", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_volume_physics_model_settings.xhtml#a2637b01347f773302d2c2f4d75fc3458", null ],
    [ "_S_PhotoluminescenceModel", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_volume_physics_model_settings.xhtml#a1abfcd38f597d1840ad99c41824bbab0", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_volume_physics_model_settings.xhtml#abdd68a49b7ecece33bc38c8c639ef023", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_volume_physics_model_settings.xhtml#a9007f1942da20d97b25df1bbb9cdbbb1", null ]
];