var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace =
[
    [ "UseArbitraryRay", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#a96c136a41b2117c3c83f6670935e2f31", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#adcdcd8a6cfb34bd9b531d93385d2ba9c", null ],
    [ "Hx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#a7118844267e372059a374427c5fa9759", null ],
    [ "Hy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#afa8542e118ab83f70d82d5ee86049156", null ],
    [ "Px", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#abfd017388528040a36ccc53fe9f62074", null ],
    [ "Py", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#af8a6c6f44b88daa868a1885af870c6ce", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#af8faac08bcdfea91c86319b39555d086", null ],
    [ "UseGlobal", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#ae24bd895227985b14aee4260de839187", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___ray_trace.xhtml#ac9695797bdd49a6d13db848761a895b0", null ]
];