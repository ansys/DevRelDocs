var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial =
[
    [ "GetZoneIFacets", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#a939af1a65d1a2f5a0d8af0d07033acc0", null ],
    [ "SetZoneIFacets", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#af4a39fbf6eff702ffbdf4d1a7067ea8c", null ],
    [ "ZoneIFacetsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#a74f54dd52439b993726ad300bc623663", null ],
    [ "IsVolume", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#a470b1f78a18f31956d2190d242b814a0", null ],
    [ "IsVolumeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#ac7845f1cf2b553de278a6201029bb297", null ],
    [ "Scale", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#ababa6894dbdfcf38b2faf189e2cde3e1", null ],
    [ "ScaleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#a4d1598b4abd8aa9662be01b5ec169c4d", null ],
    [ "StartAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#aa65d06ea66c871ed88f9c009a55fe6b1", null ],
    [ "StartAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#acb2843b2e6fb0ddc23fdcfae09458209", null ],
    [ "StopAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#aeda8ee347ea3b45b61c4d0678a0a869a", null ],
    [ "StopAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_radial.xhtml#a9d1a99777633c31f4c2a1f1edab067e8", null ]
];