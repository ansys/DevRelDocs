var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data =
[
    [ "FillData", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#ac20fb905ad529c14d3417629237928d1", null ],
    [ "GetVertex", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#a19ea07a11bfc9783197f6d919be6cc40", null ],
    [ "GetVertexNormal", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#a4ac87928b250115fb748bc618d840aa1", null ],
    [ "AbsorbedFlux", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#abbaf71b1bf4d33bbe9cb2ab09edd4d0d", null ],
    [ "AbsorbedIrradiance", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#a388f7efef558eea33805f470616ff089", null ],
    [ "ConvertToGlobal", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#a7d4b000bfe8882d98b57ed2c265fbbbc", null ],
    [ "CurrentFace", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#af350224c908ad1f5c80df7c82748b702", null ],
    [ "Flux", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#a45a292fa5293a3e1876071f9a65d268a", null ],
    [ "Irradiance", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#aba8d2b3ede55ebebf991dbf8ed82f4bb", null ],
    [ "NumberOfFaces", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#acec4eb0a1d854d993babf37a12cbff12", null ],
    [ "NumberOfVertices", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_face_data.xhtml#af016bb7791bf34919c9ffae158982cb9", null ]
];