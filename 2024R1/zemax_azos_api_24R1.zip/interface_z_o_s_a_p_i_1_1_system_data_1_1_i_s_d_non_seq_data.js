var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data =
[
    [ "GlueDistanceInLensUnits", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#a2cfae96c11ae2b80038626aa2c50f5e1", null ],
    [ "MaximumIntersectionsPerRay", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#a8903acef15b0f4b2e58d43c137977319", null ],
    [ "MaximumNestedTouchingObjects", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#a143ff11bbadd8e85673e633fc331babe", null ],
    [ "MaximumSegmentsPerRay", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#a302a1f1300be8b61af65191e307f01ef", null ],
    [ "MaximumSourceFileRaysInMemory", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#a2b3c8cc0d2d6fd0028db69d864b1e9b3", null ],
    [ "MinimumAbsoluteRayIntensity", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#ad29b95b8f3e8b53ff437c3d0dede32fc", null ],
    [ "MinimumRelativeRayIntensity", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#ae39813ced85842fdd107080d326e2440", null ],
    [ "MissedRayDrawDistanceInLensUnits", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#aac4a40adaf4c8d3d436ca763ec8b77e1", null ],
    [ "RetraceSourceRaysUponFileOpen", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#a7be6d7c64cc23a8f5c3870a8781cfb3b", null ],
    [ "SimpleRaySplitting", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_non_seq_data.xhtml#ab4bb2fcb773dd34dfa3c28d85c87308f", null ]
];