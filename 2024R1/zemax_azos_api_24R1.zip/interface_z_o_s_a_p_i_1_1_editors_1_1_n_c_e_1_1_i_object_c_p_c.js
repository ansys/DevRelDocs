var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c =
[
    [ "AngleDegrees", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#a175d764ad2d02029745575c78673b41f", null ],
    [ "AngleDegreesCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#acdc762c3847e8969750b146fb1952a0c", null ],
    [ "IsVolume", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#ad6f1e8d3de8ce004c015aa60665cdc19", null ],
    [ "IsVolumeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#a7a86643fe5ebb2f54cf43b9ef62f5a0c", null ],
    [ "Length", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#ab64c2084438c07f6098a19e2cc687ebd", null ],
    [ "LengthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#a5ae2d8af4aca474d382fa82b984bb321", null ],
    [ "RadialAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#a297dadc80c78cc62d880e74f4222836e", null ],
    [ "RadialApertureCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#aca6793768b59193d808f354b5b303236", null ],
    [ "VolumeIndex", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#a9b9c8a65f52fdb005721ec7533e5c516", null ],
    [ "VolumeIndexCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c.xhtml#a14073a547a94230f9b96c89a25eef00c", null ]
];