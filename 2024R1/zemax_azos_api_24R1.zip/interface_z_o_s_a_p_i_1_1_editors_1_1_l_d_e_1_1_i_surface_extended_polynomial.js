var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_polynomial =
[
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_polynomial.xhtml#ad28a6a4a12ae408826f30c566e987ee6", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_polynomial.xhtml#ac3a47ca456d6fb8e74320662dd85da23", null ]
];