var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___black_body_spectrum =
[
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___black_body_spectrum.xhtml#a9d978663156e1502ac0c2769035ca49e", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___black_body_spectrum.xhtml#ac88d8052265972cb359719c56dcf1568", null ],
    [ "TemperatureK", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___black_body_spectrum.xhtml#ac3cb6b394e2cc9065d57fca380c358e8", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___black_body_spectrum.xhtml#a439249fe9055feeeb73fff23cc9a4a40", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___black_body_spectrum.xhtml#a0a35bb7f9456de8d5f213465aa3c118a", null ]
];