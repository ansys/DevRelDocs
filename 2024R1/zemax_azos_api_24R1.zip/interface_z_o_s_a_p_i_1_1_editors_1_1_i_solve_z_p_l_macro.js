var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_z_p_l_macro =
[
    [ "GetAvailableMacros", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_z_p_l_macro.xhtml#a04803390389d29c59d6356b5a2197538", null ],
    [ "Macro", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_z_p_l_macro.xhtml#ae226e2e3a204b093c36db15678f437a9", null ]
];