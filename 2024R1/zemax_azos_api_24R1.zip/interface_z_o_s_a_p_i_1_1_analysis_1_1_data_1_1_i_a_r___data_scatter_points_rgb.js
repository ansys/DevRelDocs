var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb =
[
    [ "FillPointValues", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb.xhtml#a1369bb1b8ddad136fff7f5761c09afd4", null ],
    [ "GetPoint", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb.xhtml#accea7c0ed72ddf4840866abf0f53f364", null ],
    [ "Description", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb.xhtml#a36571c72f6d307f407f48b797277aa57", null ],
    [ "NumPoints", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb.xhtml#ae69335034044e1e5dbb4c329b818b8d4", null ],
    [ "Points", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb.xhtml#a8673df07ba4f7238ffa0ee36a1301409", null ],
    [ "ValueLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb.xhtml#a08f67a3f5380b882e54c668c9012e326", null ],
    [ "XLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb.xhtml#ae321b21642e39af241dd82059acd268b", null ],
    [ "YLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_scatter_points_rgb.xhtml#a3039901ae980330e3d1554bbb469d0a5", null ]
];