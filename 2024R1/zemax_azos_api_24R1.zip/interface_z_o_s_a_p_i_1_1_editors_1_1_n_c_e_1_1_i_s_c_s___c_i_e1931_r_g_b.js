var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_r_g_b =
[
    [ "B", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_r_g_b.xhtml#a7b73a5f930e87968a8de5d0dc1b9bca9", null ],
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_r_g_b.xhtml#a3f3513427abf1a195985101fb52736a8", null ],
    [ "G", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_r_g_b.xhtml#abe1c856d99324b63496f224014dbd75b", null ],
    [ "R", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_r_g_b.xhtml#a145d2cc9044fceefa45358e04ceb1e4f", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_r_g_b.xhtml#a184fc16e0ada5108f6e244ecd41ff2c9", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_r_g_b.xhtml#a48434fab79707c6aae21cd8cfa05ba68", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_r_g_b.xhtml#a181f62866e0638a9397efd8b1dc6d316", null ]
];