var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_optical_path_difference =
[
    [ "OPD", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_optical_path_difference.xhtml#a8165281eaf4a13708bddd00560ba78f8", null ],
    [ "PupilZone", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_optical_path_difference.xhtml#ac1952f8a77a39f60a0b9047c6899da48", null ]
];