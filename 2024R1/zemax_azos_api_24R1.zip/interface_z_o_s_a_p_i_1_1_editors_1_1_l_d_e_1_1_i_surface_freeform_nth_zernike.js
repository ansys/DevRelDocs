var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_freeform_nth_zernike =
[
    [ "GetNthZernikeCoefficient", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_freeform_nth_zernike.xhtml#acff7d8f91c35e454969ab555fcb1b42c", null ],
    [ "NthZernikeCoefficientCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_freeform_nth_zernike.xhtml#a6a130bd617e9b3dd8fa0e134d4ee9009", null ],
    [ "SetNthZernikeCoefficient", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_freeform_nth_zernike.xhtml#ad52cf64b745abb5b29d9e9bcd313c309", null ],
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_freeform_nth_zernike.xhtml#a90351264c0f6480b09e5683a34aa24c8", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_freeform_nth_zernike.xhtml#aaaa53edcfac7a25bf11608b7752727f8", null ],
    [ "NumberOfZernikeTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_freeform_nth_zernike.xhtml#a6e5715615629dcd56ac9b6eccbaee460", null ],
    [ "NumberOfZernikeTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_freeform_nth_zernike.xhtml#a2702f96099e524539b5f387c84143430", null ]
];