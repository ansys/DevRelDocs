var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault =
[
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#af67dc7633050df231e78813c9c485b6e", null ],
    [ "Decenter_X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#adc0377d227bd351244859e36e0d9fbb6", null ],
    [ "Decenter_Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#ae12a2d97caa65ed139b923819e69d986", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a82d4713ab4464e4c134f8b8b78e31099", null ],
    [ "Knife", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a75e7db507a77a3573dbb7eaf2cd41312", null ],
    [ "RowColumn", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a02bf098e40ab4777a61b9af6fd02e238", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a3f2d0b05a46cf159d477b061943be66a", null ],
    [ "SaveBMP", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a2745400b4b8c04cf133d448241a23652", null ],
    [ "Scale_X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a095842fb781c5c76cc3f57e779612f9d", null ],
    [ "Scale_Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a7321066db4721c4e984bd1a95286dc36", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a7bbea01762a37bb38f167a6bc1e05385", null ],
    [ "Source", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a4d5648dcaab39fd5113a6c740b193470", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a2bb12c8879168d4d7e265ba765a91488", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a655eb4aa97a28bc639b32ac85dd6d90a", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a51029217c5d9ab513324ce2710309acf", null ],
    [ "Y_Position", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_wavefront_1_1_i_a_s___foucault.xhtml#a22b6dd7302569d497aa8cdff1a70a010", null ]
];