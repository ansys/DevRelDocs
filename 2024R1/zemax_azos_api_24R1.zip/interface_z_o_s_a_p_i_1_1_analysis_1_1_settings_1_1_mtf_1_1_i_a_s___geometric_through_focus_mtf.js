var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf =
[
    [ "DeltaFocus", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#a962e870b05a4f794dd46c73d62441c46", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#a5307fab230eb9d032e03cf0eff85a184", null ],
    [ "Frequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#a166a266f6ac4f977bd752e2dd943c446", null ],
    [ "MultiplyByDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#a5b6c37ca08ab32ec5653d8f076bfb246", null ],
    [ "NumberOfSteps", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#abe257d188b99a29fca37afd606f508d9", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#a9d0c91e282df3d2d7219d96334bc4938", null ],
    [ "ScatterRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#a142f94c977eb7416ccf59e4eaa2f8389", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#ad3a2f707acefdf028062df659511e276", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#a6b6b78f19b6209b9839df5f173c1a77e", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_through_focus_mtf.xhtml#aa911362cd498dc143223bca49f26972d", null ]
];