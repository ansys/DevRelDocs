var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross =
[
    [ "Angle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross.xhtml#a53207a584f7f16ebe6edfb80d23982dc", null ],
    [ "BestFitSphereOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross.xhtml#afdea234751bc231ac37d09a7daa2602f", null ],
    [ "ConsiderOffAxisAperture", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross.xhtml#a4c6dfda8cf0dc6a3ba873e1b3fd43ea2", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross.xhtml#aabda4f7cc0c1191648bb4352759b13f0", null ],
    [ "RemoveOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross.xhtml#a01e30e55370d33519523abc8c05c6711", null ],
    [ "ReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross.xhtml#a2a24173d342fe4bba2bea9628769cc07", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross.xhtml#a6a7dfced915dfe595e7ca9398f485fab", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag_cross.xhtml#a698f72c51fd4a88ea1d8e5282f91cf5b", null ]
];