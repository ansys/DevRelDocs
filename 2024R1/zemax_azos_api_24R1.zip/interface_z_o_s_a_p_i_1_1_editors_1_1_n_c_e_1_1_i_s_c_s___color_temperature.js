var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___color_temperature =
[
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___color_temperature.xhtml#a9b41b05f0b235d4fd15d929eec3976df", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___color_temperature.xhtml#a767f4107caa289bd3ad1d6a0fed18341", null ],
    [ "TemperatureK", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___color_temperature.xhtml#a8400379867e1177e58b4f40ea6e07428", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___color_temperature.xhtml#ab3ce13e9e219023a4f47c7d6fe9bdcf9", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___color_temperature.xhtml#ab6fcdcc831728b8c4cca91a6b7eac167", null ]
];