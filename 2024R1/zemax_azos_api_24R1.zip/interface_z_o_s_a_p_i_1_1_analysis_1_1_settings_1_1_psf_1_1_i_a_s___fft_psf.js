var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#a9484be17392a674ac54f121decc8c385", null ],
    [ "ImageDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#a9c1e2e1e55ff554c41888f980aa06e7b", null ],
    [ "Normalize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#a779782985d6d1105b627f177169f56d0", null ],
    [ "OutputSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#a6b164a712c961814baf6ddf0906a4df7", null ],
    [ "Rotation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#a125515a37ec76bd22bd9eb960a93954b", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#a1e1b59d3ee30de960958e95a37853bb0", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#abcd4e02de25c6063031105a689a621a8", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#ab94d5d6058264076b1e47201efc83787", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#a7430b9b8991c54130e95807d5e579290", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf.xhtml#aabbe1b3816ef3acae9ff707b32d97631", null ]
];