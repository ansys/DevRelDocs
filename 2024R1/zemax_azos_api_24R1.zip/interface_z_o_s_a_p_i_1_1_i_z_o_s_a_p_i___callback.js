var interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___callback =
[
    [ "Copy", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___callback.xhtml#a620b29e3736b0d4f235e1af95237a656", null ],
    [ "Execute", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___callback.xhtml#a28060c02905b5cf2bb64ece4a853f005", null ],
    [ "IsLocal", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___callback.xhtml#ab24da0ca3c25a474a01053be9c3d5779", null ],
    [ "Name", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___callback.xhtml#a995e9f7109d2e8d21376ecbe88bea2c8", null ],
    [ "Settings", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___callback.xhtml#a358024cdffde099d4e8ab8fdfde3b06f", null ],
    [ "TheApp", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___callback.xhtml#a9e5838b7ebb93934248801626e46a4d9", null ]
];