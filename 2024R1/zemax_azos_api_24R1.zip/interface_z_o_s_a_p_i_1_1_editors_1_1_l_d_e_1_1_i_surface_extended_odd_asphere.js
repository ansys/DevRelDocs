var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_odd_asphere =
[
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_odd_asphere.xhtml#a8967a5681b5a6fed9477e26f9ffb5483", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_extended_odd_asphere.xhtml#a58424568eb4138b0f2257c4b1b175f26", null ]
];