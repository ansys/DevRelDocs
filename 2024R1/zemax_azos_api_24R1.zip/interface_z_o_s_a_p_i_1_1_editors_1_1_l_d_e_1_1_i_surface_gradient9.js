var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient9 =
[
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient9.xhtml#a89ed2bd62c5751739840e6ba53b12d7b", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient9.xhtml#a8ae1ba6f999b9c2c07d41743a95f9fc1", null ],
    [ "X_Tangent", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient9.xhtml#ae939d823fe57944be1bb3ea62e21c938", null ],
    [ "X_TangentCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient9.xhtml#ae5b973126dd3d49ccecdf768ce8829be", null ],
    [ "Y_Tangent", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient9.xhtml#a3706146a030b1deb27e09acda96762e5", null ],
    [ "Y_TangentCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient9.xhtml#a23911d81ef6e572d24d686f9d756f3ea", null ]
];