var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1 =
[
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1.xhtml#a2f2a58365254d9439c9a3e99f91bfe14", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1.xhtml#aee694386a05dbdbb825811d7e8d917c9", null ],
    [ "n0", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1.xhtml#aeed0d8675166a046af303e2ea5f215ea", null ],
    [ "n0Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1.xhtml#a3c3319e10e90acf0edd90baea579b862", null ],
    [ "Nr1", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1.xhtml#a8f54506c8211a7315c1dc03e9f240b78", null ],
    [ "Nr1Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1.xhtml#ae20bfb33388c207d849b4676b320a1de", null ],
    [ "Nr2", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1.xhtml#a9c4372b0eb786c13e9115d505d87593a", null ],
    [ "Nr2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient1.xhtml#a95d1946c008cebc21f3a92bfab0d179a", null ]
];