var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform =
[
    [ "ConvertAnglesToRotationMatrix", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#aba7b0bbed58f6511427f745a0d90b7b8", null ],
    [ "Disable", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#aaedd66f8af60301b8659809c43e8d91f", null ],
    [ "Enable", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a3957edb8cc18a7ab042c9c2cde94d028", null ],
    [ "IsInDefaultFrameOfReference", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a7618c8107cadd64fff752f02c025a321", null ],
    [ "ResetToDefaultFrameOfReference", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a6b35ba9aacb2dfc5ccf9ca9468ace0e4", null ],
    [ "SetDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#acab65464daf35ab37a3ccc27812e5083", null ],
    [ "SetRotationMatrix", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a85d54f8b342bf3f0eb347b55eba912bc", null ],
    [ "SetTransformValues", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a4e59d1fed84fe06096cf6d129a0100eb", null ],
    [ "SetTransformValuesWithAngles", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a30f7267f2d03a49a272dc0de6c63d5c1", null ],
    [ "Decenters", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a252b84cda6d2145a2a0f3038c75fbff2", null ],
    [ "IsEnabled", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a94ac311838d7034c6cf6470f0eaf44dc", null ],
    [ "Rotations", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a4a35e415ed179e72f8dafd0930df9ecf", null ],
    [ "SurfaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a9f98a5f13162688b8558bd2df8f17971", null ],
    [ "Transform", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___coordinate_transform.xhtml#a66b85f2d360e3e3c2a6c06c7e00532ea", null ]
];