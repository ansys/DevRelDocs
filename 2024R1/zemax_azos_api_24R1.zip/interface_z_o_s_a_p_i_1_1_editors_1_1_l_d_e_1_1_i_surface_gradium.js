var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium =
[
    [ "BouleThickness", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a8d3a3ec4e313b5695504ccbdcb59dec0", null ],
    [ "BouleThicknessCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a93096182ad7c46fdae2a3a8e3d756919", null ],
    [ "Capping", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a0436121b68087d1a1b17fdd41f01e02e", null ],
    [ "CappingCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a4a1285a4fd9a48f28550ba93d33104bf", null ],
    [ "Dec_x", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a90a264108cd598d6a5656f19a763fdd2", null ],
    [ "Dec_x_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#abf6a2e31fe120b8a5716b8afc7f5ff68", null ],
    [ "Dec_y", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a3c7066443202eeb973f75f6f94acef2b", null ],
    [ "Dec_y_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a67cc9be022f0fc9b99f2bb388a905fa0", null ],
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a119c85cdd2c03adf23a7f3b40d6c1a83", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a3ab70f8575ffe6cd8f353a6e54bd64b3", null ],
    [ "DeltaZ", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a9a83c01937672e8d3745be2604b0d3a6", null ],
    [ "DeltaZCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a0500d03122a59225d5a5f3b391175bf7", null ],
    [ "Ref_n", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a530c276ea5e6e10a003625d0f09e71d0", null ],
    [ "Ref_n_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a82d4f82b1482b02e5d4fa599ed655b06", null ],
    [ "Tilt_x", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#ac9a8ab0afcbc339b8fea01ea59476248", null ],
    [ "Tilt_x_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a0805aea4296eccbd3a9981511ca834a4", null ],
    [ "Tilt_y", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#a6f7eb27f4533adb06c817d5e3942d09a", null ],
    [ "Tilt_y_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradium.xhtml#ab34659b75ccf6b598b45acdbb9f56963", null ]
];