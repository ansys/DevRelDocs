var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_order_terms =
[
    [ "GetNthOrderTerm", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_order_terms.xhtml#aa040897c9bca0fc8acc024ad0a1db949", null ],
    [ "NthOrderTermCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_order_terms.xhtml#a35780882f574ea4dcde366b40658c727", null ],
    [ "SetNthOrderTerm", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_order_terms.xhtml#ae1dfa08ea91ac4d15db77480c940398e", null ]
];