var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_deformation =
[
    [ "DX", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_deformation.xhtml#a61276c80dc247b42819d9b8e0a13c83c", null ],
    [ "DY", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_deformation.xhtml#a4735c43008c96ef5adadb0ee4188abb0", null ],
    [ "DZ", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_deformation.xhtml#a865321c47482257f4ab4b07ef0d03cb7", null ],
    [ "X", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_deformation.xhtml#a31adae40c9eccd594d3d598e6a8140c9", null ],
    [ "Y", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_deformation.xhtml#a30aceb0f81c4be77e6cf0a529737724a", null ],
    [ "Z", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_deformation.xhtml#afba67e09095699d5e9ceb5f22d5bc3ca", null ]
];