var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings =
[
    [ "GetFileNames1", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings.xhtml#a2736902f3b94699608a7e350e31d4122", null ],
    [ "GetFileNames2", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings.xhtml#a53f2f8c252157a21760ebe703424677b", null ],
    [ "FileName1", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings.xhtml#ad361d032b227c7e00e2343dee3d224bc", null ],
    [ "FileName2", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings.xhtml#a214499477b6e25d3fa4e7b59b2c6c78e", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings.xhtml#a0e3b6f7909b934ba676aadda5da43410", null ],
    [ "RequiresFile1", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings.xhtml#acdf692e8dc25835fa1bf8d320418b2e0", null ],
    [ "RequiresFile2", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings.xhtml#a0dd21deb96d21708584afef0ae8dcfe4", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_type_settings.xhtml#a56b153a3629dd8500a9f95a325a8e9d3", null ]
];