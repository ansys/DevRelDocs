var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_scattering_data =
[
    [ "ChangeScatteringTypeSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_scattering_data.xhtml#ad450aa4d2c2eb16777cac1a95e26253c", null ],
    [ "CreateScatteringTypeSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_scattering_data.xhtml#ae6fe16458bb6f95a96ed43c21ebed233", null ],
    [ "CurrentType", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_scattering_data.xhtml#a0c06959f30371c05111dd3f2ae089532", null ],
    [ "CurrentTypeSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_scattering_data.xhtml#aa38cd4f0a8b4b5c9149f2dcb486247d5", null ]
];