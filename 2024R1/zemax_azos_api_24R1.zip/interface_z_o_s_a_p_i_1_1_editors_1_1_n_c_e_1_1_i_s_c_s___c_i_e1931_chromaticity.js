var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_chromaticity =
[
    [ "cx", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_chromaticity.xhtml#a6a496f76e712052c48dfb3070c1c8461", null ],
    [ "cy", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_chromaticity.xhtml#ab2cc6bf73a3a58145d518da52a5e87f2", null ],
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_chromaticity.xhtml#a50f73b0690180f914c6d4a1c1b3cd2c2", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_chromaticity.xhtml#a0bdd9891d52aeddcf39972413c5847db", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_chromaticity.xhtml#a539059eb5e769cd82a440d72a3c3d9d4", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_chromaticity.xhtml#aeffe32dd4dd87f2e72dfbc53c612d111", null ]
];