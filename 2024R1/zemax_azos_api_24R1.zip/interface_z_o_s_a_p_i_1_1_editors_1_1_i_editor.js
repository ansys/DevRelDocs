var interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor =
[
    [ "AddRow", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#a7a4b1663300efa48b1af005b71c5e6cc", null ],
    [ "DeleteAllRows", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#a6a214f428fde561b408723563cb63d16", null ],
    [ "DeleteRowAt", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#acc52182a5f56f3559c49af15351b9d7b", null ],
    [ "DeleteRowsAt", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#a4b0d2919682f61f9bbfc2b1f4a8684ee", null ],
    [ "GetRowAt", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#a55d7953b4bcf937ccc91a22e5ed1b64d", null ],
    [ "HideEditor", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#aa27886e8ce393b3e7f3da903ad952ddd", null ],
    [ "InsertRowAt", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#a528b4a4c89b73c97f8fb0440be176147", null ],
    [ "ShowEditor", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#a9971ba810c39993f1693405663d109a3", null ],
    [ "Editor", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#afa3443875a539cc24e6fab36d37809a8", null ],
    [ "MaxColumn", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#ac48c64eb7297f62d3687762a66f8277d", null ],
    [ "MinColumn", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#a00feb76f3b9e070a94ed7475b351768b", null ],
    [ "NumberOfRows", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor.xhtml#a28a0d35664035366c10f6b0a3b5003c2", null ]
];