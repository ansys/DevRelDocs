var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection =
[
    [ "GetSelectedSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#a90f7005e2fa7bca9fa4e11a1c5e8beec", null ],
    [ "SetSelectedSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#a801f359b2bc2891a0ceef68454ea6029", null ],
    [ "UseImageSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#a3945f11fad29ce02fa145ce480fa4c3f", null ],
    [ "UseObjectSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#a012a49a9303efe597836e1ef6db8e21d", null ],
    [ "UseStopSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#a74d7d64b0ac7754c9ab29816ff82dc93", null ],
    [ "FirstAllowedSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#af934bbcf7b063011297d14690736b58f", null ],
    [ "ImageSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#a282fbae816bd990428d95ee4c27981a1", null ],
    [ "LastAllowedSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#a8e10f4a5f1406c07c7e041e31939a269", null ],
    [ "StopSurface", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_surface_selection.xhtml#ab701b7d143b66846f11dabbabb9d3151", null ]
];