var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result =
[
    [ "Detector_X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#aa241d185fc0e7705bfb77bcc54d84ab0", null ],
    [ "Detector_Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a89d2b7a18010a3d8b68610f2d96d534f", null ],
    [ "Detector_Z", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a8f845d6e5c922054dc2a9f616f178ae8", null ],
    [ "GeoSpotSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#aa553dc00ba5bfc451c89927ceaecc0a5", null ],
    [ "L", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#ab75fbc05c4adef6b5f4518822c645ac5", null ],
    [ "M", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a50588cd0cfee118fe98fca92dd651e59", null ],
    [ "N", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a6efab6c88623f4a042bf0c6a536e9234", null ],
    [ "RefCoord_X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a64e6d02acf3d2a939b7cb08ff683cede", null ],
    [ "RefCoord_Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a98f623fa8ed89b88541ecbc0d7376426", null ],
    [ "RMSSpot_X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#aa3fd921ce200d65b28c725677ef73ea8", null ],
    [ "RMSSpot_Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a64b99e27c4e830cf9f1e591637467a02", null ],
    [ "RMSSpotSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a440bcbf04e72ace2fbbb671168ced785", null ],
    [ "X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a166e06e98a66b3532d191f48635ec1d6", null ],
    [ "Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a2b974a21018223fa5266009af691343d", null ],
    [ "Z", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result.xhtml#a51f1526c40b11d20698c1330406d59dd", null ]
];