var interface_z_o_s_a_p_i_1_1_i_s_t_a_r_subsystem =
[
    [ "DoManualUpdate", "interface_z_o_s_a_p_i_1_1_i_s_t_a_r_subsystem.xhtml#a078e6290614d13520f7f074eaf43a2b4", null ],
    [ "Materials", "interface_z_o_s_a_p_i_1_1_i_s_t_a_r_subsystem.xhtml#a721cce9b009fef6ad11b15a3f0d39ea6", null ],
    [ "UpdateMode", "interface_z_o_s_a_p_i_1_1_i_s_t_a_r_subsystem.xhtml#ae78c78eb74dbeabfd3430efa5099b4ca", null ]
];