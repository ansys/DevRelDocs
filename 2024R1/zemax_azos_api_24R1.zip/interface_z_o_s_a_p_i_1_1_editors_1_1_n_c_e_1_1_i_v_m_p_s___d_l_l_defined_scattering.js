var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering =
[
    [ "GetAvailableDLLs", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#aa26819220a2eb74a5f4fb35ae620bcde", null ],
    [ "GetParameterName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#a581ce3691e008b485cf7ec0465351703", null ],
    [ "GetParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#ad7e1f78315683429b90137de83cf863f", null ],
    [ "SetParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#a222d77d6ba3699acd2490eba2e040728", null ],
    [ "Angle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#aac8962d9a4c8c2d7da75e7b40b7099a5", null ],
    [ "AngleRequired", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#adede94df322780757494086077423ac9", null ],
    [ "DLL", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#aa1ea14dbc9bf83ab0590c5baa78679a6", null ],
    [ "MeanPath", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#a33a7e84e5de8ae8b54c18fc7d6cf44c9", null ],
    [ "MeanPathRequired", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#a23b6302519ab8dbbad8078ab7c6beca6", null ],
    [ "NumberOfParameters", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_v_m_p_s___d_l_l_defined_scattering.xhtml#aaee61e7e66273c56accf49ef2d908590", null ]
];