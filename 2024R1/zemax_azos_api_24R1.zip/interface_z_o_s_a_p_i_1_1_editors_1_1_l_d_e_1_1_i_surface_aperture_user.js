var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_user =
[
    [ "GetAvailableFiles", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_user.xhtml#ab340bd2582f66cf8c97f8360a40a6899", null ],
    [ "ApertureFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_user.xhtml#aebee2af4d64658776c66cb8a7a502404", null ],
    [ "ApertureXDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_user.xhtml#a1434d396c4fcaac76fa17d363ea73170", null ],
    [ "ApertureYDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_user.xhtml#ae78e686cde72796d07bd66c51dba277b", null ],
    [ "UDASCale", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_user.xhtml#aaa6a57248f74c9309f7629db8eff1518", null ]
];