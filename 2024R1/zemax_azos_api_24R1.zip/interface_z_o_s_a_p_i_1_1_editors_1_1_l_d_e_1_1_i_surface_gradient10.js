var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10 =
[
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a021af66017ef7868ab328bdb3f7dfea1", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a74c82aa1bfa05b6acfe094dd8356880e", null ],
    [ "n0", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a360b5dedad05c38c16e85d728d0884f6", null ],
    [ "n0Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#af44ab601be05cdc0dd48708a9c0ad54e", null ],
    [ "Ny1", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a5c77bfb3a3e2e77bb799760e79283143", null ],
    [ "Ny1Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#aebe1b44ad9795190b84699c87ee78cb4", null ],
    [ "Ny2", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a3bfaa4cb067851301e14da3296bdd7f8", null ],
    [ "Ny2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#aa359e8272a09908386174acffcb86a44", null ],
    [ "Ny3", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#af2eef1a772927ced454c1095c39c15e6", null ],
    [ "Ny3Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a86291637993b46a292fe080e43a65f68", null ],
    [ "Ny4", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a773ce254fa84da69e994deb056db3135", null ],
    [ "Ny4Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#ad7dde2d5f0b16ed19ac85de566da5919", null ],
    [ "Ny5", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a6bdde43079441e97cb2c50b0acdc1b5d", null ],
    [ "Ny5Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a79d4a171f09e6833ed60c3996610302d", null ],
    [ "Ny6", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#ad7f55698f5fe94f262344a8e4210ceac", null ],
    [ "Ny6Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient10.xhtml#a33e354b2a6a8fa34cc5cde6d9996ec9c", null ]
];