var interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_editor =
[
    [ "Decimals", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_editor.xhtml#a092ad5430fa9992f9b5d144ad4ea2530", null ],
    [ "ExponentialAbove", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_editor.xhtml#a886b2b1c343c8a4cd25fd70ea7036596", null ],
    [ "ExponentialBelow", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_editor.xhtml#a1c8295758e2c86134699310c995a2cbd", null ]
];