var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_edge_thickness =
[
    [ "RadialHeight", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_edge_thickness.xhtml#a56477050f0133c5e374b68dd1a6be150", null ],
    [ "Thickness", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_edge_thickness.xhtml#ab2c463817268f446995df8cd69f8e457", null ]
];