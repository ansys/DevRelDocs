var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field =
[
    [ "FieldDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#adf1869e455a2848e0418e452a7812de6", null ],
    [ "Freq_1", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#a90f7cd8b7c0d2a9bc0bd13c7ac1a8b5a", null ],
    [ "Freq_2", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#a00378a25c4635ada53bf5f41e510f1ea", null ],
    [ "Freq_3", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#ac14a206c5e480f2d99ae07f28de1766f", null ],
    [ "Freq_4", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#aa93cf2dff649e4eaa39037f598edf47e", null ],
    [ "Freq_5", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#af26332f170dc4202aa8856f2e9d1cfeb", null ],
    [ "Freq_6", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#a6adae058481b2e704cb6bec833f84632", null ],
    [ "RemoveVignetting", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#ae0c6f656054b81ff829aeaae62324f60", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#a457529194f4d981d1237c99b4d76c209", null ],
    [ "ScanType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#ab836469dfa6405288bd5986285343cd2", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#a32ab26a59bbbd80926b2291bbff7b89b", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#a1ce5722ebfef824f8b0575569db65657", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtfvs_field.xhtml#adceeb1cd66a406baba84baa86ebc3ec2", null ]
];