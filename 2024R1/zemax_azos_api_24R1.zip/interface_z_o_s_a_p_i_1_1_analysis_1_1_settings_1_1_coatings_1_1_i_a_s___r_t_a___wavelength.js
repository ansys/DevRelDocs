var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength =
[
    [ "Angle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#adf67f02414ff6a560e8957c7d11601f4", null ],
    [ "FaceNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#a21c5dd2100d2d9282163eb99dff4abd7", null ],
    [ "MaxWavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#a7fccee4e9688aee4043ad924fddbdc4b", null ],
    [ "MaxY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#a06512f0657346cec0141551a16a6a166", null ],
    [ "MinWavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#a9b841ea84eda199668770134a889a1d0", null ],
    [ "MinY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#a1b7ce5aa0700bd8377745187be51255f", null ],
    [ "ObjectNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#a38125fc6e178665ef8e0b387d210077a", null ],
    [ "ReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#af8c09273878d68028519b5806a1f59fe", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___wavelength.xhtml#af0e45b91cfb84d1024a642a56caabd18", null ]
];