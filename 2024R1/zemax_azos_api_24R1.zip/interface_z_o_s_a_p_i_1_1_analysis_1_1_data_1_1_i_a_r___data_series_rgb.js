var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb =
[
    [ "FillYValues", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#a4c7de550e9ff746e0b4dba7aa375e08a", null ],
    [ "GetYPoint", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#ad385cd9eab0730cf4620e01234730b7d", null ],
    [ "Description", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#afc834a826d8b65335ea87fd490c42553", null ],
    [ "NumberOfRows", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#a28c4a9a2f6f95a786f943b07a7122925", null ],
    [ "NumSeries", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#a265b04180e1c510e976db8e38717f4ed", null ],
    [ "SeriesLabels", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#a8d1a84dbdf848af9ddca63f45edc6c66", null ],
    [ "XData", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#a88ba2240b8cf2cee6c986b7a922d2cd3", null ],
    [ "XLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#acbc1188a5c64f2418cbeb20007fd97fd", null ],
    [ "YVals", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_series_rgb.xhtml#a4abf5f25535915ebe16f1e36589407ff", null ]
];