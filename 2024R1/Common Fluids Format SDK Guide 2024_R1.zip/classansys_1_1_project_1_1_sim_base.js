var classansys_1_1_project_1_1_sim_base =
[
    [ "copyInput", "classansys_1_1_project_1_1_sim_base.xhtml#aeb5ffe7267a10b465dc8c2c825195074", null ],
    [ "getCase", "classansys_1_1_project_1_1_sim_base.xhtml#a1fb985412b84a850718aa3aae6e03147", null ],
    [ "getInputByType", "classansys_1_1_project_1_1_sim_base.xhtml#a7eb8d0c48e61b171014c593fb63e85c6", null ],
    [ "getInputs", "classansys_1_1_project_1_1_sim_base.xhtml#a2d532a01d1f99cb76ec85e8f4908d932", null ],
    [ "getInputsByType", "classansys_1_1_project_1_1_sim_base.xhtml#abc3d5315d8f3a3cff217c2112b4581a1", null ],
    [ "getIterator", "classansys_1_1_project_1_1_sim_base.xhtml#a16f3c24244ab0ec6587d945785c7718d", null ],
    [ "getMainDataType", "classansys_1_1_project_1_1_sim_base.xhtml#a743bc36e30200c87603dedaafe1d969d", null ],
    [ "getMeta", "classansys_1_1_project_1_1_sim_base.xhtml#a067d578e43cf6085623921adb816d5f4", null ],
    [ "getMeta", "classansys_1_1_project_1_1_sim_base.xhtml#af6e6bd9bee7a4fe152ff2ac2f51ad8c9", null ],
    [ "getName", "classansys_1_1_project_1_1_sim_base.xhtml#a8aef8314dfc33a8d25e3963fa3fd07ba", null ],
    [ "setCase", "classansys_1_1_project_1_1_sim_base.xhtml#a2312d3c69d5f32a7c76bc567c942e945", null ],
    [ "setInput", "classansys_1_1_project_1_1_sim_base.xhtml#a0b6fee750eeb02e8068640758c6d8b0d", null ],
    [ "setMainDataType", "classansys_1_1_project_1_1_sim_base.xhtml#ac44fe199d4f2c2c7aa8be5d22353740a", null ]
];