var classansys_1_1_cff_file_i_o =
[
    [ "getDataClasses", "classansys_1_1_cff_file_i_o.xhtml#a0ee7191bc49e9b689362e2195bacc3f4", null ],
    [ "getFile", "classansys_1_1_cff_file_i_o.xhtml#a77ef49cc6834d7f441c61e0128b5dac7", null ],
    [ "getFileVersion", "classansys_1_1_cff_file_i_o.xhtml#a00f3a9cd110d836abebdbafd1516cc6f", null ],
    [ "getFileVersion", "classansys_1_1_cff_file_i_o.xhtml#a548f6a285539d9d571ded617ba1a8041", null ],
    [ "setFile", "classansys_1_1_cff_file_i_o.xhtml#a5e700a7a3cb529ab48fb759e339c85e7", null ],
    [ "setFileVersion", "classansys_1_1_cff_file_i_o.xhtml#abaebab966110531b473dcdb219134822", null ]
];