var classansys_1_1_project_1_1_result =
[
    [ "Result", "classansys_1_1_project_1_1_result.xhtml#ab9f32346b8cee0bf1cdde298cd0df707", null ],
    [ "getCase", "classansys_1_1_project_1_1_result.xhtml#ae4d6f08c396ff7a225d91fc21b6dbf6d", null ],
    [ "getInputByType", "classansys_1_1_project_1_1_result.xhtml#a297e3c3b13ced95b7ce971478c9d94f7", null ],
    [ "getIterator", "classansys_1_1_project_1_1_result.xhtml#acfea7c7aac843ba7446fbc7702a00462", null ],
    [ "getValue", "classansys_1_1_project_1_1_result.xhtml#a6ffc6355c8a3f4acb1b06248a3dc77d3", null ],
    [ "getValueDouble", "classansys_1_1_project_1_1_result.xhtml#a3615dcd65b532b7a0f5c1dae754879fa", null ],
    [ "getValueInt", "classansys_1_1_project_1_1_result.xhtml#ab5abd5185c32099ac41e36a69dd81120", null ],
    [ "getValueIter", "classansys_1_1_project_1_1_result.xhtml#aa03b8fb6209b15868a24500fbd3363ab", null ],
    [ "getValueType", "classansys_1_1_project_1_1_result.xhtml#ac0a7814e7e2bc58e2c81710c01a74e8c", null ],
    [ "hasValue", "classansys_1_1_project_1_1_result.xhtml#a202246d89e8ed5f92f93282046dca7d2", null ],
    [ "isValid", "classansys_1_1_project_1_1_result.xhtml#a1bcecc63b00d62616e954e55dbbd0b5d", null ],
    [ "ok", "classansys_1_1_project_1_1_result.xhtml#a7ca38918f62e55d5e32c44b53045a00f", null ],
    [ "setCase", "classansys_1_1_project_1_1_result.xhtml#a4c7ecb1ac172098dda315389ac1f45a7", null ],
    [ "setValue", "classansys_1_1_project_1_1_result.xhtml#a09235debe70f3b375cbb97d768ba1237", null ],
    [ "setValueDouble", "classansys_1_1_project_1_1_result.xhtml#aebd750fd5bcb7593d90089716c2e8145", null ],
    [ "setValueInt", "classansys_1_1_project_1_1_result.xhtml#ac1d2a31f02294a74f2b41f30419ad099", null ]
];