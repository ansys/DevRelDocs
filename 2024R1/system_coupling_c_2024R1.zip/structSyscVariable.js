var structSyscVariable =
[
    [ "dataType", "structSyscVariable.xhtml#aedd58bab04a4c0036cd07cef9016a91c", null ],
    [ "displayName", "structSyscVariable.xhtml#a04451c3da4978114e5aba6bcf2713731", null ],
    [ "isExtensive", "structSyscVariable.xhtml#aed5ddca8dd956e1b4935aa69c323e011", null ],
    [ "location", "structSyscVariable.xhtml#a417605c130a691478393fbb05840a5ab", null ],
    [ "name", "structSyscVariable.xhtml#a2eba6c9ae1b937d16229bb14abfd0b8c", null ],
    [ "quantityType", "structSyscVariable.xhtml#ac986a066454132f9f70180349586ab8b", null ],
    [ "tensorType", "structSyscVariable.xhtml#a0293955653368e2f48d36587d4d90ca8", null ]
];