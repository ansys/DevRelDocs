var group__properties =
[
    [ "PropertyBase", "struct_property_base.xhtml", [
      [ "__str__", "struct_property_base.xhtml#a3031d648b73235d11d64df95db3d84ce", null ]
    ] ],
    [ "PropertyList", "class_property_list.xhtml", [
      [ "const_iterator", "class_property_list.xhtml#a45e7948705e5aea09a975bbdbfe7b43a", null ],
      [ "iterator", "class_property_list.xhtml#a6c030606fde1400a3a6447becc40e11a", null ],
      [ "ListType", "class_property_list.xhtml#a53a5ff304175a7f235ac2d779a11eb98", null ],
      [ "value_type", "class_property_list.xhtml#ad78eedca7dc9da8184112de9199d246b", null ],
      [ "PropertyList", "class_property_list.xhtml#ae767ef0dd7c2d00d2860c51bdee20974", null ],
      [ "PropertyList", "class_property_list.xhtml#a5cd444e27b7c7c4ded55ea3970ac271c", null ],
      [ "__str__", "class_property_list.xhtml#a3031d648b73235d11d64df95db3d84ce", null ],
      [ "loadJson", "class_property_list.xhtml#ae5700ae63985e3e6b30cb716ddb5fdd0", null ],
      [ "operator=", "class_property_list.xhtml#a88fb4b13ffd84df44d54cff0a083f64f", null ],
      [ "push_back", "class_property_list.xhtml#a32d36491abec383e98bf94a25b87bb28", null ],
      [ "saveJson", "class_property_list.xhtml#ab4587af0230811304c91f1c0aaa1c9ce", null ],
      [ "write", "class_property_list.xhtml#a5246641e855e709d801786e7514c486a", null ]
    ] ],
    [ "PropertyUserBase", "class_property_user_base.xhtml", [
      [ "addProperty", "class_property_user_base.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
      [ "getProperties", "class_property_user_base.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
      [ "transferProperties", "class_property_user_base.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ],
      [ "boost::serialization::access", "class_property_user_base.xhtml#ac98d07dd8f7b70e16ccb9a01abf56b9c", null ]
    ] ],
    [ "ModelComplexity", "group__properties.xhtml#ga7034fdb363cebc76924b41fe385048be", null ]
];