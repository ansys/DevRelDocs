var structansys_1_1dpf_1_1PinDefinition =
[
    [ "PinDefinition", "structansys_1_1dpf_1_1PinDefinition.xhtml#a7f96a3b401928fd5b7d29728869c2188", null ],
    [ "setAcceptedTypes", "structansys_1_1dpf_1_1PinDefinition.xhtml#a99d14d58f90782a06a872c88d2fd6953", null ],
    [ "setDoc", "structansys_1_1dpf_1_1PinDefinition.xhtml#a58cc9d8a539bed16ae22b5b2da90aaf5", null ],
    [ "setEllipsis", "structansys_1_1dpf_1_1PinDefinition.xhtml#acbb3bc62e8c5e128db45a28c9ba21d57", null ],
    [ "setName", "structansys_1_1dpf_1_1PinDefinition.xhtml#a9973d2c279a5ce1db63556c815dcb5b7", null ],
    [ "setOptional", "structansys_1_1dpf_1_1PinDefinition.xhtml#a16aa7c1924a66ce4d73e72b8ceeb8a57", null ],
    [ "setPosition", "structansys_1_1dpf_1_1PinDefinition.xhtml#a65b3f392b270b9cf3ef1160764b49c82", null ],
    [ "documentation", "structansys_1_1dpf_1_1PinDefinition.xhtml#a280231283314d4275889e5b1871fbde0", null ],
    [ "name", "structansys_1_1dpf_1_1PinDefinition.xhtml#a2dd76d015c235c3f89e7d223dde5860c", null ],
    [ "position", "structansys_1_1dpf_1_1PinDefinition.xhtml#ac3a15b557922e20c2351e4b91c1b8fa1", null ]
];