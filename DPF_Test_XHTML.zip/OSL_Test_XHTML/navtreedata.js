/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "Concepts and Terminology", "md_cpp_doc_02_Concepts.xhtml", null ],
    [ "Ways of Using DPF", "md_cpp_doc_03_Ways_of_Using.xhtml", null ],
    [ "Using DPF: Step by Step", "md_cpp_doc_05_Using_DPF.xhtml", null ],
    [ "Debugging DPF", "md_cpp_doc_06_Debugging_DPF.xhtml", null ],
    [ "DPF XML Files", "md_cpp_doc_07_DPF_XML_Files.xhtml", null ],
    [ "Operators", "^https://dpf.docs.pyansys.com/operator_reference.html", null ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Examples", "examples.xhtml", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"CompleteRST_8cpp-example.xhtml",
"classansys_1_1dpf_1_1ExternalData.xhtml",
"classansys_1_1dpf_1_1GenericSupport.xhtml#ab69289ea19752bb26eff730f73269ede",
"classansys_1_1dpf_1_1Model.xhtml#abadaeac1d698448632bc92df349f0ed9",
"classansys_1_1dpf_1_1OperatorConfig.xhtml",
"classansys_1_1dpf_1_1PropertyField.xhtml#ad7e142a83fd4138694a80f1a36bb778a",
"classansys_1_1dpf_1_1ScopingsContainer.xhtml#a840c89a1ed4500527461ed55d4e323e4",
"classansys_1_1dpf_1_1Workflow.xhtml#a3a223ef1c0200cc16ac1434ef938efca",
"classansys_1_1dpf_1_1core.xhtml#a768caf3bdc514ba3469584ea6da7ce78"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';