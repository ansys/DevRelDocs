var struct_convert_to_element =
[
    [ "ConvertToElement", "struct_convert_to_element.xhtml#a740eaf064670e34f5375dae5d079dc66", null ],
    [ "check", "struct_convert_to_element.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "struct_convert_to_element.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "compute", "struct_convert_to_element.xhtml#a2ee6c389c27f8cb563b6b1aa31f6bf17", null ],
    [ "data", "struct_convert_to_element.xhtml#aff21fffab499ea652443206d66e1a9bb", null ],
    [ "new_quantity_idents", "struct_convert_to_element.xhtml#a30b1bcf63b9bdc707fea30bd96d70447", null ],
    [ "quantity_idents", "struct_convert_to_element.xhtml#aced57c746ae1d69d2fd56872fa1768bf", null ]
];