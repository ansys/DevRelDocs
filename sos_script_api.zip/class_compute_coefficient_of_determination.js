var class_compute_coefficient_of_determination =
[
    [ "ComputeCoefficientOfDetermination", "class_compute_coefficient_of_determination.xhtml#af5745209a41f6d94b036225fa56771e8", null ],
    [ "check", "class_compute_coefficient_of_determination.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "class_compute_coefficient_of_determination.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "adjusted", "class_compute_coefficient_of_determination.xhtml#ac27cc4bbf7f11e28f3c749e0aa61ed5b", null ],
    [ "field_data", "class_compute_coefficient_of_determination.xhtml#af22724fd9c1e0dd42ec296e4784b9df8", null ],
    [ "field_quantity_idents", "class_compute_coefficient_of_determination.xhtml#ab01db6dea146fd2a35511af297363e7b", null ],
    [ "new_design_idents", "class_compute_coefficient_of_determination.xhtml#a92a339e93315b87782ce1744408c370d", null ],
    [ "new_quantity_idents", "class_compute_coefficient_of_determination.xhtml#a30b1bcf63b9bdc707fea30bd96d70447", null ],
    [ "overwrite_existing", "class_compute_coefficient_of_determination.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "scalar_data", "class_compute_coefficient_of_determination.xhtml#a0c1c80374ba4d28153ed219819d24612", null ],
    [ "scalar_quantity_idents", "class_compute_coefficient_of_determination.xhtml#aeff6fae62a2847852dc0cc49fa48d31d", null ]
];