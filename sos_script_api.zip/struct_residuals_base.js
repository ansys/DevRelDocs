var struct_residuals_base =
[
    [ "adjustmentCoefficient", "struct_residuals_base.xhtml#a87fe2546ad406551bfb14661eb27b183", null ],
    [ "adjustmentCoefficientRef", "struct_residuals_base.xhtml#acafb986adcf3931cf8fb5bd60fbaee5b", null ],
    [ "approximationValues", "struct_residuals_base.xhtml#ae88060171492f9cde2caa03a1d7d8673", null ],
    [ "approximationValuesRef", "struct_residuals_base.xhtml#a305838b4a859164ef4326c672a4740f4", null ],
    [ "crossValidationValues", "struct_residuals_base.xhtml#af00a7e4b9360ddad6cb2193202c801b4", null ],
    [ "crossValidationValuesRef", "struct_residuals_base.xhtml#a43e5fabbaef8c80a34ba7c6634cf9a3a", null ],
    [ "originalValues", "struct_residuals_base.xhtml#a9389a044beed6f6bd43ad9e31e8262c3", null ],
    [ "originalValuesRef", "struct_residuals_base.xhtml#a4744f846fc5021b1de3165c0021c57c6", null ],
    [ "serialize", "struct_residuals_base.xhtml#aaa3a4f99152c0c2dce6c8794c9b1ee49", null ]
];