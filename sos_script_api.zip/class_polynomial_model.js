var class_polynomial_model =
[
    [ "PolynomialModel", "class_polynomial_model.xhtml#aa47bd2850cda208ef8a9064b03e082a9", null ],
    [ "PolynomialModel", "class_polynomial_model.xhtml#aa0ccc82f84ceeed4b03f5eca8f2ca13d", null ],
    [ "PolynomialModel", "class_polynomial_model.xhtml#af7fdc49422192c85d4d69430655b9890", null ],
    [ "addProperty", "class_polynomial_model.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "evaluate", "class_polynomial_model.xhtml#a5ec7821e9b8c1aaa6c43dc5ca1263f2f", null ],
    [ "getProperties", "class_polynomial_model.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "operator=", "class_polynomial_model.xhtml#a137935f0ff0edbfcdeb238f1ea05f514", null ],
    [ "transferProperties", "class_polynomial_model.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ]
];