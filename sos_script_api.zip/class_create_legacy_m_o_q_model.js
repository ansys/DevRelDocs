var class_create_legacy_m_o_q_model =
[
    [ "CreateLegacyMOQModel", "class_create_legacy_m_o_q_model.xhtml#a604dd8fac349f4031c8e7bcac66ed2f6", null ],
    [ "CreateLegacyMOQModel", "class_create_legacy_m_o_q_model.xhtml#af974357aa62311511d47c7b6c5f1a843", null ],
    [ "__str__", "class_create_legacy_m_o_q_model.xhtml#a3031d648b73235d11d64df95db3d84ce", null ],
    [ "addProperty", "class_create_legacy_m_o_q_model.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "compute", "class_create_legacy_m_o_q_model.xhtml#a428e7ba979340c651ec1372a3307e037", null ],
    [ "getProperties", "class_create_legacy_m_o_q_model.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "isValid", "class_create_legacy_m_o_q_model.xhtml#a1a42d0ff7ef3b9c17965ecc14310ed5d", null ],
    [ "operator=", "class_create_legacy_m_o_q_model.xhtml#a4be004a83db31e2a7b337478420ffe90", null ],
    [ "transferProperties", "class_create_legacy_m_o_q_model.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ],
    [ "altsupport", "class_create_legacy_m_o_q_model.xhtml#ad59f74edd2cee4b6ca041c129e4c0a3c", null ],
    [ "anisotropic", "class_create_legacy_m_o_q_model.xhtml#a8e6f94721593ca05c2be2ed71d594b5e", null ],
    [ "corrfilter", "class_create_legacy_m_o_q_model.xhtml#a2414b09a907b9949960cca3eb4483f90", null ],
    [ "generate_auto_settings", "class_create_legacy_m_o_q_model.xhtml#a335ea5c4234dde32c761eb073e7378ff", null ],
    [ "mincorr", "class_create_legacy_m_o_q_model.xhtml#a6800f9a034fa5e0bc4a6482700b6207e", null ],
    [ "mineval", "class_create_legacy_m_o_q_model.xhtml#aeccb5f3a3f09db023b55ab5326ae7ff0", null ],
    [ "reshuffles", "class_create_legacy_m_o_q_model.xhtml#aa5769b13c65c9e6ee1eae71b2b078b5f", null ],
    [ "tolerance", "class_create_legacy_m_o_q_model.xhtml#a593cce5ceb99745d936991573c146cf2", null ],
    [ "use_basic_fit", "class_create_legacy_m_o_q_model.xhtml#a1fa6b21ae19828191536d2c5fbeb83a2", null ]
];