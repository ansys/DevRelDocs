var struct_compute_nodal_coor_deviation =
[
    [ "ComputeNodalCoorDeviation", "struct_compute_nodal_coor_deviation.xhtml#ad46e4813869fcaa609a4898daa5143e0", null ],
    [ "check", "struct_compute_nodal_coor_deviation.xhtml#a0189742f0da37a369d017a2050a4719e", null ],
    [ "compute", "struct_compute_nodal_coor_deviation.xhtml#a26489e6c76f5d0965166ffe579ee857f", null ],
    [ "getDesignList", "struct_compute_nodal_coor_deviation.xhtml#aefe1c6e9dd58271755ca069fdf346207", null ],
    [ "associate_face_normals", "struct_compute_nodal_coor_deviation.xhtml#a7dbc119025a1e10805b8513bcacf800f", null ],
    [ "data", "struct_compute_nodal_coor_deviation.xhtml#aff21fffab499ea652443206d66e1a9bb", null ],
    [ "max_search_distance", "struct_compute_nodal_coor_deviation.xhtml#a84f171f159e44cda05468c390a26b117", null ],
    [ "new_normal_deviation_ident", "struct_compute_nodal_coor_deviation.xhtml#a0b9ec182265ba45241552ff7f16c00c5", null ],
    [ "new_x_deviation_ident", "struct_compute_nodal_coor_deviation.xhtml#ab520eea66858d526a07de90390e1848a", null ],
    [ "new_y_deviation_ident", "struct_compute_nodal_coor_deviation.xhtml#a379503396eb9accb822e19da8f4aebdd", null ],
    [ "new_z_deviation_ident", "struct_compute_nodal_coor_deviation.xhtml#aad269398b809e89e37bf0121f27b5a3c", null ],
    [ "number_sided_n2s_contact", "struct_compute_nodal_coor_deviation.xhtml#adf4bf7ef2a5f03a8fd33c34eb119744f", null ],
    [ "overwrite_existing", "struct_compute_nodal_coor_deviation.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "x_coor_ident", "struct_compute_nodal_coor_deviation.xhtml#a6825b5dc4ccdba6de65e45b3860e1c5c", null ],
    [ "y_coor_ident", "struct_compute_nodal_coor_deviation.xhtml#a6a8ddf0194439f51b9be18cb5d994dae", null ],
    [ "z_coor_ident", "struct_compute_nodal_coor_deviation.xhtml#a3a3fb9a43eb09e70eed52ee2486e5d32", null ]
];