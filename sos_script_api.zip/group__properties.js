var group__properties =
[
    [ "PropertyBase", "struct_property_base.xhtml", [
      [ "__str__", "struct_property_base.xhtml#a3031d648b73235d11d64df95db3d84ce", null ]
    ] ],
    [ "PropertyList", "class_property_list.xhtml", [
      [ "__str__", "class_property_list.xhtml#a3031d648b73235d11d64df95db3d84ce", null ],
      [ "loadJson", "class_property_list.xhtml#ae5700ae63985e3e6b30cb716ddb5fdd0", null ],
      [ "push_back", "class_property_list.xhtml#a32d36491abec383e98bf94a25b87bb28", null ],
      [ "saveJson", "class_property_list.xhtml#ab4587af0230811304c91f1c0aaa1c9ce", null ],
      [ "write", "class_property_list.xhtml#a5246641e855e709d801786e7514c486a", null ]
    ] ],
    [ "PropertyUserBase", "class_property_user_base.xhtml", [
      [ "addProperty", "class_property_user_base.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
      [ "getProperties", "class_property_user_base.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
      [ "transferProperties", "class_property_user_base.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ]
    ] ],
    [ "ModelComplexity", "group__properties.xhtml#ga7034fdb363cebc76924b41fe385048be", null ]
];