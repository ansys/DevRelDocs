var struct_cancel_base =
[
    [ "cancel", "struct_cancel_base.xhtml#ae34e24836f54808a79018854faec5383", null ],
    [ "isCancelled", "struct_cancel_base.xhtml#abf66400947187c9d1488661356df12f4", null ]
];