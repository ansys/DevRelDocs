var struct_training_plan_base =
[
    [ "getInputs", "struct_training_plan_base.xhtml#a6e262334d7e27b9f05121454531fa5b6", null ],
    [ "getMOPIdent", "struct_training_plan_base.xhtml#a5df8016765ccb017b2ff5778e3e81558", null ],
    [ "getOutputs", "struct_training_plan_base.xhtml#a8de106670ace9e349ee9c149741b8e44", null ],
    [ "getSampleUsageInSet", "struct_training_plan_base.xhtml#a1c4be324fc1e91c3039a49631f6e2cc9", null ],
    [ "getSampleUsageInSetRef", "struct_training_plan_base.xhtml#af67b70402c8a7610ce4a99c252f53681", null ],
    [ "inputImportance", "struct_training_plan_base.xhtml#ab9acd4287a8208fa9a32867cafaf8e46", null ],
    [ "inputImportanceInSubspace", "struct_training_plan_base.xhtml#a60399ab71c2fcf3a21c9a613997c4822", null ],
    [ "isValid", "struct_training_plan_base.xhtml#aed20b1ee85452a87a9e10f39077b94a3", null ],
    [ "numInputs", "struct_training_plan_base.xhtml#a5c973e14b896504b0522fc953bb3b2dc", null ],
    [ "numOutputs", "struct_training_plan_base.xhtml#aad28bd2bb818cf6c433e22e22768086c", null ],
    [ "numSamplesInSet", "struct_training_plan_base.xhtml#a0ef7e16a9a52c22ecb59f6148accae62", null ],
    [ "numSets", "struct_training_plan_base.xhtml#ad536b0ba37fa27e95a51c0aa3afc96da", null ],
    [ "numSubspaces", "struct_training_plan_base.xhtml#a44682836a8190246e4db84f997a003cc", null ],
    [ "numTestSamplesInSet", "struct_training_plan_base.xhtml#a88109fe981a2b192eb8e09a87ae563ed", null ],
    [ "numTrainingSamplesInSet", "struct_training_plan_base.xhtml#a13261fec66c7bbac8c07123619300275", null ],
    [ "output", "struct_training_plan_base.xhtml#a3e0dff9e7373d9800e8abe6a61af4c16", null ]
];