var struct_parameter =
[
    [ "load", "struct_parameter.xhtml#ae504199e2178abdd49fea50a135f9a2a", null ],
    [ "save", "struct_parameter.xhtml#a6ea2eacd9f701a26520d0a2b26463782", null ],
    [ "save", "struct_parameter.xhtml#a41136433d53167aa64a66be80945d814", null ],
    [ "save", "struct_parameter.xhtml#ab58ca861d04e5ae6e2545bbeab134ee8", null ]
];