var class_reconstruct_data =
[
    [ "enum_type", "class_reconstruct_data.xhtml#af7ca783694e51f78ef01ceb1e00104c5", [
      [ "STOCHASTIC", "class_reconstruct_data.xhtml#af7ca783694e51f78ef01ceb1e00104c5a2f408d13698dc4a90bca408d8aa29d8c", null ],
      [ "STOCHASTIC_AND_INTERPOLATE", "class_reconstruct_data.xhtml#af7ca783694e51f78ef01ceb1e00104c5a2a8c6ebc2793e96922bb7c43756aff20", null ]
    ] ],
    [ "ReconstructData", "class_reconstruct_data.xhtml#a36d283177fe59e0ad6c26925b488e5a7", null ],
    [ "check", "class_reconstruct_data.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "class_reconstruct_data.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "algorithm", "class_reconstruct_data.xhtml#a701921501ba32dc7a5be7e7a52265a97", null ],
    [ "element_data", "class_reconstruct_data.xhtml#a0a142faa1cc762466b884ad3c8979f3a", null ],
    [ "node_data", "class_reconstruct_data.xhtml#a4b3543f31398671628dd711c98a0d37e", null ],
    [ "overwrite_existing", "class_reconstruct_data.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "prefix", "class_reconstruct_data.xhtml#ab7b6fb49a3a178b1628690ad0f00927d", null ],
    [ "scalar_data", "class_reconstruct_data.xhtml#a0c1c80374ba4d28153ed219819d24612", null ]
];