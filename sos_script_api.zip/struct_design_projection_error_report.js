var struct_design_projection_error_report =
[
    [ "Ttuple", "struct_design_projection_error_report.xhtml#a037a9c935641da5a357eea605c341b9c", null ],
    [ "empty", "struct_design_projection_error_report.xhtml#a9625b002313a3fef67010c74415e5911", null ],
    [ "max", "struct_design_projection_error_report.xhtml#a4ec8b2c9bd8f4ce1fce8ebb65405349e", null ],
    [ "mean", "struct_design_projection_error_report.xhtml#a24ab11e80b31e5709581f93f1551be0b", null ],
    [ "min", "struct_design_projection_error_report.xhtml#aa1003bbf0546cfba3c2e3ee43505804d", null ],
    [ "range", "struct_design_projection_error_report.xhtml#af7c2770b787fbd7508e754e6ec0283a4", null ]
];