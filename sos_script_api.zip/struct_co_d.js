var struct_co_d =
[
    [ "CoD", "struct_co_d.xhtml#a1442ebff8492bb1572af5911d890aada", null ],
    [ "CoD", "struct_co_d.xhtml#ad74c3bc524398d07f21927db78b7b26f", null ],
    [ "error", "struct_co_d.xhtml#a4a4f4dfb26f77b55280f37a0610dd5f9", null ],
    [ "expectsCrossValidation", "struct_co_d.xhtml#ad9917a97363feb7eeee81a1b47fc41fa", null ],
    [ "loadJson", "struct_co_d.xhtml#ae5700ae63985e3e6b30cb716ddb5fdd0", null ],
    [ "measure", "struct_co_d.xhtml#a4b157842a805ad774da2ab43e530e3d4", null ],
    [ "operator=", "struct_co_d.xhtml#ad24524a85f2564443b2bf0fce3658cd0", null ],
    [ "saveJson", "struct_co_d.xhtml#ab4587af0230811304c91f1c0aaa1c9ce", null ],
    [ "write", "struct_co_d.xhtml#a77047bf810e52c1c56fa06464a9ecc3f", null ]
];