var struct_import_opti_s_lang_binary =
[
    [ "ImportOptiSLangBinary", "struct_import_opti_s_lang_binary.xhtml#a1f528a5f1fd117a3ba6dc5af24c2e03d", null ],
    [ "check", "struct_import_opti_s_lang_binary.xhtml#a483e471aa905217dc69d9b12390ba367", null ],
    [ "import", "struct_import_opti_s_lang_binary.xhtml#aede94ac324007dfdc28cad1dd38e158f", null ],
    [ "filename", "struct_import_opti_s_lang_binary.xhtml#a3a1a90139c2c8ab1fca0ea8b1790b7b2", null ],
    [ "import_constant_inputs", "struct_import_opti_s_lang_binary.xhtml#a2c19fa2e1dd0d3a65f5023d5af94144d", null ],
    [ "import_dependent_inputs", "struct_import_opti_s_lang_binary.xhtml#a182412b4528293afe16d7c86f561a101", null ],
    [ "import_inputs", "struct_import_opti_s_lang_binary.xhtml#a1779fd0ed7406bcf8b1a33cb53b102ea", null ],
    [ "import_responses", "struct_import_opti_s_lang_binary.xhtml#a0086995286c153dec1bb8615e26c480b", null ],
    [ "overwrite_existing", "struct_import_opti_s_lang_binary.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ]
];