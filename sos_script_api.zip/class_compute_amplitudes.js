var class_compute_amplitudes =
[
    [ "enum_missing_data_type", "class_compute_amplitudes.xhtml#af4a82e782245e02b74bdf0da297346ac", [
      [ "USE_MEAN", "class_compute_amplitudes.xhtml#af4a82e782245e02b74bdf0da297346aca1554f242c24c60d2778d7f675a6c7d7a", null ],
      [ "INTERPOLATE", "class_compute_amplitudes.xhtml#af4a82e782245e02b74bdf0da297346aca294efc1e1cce72175be5f7bce86d539f", null ],
      [ "RECONSTRUCT", "class_compute_amplitudes.xhtml#af4a82e782245e02b74bdf0da297346acae4a14e37c0374b955cfcde5b4941d927", null ]
    ] ],
    [ "ComputeAmplitudes", "class_compute_amplitudes.xhtml#a61c7c7471dc986aa16c35f08160fa288", null ],
    [ "check", "class_compute_amplitudes.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "class_compute_amplitudes.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "element_data", "class_compute_amplitudes.xhtml#a0a142faa1cc762466b884ad3c8979f3a", null ],
    [ "missing_items", "class_compute_amplitudes.xhtml#a4bdc72c53f6cc6fe4c45b2ed5dc621fa", null ],
    [ "node_data", "class_compute_amplitudes.xhtml#a4b3543f31398671628dd711c98a0d37e", null ],
    [ "overwrite_existing", "class_compute_amplitudes.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "scalar_data", "class_compute_amplitudes.xhtml#a0c1c80374ba4d28153ed219819d24612", null ]
];