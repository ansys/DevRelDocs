var class_data_model_reporter =
[
    [ "getAll", "class_data_model_reporter.xhtml#a0be0443b31ea9fa1fe6a9f111bb2f1a7", null ],
    [ "getAllLicenseCapabilities", "class_data_model_reporter.xhtml#a1dfd2eb7fd93b20cef6bd60d940144cf", null ],
    [ "getAllModels", "class_data_model_reporter.xhtml#a6607e8625bffd2ac3fad644252019d61", null ],
    [ "getAllProperties", "class_data_model_reporter.xhtml#a5a820c0785dfc0c4f868234c5cbef247", null ],
    [ "getAllQualityMeasures", "class_data_model_reporter.xhtml#a36cb9a7fe571d138cf9e77d6a4fad630", null ],
    [ "getMOP", "class_data_model_reporter.xhtml#a6daecf733d4774ecac1237e704d1b1db", null ],
    [ "getScalarMOP", "class_data_model_reporter.xhtml#ad29521e5539c7797839c63c6e9632b03", null ],
    [ "DISOWN", "class_data_model_reporter.xhtml#aef3131b453733ae4ee2f7852b4b6dbc7", null ]
];