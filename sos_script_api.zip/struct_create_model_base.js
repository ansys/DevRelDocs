var struct_create_model_base =
[
    [ "__str__", "struct_create_model_base.xhtml#a3031d648b73235d11d64df95db3d84ce", null ],
    [ "addProperty", "struct_create_model_base.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "compute", "struct_create_model_base.xhtml#a5e64887b96b93ac8aa95cca396d78f0a", null ],
    [ "equals", "struct_create_model_base.xhtml#a4a1cc8519f2bdb1f9952ceaa3391cbca", null ],
    [ "getProperties", "struct_create_model_base.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "isValid", "struct_create_model_base.xhtml#a1202ca4468e899d1e6d321ebf59e67a1", null ],
    [ "transferProperties", "struct_create_model_base.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ]
];