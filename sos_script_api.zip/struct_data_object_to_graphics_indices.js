var struct_data_object_to_graphics_indices =
[
    [ "getData", "struct_data_object_to_graphics_indices.xhtml#a8777db20d13ae82d05cdd8c48178afe1", null ],
    [ "getHasData", "struct_data_object_to_graphics_indices.xhtml#a9d74cc00d57dac7f8e4bbaebd83e6201", null ],
    [ "init", "struct_data_object_to_graphics_indices.xhtml#a738c70d933145c214382f4752b2dfb8b", null ],
    [ "GL_to_data_indices_line", "struct_data_object_to_graphics_indices.xhtml#a7b03266474d77668bb8fa6d5ea998219", null ],
    [ "GL_to_data_indices_point", "struct_data_object_to_graphics_indices.xhtml#a4b715bea770f22d8c763de4375c94d22", null ],
    [ "GL_to_data_indices_tet", "struct_data_object_to_graphics_indices.xhtml#aa9ae49e7a428b2cdcca5c9126044694d", null ],
    [ "GL_to_data_indices_tri", "struct_data_object_to_graphics_indices.xhtml#a744fc173e53fa31f3b0586bd4342d714", null ],
    [ "has_data_line", "struct_data_object_to_graphics_indices.xhtml#a5cee6e492aaa90d5c6b90bd3db22ed61", null ],
    [ "has_data_point", "struct_data_object_to_graphics_indices.xhtml#a26905c29ee82d9abb26f1dbeb11d7ba8", null ],
    [ "has_data_tet", "struct_data_object_to_graphics_indices.xhtml#ac7ce58a8165ba60af1bcd140caab3dd2", null ],
    [ "has_data_tri", "struct_data_object_to_graphics_indices.xhtml#ab8a7958bdc32ae0713cbd1058571be73", null ]
];