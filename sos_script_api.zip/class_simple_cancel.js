var class_simple_cancel =
[
    [ "cancel", "class_simple_cancel.xhtml#adc7ad0a041e23fea7e65a7b4a4da9ec7", null ],
    [ "isCancelled", "class_simple_cancel.xhtml#a0d78ccfebb4ea3e786be49370876f85a", null ]
];