var group__common =
[
    [ "EnumTraits< ParameterImportance >", "struct_enum_traits_3_01_parameter_importance_01_4.xhtml", null ],
    [ "EnumTraits< TrainingPlanType >", "struct_enum_traits_3_01_training_plan_type_01_4.xhtml", null ],
    [ "SerializableTraits< ParameterImportance >", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml", null ],
    [ "ParameterImportance", "group__common.xhtml#gad5ca470fd07552bf1da82219827c4ec0", null ],
    [ "TrainingPlanType", "group__common.xhtml#ga8f73c0a2225e425c9ffeecb046034a43", null ]
];