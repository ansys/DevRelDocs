var class_create_scalar_m_o_p =
[
    [ "__str__", "class_create_scalar_m_o_p.xhtml#a3031d648b73235d11d64df95db3d84ce", null ],
    [ "addConfig", "class_create_scalar_m_o_p.xhtml#a8c9e9b33aa08c8adc83c5c603584baf6", null ],
    [ "addProperty", "class_create_scalar_m_o_p.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "compute", "class_create_scalar_m_o_p.xhtml#a2fb8c89a4dd4b11ceb0d033683d0019b", null ],
    [ "getProperties", "class_create_scalar_m_o_p.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "isValid", "class_create_scalar_m_o_p.xhtml#a54ae75757bd7c8c3936ab036df6d18e3", null ],
    [ "loadJson", "class_create_scalar_m_o_p.xhtml#ae5700ae63985e3e6b30cb716ddb5fdd0", null ],
    [ "saveJson", "class_create_scalar_m_o_p.xhtml#ab4587af0230811304c91f1c0aaa1c9ce", null ],
    [ "setInputImportance", "class_create_scalar_m_o_p.xhtml#a7b3d9ae89849827c6ce4987f69ad7e9c", null ],
    [ "setQualityMeasure", "class_create_scalar_m_o_p.xhtml#a67e6e9484b7f0afc23dd59b417cf6abc", null ],
    [ "transferProperties", "class_create_scalar_m_o_p.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ],
    [ "write", "class_create_scalar_m_o_p.xhtml#aa71b0f057f1559d99319ecb71b50c0f8", null ],
    [ "input_importances", "class_create_scalar_m_o_p.xhtml#afff2ed8fc84ff999a9ff1b187dc4fe8a", null ],
    [ "number_of_folds", "class_create_scalar_m_o_p.xhtml#ae29a97cfbae42dc37b7a9be964b5d266", null ]
];