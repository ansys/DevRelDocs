var class_data_object_ident_map =
[
    [ "PtrBase", "class_data_object_ident_map.xhtml#aecda2762686ef28a64e707ca8adbf775", null ],
    [ "DataObjectIdentMap", "class_data_object_ident_map.xhtml#abdcc12704b48e722663a1e9c87c1941d", null ],
    [ "__getitem__", "class_data_object_ident_map.xhtml#a5a195b690a64e43e80a69a7e85d038db", null ],
    [ "__setitem__", "class_data_object_ident_map.xhtml#adc74708ac63d88d2bf7eaba067f57e98", null ]
];