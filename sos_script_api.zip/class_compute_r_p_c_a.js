var class_compute_r_p_c_a =
[
    [ "TAlgorithmFunction", "class_compute_r_p_c_a.xhtml#afe5cfc4ea6277ec393adca68465c9a5e", null ],
    [ "TAlgorithmFunction2", "class_compute_r_p_c_a.xhtml#adbff8fbbd061127936232ab5600cbe01", null ],
    [ "ComputeRPCA", "class_compute_r_p_c_a.xhtml#afb3c7912b78f2ec44c06e8198df36617", null ],
    [ "ComputeRPCA", "class_compute_r_p_c_a.xhtml#a216cd82ee2b0a4340813f2d0713b4806", null ],
    [ "check", "class_compute_r_p_c_a.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "class_compute_r_p_c_a.xhtml#a2ee6c389c27f8cb563b6b1aa31f6bf17", null ],
    [ "data", "class_compute_r_p_c_a.xhtml#aff21fffab499ea652443206d66e1a9bb", null ],
    [ "lambda", "class_compute_r_p_c_a.xhtml#a494c8da7f3865175fcb8044abce244fc", null ],
    [ "maxIterations", "class_compute_r_p_c_a.xhtml#a0bc677a1bf92968ad92aa7d973e24ba4", null ],
    [ "new_quantity_idents", "class_compute_r_p_c_a.xhtml#a30b1bcf63b9bdc707fea30bd96d70447", null ],
    [ "overwrite_existing", "class_compute_r_p_c_a.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "quantity_idents", "class_compute_r_p_c_a.xhtml#aced57c746ae1d69d2fd56872fa1768bf", null ],
    [ "relativeError", "class_compute_r_p_c_a.xhtml#a033dc667b0fe6b15482f2703c104f415", null ]
];