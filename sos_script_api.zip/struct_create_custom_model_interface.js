var struct_create_custom_model_interface =
[
    [ "__class_name_internal__", "struct_create_custom_model_interface.xhtml#a31de2088e35819f6e03dc305bcc22294", null ],
    [ "compute", "struct_create_custom_model_interface.xhtml#a8c21bb60a1ae5e9c3e6ee1c7cfb6c86d", null ],
    [ "displayName", "struct_create_custom_model_interface.xhtml#a2d5202c0fb80141117dfbfbb41a46a77", null ],
    [ "getProperties", "struct_create_custom_model_interface.xhtml#a1111f254a4d5749fb9e1d62a0bf976f0", null ],
    [ "isValid", "struct_create_custom_model_interface.xhtml#a1637eb7dcd73ee7adfe215c49b330f44", null ],
    [ "licenseLevel", "struct_create_custom_model_interface.xhtml#a5a4c33e8a236524ef9d522558e547b27", null ],
    [ "loadJson", "struct_create_custom_model_interface.xhtml#a64a299a9067f1d5c4d8eeb74b39e9f94", null ],
    [ "saveJson", "struct_create_custom_model_interface.xhtml#ab8451e71159211ca3e07325fd1f0eeb8", null ]
];