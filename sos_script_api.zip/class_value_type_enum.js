var class_value_type_enum =
[
    [ "eType", "class_value_type_enum.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60e", [
      [ "DOUBLE", "class_value_type_enum.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60eafd3e4ece78a7d422280d5ed379482229", null ],
      [ "INT", "class_value_type_enum.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60ea53f93baa3057821107c750323892fa92", null ],
      [ "BOOL", "class_value_type_enum.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60eaa97b2c144243b2b9d2c593ec268b62f5", null ],
      [ "ENUM", "class_value_type_enum.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60ea85a1979d26d0ef93dcc13a72fee80705", null ]
    ] ],
    [ "__str__", "class_value_type_enum.xhtml#a44139caf93a3463ea4f2a6671cdce842", null ],
    [ "attribute", "class_value_type_enum.xhtml#a4fe78fe23647b841774a467f7115e242", null ],
    [ "attribute", "class_value_type_enum.xhtml#a945190dbb867b410997fa2d77a1a629f", null ],
    [ "attributeExists", "class_value_type_enum.xhtml#abc6417bd7b50620ce73098bd5859540d", null ],
    [ "create", "class_value_type_enum.xhtml#a5759d5b685b07907b22bba0d257f1488", null ],
    [ "description", "class_value_type_enum.xhtml#a166e44f3030115668a91a35ffb81ff11", null ],
    [ "eraseAttribute", "class_value_type_enum.xhtml#a39693bcee84d3daf689384219bd7e89c", null ],
    [ "name", "class_value_type_enum.xhtml#aa62b508d2c0e7d9cec12924965276eb5", null ],
    [ "operator!=", "class_value_type_enum.xhtml#a7fe700521405d7e9ecb39f9c20eb2589", null ],
    [ "operator==", "class_value_type_enum.xhtml#a99b4ecb5a908b5fb78fddad314091737", null ],
    [ "operator>", "class_value_type_enum.xhtml#a3355fe903707accf684bf8ca5dd30f34", null ],
    [ "setAttribute", "class_value_type_enum.xhtml#a8bdd98028a4fcad8345fb72becb3c0d4", null ],
    [ "toDouble", "class_value_type_enum.xhtml#a3feb53908f4c019f35111daf04a190b8", null ],
    [ "toString", "class_value_type_enum.xhtml#afe98eed581fb1712f5b265fcce59dfda", null ],
    [ "type", "class_value_type_enum.xhtml#a04b0a9497332985d1c7386b487924e85", null ]
];