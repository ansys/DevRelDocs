var struct_export_geometry =
[
    [ "enum_format_type", "struct_export_geometry.xhtml#acf1b366f46b9570951935096bc25e2e6", [
      [ "UNINITIALIZED", "struct_export_geometry.xhtml#acf1b366f46b9570951935096bc25e2e6af096820742c38363e9d6c33e7c932780", null ],
      [ "STL", "struct_export_geometry.xhtml#acf1b366f46b9570951935096bc25e2e6a3a8b3333d20fa8bfc7a658976116142c", null ],
      [ "LSDYNA", "struct_export_geometry.xhtml#acf1b366f46b9570951935096bc25e2e6ae3ed41cd8fb28b6c00b37ec52b7cb6b7", null ],
      [ "NASTRAN", "struct_export_geometry.xhtml#acf1b366f46b9570951935096bc25e2e6ae47615bbaba7255ab17b5475d3ba6f12", null ],
      [ "ANSYS_MECHANICAL_DAT", "struct_export_geometry.xhtml#acf1b366f46b9570951935096bc25e2e6ade3177a1c4bcd64ecd84cd388c6726a5", null ]
    ] ],
    [ "ExportGeometry", "struct_export_geometry.xhtml#ae65ff1ee9cfeca8e51a9bb090026c3f4", null ],
    [ "isAnyCoordinateSet", "struct_export_geometry.xhtml#a7fe742a326ed093610a77be41f0d5daf", null ],
    [ "isXCoordinateSet", "struct_export_geometry.xhtml#a3d06db310cea1faa5f35b16e4a863883", null ],
    [ "isYCoordinateSet", "struct_export_geometry.xhtml#ace43862f6f933e57005e4d669bf95ec8", null ],
    [ "isZCoordinateSet", "struct_export_geometry.xhtml#af263b289cd0bc9436b144c942ba18b9d", null ],
    [ "save", "struct_export_geometry.xhtml#a6a338dc4344270fcbccadf5667ef12f9", null ],
    [ "coor_increment_factor", "struct_export_geometry.xhtml#ae41d9f831e08fa05af4ff8562081865f", null ],
    [ "file_format", "struct_export_geometry.xhtml#a36f06489f13fd31d60f437a4624ac63a", null ],
    [ "file_name", "struct_export_geometry.xhtml#a755d42f2e9c635ce2213e0efad62b796", null ],
    [ "mesh_stabilization", "struct_export_geometry.xhtml#ab017799d29c8279bc2b4976f4aa3e4d0", null ],
    [ "node_coor_increment_x", "struct_export_geometry.xhtml#a2716ab8a487117f921f7a6827212d79f", null ],
    [ "node_coor_increment_y", "struct_export_geometry.xhtml#aeb73eaa26c8065e09713c94bcd61b920", null ],
    [ "node_coor_increment_z", "struct_export_geometry.xhtml#a33fde5ec2727661509ed1414a90db1bd", null ],
    [ "node_coor_x", "struct_export_geometry.xhtml#a159f2eb0ab4b04af4c6f560808af08b6", null ],
    [ "node_coor_y", "struct_export_geometry.xhtml#aa0300af1da21afa4e43fd0e64533e189", null ],
    [ "node_coor_z", "struct_export_geometry.xhtml#a5cc7124a1cba852c8dba82d827896358", null ],
    [ "replace_files", "struct_export_geometry.xhtml#a2f8b3cba47ad64fb6bda4b6428a032d3", null ],
    [ "throw_error_on_unstable_mesh", "struct_export_geometry.xhtml#ac92d2c3e8ade2a17ee2edb8eb6747008", null ]
];