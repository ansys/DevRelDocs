var class_compute_absolute_maxima =
[
    [ "TAlgorithmFunction", "class_compute_absolute_maxima.xhtml#afe5cfc4ea6277ec393adca68465c9a5e", null ],
    [ "TAlgorithmFunction2", "class_compute_absolute_maxima.xhtml#adbff8fbbd061127936232ab5600cbe01", null ],
    [ "ComputeAbsoluteMaxima", "class_compute_absolute_maxima.xhtml#af8f5fd57734506fe3bf1a476dcd51345", null ],
    [ "ComputeAbsoluteMaxima", "class_compute_absolute_maxima.xhtml#a430e074211591d4a00b93e20db432fb5", null ],
    [ "check", "class_compute_absolute_maxima.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "class_compute_absolute_maxima.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "compute", "class_compute_absolute_maxima.xhtml#a2ee6c389c27f8cb563b6b1aa31f6bf17", null ],
    [ "data", "class_compute_absolute_maxima.xhtml#aff21fffab499ea652443206d66e1a9bb", null ],
    [ "new_quantity_idents", "class_compute_absolute_maxima.xhtml#a30b1bcf63b9bdc707fea30bd96d70447", null ],
    [ "number", "class_compute_absolute_maxima.xhtml#a77f4fc869835d36acebf03dc46aab96e", null ],
    [ "overwrite_existing", "class_compute_absolute_maxima.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "quantity_idents", "class_compute_absolute_maxima.xhtml#aced57c746ae1d69d2fd56872fa1768bf", null ]
];