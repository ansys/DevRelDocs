var class_export_signals_settings =
[
    [ "ExportSignalsSettings", "class_export_signals_settings.xhtml#a4b00f2ec80954839e215f2d1c303009a", null ],
    [ "check", "class_export_signals_settings.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "save", "class_export_signals_settings.xhtml#a6a338dc4344270fcbccadf5667ef12f9", null ],
    [ "delimiter", "class_export_signals_settings.xhtml#a0b2e98e6d6483b285675f9e0128ad223", null ],
    [ "factor", "class_export_signals_settings.xhtml#a29a9f0233f0f63dbf3e5d3886ae54b6c", null ],
    [ "output_file_cop", "class_export_signals_settings.xhtml#aa7f8f943bac2f83543e757f98d254472", null ],
    [ "output_file_cop_abs", "class_export_signals_settings.xhtml#a1c44dd02e4655f4a4186211878d2a2d4", null ],
    [ "output_file_interval", "class_export_signals_settings.xhtml#a5de4d09e5e26129334921b0041dc7fb7", null ],
    [ "replace_files", "class_export_signals_settings.xhtml#a2f8b3cba47ad64fb6bda4b6428a032d3", null ]
];