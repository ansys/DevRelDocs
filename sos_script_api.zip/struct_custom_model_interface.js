var struct_custom_model_interface =
[
    [ "CustomModelInterface", "struct_custom_model_interface.xhtml#a4b26dc532338309b6aaba464c015fe2c", null ],
    [ "__class_name_internal__", "struct_custom_model_interface.xhtml#a31de2088e35819f6e03dc305bcc22294", null ],
    [ "activeVariables", "struct_custom_model_interface.xhtml#aa6fb875d0085ac970498de0cf24647e0", null ],
    [ "deserialize", "struct_custom_model_interface.xhtml#acffc114f2bfcb5ebd08ffb8db009a434", null ],
    [ "evaluate", "struct_custom_model_interface.xhtml#a5c383d2586219fc4db627879e98f0d0d", null ],
    [ "residuals", "struct_custom_model_interface.xhtml#ab6b1de8c8ced0af688df281adecfdfcc", null ],
    [ "serialize", "struct_custom_model_interface.xhtml#a09bb54030260cdeef6d3b2d5ed92f075", null ]
];