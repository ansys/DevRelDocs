var class_create_polynomial_model =
[
    [ "CreatePolynomialModel", "class_create_polynomial_model.xhtml#a4c733efb0cce664014dbff681f8aa200", null ],
    [ "CreatePolynomialModel", "class_create_polynomial_model.xhtml#a4f38679ec6c4c3f6e2406f841a0cf01a", null ],
    [ "__str__", "class_create_polynomial_model.xhtml#a3031d648b73235d11d64df95db3d84ce", null ],
    [ "addProperty", "class_create_polynomial_model.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "compute", "class_create_polynomial_model.xhtml#a428e7ba979340c651ec1372a3307e037", null ],
    [ "getProperties", "class_create_polynomial_model.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "isValid", "class_create_polynomial_model.xhtml#a1a42d0ff7ef3b9c17965ecc14310ed5d", null ],
    [ "operator=", "class_create_polynomial_model.xhtml#af9abc184ff13de6ca630781a2fc35fcf", null ],
    [ "transferProperties", "class_create_polynomial_model.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ],
    [ "interaction", "class_create_polynomial_model.xhtml#a0c4b96340c20432ff0d6b429ac2f75ee", null ],
    [ "max_order", "class_create_polynomial_model.xhtml#ac4bd3143ec6179fe07419cd827281496", null ],
    [ "order", "class_create_polynomial_model.xhtml#ac85d5511fdb8d162a7278bfb440ae420", null ],
    [ "value_transformation", "class_create_polynomial_model.xhtml#a850bec49118fd5e977ea5be55a59d594", null ]
];