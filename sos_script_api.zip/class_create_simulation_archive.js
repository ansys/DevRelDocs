var class_create_simulation_archive =
[
    [ "CreateSimulationArchive", "class_create_simulation_archive.xhtml#a1694082771d86e6a33750c071ff76a6c", null ],
    [ "check", "class_create_simulation_archive.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "save", "class_create_simulation_archive.xhtml#a6a338dc4344270fcbccadf5667ef12f9", null ],
    [ "output_file", "class_create_simulation_archive.xhtml#a8643191a264f6d55fead82a6d23a88b6", null ],
    [ "reference_design", "class_create_simulation_archive.xhtml#acf3a932aa2f8b555c1a254385c014629", null ],
    [ "replace_files", "class_create_simulation_archive.xhtml#a2f8b3cba47ad64fb6bda4b6428a032d3", null ]
];