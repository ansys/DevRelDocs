var class_approximate_m_o_p =
[
    [ "StringVector", "class_approximate_m_o_p.xhtml#a999a7ace250aceefc403bb62cd8c3bcc", null ],
    [ "ApproximateMOP", "class_approximate_m_o_p.xhtml#a8f7677df9d0c67b1e208dce034b82bf1", null ],
    [ "check", "class_approximate_m_o_p.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "class_approximate_m_o_p.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "accept_partial_subspace", "class_approximate_m_o_p.xhtml#a591952882aeaa67ab84a56aa4d053268", null ],
    [ "element_fmop_idents", "class_approximate_m_o_p.xhtml#a6004ee87717c9664d2314e817547d0a5", null ],
    [ "node_fmop_idents", "class_approximate_m_o_p.xhtml#a6127bef6ec70cb87bbba71911fd1e689", null ],
    [ "overwrite_existing", "class_approximate_m_o_p.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "scalar_fmop_idents", "class_approximate_m_o_p.xhtml#a138c218375fc3166ddcf7e6b23e6b373", null ],
    [ "selected_inputs", "class_approximate_m_o_p.xhtml#afac43f97194e263427759f8414a2d703", null ],
    [ "use_sampling_bounds", "class_approximate_m_o_p.xhtml#ac0f888ea04ab875135d8dc97bd060a77", null ]
];