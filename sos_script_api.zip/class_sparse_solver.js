var class_sparse_solver =
[
    [ "TScalar", "class_sparse_solver.xhtml#ad33f729eda6e45412aac71cee702012f", null ],
    [ "TSparseMatrix", "class_sparse_solver.xhtml#a0ce6eae547dc1456730d2df72d9c29cb", null ],
    [ "SparseSolver", "class_sparse_solver.xhtml#af1e7f2e7e3552b4dc667f324d0f21492", null ],
    [ "Compute", "class_sparse_solver.xhtml#a198e988cd87fa6915dd1aa906d1fb87c", null ],
    [ "Compute", "class_sparse_solver.xhtml#ac6480ddf60c975e344ad332af27eba9b", null ],
    [ "operator*", "class_sparse_solver.xhtml#ab575d53b6b3741bf8b54ca4dad896322", null ],
    [ "Solve", "class_sparse_solver.xhtml#a03c9937003c1c78404c778f1ce257cfd", null ],
    [ "Solve", "class_sparse_solver.xhtml#aed85b6e6bc9e10b49a5eacee4930dc12", null ],
    [ "SolveInPlace", "class_sparse_solver.xhtml#a6facb69b91b239c79f8272159402c4f4", null ],
    [ "SolveTransposed", "class_sparse_solver.xhtml#aeb600a838ac25ea5705191ddcd35d5aa", null ],
    [ "typeIdent", "class_sparse_solver.xhtml#a4bab1e661cce06aa1bab0b15bc3f5f9e", null ]
];