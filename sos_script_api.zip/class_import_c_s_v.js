var class_import_c_s_v =
[
    [ "delimiter_set_type", "class_import_c_s_v.xhtml#a7ca6b7dfb092f003a8112eab3ab69523", null ],
    [ "ImportCSV", "class_import_c_s_v.xhtml#a60886859ba515644d1501c975b1af532", null ],
    [ "check", "class_import_c_s_v.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "import", "class_import_c_s_v.xhtml#a73dd3f56399568385400db0c3fc08295", null ],
    [ "delimiter", "class_import_c_s_v.xhtml#a0b2e98e6d6483b285675f9e0128ad223", null ],
    [ "enforce_integer_design_idents", "class_import_c_s_v.xhtml#a05bc029610051c80b0f364bfc6587340", null ],
    [ "filename", "class_import_c_s_v.xhtml#a3a1a90139c2c8ab1fca0ea8b1790b7b2", null ],
    [ "row_orientated", "class_import_c_s_v.xhtml#ae3708cb2d385c0e5dccbad90b0dd1069", null ]
];