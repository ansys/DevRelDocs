var class_extract_scalars =
[
    [ "index_type", "class_extract_scalars.xhtml#ac455005009c3d22b1e98034fd5df9547", null ],
    [ "quantity_map_type", "class_extract_scalars.xhtml#a307e043c1b029bb9a68ad6b69d9dd72a", null ],
    [ "ExtractScalars", "class_extract_scalars.xhtml#a3263893c6f3be92d08426539e70fb063", null ],
    [ "compute", "class_extract_scalars.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "determineObjectsToBeReplaced", "class_extract_scalars.xhtml#aed4396d64c1a5eb946769d16dae346a2", null ],
    [ "data", "class_extract_scalars.xhtml#aff21fffab499ea652443206d66e1a9bb", null ],
    [ "overwrite_existing", "class_extract_scalars.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "quantity_idents", "class_extract_scalars.xhtml#aced57c746ae1d69d2fd56872fa1768bf", null ]
];