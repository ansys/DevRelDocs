var class_model_base =
[
    [ "addProperty", "class_model_base.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "evaluate", "class_model_base.xhtml#a5ec7821e9b8c1aaa6c43dc5ca1263f2f", null ],
    [ "getProperties", "class_model_base.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "transferProperties", "class_model_base.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ]
];