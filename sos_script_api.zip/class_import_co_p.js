var class_import_co_p =
[
    [ "ImportCoP", "class_import_co_p.xhtml#a8939bd20c8a90fd23e86b01270f271aa", null ],
    [ "check", "class_import_co_p.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "checkOverwriteExisting", "class_import_co_p.xhtml#abdcd2125bfa27ba032579f06c6c15b41", null ],
    [ "import", "class_import_co_p.xhtml#a73dd3f56399568385400db0c3fc08295", null ],
    [ "file_name", "class_import_co_p.xhtml#a755d42f2e9c635ce2213e0efad62b796", null ],
    [ "min_cop", "class_import_co_p.xhtml#a9c4157039d23c5bdda684578b63c50e5", null ],
    [ "overwrite_existing", "class_import_co_p.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ]
];