var struct_mesh_morpher_settings =
[
    [ "MeshMorpherSettings", "struct_mesh_morpher_settings.xhtml#ae2586e7c4cb74ca42b5145e709126ad7", null ],
    [ "use_linearized_quadratic_elements", "struct_mesh_morpher_settings.xhtml#a6558020cf6de06aafd65a20121d795ec", null ]
];