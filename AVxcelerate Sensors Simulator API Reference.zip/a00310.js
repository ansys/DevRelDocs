var a00310 =
[
    [ "bit_resolution", "a00310.xhtml#a6e0f521da4a167ce578a8793f8276941", null ],
    [ "sampling_frequency", "a00310.xhtml#a76a0ffa54413fbba7b2c7449a6472134", null ]
];