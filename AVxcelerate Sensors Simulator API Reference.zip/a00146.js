var a00146 =
[
    [ "exposure_time", "a00146.xhtml#a0a4a26ce7f91d68fb37830c946775fe5", null ],
    [ "gain", "a00146.xhtml#aafe6efa36b2f9ae0a3f4eb005ec0c24a", null ],
    [ "injection_time", "a00146.xhtml#afac483ed53443a246463aec9deb9a653", null ]
];