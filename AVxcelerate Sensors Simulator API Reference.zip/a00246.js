var a00246 =
[
    [ "emitter", "a00246.xhtml#a29bc835652b3d7eb564dc1b837cc3e48", null ],
    [ "receiver", "a00246.xhtml#a6e46267c3c770c076f1a6d83a574d6ea", null ]
];