var a00430 =
[
    [ "Get", "a00430.xhtml#a350f4512f37143a5c7d4430212d092b9", null ],
    [ "Set", "a00430.xhtml#afd712cf0f68936c1f76224dfdfc78b20", null ]
];