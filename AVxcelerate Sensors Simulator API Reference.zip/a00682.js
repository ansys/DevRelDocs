var a00682 =
[
    [ "contribution", "a00682.xhtml#af92bd4d6cc507e59da0dffa5bd0249ac", null ],
    [ "gpu_name", "a00682.xhtml#a509612d128731b71d5bc3fdd5774d6c8", null ],
    [ "grid", "a00682.xhtml#a83842cf7b7afa4040063c9031a82b17c", null ],
    [ "number_of_batches", "a00682.xhtml#af80e7826b0ec5d66d3794cf92311c742", null ],
    [ "waveform", "a00682.xhtml#a83c1c68bc4af8352a58e888e57449dd0", null ]
];