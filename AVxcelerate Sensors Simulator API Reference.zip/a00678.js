var a00678 =
[
    [ "mode_id", "a00678.xhtml#a3f6f1a2be0d89f017fbb4ea0f255fec1", null ],
    [ "number_of_rx_batches", "a00678.xhtml#a11fce4513300edccbe78b125d4b6287b", null ]
];