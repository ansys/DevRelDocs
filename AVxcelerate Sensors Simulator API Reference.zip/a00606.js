var a00606 =
[
    [ "deploy_hosts", "a00606.xhtml#ae7dfdfc0987ccf6690e2ba96904cc237", null ],
    [ "local_nodes", "a00606.xhtml#a812f1b977d06f1a02ddcb2d476ebbd0b", null ]
];