var a00314 =
[
    [ "duration", "a00314.xhtml#a8ee76491c836a78df05b258a06277d9f", null ],
    [ "extinction_coefficient", "a00314.xhtml#a5b44e6c50cf6f14669a352efdc9313f9", null ],
    [ "shape", "a00314.xhtml#abb092a62d75d5191fd2edc4a9112ddf2", null ],
    [ "wavelength", "a00314.xhtml#ab5e4b49d163b07c49e116319f5a7789d", null ]
];