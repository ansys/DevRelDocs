var a00390 =
[
    [ "pitch", "a00390.xhtml#add04f3a1b9c487ae403850139fe38ba3", null ],
    [ "roll", "a00390.xhtml#a17c6d048a0e5d7f9c6cc2de289361d6c", null ],
    [ "yaw", "a00390.xhtml#a888cc94a5a110bb79ed09b08349171b4", null ]
];