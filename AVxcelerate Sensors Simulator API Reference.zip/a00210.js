var a00210 =
[
    [ "dark_current_coefficient", "a00210.xhtml#a080dfcafedbb0c85305c122551ce862c", null ],
    [ "dark_current_reference_temperature", "a00210.xhtml#a424b4a3cba094fc9518bdf35416c7d36", null ],
    [ "dark_current_reference_value", "a00210.xhtml#a2c53e5426f66522ffafc63985d544f22", null ],
    [ "imager_temperature", "a00210.xhtml#a11a0f5326635d8f4d8cb908955900841", null ]
];