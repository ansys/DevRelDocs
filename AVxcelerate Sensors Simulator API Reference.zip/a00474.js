var a00474 =
[
    [ "label", "a00474.xhtml#a35978cb1369d7362b667b7e143eb76f6", null ],
    [ "tag_name", "a00474.xhtml#afa5af2af615a8a9c2b0b45867cc52596", null ],
    [ "x_max", "a00474.xhtml#ace517783b0848a95a83fef9e596b3d2b", null ],
    [ "x_min", "a00474.xhtml#af777b5808f48501cfa848e7c139fe105", null ],
    [ "y_max", "a00474.xhtml#ae494cfe0fefb6a8f9366867e8202baeb", null ],
    [ "y_min", "a00474.xhtml#a0652fc37fbd303b61a183813eb2cc292", null ]
];