var a00358 =
[
    [ "performance_pulse_doppler_waveform", "a00358.xhtml#a8164682119ac5e6c366eefcdec948fec", null ],
    [ "system_pulse_doppler_waveform", "a00358.xhtml#ad05b00c3fb4dc12daffe5ec59fc71fb4", null ]
];