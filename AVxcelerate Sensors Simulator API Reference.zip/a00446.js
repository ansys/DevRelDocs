var a00446 =
[
    [ "modules_state", "a00446.xhtml#a271b67339a23493274196d4be3e907d0", null ],
    [ "orientation", "a00446.xhtml#a8c9dfcb5d34084385d2f907018a6d769", null ],
    [ "position", "a00446.xhtml#aad4acd85f0e76852a3218b69ceedb9e8", null ],
    [ "projector_name", "a00446.xhtml#aea26637c87a2da27ba1ed89d67d9caea", null ]
];