var a00190 =
[
    [ "aperture_area", "a00190.xhtml#abca6218ebda4a3ee35f6921022128069", null ],
    [ "edge_number", "a00190.xhtml#a1202d79d6e03fccf0f23b0c95391cab0", null ],
    [ "offset_angle", "a00190.xhtml#a584ac84e7311286b8387e4a105d59272", null ]
];