var a00610 =
[
    [ "gpu_identifiers", "a00610.xhtml#a22fc662f13b7cd333d526beba49351da", null ],
    [ "max_port", "a00610.xhtml#a46b29127396f8b525e3a763ba79eba8f", null ],
    [ "min_port", "a00610.xhtml#a85fc9921679c1d3566a6d20dc354e6f9", null ]
];