var a00538 =
[
    [ "data", "a00538.xhtml#ab21fdc4a176daadc704945a49ed38218", null ],
    [ "frequency_domain", "a00538.xhtml#a167deb0e5c1b1556bd014134d675f875", null ],
    [ "pulse_time_domain", "a00538.xhtml#ae906555a495e7cd9ebe97b3ef3b28eb2", null ],
    [ "rx_identifiers", "a00538.xhtml#a498d1d7fcbce4e41599d44b5082ae59a", null ],
    [ "tx_identifiers", "a00538.xhtml#a49b3b14351766ea05632020877098b22", null ]
];