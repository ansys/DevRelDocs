var a00438 =
[
    [ "lighting_system_name", "a00438.xhtml#af4214546b2593d8c06cb1b0d50bf3114", null ],
    [ "projectors_state", "a00438.xhtml#a22d6468f660ecb67ea5a1983ff33ab85", null ]
];