var a00290 =
[
    [ "horizontal", "a00290.xhtml#a2a4449161574262bb66096aed218cf14", null ],
    [ "vertical", "a00290.xhtml#a6a70df464828c861a708829dd0888973", null ]
];