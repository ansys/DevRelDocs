var a00378 =
[
    [ "bandwidth", "a00378.xhtml#abf335cf038fda465e7829b8fd7d90c77", null ],
    [ "chirp_interval", "a00378.xhtml#a2784a334efa21fcc334a0e00f767d1fc", null ],
    [ "number_of_chirps_in_coherent_processing_interval", "a00378.xhtml#a8082fb142ce411fc025332c8223de6c6", null ],
    [ "number_of_samples_per_chirp", "a00378.xhtml#a289f2987040b0c161af312961569f6af", null ],
    [ "rx_components", "a00378.xhtml#a80da493360ecaf60c26bc2b82a48a47d", null ],
    [ "sampling_rate", "a00378.xhtml#a0a6710006b442c662e12445d25257edb", null ]
];