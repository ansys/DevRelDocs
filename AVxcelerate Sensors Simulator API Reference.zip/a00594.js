var a00594 =
[
    [ "sensor_configuration", "a00594.xhtml#aef0b7c47b6efd845be550dcabc836dfd", null ]
];