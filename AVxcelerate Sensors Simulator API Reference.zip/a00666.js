var a00666 =
[
    [ "automatic_batching", "a00666.xhtml#a493be82dc35cd6e183f3395941a9d955", null ],
    [ "manual_batching", "a00666.xhtml#a2eeb1e2e236b79be60d591c578973864", null ],
    [ "number_of_ray_reflections", "a00666.xhtml#a70073a61105bdd142ad080800ac22625", null ],
    [ "number_of_ray_transmissions", "a00666.xhtml#a36d61fdafa9f1f35f7613a8d7290c9b4", null ],
    [ "ray_density", "a00666.xhtml#aa85ed56a33c422d630d42f3b6c5d5cca", null ],
    [ "tx_waveform_report", "a00666.xhtml#a4b751460978e88e3350d1be39554c309", null ]
];