var a00142 =
[
    [ "formats", "a00142.xhtml#ae39bdd277e5999738c80febebd2f7619", null ],
    [ "mode_identifier", "a00142.xhtml#a17aa64fa6b7a88e32c1be928b89b23c1", null ],
    [ "tx_identifier", "a00142.xhtml#a257f1fc4a604ac383a8198c529769dd7", null ],
    [ "tx_waveform_reported", "a00142.xhtml#a17e2eac53ca2ce5aa04ee86360312809", null ]
];