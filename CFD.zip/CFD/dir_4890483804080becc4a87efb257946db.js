var dir_4890483804080becc4a87efb257946db =
[
    [ "KINetics.hpp", "_k_i_netics_8hpp.html", "_k_i_netics_8hpp" ]
];