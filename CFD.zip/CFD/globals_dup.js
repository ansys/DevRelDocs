var globals_dup =
[
    [ "d", "globals.html", null ],
    [ "k", "globals_k.html", null ]
];