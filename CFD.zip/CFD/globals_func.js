var globals_func =
[
    [ "k", "globals_func.html", null ]
];