var a01107 =
[
    [ "near_field_precision", "a01107.xhtml#a31acdb03fc20f6c8d59d04453faf424e", null ],
    [ "resolution", "a01107.xhtml#a01762e8b1ae07e600d7158bd01f7231c", null ],
    [ "shadow_offset_ratio", "a01107.xhtml#ab69c9e8e21911b016399714340057b31", null ],
    [ "shadow_radius", "a01107.xhtml#a1ca8f848b2774dccacc94e5c588f5c48", null ],
    [ "softness", "a01107.xhtml#ade4d532988f7ffdcf1a7bcdafd3f8a21", null ]
];