var a00455 =
[
    [ "geometry_id", "a00455.xhtml#a6ca081ad73f429d2bdf643f69d8b47c2", null ],
    [ "material_part_id", "a00455.xhtml#acb8df308ef2d55c340d6691e3906c19b", null ],
    [ "properties", "a00455.xhtml#a209a0e24462575763d340a1d224a5c06", null ]
];