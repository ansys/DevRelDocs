var a00631 =
[
    [ "intensity", "a00631.xhtml#a5360111129463b4d84916b7ec0ae29c8", null ],
    [ "map_id", "a00631.xhtml#ae6c88529e2762fa3cbe500131880946e", null ],
    [ "map_uv_channel", "a00631.xhtml#a5014bb62d6eed1b239526d56ade50b8e", null ]
];