var a00575 =
[
    [ "absorption", "a00575.xhtml#a50c69e98ea9839c9f5e98311e635d212", null ],
    [ "anisotropy_properties", "a00575.xhtml#ab714e263989506c6ab0e53dd7eb79214", null ],
    [ "diffuse_properties", "a00575.xhtml#a98ba4d3d1cceef424eaae77c078d472d", null ],
    [ "mask_properties", "a00575.xhtml#a2c426ae9281f34f84850ffd12e215fa3", null ],
    [ "normal_properties", "a00575.xhtml#add554b3f134bceefa4741c2e7b38476c", null ]
];