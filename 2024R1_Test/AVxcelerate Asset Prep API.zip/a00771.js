var a00771 =
[
    [ "wavelength", "a00771.xhtml#a4354a38d266c25b410f2ee814cbad93d", null ]
];