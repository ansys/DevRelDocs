var a00635 =
[
    [ "color", "a00635.xhtml#a2ac96967fc7c1bbbdce15659191e7773", null ],
    [ "no_anisotropy", "a00635.xhtml#a2cb7e89f6b74fb4d7cb01d140758472a", null ],
    [ "texture", "a00635.xhtml#a7ca6f36cda02e33cf5c4964196b8574b", null ]
];