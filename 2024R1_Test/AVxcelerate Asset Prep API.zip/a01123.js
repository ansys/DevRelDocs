var a01123 =
[
    [ "cardinal_direction", "a01123.xhtml#a588d284d8fb341262b0d1a307a4b93fc", null ],
    [ "latitude", "a01123.xhtml#a23deff0a21587dbdb3b9fdf97ba4a51e", null ],
    [ "longitude", "a01123.xhtml#a0d54fc53886e1e5bd9e24a99e03f19d8", null ]
];