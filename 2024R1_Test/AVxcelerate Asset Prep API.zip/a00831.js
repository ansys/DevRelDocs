var a00831 =
[
    [ "id", "a00831.xhtml#aa7372556d92fb185ace16df8f05b4b37", null ],
    [ "nodes", "a00831.xhtml#a93f345f49a59be69d5f19d7666ad4aaf", null ],
    [ "properties", "a00831.xhtml#a4b10de8aae562b48a2f9fd40df7bcaab", null ],
    [ "status", "a00831.xhtml#a57e1e82ceebbb8ec5ee74c8ad5f7b1dc", null ]
];