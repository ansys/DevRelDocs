var a00535 =
[
    [ "id", "a00535.xhtml#adfb4ae99d0dd7a362f04d79a01c1fb71", null ],
    [ "properties", "a00535.xhtml#ae38d082c182d2997c4359fe8495086e8", null ],
    [ "status", "a00535.xhtml#a3cb805d73095a3ea1ae2d675553190bb", null ]
];