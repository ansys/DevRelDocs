var a00799 =
[
    [ "identifiers", "a00799.xhtml#a476dd982ff98b5855e1810c066c60a3c", null ],
    [ "status", "a00799.xhtml#abb908209dd57ede7dd9ee7b727a67770", null ]
];