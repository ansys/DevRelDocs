var a00803 =
[
    [ "identifier", "a00803.xhtml#afda4c96dedfd858929a95d4db56d54b3", null ],
    [ "type", "a00803.xhtml#a2ee99b1f8ae7725e5e3ca7e0cb3ffc2d", null ]
];