var a00695 =
[
    [ "id", "a00695.xhtml#a7286643e30b1c369ded2503d1339d1e3", null ],
    [ "status", "a00695.xhtml#ab06963eb29b53542a3dc997386eca1f1", null ]
];