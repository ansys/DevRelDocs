var a00667 =
[
    [ "emissivity", "a00667.xhtml#a91706c2563239ef8f41300a7ac4e7698", null ],
    [ "emissivity_variation_amplitude", "a00667.xhtml#a3d9b93cb2f3eb85ff3cbdf6c43665712", null ],
    [ "emissivity_variation_texture_id", "a00667.xhtml#a46e51da031a225efd3f053f93d20a559", null ],
    [ "emissivity_variation_uv_channel", "a00667.xhtml#a7ec909e99f92a8669f0845795fb90657", null ],
    [ "reflection_coefficient", "a00667.xhtml#ae0ea6cdea2962281dc6fab6cbd0794ef", null ],
    [ "shininess", "a00667.xhtml#ac5e0ff83387693bdf4f58edb47531f0b", null ],
    [ "thermal_coefficient", "a00667.xhtml#aa546b7ba264d919927e802a4a4f6c1c0", null ]
];