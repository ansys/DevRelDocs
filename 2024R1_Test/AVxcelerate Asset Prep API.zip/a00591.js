var a00591 =
[
    [ "anisotropy_properties", "a00591.xhtml#a33910835ffb1a0ca11c5183d4b829d98", null ],
    [ "diffuse_properties", "a00591.xhtml#a96a9069df9e0335caed2deeddf045718", null ],
    [ "mask_properties", "a00591.xhtml#aa93365d62f643a57dabdce3575a201fc", null ],
    [ "normal_properties", "a00591.xhtml#a35808ea410f04b7d74da2c3a5de9d52f", null ],
    [ "roughness_properties", "a00591.xhtml#afe1c1bcb9bba3ef52d609fd6bc8f395d", null ],
    [ "specular_properties", "a00591.xhtml#a25b2104d3ccf0b6be04664709c0bc5fb", null ]
];