var a00775 =
[
    [ "DeleteResource", "a00775.xhtml#a57819bb42e0538f03fa599f4ec0ca187", null ],
    [ "DownloadResourceAsChunks", "a00775.xhtml#a3d1761ab3855b2fba09aec7315ccf5ae", null ],
    [ "DownloadResourceAsFile", "a00775.xhtml#a4702b58328d6bc8c0dab31d1f0b6f664", null ],
    [ "ListResources", "a00775.xhtml#a5250d7891f4d633aa54c440bb9294e08", null ],
    [ "UploadResource", "a00775.xhtml#a52e0678e0821277b4a45bbb125b5c611", null ]
];