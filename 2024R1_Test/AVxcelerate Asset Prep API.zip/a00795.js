var a00795 =
[
    [ "type", "a00795.xhtml#ae3d84398aef81d66fe4e6d2a91f56b9b", null ]
];