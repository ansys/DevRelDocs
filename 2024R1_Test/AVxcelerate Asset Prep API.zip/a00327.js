var a00327 =
[
    [ "spectrum_id", "a00327.xhtml#ac8c68ed54eb90a51aa715230eb750a19", null ]
];