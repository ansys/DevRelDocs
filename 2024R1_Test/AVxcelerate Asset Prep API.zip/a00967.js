var a00967 =
[
    [ "instance_id", "a00967.xhtml#acde938948303726984aafb552ab3a0c5", null ],
    [ "node_id", "a00967.xhtml#a7b0cafb6d53453dbc1a6b1e69cd6acb0", null ],
    [ "properties", "a00967.xhtml#adc614fc2fab6ec2293c3f155f5633894", null ]
];