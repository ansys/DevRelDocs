var a00230 =
[
    [ "AmbientConditions", "a01127.xhtml", "a01127" ],
    [ "CreateSkyRequest", "a01059.xhtml", "a01059" ],
    [ "CreateSkyResponse", "a01063.xhtml", "a01063" ],
    [ "Date", "a01119.xhtml", "a01119" ],
    [ "DeleteSkyRequest", "a01087.xhtml", "a01087" ],
    [ "DeleteSkyResponse", "a01091.xhtml", "a01091" ],
    [ "DynamicAccurateShadows", "a01107.xhtml", "a01107" ],
    [ "GetSkyRequest", "a01067.xhtml", "a01067" ],
    [ "GetSkyResponse", "a01071.xhtml", "a01071" ],
    [ "Hdri", "a01111.xhtml", "a01111" ],
    [ "ListSkiesResponse", "a01075.xhtml", "a01075" ],
    [ "Location", "a01123.xhtml", "a01123" ],
    [ "Natural", "a01103.xhtml", "a01103" ],
    [ "SkyIdentity", "a01095.xhtml", "a01095" ],
    [ "SkyPreparation", "a01055.xhtml", "a01055" ],
    [ "SkyProperties", "a01099.xhtml", "a01099" ],
    [ "Time", "a01115.xhtml", "a01115" ],
    [ "UpdateSkyRequest", "a01079.xhtml", "a01079" ],
    [ "UpdateSkyResponse", "a01083.xhtml", "a01083" ]
];