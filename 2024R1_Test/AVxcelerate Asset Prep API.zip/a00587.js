var a00587 =
[
    [ "anisotropy_properties", "a00587.xhtml#a449ba0ff3a8339c46b44664f18f5a595", null ],
    [ "diffuse_properties", "a00587.xhtml#a242897b09834d795dfdba1a7caf85bba", null ],
    [ "mask_properties", "a00587.xhtml#a7534dc7be884ee0375a97fb4c23814f7", null ],
    [ "normal_properties", "a00587.xhtml#ae2bf5b3c996f601971716b6887eb8bf5", null ],
    [ "surface_state_id", "a00587.xhtml#a8c9f270105ae8d948fec62fdf6cb9479", null ]
];