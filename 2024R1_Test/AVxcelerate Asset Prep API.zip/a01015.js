var a01015 =
[
    [ "added_tags", "a01015.xhtml#a3785051f361d4f3e95b6ea5c812aae35", null ],
    [ "geometry_id", "a01015.xhtml#a331f241f940b2b13d094aae74f210e43", null ],
    [ "name", "a01015.xhtml#a3c45a29536b5d16dbfd70fb76fcfd147", null ],
    [ "removed_tags", "a01015.xhtml#a3a6db9f15fd8dfc7493cd3fdb362b9bc", null ],
    [ "thermal_properties", "a01015.xhtml#a870db13d86433e5c459306229e8c0c6e", null ],
    [ "transform", "a01015.xhtml#acc8d2aa703c5452443fb7de39afc6718", null ],
    [ "visibility", "a01015.xhtml#af84e66c6cd79e20ae57586fa46e32b75", null ]
];