var a00639 =
[
    [ "map_id", "a00639.xhtml#a32e004b92ade48fe95fce72b08252da4", null ],
    [ "map_uv_channel", "a00639.xhtml#aa1c4d1364ebbce1488d7c00a87f02612", null ]
];