var a01055 =
[
    [ "CreateSky", "a01055.xhtml#abf46ce0532774ada64653c174c4d31aa", null ],
    [ "DeleteSky", "a01055.xhtml#ad26f8950317461a4b33c810b056bd59f", null ],
    [ "GetSky", "a01055.xhtml#a3e7b2fcfb2f314a375a45c4b8e829673", null ],
    [ "ListSkies", "a01055.xhtml#a17edb4dfc1ee781e24d3f7026bedc791", null ],
    [ "UpdateSky", "a01055.xhtml#ac35eaf40efb2c27e8a5b4cf6c3c5569e", null ]
];