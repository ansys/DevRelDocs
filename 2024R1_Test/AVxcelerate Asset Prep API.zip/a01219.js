var a01219 =
[
    [ "temperature", "a01219.xhtml#afa60ab72914f67e46fe2837638222476", null ]
];