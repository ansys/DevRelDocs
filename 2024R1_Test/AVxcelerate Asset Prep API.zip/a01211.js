var a01211 =
[
    [ "near_clip", "a01211.xhtml#a29c6ef2bffe4bad0f097057b230858e2", null ],
    [ "shadows_offset_ratio", "a01211.xhtml#a74a48d7482878531b8c7a2fc815b35da", null ],
    [ "softness", "a01211.xhtml#ac5b5d247b3e74c89e9d22940c39fe6ca", null ]
];