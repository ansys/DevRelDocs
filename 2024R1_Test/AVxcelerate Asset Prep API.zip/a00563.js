var a00563 =
[
    [ "dielectric_properties", "a00563.xhtml#adda66b9a74c6f5b0afa93c2aaf3c85d5", null ],
    [ "name", "a00563.xhtml#a7f3e5b962f9219d2792b0fcd6c7d808d", null ],
    [ "reflection_effect", "a00563.xhtml#af7b5055ecfe7294cda8549df6b38a34d", null ],
    [ "surface_optical_properties", "a00563.xhtml#abd7119aabaedebf96ca090a0571f3acd", null ],
    [ "thermal_properties", "a00563.xhtml#a634f865a061093d54e022855e4a5ef80", null ],
    [ "volume_optical_properties", "a00563.xhtml#af86535a30b712a2521cae0f7a688c34d", null ]
];