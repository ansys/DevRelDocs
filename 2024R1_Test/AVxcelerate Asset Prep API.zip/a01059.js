var a01059 =
[
    [ "properties", "a01059.xhtml#a206123c96af74dcbdfe2a5a17d744fcb", null ]
];