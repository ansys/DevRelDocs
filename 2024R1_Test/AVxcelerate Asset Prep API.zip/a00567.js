var a00567 =
[
    [ "layer_1", "a00567.xhtml#a337fc56938c9ced402678f2b4f03a6d0", null ],
    [ "layer_2", "a00567.xhtml#a1690f60cfb442c0966a252c76cba2224", null ],
    [ "layer_3", "a00567.xhtml#ac2386b93f985b0a9c6b3e927507c5034", null ],
    [ "texture_normalization", "a00567.xhtml#a4050e03a01c7e316d3a877f763baa615", null ]
];