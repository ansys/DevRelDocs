var a00527 =
[
    [ "id", "a00527.xhtml#ab0d51a6b6b841a0e5cea7262a91e139d", null ],
    [ "status", "a00527.xhtml#a3e1468dc53b3a09f16925958c314c150", null ]
];