var a00599 =
[
    [ "intensity", "a00599.xhtml#a077b22bfc4791067939dd8d8c421fab3", null ],
    [ "map_id", "a00599.xhtml#a0306ebc4c6a160a6d4a69bb74f0f4be4", null ],
    [ "map_uv_channel", "a00599.xhtml#a9f677260fa84e4b63bff5379beefc37d", null ]
];