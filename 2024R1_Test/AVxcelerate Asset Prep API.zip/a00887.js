var a00887 =
[
    [ "node_id", "a00887.xhtml#a494b328daabc650105e0d4055fc51c0f", null ],
    [ "properties", "a00887.xhtml#af674df35aadcd7c1770412caf0eadc9d", null ]
];