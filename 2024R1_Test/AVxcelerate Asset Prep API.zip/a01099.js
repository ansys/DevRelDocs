var a01099 =
[
    [ "hdri", "a01099.xhtml#a6436c0e156fec626a44e7e37361d621d", null ],
    [ "name", "a01099.xhtml#a4ea7722449a6cf82ede246da85fc9f6f", null ],
    [ "natural", "a01099.xhtml#a5fadf87fb9f0bd42aba89f892b64e5b1", null ]
];