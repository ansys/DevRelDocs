var a00731 =
[
    [ "black_body", "a00731.xhtml#a77c51acdd35bfd35da13418a37372065", null ],
    [ "dynamic_shadows", "a00731.xhtml#a6a32ccc804cf8fc2dba36513c53e772f", null ],
    [ "intensity", "a00731.xhtml#a27a93ca2d3e48a79ad7f6dc148d44395", null ],
    [ "monochromatic", "a00731.xhtml#a735c0a75be9029c0061fbc9eb2ee30cf", null ],
    [ "name", "a00731.xhtml#aea2ac4e4aae61b5e3f2351da10c2bc60", null ],
    [ "no_shadow", "a00731.xhtml#a2b38c4c3f40c5a9a24955a54853a87ea", null ],
    [ "rendering", "a00731.xhtml#af6db999abaa5d1a55be7fac74af13c7b", null ],
    [ "spectrum_library", "a00731.xhtml#a8874428acbb04fcec3449d0b357b7112", null ],
    [ "static_shadows", "a00731.xhtml#ad63badad64bc11c3de42c115714d84b7", null ]
];