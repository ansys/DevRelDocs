var a00703 =
[
    [ "id", "a00703.xhtml#a9e24000a1f315ecb58d42b9965c505c2", null ],
    [ "properties", "a00703.xhtml#ad5291d52ddf13db0b9c9c2dadaa7afe6", null ],
    [ "status", "a00703.xhtml#a8d2d792964b1d5df85f1d8f815b1244a", null ]
];