var a01007 =
[
    [ "added_tags", "a01007.xhtml#a1edfec9094fc361c19040e72300cbd3f", null ],
    [ "name", "a01007.xhtml#a1c2928f8cc9315d1bbaa4da435f93f96", null ],
    [ "removed_tags", "a01007.xhtml#a97074a22577251d499f97ca8fd07f472", null ],
    [ "transform", "a01007.xhtml#a9619222c2a378cd8f7f248e413a0b0be", null ],
    [ "visibility", "a01007.xhtml#a00b797e9da856b07d918feac9339827d", null ]
];