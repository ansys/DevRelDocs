var a00222 =
[
    [ "BlackBody", "a00331.xhtml", "a00331" ],
    [ "CreateDirectionalLightRequest", "a00271.xhtml", "a00271" ],
    [ "CreateDirectionalLightResponse", "a00275.xhtml", "a00275" ],
    [ "Custom", "a00319.xhtml", "a00319" ],
    [ "DeleteDirectionalLightRequest", "a00299.xhtml", "a00299" ],
    [ "DeleteDirectionalLightResponse", "a00303.xhtml", "a00303" ],
    [ "DirectionalLightIdentity", "a00307.xhtml", "a00307" ],
    [ "DirectionalLightPreparation", "a00267.xhtml", "a00267" ],
    [ "DirectionalLightProperties", "a00311.xhtml", "a00311" ],
    [ "DynamicAccurateShadows", "a00323.xhtml", "a00323" ],
    [ "GetDirectionalLightRequest", "a00279.xhtml", "a00279" ],
    [ "GetDirectionalLightResponse", "a00283.xhtml", "a00283" ],
    [ "ListDirectionalLightsResponse", "a00287.xhtml", "a00287" ],
    [ "Monochromatic", "a00335.xhtml", "a00335" ],
    [ "SpectrumLibrary", "a00327.xhtml", "a00327" ],
    [ "Sun", "a00315.xhtml", "a00315" ],
    [ "UpdateDirectionalLightRequest", "a00291.xhtml", "a00291" ],
    [ "UpdateDirectionalLightResponse", "a00295.xhtml", "a00295" ]
];