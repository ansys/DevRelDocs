var a00491 =
[
    [ "has_binormals", "a00491.xhtml#ac16862fe9c4672182e453f276d0e2fc7", null ],
    [ "has_tangents", "a00491.xhtml#af4dafc97210ea208ea544e99645cbb56", null ],
    [ "name", "a00491.xhtml#ad4824fb75c09ae525d524f28a07b7d82", null ],
    [ "uv_count", "a00491.xhtml#a06e9a947ebfec6c25018460f8aea5571", null ],
    [ "winding_order", "a00491.xhtml#ac7d30920f7dc81621264431b1bbb957b", null ]
];