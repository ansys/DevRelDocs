var a00499 =
[
    [ "added_tags", "a00499.xhtml#add241f7ea05aa30dbc650527475857c8", null ],
    [ "indices_count", "a00499.xhtml#a57523198080a4e8bb67a6ccf7bddc2f7", null ],
    [ "material_id", "a00499.xhtml#ad22fe61032f57a9f607123009ba396b8", null ],
    [ "name", "a00499.xhtml#a5dd53acd29bcda51b68746aeb1e399a4", null ],
    [ "removed_tags", "a00499.xhtml#a833e35dac8bae809329b8de26f4f0bbe", null ],
    [ "start_index", "a00499.xhtml#ab97c8c02c6d86c69c008afde480dce3b", null ],
    [ "surface_source_id", "a00499.xhtml#a4322803ad26a24f47d92f2d24fa4fbe1", null ],
    [ "temperature_variation_amplitude", "a00499.xhtml#a792d2666ef8fe14f19ecd7393153c441", null ],
    [ "temperature_variation_texture_id", "a00499.xhtml#a326162784cb8c8452049c98345cbb123", null ],
    [ "temperature_variation_uv_channel", "a00499.xhtml#a038bdeb22963141e686e80c971cf3875", null ],
    [ "transparency_mode", "a00499.xhtml#af11dcfdbf317de0d34d0b92c2ab93a76", null ]
];