var a00283 =
[
    [ "id", "a00283.xhtml#a147f9d1a456543b59317dd15d2264925", null ],
    [ "properties", "a00283.xhtml#ae75b524dac8626490ddd9e57c4a3741b", null ],
    [ "status", "a00283.xhtml#ae701fa8c5e0baf8e1cfcc5315a1b98d2", null ]
];