var a00355 =
[
    [ "id", "a00355.xhtml#a0878791eb55182f79ded2ac12eff62d0", null ],
    [ "properties", "a00355.xhtml#aa41c761356a7a424636314a3c9877609", null ],
    [ "status", "a00355.xhtml#a492626bd6aabb344e68ecd06d7dd2eed", null ]
];