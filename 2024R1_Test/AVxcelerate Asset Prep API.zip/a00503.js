var a00503 =
[
    [ "ambient_occlusion", "a00503.xhtml#ade9e3f69fbec336cc1e32babf2024224", null ],
    [ "uv_coordinates", "a00503.xhtml#a757fa2de17d38cf2fa01ece4570b6252", null ],
    [ "x_binormal", "a00503.xhtml#a8092df3cfcb1fefaa37914fdf60d682c", null ],
    [ "x_normal", "a00503.xhtml#a09eba978a52253948a9840351ad78566", null ],
    [ "x_position", "a00503.xhtml#a3d9d15693d3341c3ef188392c12146c2", null ],
    [ "x_tangent", "a00503.xhtml#a10e53f0714e2100be154c83f42402033", null ],
    [ "y_binormal", "a00503.xhtml#a066effe35ccc6866a11e3d0c962f57ce", null ],
    [ "y_normal", "a00503.xhtml#aafe6d4ec7990ceff0a4e606f3eb610c6", null ],
    [ "y_position", "a00503.xhtml#a58c4123eb4623262487c1e7fad4c5fdc", null ],
    [ "y_tangent", "a00503.xhtml#a8a8eb8308c70fb2a18db5cb04ef58a00", null ],
    [ "z_binormal", "a00503.xhtml#a97cecb9a6edbeb5a204ea137894d9075", null ],
    [ "z_normal", "a00503.xhtml#af2e6f6873e23f1010cfa08b92569063c", null ],
    [ "z_position", "a00503.xhtml#a1a11baa8623b6ca7e27eee4185ea6d26", null ],
    [ "z_tangent", "a00503.xhtml#a9103c0e0eed808f1f1c1a24ec1c1e44c", null ]
];