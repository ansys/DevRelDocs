var a00415 =
[
    [ "id", "a00415.xhtml#adf8adcb41b96aa07706d1f6114fe4b58", null ],
    [ "material_parts", "a00415.xhtml#a817079f7ea51bd2944e24dc4174f1de9", null ],
    [ "properties", "a00415.xhtml#ac8ba04c29a0bf35c3d4ed55f1a5f9e40", null ],
    [ "status", "a00415.xhtml#a51552b14917e60ce11cc939ab48c55d6", null ]
];