var a00627 =
[
    [ "no_normal", "a00627.xhtml#acc132eb463081fc5f494cb77da090bfc", null ],
    [ "texture", "a00627.xhtml#aca11029a98f8d8ab5ad4f60de2e9f012", null ]
];