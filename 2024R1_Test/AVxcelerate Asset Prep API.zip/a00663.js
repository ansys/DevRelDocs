var a00663 =
[
    [ "index_of_refraction", "a00663.xhtml#a8c1a3fef1d9ca606d8e26a52a8d8e8b1", null ],
    [ "reflectivity", "a00663.xhtml#a4c11fcb95ea0d098523131e775fa29c9", null ],
    [ "size", "a00663.xhtml#a2ce75bbb617eaada551302de9da48c6b", null ]
];