var a00919 =
[
    [ "node_id", "a00919.xhtml#a09c55cc4381b5bc2f52de40f3f94ec99", null ],
    [ "properties", "a00919.xhtml#a052bbdc8bc17317b18a4f88c18bffd99", null ]
];