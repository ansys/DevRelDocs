var a01215 =
[
    [ "spectrum_id", "a01215.xhtml#a0ac4ef7c3bc6c2ee4dcc7dd428b3c510", null ]
];