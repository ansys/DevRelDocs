var a00479 =
[
    [ "geometry_id", "a00479.xhtml#a13ebd43aa2e64e88199d545f72e1dc78", null ],
    [ "indices", "a00479.xhtml#a1d1151e9535d8d02aebc90f1896d580a", null ]
];