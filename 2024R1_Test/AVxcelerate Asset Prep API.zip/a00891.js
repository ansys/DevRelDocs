var a00891 =
[
    [ "instance_id", "a00891.xhtml#aa41ed64fa64ea4c3c7ca13fe2a0ad482", null ],
    [ "node_id", "a00891.xhtml#a5097500c647119a050b46738ffed4c9c", null ],
    [ "status", "a00891.xhtml#a6f2aee56df55d154c33a3c75468eba0c", null ]
];