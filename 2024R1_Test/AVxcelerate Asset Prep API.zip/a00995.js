var a00995 =
[
    [ "id", "a00995.xhtml#a19b289334b56b658cb3657b43840d8b0", null ],
    [ "name", "a00995.xhtml#a14bc0336e9b3dd718c8040083a54080f", null ]
];