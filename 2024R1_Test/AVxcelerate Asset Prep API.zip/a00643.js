var a00643 =
[
    [ "fast_transmission_gathering", "a00643.xhtml#a458c6d4ce721bb286a76d97ae33eaefc", null ],
    [ "opaque", "a00643.xhtml#a85ac880df23a2b12609136005f07811a", null ],
    [ "optic", "a00643.xhtml#a9ffaac47255145d658acfa4ce32db176", null ],
    [ "volume_optical_library", "a00643.xhtml#a9035a558a2ff49f940f537d541e5895a", null ]
];