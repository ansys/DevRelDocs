var a01039 =
[
    [ "added_tags", "a01039.xhtml#a75f1705a712544120f6a10b7b0443861", null ],
    [ "name", "a01039.xhtml#a748469983654394f5ef26982dd553567", null ],
    [ "point_light_id", "a01039.xhtml#a0ff06cd4e2b60831800cf27a11e4a480", null ],
    [ "removed_tags", "a01039.xhtml#ae28a947c649f1dcf1169e3082de38723", null ],
    [ "transform", "a01039.xhtml#a98b359a33f79a25a7ece0521307fa0d6", null ],
    [ "visibility", "a01039.xhtml#a9c1678d285fba360811fa93db438ec7d", null ]
];