var a00263 =
[
    [ "basic_type", "a00263.xhtml#aa13df0e5033d4c9df4ccb22f7d3d6214", null ],
    [ "lighting_type", "a00263.xhtml#a083066984b198f87317c965e31708589", null ],
    [ "name", "a00263.xhtml#af14d527d971da18556a67e3bf3042b78", null ]
];