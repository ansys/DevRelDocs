var a00579 =
[
    [ "anisotropy_properties", "a00579.xhtml#aea9a02a838a8fcb2bc50597454b14f69", null ],
    [ "diffuse_properties", "a00579.xhtml#aaa641bb543ca03102ff313388da2f841", null ],
    [ "mask_properties", "a00579.xhtml#ae872ddc03132002d672b44322b1187b6", null ],
    [ "normal_properties", "a00579.xhtml#afd217df6cf948ba36550b9236ad3e33a", null ]
];