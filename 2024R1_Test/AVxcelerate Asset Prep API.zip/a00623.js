var a00623 =
[
    [ "alpha_uv_channel", "a00623.xhtml#adf5198c9a81e6b2fdc07cf666469fd69", null ],
    [ "map_id", "a00623.xhtml#ab2722cc6e9b34b717bb3810ae8897dfc", null ],
    [ "map_uv_channel", "a00623.xhtml#ae37f291ecc697b1670a1c4be77fda4c0", null ]
];