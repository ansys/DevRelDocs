var a00235 =
[
    [ "bytes", "a00235.xhtml#a6fcf376385b42bc7173fef266a96c4d1", null ],
    [ "metadata", "a00235.xhtml#a1f3393d4fdd72a3b06b921ef21e60af8", null ]
];