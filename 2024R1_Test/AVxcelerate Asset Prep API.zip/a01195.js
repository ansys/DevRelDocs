var a01195 =
[
    [ "x", "a01195.xhtml#a7bcfefdfe8ffeef8f5e55c74e2cabbdb", null ],
    [ "y", "a01195.xhtml#a1c62ccc2d2dcb018aa24804fabcaf7cd", null ]
];