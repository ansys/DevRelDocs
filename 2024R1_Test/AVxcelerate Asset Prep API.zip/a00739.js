var a00739 =
[
    [ "near_clip", "a00739.xhtml#a8ecb1b929912c4781e642cef97f9c624", null ],
    [ "shadows_offset_ratio", "a00739.xhtml#adf32f8f1e95f45c1d55c414a0915dac0", null ],
    [ "softness", "a00739.xhtml#aeab20e9829bf70d8741371b026c311d8", null ]
];