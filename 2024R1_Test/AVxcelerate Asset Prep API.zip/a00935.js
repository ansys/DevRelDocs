var a00935 =
[
    [ "instance_id", "a00935.xhtml#aca263e81a6f2b6f9057e5318b58ae167", null ],
    [ "node_id", "a00935.xhtml#a64e31f0f3d08ff5b628b976135de5ff9", null ],
    [ "properties", "a00935.xhtml#aa76348d424315bd223b3d60688a8769a", null ]
];