var a00519 =
[
    [ "CreateMaterial", "a00519.xhtml#a32e32744719dbd7284a6dac7e67d963f", null ],
    [ "DeleteMaterial", "a00519.xhtml#a5f333649bf99fd1d0cf2ab1b5bb3ea90", null ],
    [ "GetMaterial", "a00519.xhtml#a26a9aec2e59065876e780dec46eb3b26", null ],
    [ "ListMaterials", "a00519.xhtml#adb26213ceb3dcac649863c195e9c055e", null ],
    [ "UpdateMaterial", "a00519.xhtml#ab7ef2d7aba7aedcc927e67da39f12446", null ]
];