var a00743 =
[
    [ "angular_precision", "a00743.xhtml#ace249a7a63c7b28db514924b648fed0a", null ],
    [ "diagram_library", "a00743.xhtml#a7c1649faf4a771f9fb024eca61fcc2dd", null ],
    [ "flux", "a00743.xhtml#ae9b16bfd84bf916d15b9e3d9b9989399", null ],
    [ "gaussian", "a00743.xhtml#a1ac0a2c8fb794c4e0125f31430f7e1d9", null ],
    [ "isotropic", "a00743.xhtml#a47d4650bd835fed5c035917b1335100a", null ],
    [ "lambertian", "a00743.xhtml#a76c61bc812a34b19b2a6b6632646061e", null ]
];