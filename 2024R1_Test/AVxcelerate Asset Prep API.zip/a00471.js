var a00471 =
[
    [ "geometry_id", "a00471.xhtml#a7577a41609cacac8c4b0384b3514a5af", null ],
    [ "vertices", "a00471.xhtml#a5daad68b228e3e24051609dae517c651", null ]
];