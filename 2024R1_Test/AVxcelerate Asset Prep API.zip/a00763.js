var a00763 =
[
    [ "spectrum_id", "a00763.xhtml#a3740ad341bafcab25968249d1aa32df9", null ]
];