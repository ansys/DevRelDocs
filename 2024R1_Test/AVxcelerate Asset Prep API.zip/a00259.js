var a00259 =
[
    [ "id", "a00259.xhtml#afc8f44d8cde7b894cfd4a94483b8b7c6", null ],
    [ "irradiance_map_id", "a00259.xhtml#a73e7d89d14b15dd165e51ebfef17ce2c", null ],
    [ "label", "a00259.xhtml#abf840423156ad2d1dfc353f059a0ab28", null ],
    [ "name", "a00259.xhtml#a21e77dd27f8a405c2edfb00b43b98a1e", null ],
    [ "position", "a00259.xhtml#a2c0864aed82f04ab1a93efac86bd3d6c", null ]
];