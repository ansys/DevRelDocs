var a00783 =
[
    [ "identifier", "a00783.xhtml#aef99b21cb47338e8c9562b3e3ebfdd82", null ],
    [ "type", "a00783.xhtml#a7f883162eafa6075d9a54de30ff99dd0", null ]
];