var a00228 =
[
    [ "DeleteResourceRequest", "a00803.xhtml", "a00803" ],
    [ "DeleteResourceResponse", "a00807.xhtml", "a00807" ],
    [ "DownloadResourceAsChunksRequest", "a00783.xhtml", "a00783" ],
    [ "DownloadResourceAsFileRequest", "a00787.xhtml", "a00787" ],
    [ "DownloadResourceAsFileResponse", "a00791.xhtml", "a00791" ],
    [ "ListResourcesRequest", "a00795.xhtml", "a00795" ],
    [ "ListResourcesResponse", "a00799.xhtml", "a00799" ],
    [ "ResourceIdentity", "a00811.xhtml", "a00811" ],
    [ "ResourcePreparation", "a00775.xhtml", "a00775" ],
    [ "UploadResourceResponse", "a00779.xhtml", "a00779" ]
];