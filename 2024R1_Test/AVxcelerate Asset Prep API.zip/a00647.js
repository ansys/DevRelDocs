var a00647 =
[
    [ "absorption", "a00647.xhtml#a8b6fc4a2a75b7a3a89eec5e6e1aa8b64", null ],
    [ "constringency", "a00647.xhtml#a2fb401132b662bf1bf323de66cb5ca67", null ],
    [ "refractive_index", "a00647.xhtml#a60c8b7622749f22a33e3e344120d5791", null ]
];