var a01115 =
[
    [ "hours", "a01115.xhtml#a3b4c134cbb3d1c922911836a20e200fe", null ],
    [ "minutes", "a01115.xhtml#af54947dd2f570419cf7da0d9e9cca8fe", null ]
];