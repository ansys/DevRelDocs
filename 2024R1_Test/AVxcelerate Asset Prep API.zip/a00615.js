var a00615 =
[
    [ "map_id", "a00615.xhtml#ababab13148701b89ab7caf54c4b93aae", null ],
    [ "map_uv_channel", "a00615.xhtml#a17f5dc6c2f9a850ab877c99947323961", null ]
];