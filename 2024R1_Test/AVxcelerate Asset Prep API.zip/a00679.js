var a00679 =
[
    [ "blue", "a00679.xhtml#a0979ccb54ee670faab5bbd530f7c79cc", null ],
    [ "green", "a00679.xhtml#a66e2da31e84f9aa1166c5bdfc24ecc02", null ],
    [ "red", "a00679.xhtml#a78cebd9fc7502d68c2781b9650844bff", null ]
];