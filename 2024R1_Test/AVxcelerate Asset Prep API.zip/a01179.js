var a01179 =
[
    [ "angular_precision", "a01179.xhtml#a556cdd9635335f5be5bb3deadcc88d8f", null ],
    [ "black_body", "a01179.xhtml#ab7e6a44883ae5dd35bc7958679e61f8c", null ],
    [ "diagram_library", "a01179.xhtml#ae4868e615d2ab7d6589e7d188a261086", null ],
    [ "exitance", "a01179.xhtml#a7dce324caeb8daf4ee7a8cfb353b90b5", null ],
    [ "gaussian", "a01179.xhtml#af4d0d69d18d6f71c7137cbb034cbdfe6", null ],
    [ "lambertian", "a01179.xhtml#aee87b18ab0244e6681d9d4ed49ae8aa4", null ],
    [ "lighting_contribution", "a01179.xhtml#aea59ead432013d8e343040bd36fa2fb3", null ],
    [ "monochromatic", "a01179.xhtml#a77429dcc1cc1acb7680895699519eb9c", null ],
    [ "no_contribution", "a01179.xhtml#aab4369655b04e76aab358b99c86f03b2", null ],
    [ "reverse_direction", "a01179.xhtml#a3ae4805490095102dcdb326350b6c19d", null ],
    [ "spectrum_library", "a01179.xhtml#aeda7e42221316be40f014f0184c345ea", null ]
];