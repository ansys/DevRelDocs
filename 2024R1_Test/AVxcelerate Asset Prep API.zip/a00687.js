var a00687 =
[
    [ "CreatePointLight", "a00687.xhtml#a774ce36a9d3c99980c8c640a3e65e43a", null ],
    [ "DeletePointLight", "a00687.xhtml#a18e138cc6cc58fd770b6e87602246491", null ],
    [ "GetPointLight", "a00687.xhtml#a5b6cf35291a66cd17526391d8769b7f2", null ],
    [ "ListPointLights", "a00687.xhtml#abc04d29583afd3b7a5ed41f877ffc903", null ],
    [ "UpdatePointLight", "a00687.xhtml#a4f0d5cb7a4ed71649da0fdf07bd250fd", null ]
];