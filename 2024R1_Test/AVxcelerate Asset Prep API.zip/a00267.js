var a00267 =
[
    [ "CreateDirectionalLight", "a00267.xhtml#aa296700e9853289e6234a0418384dfac", null ],
    [ "DeleteDirectionalLight", "a00267.xhtml#a4ad9bdb3b482e9af510dbfd8838bedaf", null ],
    [ "GetDirectionalLight", "a00267.xhtml#a853be44d84481e223792c403fb4f91d7", null ],
    [ "ListDirectionalLights", "a00267.xhtml#a0cb9df1fb536c5a61203064aca324819", null ],
    [ "UpdateDirectionalLight", "a00267.xhtml#afad1e0ff341f0050f0d8416fca096ac9", null ]
];