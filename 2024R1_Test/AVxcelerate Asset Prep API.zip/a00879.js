var a00879 =
[
    [ "id", "a00879.xhtml#adedc9b3b8a58c4e9dcfc7da0bb0f841e", null ],
    [ "node_id", "a00879.xhtml#a2f93482acd5033fd17b70d3f9350748e", null ],
    [ "scene_tree_id", "a00879.xhtml#a07b3d96fc1effacba30eefbbcceebf7f", null ]
];