var a01111 =
[
    [ "ambient_factor", "a01111.xhtml#a288e26b4d1e836d2eb8e4becd53aff1f", null ],
    [ "ground_radius", "a01111.xhtml#a55cbfe2140a434aff80af3a7564464af", null ],
    [ "luminance_factor", "a01111.xhtml#a8a5e1c882055fb393c4b4fba472a83ae", null ],
    [ "orientation", "a01111.xhtml#a6a7095158ae77e3f2e453a283661d2e4", null ],
    [ "projection_type", "a01111.xhtml#ad933fd18c0916b9128354661f4af9dea", null ],
    [ "texture_id", "a01111.xhtml#a6463e7d7d53a6ca1cecfee1c9f52accb", null ]
];