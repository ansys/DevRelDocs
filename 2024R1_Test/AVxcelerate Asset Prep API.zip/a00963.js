var a00963 =
[
    [ "id", "a00963.xhtml#a6da0ca99ef27ad71a50520887f6da3a3", null ],
    [ "properties", "a00963.xhtml#af40fe321b59fedfb0e5b77d4b3fb8346", null ],
    [ "status", "a00963.xhtml#acd8805b5f58e207f9042e4455d5fa31c", null ]
];