var a00251 =
[
    [ "code", "a00251.xhtml#aacf515be981953c34e4c319c94d68a5a", null ],
    [ "feedback_message", "a00251.xhtml#aa6c57936fded500442e074b215d46caa", null ],
    [ "level", "a00251.xhtml#ab1bf965123e9621bd3e2b44a177ea6e2", null ]
];