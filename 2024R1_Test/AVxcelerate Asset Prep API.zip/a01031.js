var a01031 =
[
    [ "directional_light_id", "a01031.xhtml#ab09f083737de582b4b8700ae855365e7", null ],
    [ "name", "a01031.xhtml#ace3e2c499f7d1fa4d4275170cd4618cf", null ],
    [ "transform", "a01031.xhtml#a9c1cb8335cc5e637c190ca44a0f3263d", null ],
    [ "visibility", "a01031.xhtml#af0960be368e0d89cd86383bbc709679d", null ]
];