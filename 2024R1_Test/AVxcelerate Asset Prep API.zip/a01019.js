var a01019 =
[
    [ "custom_temperature", "a01019.xhtml#ae00a2a9029d6f61de4a443a886a80fb2", null ],
    [ "no_custom_temperature", "a01019.xhtml#a1110356befa96f1298846a6a020385da", null ]
];