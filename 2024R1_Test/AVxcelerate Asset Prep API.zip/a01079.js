var a01079 =
[
    [ "id", "a01079.xhtml#abc5d62e1cf6387623f25fa12a055945f", null ],
    [ "properties", "a01079.xhtml#acf5c691cf0a0bbe80c5e4f45a47e1320", null ]
];