var a01071 =
[
    [ "id", "a01071.xhtml#a58fa6063b0424d9e108def66056197be", null ],
    [ "properties", "a01071.xhtml#a1c79edaf7f2db2e53c2f658d51a49d61", null ],
    [ "status", "a01071.xhtml#aa4626e60ff5f978a2cd362415e9bf7b4", null ]
];