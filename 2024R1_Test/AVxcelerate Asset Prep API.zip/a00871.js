var a00871 =
[
    [ "id", "a00871.xhtml#a9d81ec145c500a9153b69f7b5a13f6aa", null ],
    [ "node_id", "a00871.xhtml#adcd002ee94c339c7ff0c78be2a6540e6", null ],
    [ "properties", "a00871.xhtml#a576be2006d48620fddc98f9bb2b2fe46", null ],
    [ "scene_tree_id", "a00871.xhtml#a484669d91f89a199b06d6349b0d8254a", null ]
];