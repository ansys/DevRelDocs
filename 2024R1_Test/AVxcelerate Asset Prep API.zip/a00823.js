var a00823 =
[
    [ "id", "a00823.xhtml#a6c176a2e8e53316d251d7e39b1cb6df8", null ],
    [ "status", "a00823.xhtml#ae55cb34d829d6838f067d102411fe7af", null ]
];