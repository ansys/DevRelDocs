var a00487 =
[
    [ "id", "a00487.xhtml#aa30b16ebe7eb0452f5b3a76c584e78e3", null ],
    [ "name", "a00487.xhtml#a8f03ba9ba0bccc72572ba27d6187370f", null ]
];