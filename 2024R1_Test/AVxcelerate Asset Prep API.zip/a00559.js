var a00559 =
[
    [ "id", "a00559.xhtml#a55a899c36cd787bac0c2678a7519bff3", null ],
    [ "name", "a00559.xhtml#ac3ff638504d2af5af0cb9786e564c8c9", null ]
];