var a00867 =
[
    [ "directional_light_instances", "a00867.xhtml#a24cc0ac9c4527cee3a56874be075cb2a", null ],
    [ "geometry_instances", "a00867.xhtml#a98ec48090f0555cf480a16f4b9f962b4", null ],
    [ "id", "a00867.xhtml#a0a81d3c4a054663dda234f6ab9c04234", null ],
    [ "nodes", "a00867.xhtml#a09204a7db29e3f69a8bc125fd85616c9", null ],
    [ "point_light_instances", "a00867.xhtml#ae4de25f66b2aed533cffd8de5efd59b8", null ],
    [ "properties", "a00867.xhtml#a21d456fdd6e1cfc6b621a346f83be056", null ],
    [ "status", "a00867.xhtml#ac0bc01f4e4bb783edaeea8c4f297afe3", null ]
];