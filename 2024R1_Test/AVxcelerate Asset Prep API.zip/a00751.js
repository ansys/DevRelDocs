var a00751 =
[
    [ "x", "a00751.xhtml#a0104921bd6f7427a49b852cfd5475ad0", null ],
    [ "y", "a00751.xhtml#aa21b4e2bea7c5cf0c60f2b8bcb9a04cd", null ]
];