var a00319 =
[
    [ "black_body", "a00319.xhtml#a5453df3ba46ea6101d0af26fe466ea32", null ],
    [ "monochromatic", "a00319.xhtml#ae855509540c1a93cf1f98b71f8935af8", null ],
    [ "power", "a00319.xhtml#ab5d2215e940800f2fdec158a6e7ee235", null ],
    [ "spectrum_library", "a00319.xhtml#acc7d1dd0fa0f0b04f75cf376c37a429b", null ]
];