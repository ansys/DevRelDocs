var a00443 =
[
    [ "geometry_id", "a00443.xhtml#a48dd1c564668d8808c5553a0bfcca3d5", null ],
    [ "material_part_id", "a00443.xhtml#a521d03d76dabf8d9cd51789e4b0f3a47", null ],
    [ "status", "a00443.xhtml#af5f3d414bd3c4c6f8886798c2a9ec303", null ]
];