var a00495 =
[
    [ "id", "a00495.xhtml#ab62465dde33ba33eb2e3feb67c2a5fa3", null ],
    [ "name", "a00495.xhtml#a9f385591f213aa9e349130ee18efcad4", null ]
];