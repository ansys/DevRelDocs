var a00955 =
[
    [ "instance_id", "a00955.xhtml#a84612a771b8207bb361701df31e83ddd", null ],
    [ "node_id", "a00955.xhtml#ac2ae972fcd7e4d785f7369ef5a98022a", null ],
    [ "status", "a00955.xhtml#ad5f71c08bcf060d9283eefc6a4f86bab", null ]
];