var a01203 =
[
    [ "disjoint_surfaces", "a01203.xhtml#a8e07058abc4a38c3fa311a28148e33c3", null ],
    [ "dynamic_shadows", "a01203.xhtml#ae891ce903d496021068b66b03138721a", null ],
    [ "no_shadow", "a01203.xhtml#a3e74d7a1657c08e305c468413e400506", null ],
    [ "orientation_offset", "a01203.xhtml#a2e5215b48cdd584277d47727f69bf09a", null ],
    [ "position_offset", "a01203.xhtml#a95d2116197808165b5cc6fbec8848512", null ],
    [ "rendering", "a01203.xhtml#a6e791dfce2477b199e6b69aad7ef303f", null ],
    [ "static_shadows", "a01203.xhtml#a1b9bb575ec98925623c927552e8e44e1", null ]
];