var a00347 =
[
    [ "id", "a00347.xhtml#a257a4855d9bdd01a428f586299adc60a", null ],
    [ "status", "a00347.xhtml#af393ab0165f1c286daebe59acc601ae9", null ]
];