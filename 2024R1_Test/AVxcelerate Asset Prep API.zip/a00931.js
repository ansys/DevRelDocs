var a00931 =
[
    [ "id", "a00931.xhtml#a23ea96c75f6d2aa1f51c1d0baaeb9aa8", null ],
    [ "properties", "a00931.xhtml#a22f674c473dd5cc11d88e8077af33caa", null ],
    [ "status", "a00931.xhtml#a2bb1e46633bda65877f35d9c69e45852", null ]
];