var a00683 =
[
    [ "hue", "a00683.xhtml#aa21b6b6f65121662151a3a269b7273e5", null ],
    [ "saturation", "a00683.xhtml#a334e7bc952995ddef89ff4856eb69a5b", null ],
    [ "value", "a00683.xhtml#a50e014c9b1db1c6814676570aada12a8", null ]
];