var a00607 =
[
    [ "intensity", "a00607.xhtml#a379b7ae8978548efb409a67ec1222249", null ],
    [ "map_id", "a00607.xhtml#adcf51eb7bcffeae2374c4ba2aba27abf", null ],
    [ "map_uv_channel", "a00607.xhtml#acc5704b4d8a9ece9063940cab3548fe0", null ]
];