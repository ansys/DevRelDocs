var a00923 =
[
    [ "instance_id", "a00923.xhtml#a6959db1c02ec0d422385267b2b4ee0f4", null ],
    [ "node_id", "a00923.xhtml#a9635b692672e72e610213b3210110f39", null ],
    [ "status", "a00923.xhtml#ae8364a1a6c892d893362a4a2ccf83085", null ]
];