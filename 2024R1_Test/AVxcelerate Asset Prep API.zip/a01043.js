var a01043 =
[
    [ "euler_angles", "a01043.xhtml#adfd5ee803d5e054d1767396bf4b6ae5e", null ],
    [ "quaternion", "a01043.xhtml#a7c5b5d4d83575bacb05dbfdbed944038", null ],
    [ "relativity", "a01043.xhtml#a53ad73a758402e74421b16c4172aab45", null ],
    [ "x_position", "a01043.xhtml#a5f47b177ba05b68359bc15e82ed4d8d8", null ],
    [ "x_scale", "a01043.xhtml#ae377363e695a367b2f2d150da02bba9f", null ],
    [ "y_position", "a01043.xhtml#a74b8dddf1543f283fc81f3432e64aba9", null ],
    [ "y_scale", "a01043.xhtml#a5fd3722a863338f2e2348534e284dd59", null ],
    [ "z_position", "a01043.xhtml#a00f6169d9630e6400d2e37d4c3708aa4", null ],
    [ "z_scale", "a01043.xhtml#ab7d9de883fb73a6919642c7a78da763f", null ]
];