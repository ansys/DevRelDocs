var a00323 =
[
    [ "near_field_precision", "a00323.xhtml#a861f3b017d761d554b81f05ccfa9f395", null ],
    [ "resolution", "a00323.xhtml#a01e915b114f7781dcdc88fbe7d90fc9e", null ],
    [ "shadow_offset_ratio", "a00323.xhtml#a44dbc0d7b0fd306ec4055665f689c854", null ],
    [ "shadow_radius", "a00323.xhtml#a171dbf4c4a806d5cf1e1b408d0a747af", null ],
    [ "softness", "a00323.xhtml#afa9648f00cb3b6c9a4bcb424ed15d32d", null ]
];