var a00951 =
[
    [ "node_id", "a00951.xhtml#afa2a79333110714f5b2cd5c6f3bd9fe2", null ],
    [ "properties", "a00951.xhtml#ab985bce9353d27ca2d8601003f3e7848", null ]
];