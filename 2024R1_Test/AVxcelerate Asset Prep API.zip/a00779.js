var a00779 =
[
    [ "identity", "a00779.xhtml#ad050f6771c11ab224252f009be3bcef3", null ],
    [ "status", "a00779.xhtml#aab5c91d660d4ed2e56b81c4aacfbad57", null ]
];