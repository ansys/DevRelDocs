var a00611 =
[
    [ "color", "a00611.xhtml#a1ad3aa2eadad14d516dae336d36decc7", null ],
    [ "texture", "a00611.xhtml#a9d7854d013f0ff5616ba1400873b604b", null ]
];