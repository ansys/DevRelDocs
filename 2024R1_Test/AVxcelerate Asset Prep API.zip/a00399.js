var a00399 =
[
    [ "CreateGeometry", "a00399.xhtml#a9bba536fd0962bb1699cce1e05fe99cd", null ],
    [ "CreateMaterialPart", "a00399.xhtml#a5c0ac5463957c13cee1962d0d40ab9d2", null ],
    [ "DeleteGeometry", "a00399.xhtml#a49e23157ca272ba1d4b0c0dd24d9c5e8", null ],
    [ "DeleteMaterialPart", "a00399.xhtml#af89381abf548baa5f6344e185295dcfb", null ],
    [ "GetGeometry", "a00399.xhtml#a66e62bc447cf636d529705884f168e0f", null ],
    [ "GetMaterialPart", "a00399.xhtml#a10d373756988e454d24b579a6eb75888", null ],
    [ "ListGeometries", "a00399.xhtml#a02c2c25976e39ca0192ebe5a3113fe7d", null ],
    [ "PushIndices", "a00399.xhtml#a77dc7aa3ccce03d3d4f6059aa0927397", null ],
    [ "PushVertices", "a00399.xhtml#a70b280a3cef2d4e9e3fc672d82d00945", null ],
    [ "UpdateGeometry", "a00399.xhtml#a2d92b588a4bdbe8d8d9fa48757037056", null ],
    [ "UpdateMaterialPart", "a00399.xhtml#ad14dc354ac20ec521bc7451aa5c27f96", null ]
];