var a01223 =
[
    [ "wavelength", "a01223.xhtml#addf490435fe7e441975f5389e7e7de7c", null ]
];