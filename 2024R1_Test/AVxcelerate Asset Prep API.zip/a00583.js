var a00583 =
[
    [ "anisotropy_properties", "a00583.xhtml#a4c14985239a12456483ff5dcc3637810", null ],
    [ "diffuse_properties", "a00583.xhtml#ac11509c90367dc04c4f2b2837bb30d16", null ],
    [ "mask_properties", "a00583.xhtml#a7a7943f7c4b2f0533ad654dba77810ca", null ],
    [ "normal_properties", "a00583.xhtml#a26725b57917350420ee40cf5b396ec9f", null ],
    [ "reflectivity", "a00583.xhtml#aec3420ba7f40c48fb55d5617710c100b", null ]
];