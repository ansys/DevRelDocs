var a00255 =
[
    [ "basic_type", "a00255.xhtml#a66f20df7367bd5b9b18e8596d9521be6", null ],
    [ "lighting_type", "a00255.xhtml#a08c785b4c528be59623ebb863e4da415", null ],
    [ "properties", "a00255.xhtml#af5fb9b507c323363cc8ca65348dc8d0d", null ]
];