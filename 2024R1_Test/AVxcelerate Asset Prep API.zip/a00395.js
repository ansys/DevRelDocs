var a00395 =
[
    [ "active_sky", "a00395.xhtml#ad3a5a0fe2abf2134c532ff366451fb33", null ],
    [ "added_skies", "a00395.xhtml#a8601d8a32f2addde61c2abba0e2251e9", null ],
    [ "name", "a00395.xhtml#a7f1ce22d2b1b8762ca653ddded4efc76", null ],
    [ "removed_skies", "a00395.xhtml#a5ed134d1ae4e5f2c7f36689da49a3ba4", null ],
    [ "scene_tree", "a00395.xhtml#a64a0164272b474bc7a528c276261fa8c", null ]
];