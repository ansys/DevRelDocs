var a00603 =
[
    [ "color", "a00603.xhtml#ab263ca4331befd41aeece4a828281ba6", null ],
    [ "texture", "a00603.xhtml#a06cc7089df190c97a6624c76666a4bc6", null ]
];