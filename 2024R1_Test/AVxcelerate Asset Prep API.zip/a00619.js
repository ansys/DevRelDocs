var a00619 =
[
    [ "color_hsv", "a00619.xhtml#a028d9ce67a8ef834531bbcb180994881", null ],
    [ "color_rgb", "a00619.xhtml#a64f010b47b8afec9f2ba6f976b30f777", null ],
    [ "texture", "a00619.xhtml#ac2e79c23cb9a057c5b4fb4e97dd235fb", null ]
];