var a00311 =
[
    [ "custom", "a00311.xhtml#a6f73dbbd2d18d41d6e2e299cd4074085", null ],
    [ "dynamic_accurate_shadows", "a00311.xhtml#a16024101a798b135c00ea65742c98af3", null ],
    [ "name", "a00311.xhtml#a9c4c339b5d8bc939956f693bfcce5780", null ],
    [ "no_shadow", "a00311.xhtml#a25e4a826638d6589401e239e959d4a91", null ],
    [ "sun", "a00311.xhtml#acba548733008e6263849e7ab6a3ab812", null ]
];