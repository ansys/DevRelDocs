var structensightservice_1_1_anim_query_progress_request =
[
    [ "cancel", "structensightservice_1_1_anim_query_progress_request.xhtml#a73eee2f395467b3961eef8422ee0fc06", null ],
    [ "id", "structensightservice_1_1_anim_query_progress_request.xhtml#af373d49350a69dd84c35f4bdf3bca2bf", null ]
];