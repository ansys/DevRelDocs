var group__group__dvs__data__model_dvs_data_model_dup =
[
    [ "DVS Data Model Overview", "group__group__dvs__data__model.xhtml#dvs_data_model_overview", null ],
    [ "DVS Ranks and Chunks", "group__group__dvs__data__model.xhtml#dvs_ranks_chunks", null ],
    [ "DVS Zoo Element Definitions", "group__group__dvs__data__model.xhtml#dvs_elements", null ]
];