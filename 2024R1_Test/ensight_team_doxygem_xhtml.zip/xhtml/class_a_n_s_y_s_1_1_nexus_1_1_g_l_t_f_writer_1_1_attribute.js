var class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute =
[
    [ "AttributeType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddb", [
      [ "AT_INT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba61b89340f40b606720433dcd8da573e4", null ],
      [ "AT_FLOAT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba6d124c894e5bdc043eeebec0f852e857", null ],
      [ "AT_FLOAT_VEC2", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddbaed110dc9dd248a0a28797e7a6763cf6a", null ],
      [ "AT_FLOAT_VEC3", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba0e6049e71b78dccf0f7f9791abe541c3", null ],
      [ "AT_FLOAT_VEC4", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba5af14585a5eb16f52089b1baf55db718", null ],
      [ "AT_FLOAT_MAT4", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba13e136aa2ada6dbe9a5253695b6abf65", null ]
    ] ],
    [ "~Attribute", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#ae4febdec4e1f68a2b051d53460c44bf9", null ],
    [ "SetLogarithmic", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#ae5dd11c515ff409ca74e94693f2d1585", null ],
    [ "SetMinMax", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#a1d3b6de1515034297d22160fc84edcfd", null ],
    [ "SetMinMax", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#ae56748a9592c0ecdc8c933e2068f5a9f", null ]
];