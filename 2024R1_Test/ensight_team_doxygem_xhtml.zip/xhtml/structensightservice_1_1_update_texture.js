var structensightservice_1_1_update_texture =
[
    [ "TextureFormat", "structensightservice_1_1_update_texture.xhtml#ad2a6342613ada16aa3484548ba964889", [
      [ "RGB", "structensightservice_1_1_update_texture.xhtml#ad2a6342613ada16aa3484548ba964889ae0e721d846808e077a0ca68c88fa20f9", null ],
      [ "RGBA", "structensightservice_1_1_update_texture.xhtml#ad2a6342613ada16aa3484548ba964889aa3f0de047893cf830b6dc4a142151f2e", null ]
    ] ],
    [ "format", "structensightservice_1_1_update_texture.xhtml#aeeab37c4b13729da0f33b95e5b479d25", null ],
    [ "hash", "structensightservice_1_1_update_texture.xhtml#a77a50c661bd0b3eb1d7c9814cd046ded", null ],
    [ "height", "structensightservice_1_1_update_texture.xhtml#aa1e144f705e33bd9d96d2e15bcd6e9e7", null ],
    [ "id", "structensightservice_1_1_update_texture.xhtml#af496b2a924971f081cbfef9915e0ea3e", null ],
    [ "parent_id", "structensightservice_1_1_update_texture.xhtml#a508115e6ce403414933c692698e26b2b", null ],
    [ "texels", "structensightservice_1_1_update_texture.xhtml#a70a85aa4869aab5dd34af3bc0e226b3f", null ],
    [ "width", "structensightservice_1_1_update_texture.xhtml#a2a421dfc3b0431e38ed9b2d988de3420", null ]
];