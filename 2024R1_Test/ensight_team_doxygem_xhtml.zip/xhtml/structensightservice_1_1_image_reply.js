var structensightservice_1_1_image_reply =
[
    [ "CompressionType", "structensightservice_1_1_image_reply.xhtml#a9bfd8548c69ab349c9e3a25f1301014f", [
      [ "NONE", "structensightservice_1_1_image_reply.xhtml#a9bfd8548c69ab349c9e3a25f1301014fa2617c314c1b65a7be10501baac8af39e", null ]
    ] ],
    [ "compression", "structensightservice_1_1_image_reply.xhtml#adbf4e4047fda62f949053243c236810e", null ],
    [ "final", "structensightservice_1_1_image_reply.xhtml#aacf31b61824c9e3bc57f002d5a7ea640", null ],
    [ "height", "structensightservice_1_1_image_reply.xhtml#a458d8f403ce40efee41992b095dfa977", null ],
    [ "pixels", "structensightservice_1_1_image_reply.xhtml#a27bb77c84bb8f94477b341dd4f669842", null ],
    [ "width", "structensightservice_1_1_image_reply.xhtml#a27122c861af05800091d1100186a84f3", null ]
];