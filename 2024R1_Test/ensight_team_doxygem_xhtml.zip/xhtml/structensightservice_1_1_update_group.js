var structensightservice_1_1_update_group =
[
    [ "attributes", "structensightservice_1_1_update_group.xhtml#aaad1709ec0adb4af890bbf63e81cd673", null ],
    [ "hash", "structensightservice_1_1_update_group.xhtml#a1c833986aaea9d12f310c5b739424148", null ],
    [ "id", "structensightservice_1_1_update_group.xhtml#a4b06508d1f2c67eed03e08761c4ffc70", null ],
    [ "matrix4x4", "structensightservice_1_1_update_group.xhtml#a59de9866a1bb62fa95f4171d0e4a6fd4", null ],
    [ "name", "structensightservice_1_1_update_group.xhtml#a2a58f9e6568b11df1cae46a0cb52644a", null ],
    [ "parent_id", "structensightservice_1_1_update_group.xhtml#aca9ddd6ca9436d5ae2c30a7ba9330512", null ]
];