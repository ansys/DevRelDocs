var class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler =
[
    [ "FilterType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2", [
      [ "FT_NEAREST", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2a6939890bb36dae2b7400ec07dda505a3", null ],
      [ "FT_LINEAR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2a540209ea328f7641ded2ef95340a4df6", null ],
      [ "FT_NEAREST_MIPMAP_NEAREST", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2a3ca339eb7d704e0df6a5a70a56e38a9d", null ],
      [ "FT_LINEAR_MIPMAP_NEAREST", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2adaf913049a73b76f655fee7017fd9735", null ],
      [ "FT_NEAREST_MIPMAP_LINEAR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2af04c2a7d89ec1932406044358213053f", null ],
      [ "FT_LINEAR_MIPMAP_LINEAR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2aeecfdb00bdb01409d41812961fca2ad8", null ]
    ] ],
    [ "WrapType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a0be78b3605d660441f31d5a90e463443", [
      [ "WT_REPEAT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a0be78b3605d660441f31d5a90e463443a75e8a28a9d155e09ff6b697429fa7a6e", null ],
      [ "WT_CLAMP_TO_EDGE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a0be78b3605d660441f31d5a90e463443a9edafbff43bdb6b2e77fab3fd1b545aa", null ],
      [ "WT_MIRRORED_REPEAT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a0be78b3605d660441f31d5a90e463443ab8da208d3e57f59504472b848fc24952", null ]
    ] ],
    [ "~Sampler", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a7fe992a1ce54447440a20d9b6a755d98", null ]
];