var structensightservice_1_1_scene_client_init =
[
    [ "allow_incremental_updates", "structensightservice_1_1_scene_client_init.xhtml#af86e19a41881498e54c38c6e75aa0c76", null ],
    [ "allow_spontaneous", "structensightservice_1_1_scene_client_init.xhtml#af8d24ffa4b58dc110e12f89f677c83f0", null ],
    [ "include_temporal_geometry", "structensightservice_1_1_scene_client_init.xhtml#aa76dee20a520300fa4fba143f7bf7d05", null ],
    [ "maximum_chunk_size", "structensightservice_1_1_scene_client_init.xhtml#a628ea445b5f241ed67b8cd1010b91c16", null ]
];