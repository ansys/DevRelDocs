var group___en_sight_subscription =
[
    [ "PublishEvent", "group___en_sight_subscription.xhtml#gaaded4bebe805118acaa44365183c2586", null ],
    [ "PublishImage", "group___en_sight_subscription.xhtml#ga052334cb4098295f08b649151eb24320", null ]
];