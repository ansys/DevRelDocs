var group__group__dvs__uri_dvs_uri_dup =
[
    [ "URI Overview", "group__group__dvs__uri.xhtml#dvs_uri_overview", null ],
    [ "Server URIs", "group__group__dvs__uri.xhtml#dvs_server_uri", null ],
    [ "Cache URIs", "group__group__dvs__uri.xhtml#dvs_cache_uri", [
      [ "Cache URI Domain", "group__group__dvs__uri.xhtml#dvs_cache_uri_domain", null ],
      [ "Cache URI Hostname/Port", "group__group__dvs__uri.xhtml#dvs_cache_uri_hostname", null ],
      [ "Cache URI Path", "group__group__dvs__uri.xhtml#dvs_cache_uri_path", null ],
      [ "Cache URI Options", "group__group__dvs__uri.xhtml#dvs_cache_uri_options", null ],
      [ "Cache URI Examples", "group__group__dvs__uri.xhtml#dvs_cache_uri_example", null ],
      [ "Cache Compression", "group__group__dvs__uri.xhtml#dvs_cache_compression", null ]
    ] ]
];