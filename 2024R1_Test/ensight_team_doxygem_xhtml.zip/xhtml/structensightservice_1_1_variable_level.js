var structensightservice_1_1_variable_level =
[
    [ "alpha", "structensightservice_1_1_variable_level.xhtml#a6d406e152cb6f786900e21ba6819567a", null ],
    [ "blue", "structensightservice_1_1_variable_level.xhtml#a805baa0b7821ec1ceeba2ae6095911d3", null ],
    [ "green", "structensightservice_1_1_variable_level.xhtml#a327318940a4765a749e93425bb09a39c", null ],
    [ "red", "structensightservice_1_1_variable_level.xhtml#aa9bb1e96e7f011a89af624dca154ee1e", null ],
    [ "value", "structensightservice_1_1_variable_level.xhtml#af281887e8328145a817abdac740998b2", null ]
];