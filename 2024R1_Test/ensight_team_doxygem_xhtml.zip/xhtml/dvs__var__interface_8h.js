var dvs__var__interface_8h =
[
    [ "IVar", "class_d_v_s_1_1_i_var.xhtml", "class_d_v_s_1_1_i_var" ],
    [ "VAR_TYPE", "dvs__var__interface_8h.xhtml#a84856d33cb231d1d87a603758b8b8066", [
      [ "FLOAT", "dvs__var__interface_8h.xhtml#a84856d33cb231d1d87a603758b8b8066ae738c26bf4ce1037fa81b039a915cbf6", null ],
      [ "INT64", "dvs__var__interface_8h.xhtml#a84856d33cb231d1d87a603758b8b8066a4e866b275c85fbb439f6484251cfb31c", null ]
    ] ]
];