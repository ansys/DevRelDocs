var class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f =
[
    [ "GLTFError", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafe", [
      [ "GLTF_ERROR_NONE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea049c3b804e69ae05c02f4c2dedf4e0ea", null ],
      [ "GLTF_ERROR_DUPLICATE_VALUE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea97ced97a4c4799ac0434f89a04806113", null ],
      [ "GLTF_ERROR_INCOMPATIBLE_VALUE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea4b4a18acdadcea64ac7afdc249170318", null ],
      [ "GLTF_ERROR_INVALID_PATH", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea1afb281a63002ee2c8a668422eccd5c0", null ],
      [ "GLTF_ERROR_INVALID_TARGET", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea7cf97ea67f80ee2bcdfcb9cfab7095c7", null ],
      [ "GLTF_ERROR_INVALID_TYPE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea59ad81f97b600a6e8c960411ed67496a", null ],
      [ "GLTF_ERROR_INVALID_VALUE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea382e97e558c7245031b324d4b91ab5f4", null ],
      [ "GLTF_ERROR_MEMORY", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafead705f5ff45e81718b44e3310b82a57ff", null ],
      [ "GLTF_ERROR_RANGE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafeaa983770c4317af7082d25f68c006e213", null ],
      [ "GLTF_ERROR_READ", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafead5336526c4f7a3cb42cb89bce88133f6", null ],
      [ "GLTF_ERROR_SIZE_MISMATCH", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafeae3bd2b97e6b41436340e0dd3954d5d26", null ],
      [ "GLTF_ERROR_VALUE_NOT_INITIALIZED", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea1c47ef5344946e5eea78d3543fe665f3", null ],
      [ "GLTF_ERROR_WRITE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea148ae23ac711c7f43dd16e92348937a3", null ],
      [ "GLT_ERROR_MAX", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea35402f8ddb046aebe01e9cf80d451229", null ]
    ] ],
    [ "OutputType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987c", [
      [ "OT_AVZ", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987caffc12fe8ec514248496a1469f781c9e1", null ],
      [ "OT_GLTF", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987ca35927e6892acc7aebd8ed3637a26a990", null ],
      [ "OT_GLB1", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987cadc89ceda75f446f79272885e11433366", null ],
      [ "OT_GLTF1", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987ca2022f4f2ac71f6d10ffa9bdd50400e05", null ],
      [ "OT_GLB2", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987caa5f5fcd8755f4a1ed14e6e09664d509a", null ]
    ] ],
    [ "~GLTF", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a6b330426d936ab04272e2b154c3551c7", null ],
    [ "GetError", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a812b885f21ed48bad70fea6b03e76913", null ],
    [ "SetDefaultScene", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a70b6a7145217bb4033fd8623bd58ec56", null ],
    [ "Write", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a7a468ecf1f594b411023782d18f08823", null ]
];