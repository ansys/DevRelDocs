var struct___shared_memory_frame =
[
    [ "buffer", "struct___shared_memory_frame.xhtml#a7cff19a44525e74c5800b1e2f9e4cc98", null ],
    [ "iFrame", "struct___shared_memory_frame.xhtml#a412d63c3ef8e7417be98997f72f3b0e5", null ],
    [ "iHeight", "struct___shared_memory_frame.xhtml#ab21b6d402e01098565be5024de341ec7", null ],
    [ "iWidth", "struct___shared_memory_frame.xhtml#a6d26bbffc622333b9f11fbadecbd6f21", null ]
];