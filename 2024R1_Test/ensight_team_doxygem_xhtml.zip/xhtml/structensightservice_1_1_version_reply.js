var structensightservice_1_1_version_reply =
[
    [ "VersionEnumType", "structensightservice_1_1_version_reply.xhtml#ad59fbb277db8881f4b306869ca3d2527", [
      [ "UNDEFINED", "structensightservice_1_1_version_reply.xhtml#ad59fbb277db8881f4b306869ca3d2527a09799e59a4e5da5ed7d83462de5c6f0f", null ],
      [ "CURRENT_VERSION", "structensightservice_1_1_version_reply.xhtml#ad59fbb277db8881f4b306869ca3d2527ac0cc9bff427faa2d8dac5e2258b3eaf9", null ]
    ] ],
    [ "version", "structensightservice_1_1_version_reply.xhtml#a980a3ce6bac7e2583368811a8ef2a865", null ]
];