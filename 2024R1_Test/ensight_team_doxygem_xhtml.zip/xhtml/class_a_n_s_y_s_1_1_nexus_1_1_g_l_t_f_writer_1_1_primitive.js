var class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive =
[
    [ "PrimitiveType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6e", [
      [ "PT_POINTS", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea0774f687d37a015adb12a7c57f157190", null ],
      [ "PT_LINES", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea58ccc160090e6c9189f73c4644e66c0e", null ],
      [ "PT_LINE_LOOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6eaf50567675c73731765f0fc37183b1691", null ],
      [ "PT_LINE_STRIP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea5b76ec80fb7d96f1aa4dbc5a136929a6", null ],
      [ "PT_TRIANGLES", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea85ba263ad510a4b423c5e1452fd5ca7d", null ],
      [ "PT_TRIANGLE_STRIP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6eafc347f454c2be56abecc316154511956", null ],
      [ "PT_TRIANGLE_FAN", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea9188d6dcf0e77ae8346e0211f1996320", null ]
    ] ],
    [ "PrimitiveXAttachment", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951", [
      [ "PXA_NONE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951ae5e474e4fe7bb28e1ad2acbbc41fa6b8", null ],
      [ "PXA_LEFT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951a6dc9b18bbe43f04ff6744a5111f0a4a3", null ],
      [ "PXA_CENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951a51f4037d8a135dab3589f9a28e53282a", null ],
      [ "PXA_RIGHT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951a2711064b0fe78b1e55fd2741e18bf68d", null ]
    ] ],
    [ "PrimitiveYAttachment", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbba", [
      [ "PYA_NONE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbbaa2247ad1da9dfef04911a51657c3163d8", null ],
      [ "PYA_BOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbbaa447716243f146a5606c2366e068a997e", null ],
      [ "PYA_CENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbbaa55629dea10122996e3ff9915fb6658ba", null ],
      [ "PYA_TOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbbaa7b6fa012e0f07cb84f0e05345174f93d", null ]
    ] ],
    [ "~Primitive", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#aac340023684f1838ed439ac4d02940d9", null ],
    [ "AppendAttribute", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a4aae56e343ac5130d42416d2ee4c52e3", null ],
    [ "Mirror", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#aee628309c26c8a02c3056fffa42aed03", null ]
];