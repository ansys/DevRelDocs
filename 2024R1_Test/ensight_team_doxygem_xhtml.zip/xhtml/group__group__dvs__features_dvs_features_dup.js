var group__group__dvs__features_dvs_features_dup =
[
    [ "Delete Item API Overview", "group__group__dvs__features.xhtml#dvs_delete_item_api", null ]
];