var structensightservice_1_1_update_variable =
[
    [ "PaletteInterpolation", "structensightservice_1_1_update_variable.xhtml#aba525af8da57834327a98c6258f5fda1", [
      [ "CONTINUOUS", "structensightservice_1_1_update_variable.xhtml#aba525af8da57834327a98c6258f5fda1a6dd78f8b0d101f7bb8c0d74c15c2af04", null ],
      [ "BANDED", "structensightservice_1_1_update_variable.xhtml#aba525af8da57834327a98c6258f5fda1a227dce087f42b9dfa5231856c003529b", null ]
    ] ],
    [ "UndefinedDisplay", "structensightservice_1_1_update_variable.xhtml#ab07eddb89db3f17a4111c2a2b0ba1c0e", [
      [ "AS_ZERO", "structensightservice_1_1_update_variable.xhtml#ab07eddb89db3f17a4111c2a2b0ba1c0eaa8c810fb96b63318847e385ab1ab93ea", null ],
      [ "AS_INVISIBLE", "structensightservice_1_1_update_variable.xhtml#ab07eddb89db3f17a4111c2a2b0ba1c0ea0a11d139963b16f66721378f6f1f7bcd", null ],
      [ "USE_PART_COLOR", "structensightservice_1_1_update_variable.xhtml#ab07eddb89db3f17a4111c2a2b0ba1c0eadb5b985665804d7818f7cbd18708ee3e", null ],
      [ "USE_UNDEF_COLOR", "structensightservice_1_1_update_variable.xhtml#ab07eddb89db3f17a4111c2a2b0ba1c0ea4ac541b1e6a12dfca57f55bfea21aac5", null ]
    ] ],
    [ "VarDimension", "structensightservice_1_1_update_variable.xhtml#a8a27406b9f0d1b4d04c7e220290a8832", [
      [ "SCALAR", "structensightservice_1_1_update_variable.xhtml#a8a27406b9f0d1b4d04c7e220290a8832a181c94167aff4fa32434f11a9517014a", null ],
      [ "VECTOR", "structensightservice_1_1_update_variable.xhtml#a8a27406b9f0d1b4d04c7e220290a8832a89579192578351c228f25c88386790e3", null ]
    ] ],
    [ "VarLocation", "structensightservice_1_1_update_variable.xhtml#a6049149a3d23ac732df1287d464a5e34", [
      [ "NODAL", "structensightservice_1_1_update_variable.xhtml#a6049149a3d23ac732df1287d464a5e34a45652249bc0510f101449c35fb92219a", null ],
      [ "ELEMENTAL", "structensightservice_1_1_update_variable.xhtml#a6049149a3d23ac732df1287d464a5e34a5bae0693219c95072c79a57e97220cf3", null ]
    ] ],
    [ "attributes", "structensightservice_1_1_update_variable.xhtml#ac82ea8d2dd9ad7410db2a784dfb95921", null ],
    [ "dimension", "structensightservice_1_1_update_variable.xhtml#a54f1a5d2fdf41622a3fdd1a29c622b5e", null ],
    [ "hash", "structensightservice_1_1_update_variable.xhtml#affd2266602a0ce71ea4765dd9d2b830b", null ],
    [ "id", "structensightservice_1_1_update_variable.xhtml#a740d5ab7439756963cb274aa5d7a395d", null ],
    [ "levels", "structensightservice_1_1_update_variable.xhtml#a3a45f0682d9ce64655fdb7c9d21ff9c9", null ],
    [ "location", "structensightservice_1_1_update_variable.xhtml#a3d45de0de8053126384af3e5442478f4", null ],
    [ "name", "structensightservice_1_1_update_variable.xhtml#af45690c2e8743fe83baa699967ca3737", null ],
    [ "pal_interp", "structensightservice_1_1_update_variable.xhtml#a93a37d3801ebe892afd00598cc36e86b", null ],
    [ "parent_id", "structensightservice_1_1_update_variable.xhtml#af0b57f59c0e4898f197637e2130d3652", null ],
    [ "sub_levels", "structensightservice_1_1_update_variable.xhtml#ae886d67fd989c05978d7c8eb5fc17001", null ],
    [ "texture", "structensightservice_1_1_update_variable.xhtml#a0da0813441db9e33553d5fb4c87ed3ce", null ],
    [ "undefined_color", "structensightservice_1_1_update_variable.xhtml#a83751ee84d20f8d059c7d792c4e58be3", null ],
    [ "undefined_display", "structensightservice_1_1_update_variable.xhtml#aae718fe32c4eb203a3b93df836aa65ad", null ],
    [ "undefined_value", "structensightservice_1_1_update_variable.xhtml#abf6d0768db50f923d6ac481949e484a8", null ]
];