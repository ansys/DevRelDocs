var structensightservice_1_1_subscribe_event_options =
[
    [ "ChannelType", "structensightservice_1_1_subscribe_event_options.xhtml#a40c27f449a1bef4be2896c9ddabc33ec", [
      [ "GRPC", "structensightservice_1_1_subscribe_event_options.xhtml#a40c27f449a1bef4be2896c9ddabc33ecac76af920867bae3f2205d0257ed35248", null ]
    ] ],
    [ "options", "structensightservice_1_1_subscribe_event_options.xhtml#a9fea05c94fe1c3d637193793a4c27ccb", null ],
    [ "prefix", "structensightservice_1_1_subscribe_event_options.xhtml#a082993f0eb40371edb50a17748c35478", null ],
    [ "type", "structensightservice_1_1_subscribe_event_options.xhtml#a48a6a952356ad524def1932913f05dd0", null ]
];