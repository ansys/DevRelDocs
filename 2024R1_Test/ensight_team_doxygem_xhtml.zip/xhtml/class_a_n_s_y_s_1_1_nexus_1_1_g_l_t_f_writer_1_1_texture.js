var class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture =
[
    [ "TextureFormat", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#aba6db4f52b9f0a1a866bce302b6d8964", [
      [ "TF_RGB", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#aba6db4f52b9f0a1a866bce302b6d8964aaa8ea9a0e6b83932a6a882b1655e8e59", null ],
      [ "TF_RGBA", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#aba6db4f52b9f0a1a866bce302b6d8964ab39a20cf05b8cbdd813d3278664879af", null ]
    ] ],
    [ "TextureTarget", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#a97a19c95bbcdc6bbf5951636a4d70e53", [
      [ "TT_TEXTURE_2D", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#a97a19c95bbcdc6bbf5951636a4d70e53ace1a5ae468e3deb5b78b1d5ed9f61263", null ]
    ] ],
    [ "~Texture", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#ab6d512f7bbc65d8b7d201eb257189443", null ]
];