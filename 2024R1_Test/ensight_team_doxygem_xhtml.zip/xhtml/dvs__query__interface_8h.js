var dvs__query__interface_8h =
[
    [ "IQuery", "class_d_v_s_1_1_i_query.xhtml", "class_d_v_s_1_1_i_query" ],
    [ "CREATE_QUERY_INSTANCE", "dvs__query__interface_8h.xhtml#a873b5129bcc509d9ae4c456512d876bb", null ]
];