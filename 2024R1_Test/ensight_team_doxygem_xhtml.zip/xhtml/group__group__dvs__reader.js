var group__group__dvs__reader =
[
    [ "DVS Reader", "group__group__dvs__reader.xhtml#dvs_reader", "group__group__dvs__reader_dvs_reader_dup" ]
];