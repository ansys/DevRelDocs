var dir_efb5d67553d49169c49ef58de7241528 =
[
    [ "client", "dir_fdd9705442facc8925ef373a77ec3b73.xhtml", "dir_fdd9705442facc8925ef373a77ec3b73" ],
    [ "user_defined_src", "dir_4e0d2d4294803448cbce42ae5b7dbd77.xhtml", "dir_4e0d2d4294803448cbce42ae5b7dbd77" ]
];