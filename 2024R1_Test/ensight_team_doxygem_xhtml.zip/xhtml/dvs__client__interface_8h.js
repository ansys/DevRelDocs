var dvs__client__interface_8h =
[
    [ "IClient", "class_d_v_s_1_1_i_client.xhtml", "class_d_v_s_1_1_i_client" ],
    [ "CREATE_CLIENT_INSTANCE", "dvs__client__interface_8h.xhtml#ab009ac80464841b8563982bafba05f14", null ],
    [ "DESTROY_CLIENT_INSTANCE", "dvs__client__interface_8h.xhtml#a3f13d009a9a07278cbca3449113d78fc", null ]
];