var class_d_v_s_1_1_i_object =
[
    [ "ObjectDefType", "class_d_v_s_1_1_i_object.xhtml#aa897daa1f7d0467515fd108c29015348", [
      [ "PART", "class_d_v_s_1_1_i_object.xhtml#aa897daa1f7d0467515fd108c29015348a8b2484e08a16329d2d91c18c254f5ca6", null ],
      [ "PLOT", "class_d_v_s_1_1_i_object.xhtml#aa897daa1f7d0467515fd108c29015348abe80fa1e67dae7efb56fdb2936914cae", null ],
      [ "CASE", "class_d_v_s_1_1_i_object.xhtml#aa897daa1f7d0467515fd108c29015348a03dcfd36d493cd1d828af236e2c357fd", null ]
    ] ],
    [ "IObject", "class_d_v_s_1_1_i_object.xhtml#ac8a6734ee192a26b574e9eec520c1495", null ],
    [ "~IObject", "class_d_v_s_1_1_i_object.xhtml#a26912f7959e8f0e610074833c677a904", null ],
    [ "IObject", "class_d_v_s_1_1_i_object.xhtml#aae99076e42a6fc37bf9a71303b3db2b5", null ],
    [ "IObject", "class_d_v_s_1_1_i_object.xhtml#af147aaab5200462fd620dbdd4a39ac76", null ],
    [ "get_dataset", "class_d_v_s_1_1_i_object.xhtml#a9184ca61b90cf245c5f596f52756001b", null ],
    [ "get_metadata_key", "class_d_v_s_1_1_i_object.xhtml#a76a8b0bf7b55678cba9bcdb7e19c9a7f", null ],
    [ "get_metadata_value", "class_d_v_s_1_1_i_object.xhtml#a5ade463d34bba53bb9e66fa547a616bd", null ],
    [ "get_metadata_value", "class_d_v_s_1_1_i_object.xhtml#aa391aa339c696ddb5fe582eb59bb7197", null ],
    [ "get_name", "class_d_v_s_1_1_i_object.xhtml#ae8edeb61ff2b87d3f3ea9cd6519e73d5", null ],
    [ "get_num_metadata", "class_d_v_s_1_1_i_object.xhtml#a31db3b716cc815c2c73f826f24384f6a", null ],
    [ "get_type", "class_d_v_s_1_1_i_object.xhtml#a889c46624013cc3802c7164d153b95f6", null ],
    [ "operator=", "class_d_v_s_1_1_i_object.xhtml#ae9617f7ddf7f5c4f31cb6d8bdec8d84a", null ],
    [ "operator=", "class_d_v_s_1_1_i_object.xhtml#aaf7c15538ff1a9e0969f670e8a8beb6d", null ]
];