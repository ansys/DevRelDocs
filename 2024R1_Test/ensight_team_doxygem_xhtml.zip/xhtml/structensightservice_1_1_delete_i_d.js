var structensightservice_1_1_delete_i_d =
[
    [ "ids", "structensightservice_1_1_delete_i_d.xhtml#a5f5d749d9a9940f19348775c91e08691", null ]
];