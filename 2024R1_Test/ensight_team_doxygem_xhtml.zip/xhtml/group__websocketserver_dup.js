var group__websocketserver_dup =
[
    [ "Overview", "group__websocketserver.xhtml#overview", [
      [ "Basic Operation", "group__websocketserver.xhtml#basic-operation", null ],
      [ "Builtin Service Operation", "group__websocketserver.xhtml#builtin-service-operation", null ],
      [ "External Services", "group__websocketserver.xhtml#external-services", null ],
      [ "HTTP Server", "group__websocketserver.xhtml#http-server", [
        [ "Ansys Nexus Viewer Service", "group__websocketserver.xhtml#ansys-nexus-viewer", null ],
        [ "EnSight REST API Service", "group__websocketserver.xhtml#ensight-rest-api", null ]
      ] ],
      [ "REST API", "group__websocketserver.xhtml#rest-api", null ]
    ] ]
];