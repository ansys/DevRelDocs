var searchData=
[
  ['log_1254',['log',['../class_d_v_s_1_1_i_logger.xhtml#a8f562c0a88964401a6bd50fc7b387ef5',1,'DVS::ILogger::log()'],['../class_d_v_s_1_1_logger_verbose.xhtml#acf148c138e5b4c3a2bd00492966e2f00',1,'DVS::LoggerVerbose::log(int level, const char *msg,...) override']]],
  ['loggerverbose_1255',['LoggerVerbose',['../class_d_v_s_1_1_logger_verbose.xhtml#a88a3288c8d7f87bb5a3574fcc8909188',1,'DVS::LoggerVerbose::LoggerVerbose(void *user_data, dvs_verbosity level, dvs_log_func func)'],['../class_d_v_s_1_1_logger_verbose.xhtml#a2cf7775542558791b4d8b8654d9175ea',1,'DVS::LoggerVerbose::LoggerVerbose(LoggerVerbose &amp;&amp;)=default'],['../class_d_v_s_1_1_logger_verbose.xhtml#af873ff781cc7ef4e0bcbfa30e05a088d',1,'DVS::LoggerVerbose::LoggerVerbose(const LoggerVerbose &amp;)=default']]]
];
