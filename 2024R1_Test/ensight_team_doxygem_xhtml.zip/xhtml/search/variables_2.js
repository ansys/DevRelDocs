var searchData=
[
  ['blue_1365',['blue',['../structensightservice_1_1_variable_level.xhtml#a805baa0b7821ec1ceeba2ae6095911d3',1,'ensightservice::VariableLevel']]],
  ['buffer_1366',['buffer',['../struct___shared_memory_frame.xhtml#a7cff19a44525e74c5800b1e2f9e4cc98',1,'_SharedMemoryFrame']]]
];
