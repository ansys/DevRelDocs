var searchData=
[
  ['sharedmemoryframe_1466',['SharedMemoryFrame',['../shared__memory__image__client_8h.xhtml#a995c49496fcc1a41fb2d104c6473223b',1,'shared_memory_image_client.h']]],
  ['sharedmemoryimageerror_1467',['SharedMemoryImageError',['../shared__memory__image__client_8h.xhtml#a0496a9a3db499fa9145fe97d2e6dae9a',1,'shared_memory_image_client.h']]],
  ['sharedmemoryimagestream_1468',['SharedMemoryImageStream',['../shared__memory__image__client_8h.xhtml#af5b8eb2ae90823f10e9a17698ea80749',1,'shared_memory_image_client.h']]]
];
