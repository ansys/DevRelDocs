var searchData=
[
  ['overview_20of_20the_20veronica_20apis_1860',['Overview of the Veronica APIs',['../index.xhtml',1,'']]]
];
