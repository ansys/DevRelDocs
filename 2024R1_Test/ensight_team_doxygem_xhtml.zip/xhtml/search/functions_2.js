var searchData=
[
  ['begin_5finit_1046',['begin_init',['../class_d_v_s_1_1_i_client.xhtml#aff782ecd341fddd87a22a15107efeb3b',1,'DVS::IClient']]],
  ['begin_5fupdate_1047',['begin_update',['../class_d_v_s_1_1_i_client.xhtml#abd1cbbd2007346ad616dc74eab9d0553',1,'DVS::IClient']]]
];
