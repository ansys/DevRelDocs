var searchData=
[
  ['logger_5finterface_2eh_1016',['logger_interface.h',['../logger__interface_8h.xhtml',1,'']]],
  ['logger_5fverbose_2eh_1017',['logger_verbose.h',['../logger__verbose_8h.xhtml',1,'']]]
];
