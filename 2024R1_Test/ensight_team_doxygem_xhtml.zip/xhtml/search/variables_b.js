var searchData=
[
  ['material_5fname_1410',['material_name',['../structensightservice_1_1_update_part.xhtml#aef2cbe0ee256ed43444ce8b46fdf7897',1,'ensightservice::UpdatePart']]],
  ['matrix4x4_1411',['matrix4x4',['../structensightservice_1_1_update_part.xhtml#a7899500fa988dd96cfa7456351ab7332',1,'ensightservice::UpdatePart::matrix4x4()'],['../structensightservice_1_1_update_group.xhtml#a59de9866a1bb62fa95f4171d0e4a6fd4',1,'ensightservice::UpdateGroup::matrix4x4()']]],
  ['maximum_5fchunk_5fsize_1412',['maximum_chunk_size',['../structensightservice_1_1_scene_client_init.xhtml#a628ea445b5f241ed67b8cd1010b91c16',1,'ensightservice::SceneClientInit']]]
];
