var searchData=
[
  ['test_5fdvs_5fclient_5fsimple_1000',['test_dvs_client_simple',['../namespacetest__dvs__client__simple.xhtml',1,'']]]
];
