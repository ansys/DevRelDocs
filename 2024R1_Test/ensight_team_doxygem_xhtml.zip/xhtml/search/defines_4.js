var searchData=
[
  ['max_5fstreams_1819',['MAX_STREAMS',['../shared__memory__image__client__python_8c.xhtml#a4a1e12ec49840b798c6413a8f6c947a9',1,'shared_memory_image_client_python.c']]]
];
