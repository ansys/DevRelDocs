var searchData=
[
  ['legendattachment_1490',['LegendAttachment',['../class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2',1,'ANSYS::Nexus::GLTFWriter::Legend']]],
  ['legendorientation_1491',['LegendOrientation',['../class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a339aacb19b79675bd3bc9a903349d933',1,'ANSYS::Nexus::GLTFWriter::Legend']]]
];
