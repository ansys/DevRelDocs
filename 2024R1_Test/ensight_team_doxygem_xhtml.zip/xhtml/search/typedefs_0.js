var searchData=
[
  ['dvs_5flog_5ffunc_1464',['dvs_log_func',['../dynamic__visualization__store__api_8h.xhtml#a80c7c60e9cd61fcc0a0aacac09d66947',1,'dynamic_visualization_store_api.h']]],
  ['dvs_5fret_1465',['dvs_ret',['../dynamic__visualization__store__error__codes_8h.xhtml#a1d7466ae72e89fe36cbf2408b4f7d9c1',1,'dynamic_visualization_store_error_codes.h']]]
];
