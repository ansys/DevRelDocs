var test__dvs__client_8c =
[
    [ "M_PI", "test__dvs__client_8c.xhtml#ae71449b1cc6e6250b91f539153a7a0d3", null ],
    [ "main", "test__dvs__client_8c.xhtml#a3c04138a5bfe5d72780bb7e82a18e627", null ]
];