var structensightservice_1_1_anim_query_progress_reply =
[
    [ "Status", "structensightservice_1_1_anim_query_progress_reply.xhtml#acf97ca8571bba823e4a3449a749fa7d3", [
      [ "IN_PROGRESS", "structensightservice_1_1_anim_query_progress_reply.xhtml#acf97ca8571bba823e4a3449a749fa7d3a8d5bd7ab98f75ad9075c688fed50b624", null ],
      [ "COMPLETE", "structensightservice_1_1_anim_query_progress_reply.xhtml#acf97ca8571bba823e4a3449a749fa7d3ad4088e7f9222e0c7c7dac02ebf67e633", null ],
      [ "CANCEL_REQUESTED", "structensightservice_1_1_anim_query_progress_reply.xhtml#acf97ca8571bba823e4a3449a749fa7d3a0f42169fcc38699ccba3da0020ca89ad", null ],
      [ "CANCELLED", "structensightservice_1_1_anim_query_progress_reply.xhtml#acf97ca8571bba823e4a3449a749fa7d3a61f072e6d795f6d19ae9478520aee776", null ],
      [ "WRITE_ERROR", "structensightservice_1_1_anim_query_progress_reply.xhtml#acf97ca8571bba823e4a3449a749fa7d3a833167b5ad8686ad147784dff9cb4256", null ]
    ] ],
    [ "error_msg", "structensightservice_1_1_anim_query_progress_reply.xhtml#af59568db7fe2d5d8a358af9a9d2973fd", null ],
    [ "id", "structensightservice_1_1_anim_query_progress_reply.xhtml#af63f10e954b89055deca8728fb274c83", null ],
    [ "num_frames", "structensightservice_1_1_anim_query_progress_reply.xhtml#a25531173d585182fd80d864580b8b89b", null ],
    [ "num_frames_finished", "structensightservice_1_1_anim_query_progress_reply.xhtml#aaa25eee1d9e5f2b5358ed71d9098f870", null ],
    [ "status", "structensightservice_1_1_anim_query_progress_reply.xhtml#a4d9e6cf495beafbed3f444a673e14820", null ]
];