var modules =
[
    [ "EnSight gRPC Interface", "group__grpc.xhtml", "group__grpc" ],
    [ "GLTFWriter Interface", "group__gltf.xhtml", "group__gltf" ],
    [ "Nexus Websocket Server", "group__websocketserver.xhtml", "group__websocketserver" ],
    [ "Nexus 3D Viewer Web Component", "group__webcomponentviewer.xhtml", "group__webcomponentviewer" ],
    [ "Shared Memory Image Transport", "group__shmem.xhtml", "group__shmem" ],
    [ "Dynamic Visualization Store", "group__dvs.xhtml", "group__dvs" ]
];