var structensightservice_1_1_subscribe_image_options =
[
    [ "ChannelType", "structensightservice_1_1_subscribe_image_options.xhtml#afa81ebc38c1801fe0f3ae7262798d340", [
      [ "GRPC", "structensightservice_1_1_subscribe_image_options.xhtml#afa81ebc38c1801fe0f3ae7262798d340a74944b7a7e1ad133402aa6e048dfe4c6", null ],
      [ "SHARED_MEM", "structensightservice_1_1_subscribe_image_options.xhtml#afa81ebc38c1801fe0f3ae7262798d340ad27444fa0b847e6156e29260e99b32c8", null ]
    ] ],
    [ "chunk", "structensightservice_1_1_subscribe_image_options.xhtml#a04eab75e486e8586ce9e434596190fa0", null ],
    [ "flip_vertical", "structensightservice_1_1_subscribe_image_options.xhtml#a5e15879112029f4c126e615d42ef2fdd", null ],
    [ "options", "structensightservice_1_1_subscribe_image_options.xhtml#a9915819de6a6c41c9710a2d811fb3cb6", null ],
    [ "prefix", "structensightservice_1_1_subscribe_image_options.xhtml#a3c11161da5e7dd00b8c3930651329d9b", null ],
    [ "type", "structensightservice_1_1_subscribe_image_options.xhtml#a5542ba033c19b9319e825ae01861617b", null ]
];