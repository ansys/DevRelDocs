var class_d_v_s_1_1_i_dataset =
[
    [ "IDataset", "class_d_v_s_1_1_i_dataset.xhtml#a5f47221543a890f8c04c7297f45e9580", null ],
    [ "~IDataset", "class_d_v_s_1_1_i_dataset.xhtml#a99d31f6d38bc358af557ca2fa236959e", null ],
    [ "IDataset", "class_d_v_s_1_1_i_dataset.xhtml#a4fafacbcd842db2b73a89b98d56f8ab4", null ],
    [ "IDataset", "class_d_v_s_1_1_i_dataset.xhtml#aa32d8780f6b7ed895870bea816396600", null ],
    [ "get_chunks_per_rank", "class_d_v_s_1_1_i_dataset.xhtml#afb023f6b10fd4c072e8c7cb140d666ae", null ],
    [ "get_num_chunks_per_rank", "class_d_v_s_1_1_i_dataset.xhtml#a5ec19061a478d6b2aea0976b9e79f73b", null ],
    [ "get_num_parts", "class_d_v_s_1_1_i_dataset.xhtml#a69aa8f4d0ad2c4fd69e6443f662fbc1d", null ],
    [ "get_num_plots", "class_d_v_s_1_1_i_dataset.xhtml#a49e3b27865d865ba36dd5d7e5c659a6b", null ],
    [ "get_num_ranks", "class_d_v_s_1_1_i_dataset.xhtml#a423774f63a6f5275d4d4f33da65f37b4", null ],
    [ "get_num_variables", "class_d_v_s_1_1_i_dataset.xhtml#acd0c0e81b283bce8044d9b4de796574a", null ],
    [ "get_part", "class_d_v_s_1_1_i_dataset.xhtml#ab71be7a6ec20c74eeccc625055bc0fb2", null ],
    [ "get_plot", "class_d_v_s_1_1_i_dataset.xhtml#a465ce7d87c7291ce115b0b8d2b848703", null ],
    [ "get_ranks", "class_d_v_s_1_1_i_dataset.xhtml#ac620a1f5fb513d636ed59d7b4552197a", null ],
    [ "get_unit_system", "class_d_v_s_1_1_i_dataset.xhtml#a58184590f98127577ba91292064ccb75", null ],
    [ "get_var", "class_d_v_s_1_1_i_dataset.xhtml#a52dd0a5187d92908761ddfae07a47273", null ],
    [ "operator=", "class_d_v_s_1_1_i_dataset.xhtml#ad87e6320180a03e49e14d0bd2d350987", null ],
    [ "operator=", "class_d_v_s_1_1_i_dataset.xhtml#a9cdcf0f0423af203bf36429a2a8e992a", null ]
];