var structensightservice_1_1_image_stream_request =
[
    [ "chunk", "structensightservice_1_1_image_stream_request.xhtml#a07aa07b988a70ac1f115d8f5a4d62ae9", null ],
    [ "flip_vertical", "structensightservice_1_1_image_stream_request.xhtml#a3f76864a9bb230e81dbd6cbbf982ebc1", null ]
];