var structensightservice_1_1_python_request =
[
    [ "CmdType", "structensightservice_1_1_python_request.xhtml#a5b38efa006c583052c1fd92c01811b4c", [
      [ "EXEC_NO_RESULT", "structensightservice_1_1_python_request.xhtml#a5b38efa006c583052c1fd92c01811b4caa457d5ed12f0a22855fc9cbf11ab8f12", null ],
      [ "EXEC_RETURN_PYTHON", "structensightservice_1_1_python_request.xhtml#a5b38efa006c583052c1fd92c01811b4caf7efb6586d41f7ef06f9430899dccf33", null ],
      [ "EXEC_RETURN_JSON", "structensightservice_1_1_python_request.xhtml#a5b38efa006c583052c1fd92c01811b4ca3d0d8c2e0e4e07259828979638233e5d", null ]
    ] ],
    [ "command", "structensightservice_1_1_python_request.xhtml#ae6161a1f28bc6b6d0774346cea096b05", null ],
    [ "type", "structensightservice_1_1_python_request.xhtml#a69df81025a161dbe3efbb1ce5be37951", null ]
];