var class_d_v_s_1_1_i_var =
[
    [ "IVar", "class_d_v_s_1_1_i_var.xhtml#a102df9a173523a896419011582abefb1", null ],
    [ "~IVar", "class_d_v_s_1_1_i_var.xhtml#a0f21e53225c764cb3441f36c32f77bee", null ],
    [ "IVar", "class_d_v_s_1_1_i_var.xhtml#aac24d89cca155832661aaf190e933e30", null ],
    [ "IVar", "class_d_v_s_1_1_i_var.xhtml#afd5bd19f8cf769575e1d6f13890c876b", null ],
    [ "get_dataset", "class_d_v_s_1_1_i_var.xhtml#a2e0600d91a89b39455ca1386998851c3", null ],
    [ "get_float_count_per_value", "class_d_v_s_1_1_i_var.xhtml#a9dbdd84e6f6342deae82ede6dcf2156e", null ],
    [ "get_metadata_key", "class_d_v_s_1_1_i_var.xhtml#a2b96533361edb6e64c7a4eb4a80d39f3", null ],
    [ "get_metadata_value", "class_d_v_s_1_1_i_var.xhtml#a2724bf3e3b01d66b909254a2a7a363f5", null ],
    [ "get_metadata_value", "class_d_v_s_1_1_i_var.xhtml#a970de1a0e394ebc738e503f072c6fc1b", null ],
    [ "get_name", "class_d_v_s_1_1_i_var.xhtml#af9d82173f26ea832cd2d9dcc9742bd56", null ],
    [ "get_num_metadata", "class_d_v_s_1_1_i_var.xhtml#a2deab60f72955106a4a4a3f67a0f295e", null ],
    [ "get_unit_dimension", "class_d_v_s_1_1_i_var.xhtml#ab5a4abf4b5a1d319f4cd3651f03df6b3", null ],
    [ "get_unit_label", "class_d_v_s_1_1_i_var.xhtml#a4d5cad1da5b03c0a35d199de4c00799b", null ],
    [ "get_var_location", "class_d_v_s_1_1_i_var.xhtml#a7e97f43d3d1057267399c0e66deadd3d", null ],
    [ "get_var_type", "class_d_v_s_1_1_i_var.xhtml#ae837af2ee946d8f54695d1abf95c5cda", null ],
    [ "operator=", "class_d_v_s_1_1_i_var.xhtml#a4fa7183cc37374962f46cd3aa84eac0d", null ],
    [ "operator=", "class_d_v_s_1_1_i_var.xhtml#acac7ddfc292e8998c4ae66ace02c3bbc", null ]
];