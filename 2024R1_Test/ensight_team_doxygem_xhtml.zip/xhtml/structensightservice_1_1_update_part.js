var structensightservice_1_1_update_part =
[
    [ "RenderingMode", "structensightservice_1_1_update_part.xhtml#a08774fd175375ce53267c2596831ddec", [
      [ "NODES", "structensightservice_1_1_update_part.xhtml#a08774fd175375ce53267c2596831ddecac09b801c81ff9a17215d193690acb941", null ],
      [ "CONNECTIVITY", "structensightservice_1_1_update_part.xhtml#a08774fd175375ce53267c2596831ddeca91f814245db2858844fd78dc9010c205", null ]
    ] ],
    [ "ShadingMode", "structensightservice_1_1_update_part.xhtml#a8a65fed5c948b9c4ee6165818da35b01", [
      [ "ELEMENTAL", "structensightservice_1_1_update_part.xhtml#a8a65fed5c948b9c4ee6165818da35b01acdfc4ad1532f97699bedfad3653ac2fe", null ],
      [ "NODAL", "structensightservice_1_1_update_part.xhtml#a8a65fed5c948b9c4ee6165818da35b01a5cb3cf33dd6e04ce4bbe8721d36f2c6a", null ]
    ] ],
    [ "TextureApplyMode", "structensightservice_1_1_update_part.xhtml#a7d558b62f6603608dd88a4a1469f6736", [
      [ "REPLACE", "structensightservice_1_1_update_part.xhtml#a7d558b62f6603608dd88a4a1469f6736a5e4ea0327459d1bf936e5a7db32ef0ba", null ],
      [ "DECAL", "structensightservice_1_1_update_part.xhtml#a7d558b62f6603608dd88a4a1469f6736a520aea4e9aa1ff0b3627e4812e77fa8a", null ],
      [ "MODULATE", "structensightservice_1_1_update_part.xhtml#a7d558b62f6603608dd88a4a1469f6736a801b9e7ee05853ab08f92695c4453fb8", null ]
    ] ],
    [ "TextureSampleMode", "structensightservice_1_1_update_part.xhtml#a41ed8e636c5565d44c63fe1e8cd62163", [
      [ "NEAREST", "structensightservice_1_1_update_part.xhtml#a41ed8e636c5565d44c63fe1e8cd62163afb41518d4aa2322e1822a7ad6860f896", null ],
      [ "LINEAR", "structensightservice_1_1_update_part.xhtml#a41ed8e636c5565d44c63fe1e8cd62163abf80688fd45aec45cc89bbf4929aabbd", null ]
    ] ],
    [ "TextureWrapMode", "structensightservice_1_1_update_part.xhtml#a694e8e5cb74ec402c0edeb2c9d232796", [
      [ "REPEAT", "structensightservice_1_1_update_part.xhtml#a694e8e5cb74ec402c0edeb2c9d232796ae49b8828574680d1dedb130bbbb9c2bc", null ],
      [ "CLAMP", "structensightservice_1_1_update_part.xhtml#a694e8e5cb74ec402c0edeb2c9d232796a244b83109d047b4fb87cd9ed347c5463", null ],
      [ "CLAMP_TEXTURE", "structensightservice_1_1_update_part.xhtml#a694e8e5cb74ec402c0edeb2c9d232796ae6e175e4e97f97b923fd496da72346c2", null ]
    ] ],
    [ "alpha_variableid", "structensightservice_1_1_update_part.xhtml#ad7834ca7d0348aef62bd8349f2c49707", null ],
    [ "ambient", "structensightservice_1_1_update_part.xhtml#a1bdde519e13ec4fe017e3cd33ac19101", null ],
    [ "color_variableid", "structensightservice_1_1_update_part.xhtml#a06f276651bacf17d190576631064b80b", null ],
    [ "diffuse", "structensightservice_1_1_update_part.xhtml#af1fac323130745d692092724afad5305", null ],
    [ "displacement_variableid", "structensightservice_1_1_update_part.xhtml#abca6bd2a86631f927e86eaa68905ea80", null ],
    [ "fill_color", "structensightservice_1_1_update_part.xhtml#a6fa26455ae14b97ed2ff47bc81a2fe01", null ],
    [ "hash", "structensightservice_1_1_update_part.xhtml#a91ffdc6c84e47f69bde3fedc8424fdac", null ],
    [ "id", "structensightservice_1_1_update_part.xhtml#a146d625ee8cfdc2174a4d040c60911c3", null ],
    [ "line_color", "structensightservice_1_1_update_part.xhtml#a518b58bb817746904e20bae13df42336", null ],
    [ "material_name", "structensightservice_1_1_update_part.xhtml#aef2cbe0ee256ed43444ce8b46fdf7897", null ],
    [ "matrix4x4", "structensightservice_1_1_update_part.xhtml#a7899500fa988dd96cfa7456351ab7332", null ],
    [ "name", "structensightservice_1_1_update_part.xhtml#a64d2b287913002e8dc978450e91d717d", null ],
    [ "node_size_default", "structensightservice_1_1_update_part.xhtml#af0d873b7ed1de4234c494af420bc3bd3", null ],
    [ "node_size_variableid", "structensightservice_1_1_update_part.xhtml#adcfa62e75a9159c60598b4b15ace17f1", null ],
    [ "parent_id", "structensightservice_1_1_update_part.xhtml#a05419f0c4aabaa6070aa80a3910d567f", null ],
    [ "render", "structensightservice_1_1_update_part.xhtml#a7bc6066b491f0e0d53f74f89e897e62a", null ],
    [ "shading", "structensightservice_1_1_update_part.xhtml#a5f0ab89caa52e901e519bb0312097b6b", null ],
    [ "specular_intensity", "structensightservice_1_1_update_part.xhtml#a435c23c1109c77b9880a22e4e97f6ecb", null ],
    [ "specular_shine", "structensightservice_1_1_update_part.xhtml#ae870baf91c0272bacc9a6b767dce9fc0", null ],
    [ "texture_apply_mode", "structensightservice_1_1_update_part.xhtml#a69b91fc0cbd910578edb81ed45b3c66c", null ],
    [ "texture_id", "structensightservice_1_1_update_part.xhtml#a2fab0e62a37c14a713f2d522e167e34b", null ],
    [ "texture_sample_mode", "structensightservice_1_1_update_part.xhtml#ada36d973467e004165e916c9b4da47df", null ],
    [ "texture_wrap_mode", "structensightservice_1_1_update_part.xhtml#a5342169c3591f1324c3bf0c8ea4e68b6", null ]
];