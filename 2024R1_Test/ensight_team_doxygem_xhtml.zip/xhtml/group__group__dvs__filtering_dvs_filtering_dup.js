var group__group__dvs__filtering_dvs_filtering_dup =
[
    [ "DVS Filtering Overview", "group__group__dvs__filtering.xhtml#dvs_filtering_overview", [
      [ "Query Stanzas", "group__group__dvs__filtering.xhtml#dvs_query_stanzas", [
        [ "Top Level Operator", "group__group__dvs__filtering.xhtml#dvs_query_top_level_operator", null ],
        [ "Objects/Attributes", "group__group__dvs__filtering.xhtml#dvs_query_objects", null ],
        [ "Operators", "group__group__dvs__filtering.xhtml#dvs_query_operator", null ],
        [ "Operands", "group__group__dvs__filtering.xhtml#dvs_query_operands", null ]
      ] ],
      [ "Misc Query Examples", "group__group__dvs__filtering.xhtml#dvs_query_examples", null ]
    ] ]
];