var group__group__dvs__server_dvs_server_dup =
[
    [ "DVS Server", "group__group__dvs__server.xhtml#dvs_server_main", [
      [ "Server Options", "group__group__dvs__server.xhtml#dvs_server_options", null ]
    ] ]
];