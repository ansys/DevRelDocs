var structensightservice_1_1_render_request =
[
    [ "RenderType", "structensightservice_1_1_render_request.xhtml#a98477acc54de7574602f36ed266c4122", [
      [ "IMAGE_PNG", "structensightservice_1_1_render_request.xhtml#a98477acc54de7574602f36ed266c4122a24ca50772e6eb62831dc1b5859234328", null ],
      [ "IMAGE_RAW", "structensightservice_1_1_render_request.xhtml#a98477acc54de7574602f36ed266c4122a1984c4e599cd46467c28ae82a91893d8", null ]
    ] ],
    [ "image_aa_passes", "structensightservice_1_1_render_request.xhtml#af5e5b4a7e1a519149f50a6a6f980f34a", null ],
    [ "image_height", "structensightservice_1_1_render_request.xhtml#af8d0600e4baa6e53e760b4ab65fcebd8", null ],
    [ "image_width", "structensightservice_1_1_render_request.xhtml#acc1fccf32ccf502623426d71bd90c4f0", null ],
    [ "include_highlighting", "structensightservice_1_1_render_request.xhtml#a7c270f2115888abd7d06fdbf6966ad93", null ],
    [ "type", "structensightservice_1_1_render_request.xhtml#aefa3944f221f219bddc1b996d41ce3f6", null ]
];