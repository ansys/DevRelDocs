var group__group__dvs__metadata_dvs_metadata_dup =
[
    [ "DVS Dataset Metadata", "group__group__dvs__metadata.xhtml#dvs_dataset_metadata", [
      [ "Supported EnSight Dataset Metadata", "group__group__dvs__metadata.xhtml#dvs_dataset_metadata_ensight_supported", null ],
      [ "EnSight DVS Element Filtering", "group__group__dvs__metadata.xhtml#dvs_element_filtering", [
        [ "Example 1", "group__group__dvs__metadata.xhtml#dvs_element_filter_example_1", null ],
        [ "Example 2", "group__group__dvs__metadata.xhtml#dvs_element_filter_example_2", null ],
        [ "Example 3", "group__group__dvs__metadata.xhtml#dvs_element_filter_example_3", null ]
      ] ]
    ] ],
    [ "DVS Part Metadata", "group__group__dvs__metadata.xhtml#dvs_part_metadata", [
      [ "Supported EnSight Part Metadata", "group__group__dvs__metadata.xhtml#dvs_part_metadata_ensight_supported", null ]
    ] ],
    [ "DVS Plot Metadata", "group__group__dvs__metadata.xhtml#dvs_plot_metadata", null ],
    [ "DVS Variable Metadata", "group__group__dvs__metadata.xhtml#dvs_variable_metadata", null ]
];