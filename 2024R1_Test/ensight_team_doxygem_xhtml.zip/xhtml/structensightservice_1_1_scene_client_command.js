var structensightservice_1_1_scene_client_command =
[
    [ "ClientCommandType", "structensightservice_1_1_scene_client_command.xhtml#a0d35bc799b8649f6ca89ba7b81d85c9d", [
      [ "INIT", "structensightservice_1_1_scene_client_command.xhtml#a0d35bc799b8649f6ca89ba7b81d85c9daf4d487da2248189a4581a1da2ef697a6", null ],
      [ "UPDATE", "structensightservice_1_1_scene_client_command.xhtml#a0d35bc799b8649f6ca89ba7b81d85c9da541ae893b9023272d6d91bc98e91ae28", null ]
    ] ],
    [ "ClientCommand", "structensightservice_1_1_scene_client_command.xhtml#ab8fc63b3d61dc3fd04f63950464ff8fa", null ],
    [ "command_type", "structensightservice_1_1_scene_client_command.xhtml#adaad41cd970c13986e303aa114d76c32", null ],
    [ "init", "structensightservice_1_1_scene_client_command.xhtml#a308cfda6fa9526f29110cc95e3e08553", null ],
    [ "update", "structensightservice_1_1_scene_client_command.xhtml#a872d1d1e4a69b5da888d1c41bd77c118", null ]
];