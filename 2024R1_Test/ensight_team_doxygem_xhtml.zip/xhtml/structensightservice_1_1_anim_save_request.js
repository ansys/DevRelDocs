var structensightservice_1_1_anim_save_request =
[
    [ "aa_passes", "structensightservice_1_1_anim_save_request.xhtml#a44c9d1da2cba6eca416d718bff933721", null ],
    [ "filename", "structensightservice_1_1_anim_save_request.xhtml#aed89c5bf60803520c1913f57fd3f4e24", null ],
    [ "format_options", "structensightservice_1_1_anim_save_request.xhtml#a3c8150118e98048a89dfccc01bf425e8", null ],
    [ "fps", "structensightservice_1_1_anim_save_request.xhtml#a3108fd76dfcc451879339f6c99a01ce0", null ],
    [ "height", "structensightservice_1_1_anim_save_request.xhtml#a8e87977a7346548017e762bec03a735c", null ],
    [ "id", "structensightservice_1_1_anim_save_request.xhtml#af913dc443e4fd1144801f856371e8382", null ],
    [ "num_frames", "structensightservice_1_1_anim_save_request.xhtml#af4c8190c87265afdaf18c26a40110016", null ],
    [ "start_frame", "structensightservice_1_1_anim_save_request.xhtml#a60bc3fb7914b4e44127e342d2ec214c9", null ],
    [ "white_background", "structensightservice_1_1_anim_save_request.xhtml#a0edbc19bd0f34f98ac52b430047e69f1", null ],
    [ "width", "structensightservice_1_1_anim_save_request.xhtml#aea93ee30169d4bcf0ec93a8d8b9f4c17", null ]
];