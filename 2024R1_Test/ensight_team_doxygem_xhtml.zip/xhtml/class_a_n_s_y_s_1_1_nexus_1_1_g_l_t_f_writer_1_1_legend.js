var class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend =
[
    [ "LegendAttachment", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2", [
      [ "LA_X_Y", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a1ffb33df0a6250b5d46b08c4b92f054a", null ],
      [ "LA_X_YBOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a6f8042caf6888d46d80f8420b21f117e", null ],
      [ "LA_X_YTOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a83b0eeafc16527b732764d5a748ad350", null ],
      [ "LA_X_YCENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a78c88258f5d9a3a003e6bb1d49446c3b", null ],
      [ "LA_XLEFT_Y", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2ae6d51f9195218713c1ff23e50eb91cb2", null ],
      [ "LA_XLEFT_YBOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a19e036b97243b63f95de8083790fba45", null ],
      [ "LA_XLEFT_YTOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2ad03c7746261cd58437b7ee988998c8fb", null ],
      [ "LA_XLEFT_YCENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2aae4032f867cdd2bc3425e78c1e272b15", null ],
      [ "LA_XRIGHT_Y", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2ac1506dad41a0a6ca7e8566fca9af9dc4", null ],
      [ "LA_XRIGHT_YBOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a25f3aff8bc8c1e7dbe6b5b08fa1cf9e4", null ],
      [ "LA_XRIGHT_YTOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a32ce101a5040ea5539acb4b81b41a050", null ],
      [ "LA_XRIGHT_YCENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a74c6997c4d92c6b6c95e67dbe827fe32", null ],
      [ "LA_XCENTER_Y", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a7cd51c74ffd247c065f7f92871849f3a", null ],
      [ "LA_XCENTER_YBOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a1c6ecc55be42d96e2a0526d71fd51c9b", null ],
      [ "LA_XCENTER_YTOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a546848f232c0cb79a70516945e7f367e", null ],
      [ "LA_XCENTER_YCENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a52f28c20ee4e911fb6ed75b648f6305d", null ]
    ] ],
    [ "LegendOrientation", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a339aacb19b79675bd3bc9a903349d933", [
      [ "LO_VERTICAL", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a339aacb19b79675bd3bc9a903349d933ae89817b11c6c1230e3a9b56d04d402fa", null ],
      [ "LO_HORIZONTAL", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a339aacb19b79675bd3bc9a903349d933aff8809926fbf87a325921ca8ab072a48", null ]
    ] ],
    [ "~Legend", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#ad866de035a14c9ece144e553aa2d9ec8", null ]
];