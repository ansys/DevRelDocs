var group__dvs =
[
    [ "DVS URIs", "group__group__dvs__uri.xhtml", "group__group__dvs__uri" ],
    [ "DVS Files", "group__group__dvs__file.xhtml", "group__group__dvs__file" ],
    [ "DVS Filtering", "group__group__dvs__filtering.xhtml", "group__group__dvs__filtering" ],
    [ "DVS Cache", "group__group__dvs__cache.xhtml", "group__group__dvs__cache" ],
    [ "DVS Features", "group__group__dvs__features.xhtml", "group__group__dvs__features" ],
    [ "DVS Reader", "group__group__dvs__reader.xhtml", "group__group__dvs__reader" ],
    [ "DVS Data Model", "group__group__dvs__data__model.xhtml", "group__group__dvs__data__model" ],
    [ "DVS Metadata", "group__group__dvs__metadata.xhtml", "group__group__dvs__metadata" ],
    [ "DVS Server", "group__group__dvs__server.xhtml", "group__group__dvs__server" ],
    [ "", "group__dvs.xhtml", null ]
];