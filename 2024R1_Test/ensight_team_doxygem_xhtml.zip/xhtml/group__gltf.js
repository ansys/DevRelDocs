var group__gltf =
[
    [ "AnimationSampler", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_animation_sampler.xhtml", [
      [ "AnimationSamplerType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_animation_sampler.xhtml#a79f9f2fc6db56d1fccc493a6efe4f932", [
        [ "AST_LINEAR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_animation_sampler.xhtml#a79f9f2fc6db56d1fccc493a6efe4f932a5ce54cba61897101d0dc84e38e55d4bc", null ]
      ] ],
      [ "~AnimationSampler", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_animation_sampler.xhtml#ae61e3f3f64700aeff8781a713e6e0aa6", null ]
    ] ],
    [ "Attribute", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml", [
      [ "AttributeType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddb", [
        [ "AT_INT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba61b89340f40b606720433dcd8da573e4", null ],
        [ "AT_FLOAT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba6d124c894e5bdc043eeebec0f852e857", null ],
        [ "AT_FLOAT_VEC2", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddbaed110dc9dd248a0a28797e7a6763cf6a", null ],
        [ "AT_FLOAT_VEC3", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba0e6049e71b78dccf0f7f9791abe541c3", null ],
        [ "AT_FLOAT_VEC4", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba5af14585a5eb16f52089b1baf55db718", null ],
        [ "AT_FLOAT_MAT4", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#aa787c451052ac912fd9af91c4ff54ddba13e136aa2ada6dbe9a5253695b6abf65", null ]
      ] ],
      [ "~Attribute", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#ae4febdec4e1f68a2b051d53460c44bf9", null ],
      [ "SetLogarithmic", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#ae5dd11c515ff409ca74e94693f2d1585", null ],
      [ "SetMinMax", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#a1d3b6de1515034297d22160fc84edcfd", null ],
      [ "SetMinMax", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_attribute.xhtml#ae56748a9592c0ecdc8c933e2068f5a9f", null ]
    ] ],
    [ "Buffer", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_buffer.xhtml", [
      [ "~Buffer", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_buffer.xhtml#a0af80b09b0e8515f0512c3ee3a15a90e", null ]
    ] ],
    [ "Camera", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_camera.xhtml", [
      [ "~Camera", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_camera.xhtml#a89be2fded33fa77e9392b2b956efdcc6", null ]
    ] ],
    [ "GLTF", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml", [
      [ "GLTFError", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafe", [
        [ "GLTF_ERROR_NONE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea049c3b804e69ae05c02f4c2dedf4e0ea", null ],
        [ "GLTF_ERROR_DUPLICATE_VALUE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea97ced97a4c4799ac0434f89a04806113", null ],
        [ "GLTF_ERROR_INCOMPATIBLE_VALUE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea4b4a18acdadcea64ac7afdc249170318", null ],
        [ "GLTF_ERROR_INVALID_PATH", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea1afb281a63002ee2c8a668422eccd5c0", null ],
        [ "GLTF_ERROR_INVALID_TARGET", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea7cf97ea67f80ee2bcdfcb9cfab7095c7", null ],
        [ "GLTF_ERROR_INVALID_TYPE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea59ad81f97b600a6e8c960411ed67496a", null ],
        [ "GLTF_ERROR_INVALID_VALUE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea382e97e558c7245031b324d4b91ab5f4", null ],
        [ "GLTF_ERROR_MEMORY", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafead705f5ff45e81718b44e3310b82a57ff", null ],
        [ "GLTF_ERROR_RANGE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafeaa983770c4317af7082d25f68c006e213", null ],
        [ "GLTF_ERROR_READ", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafead5336526c4f7a3cb42cb89bce88133f6", null ],
        [ "GLTF_ERROR_SIZE_MISMATCH", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafeae3bd2b97e6b41436340e0dd3954d5d26", null ],
        [ "GLTF_ERROR_VALUE_NOT_INITIALIZED", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea1c47ef5344946e5eea78d3543fe665f3", null ],
        [ "GLTF_ERROR_WRITE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea148ae23ac711c7f43dd16e92348937a3", null ],
        [ "GLT_ERROR_MAX", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#acf83a4d185d959503cb9f3f2c2e9fafea35402f8ddb046aebe01e9cf80d451229", null ]
      ] ],
      [ "OutputType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987c", [
        [ "OT_AVZ", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987caffc12fe8ec514248496a1469f781c9e1", null ],
        [ "OT_GLTF", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987ca35927e6892acc7aebd8ed3637a26a990", null ],
        [ "OT_GLB1", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987cadc89ceda75f446f79272885e11433366", null ],
        [ "OT_GLTF1", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987ca2022f4f2ac71f6d10ffa9bdd50400e05", null ],
        [ "OT_GLB2", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a65f7ca2b0855b66b6ae9f93bd3c1987caa5f5fcd8755f4a1ed14e6e09664d509a", null ]
      ] ],
      [ "~GLTF", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a6b330426d936ab04272e2b154c3551c7", null ],
      [ "GetError", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a812b885f21ed48bad70fea6b03e76913", null ],
      [ "SetDefaultScene", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a70b6a7145217bb4033fd8623bd58ec56", null ],
      [ "Write", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_g_l_t_f.xhtml#a7a468ecf1f594b411023782d18f08823", null ]
    ] ],
    [ "Image", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_image.xhtml", [
      [ "~Image", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_image.xhtml#a443c4109e065dc9405a535da16c5b40e", null ]
    ] ],
    [ "Index", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_index.xhtml", [
      [ "~Index", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_index.xhtml#ae4fae07722be35742cefde472cc7f5f8", null ]
    ] ],
    [ "Legend", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml", [
      [ "LegendAttachment", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2", [
        [ "LA_X_Y", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a1ffb33df0a6250b5d46b08c4b92f054a", null ],
        [ "LA_X_YBOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a6f8042caf6888d46d80f8420b21f117e", null ],
        [ "LA_X_YTOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a83b0eeafc16527b732764d5a748ad350", null ],
        [ "LA_X_YCENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a78c88258f5d9a3a003e6bb1d49446c3b", null ],
        [ "LA_XLEFT_Y", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2ae6d51f9195218713c1ff23e50eb91cb2", null ],
        [ "LA_XLEFT_YBOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a19e036b97243b63f95de8083790fba45", null ],
        [ "LA_XLEFT_YTOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2ad03c7746261cd58437b7ee988998c8fb", null ],
        [ "LA_XLEFT_YCENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2aae4032f867cdd2bc3425e78c1e272b15", null ],
        [ "LA_XRIGHT_Y", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2ac1506dad41a0a6ca7e8566fca9af9dc4", null ],
        [ "LA_XRIGHT_YBOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a25f3aff8bc8c1e7dbe6b5b08fa1cf9e4", null ],
        [ "LA_XRIGHT_YTOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a32ce101a5040ea5539acb4b81b41a050", null ],
        [ "LA_XRIGHT_YCENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a74c6997c4d92c6b6c95e67dbe827fe32", null ],
        [ "LA_XCENTER_Y", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a7cd51c74ffd247c065f7f92871849f3a", null ],
        [ "LA_XCENTER_YBOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a1c6ecc55be42d96e2a0526d71fd51c9b", null ],
        [ "LA_XCENTER_YTOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a546848f232c0cb79a70516945e7f367e", null ],
        [ "LA_XCENTER_YCENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a96892dc857e05a292528ddc6c29a6ea2a52f28c20ee4e911fb6ed75b648f6305d", null ]
      ] ],
      [ "LegendOrientation", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a339aacb19b79675bd3bc9a903349d933", [
        [ "LO_VERTICAL", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a339aacb19b79675bd3bc9a903349d933ae89817b11c6c1230e3a9b56d04d402fa", null ],
        [ "LO_HORIZONTAL", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#a339aacb19b79675bd3bc9a903349d933aff8809926fbf87a325921ca8ab072a48", null ]
      ] ],
      [ "~Legend", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_legend.xhtml#ad866de035a14c9ece144e553aa2d9ec8", null ]
    ] ],
    [ "Light", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_light.xhtml", [
      [ "~Light", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_light.xhtml#aa1ae6c58e45efaaa56b1601312b5582e", null ]
    ] ],
    [ "Material", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_material.xhtml", [
      [ "~Material", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_material.xhtml#a2fcb4fa0119e24b598d013866d5a1615", null ],
      [ "AppendValue", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_material.xhtml#a17160c12f2a00713c522c371a22dbca5", null ],
      [ "Mirror", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_material.xhtml#a89ffaa0811aa070c4b6dcd364fa4e252", null ]
    ] ],
    [ "Primitive", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml", [
      [ "PrimitiveType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6e", [
        [ "PT_POINTS", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea0774f687d37a015adb12a7c57f157190", null ],
        [ "PT_LINES", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea58ccc160090e6c9189f73c4644e66c0e", null ],
        [ "PT_LINE_LOOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6eaf50567675c73731765f0fc37183b1691", null ],
        [ "PT_LINE_STRIP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea5b76ec80fb7d96f1aa4dbc5a136929a6", null ],
        [ "PT_TRIANGLES", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea85ba263ad510a4b423c5e1452fd5ca7d", null ],
        [ "PT_TRIANGLE_STRIP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6eafc347f454c2be56abecc316154511956", null ],
        [ "PT_TRIANGLE_FAN", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a062b429c87d913e5adda11b381414c6ea9188d6dcf0e77ae8346e0211f1996320", null ]
      ] ],
      [ "PrimitiveXAttachment", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951", [
        [ "PXA_NONE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951ae5e474e4fe7bb28e1ad2acbbc41fa6b8", null ],
        [ "PXA_LEFT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951a6dc9b18bbe43f04ff6744a5111f0a4a3", null ],
        [ "PXA_CENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951a51f4037d8a135dab3589f9a28e53282a", null ],
        [ "PXA_RIGHT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a3c17546f3d50b4462d11df6819f93951a2711064b0fe78b1e55fd2741e18bf68d", null ]
      ] ],
      [ "PrimitiveYAttachment", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbba", [
        [ "PYA_NONE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbbaa2247ad1da9dfef04911a51657c3163d8", null ],
        [ "PYA_BOTTOM", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbbaa447716243f146a5606c2366e068a997e", null ],
        [ "PYA_CENTER", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbbaa55629dea10122996e3ff9915fb6658ba", null ],
        [ "PYA_TOP", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a1537dd0f96086f101b67ad7f8640cbbaa7b6fa012e0f07cb84f0e05345174f93d", null ]
      ] ],
      [ "~Primitive", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#aac340023684f1838ed439ac4d02940d9", null ],
      [ "AppendAttribute", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#a4aae56e343ac5130d42416d2ee4c52e3", null ],
      [ "Mirror", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_primitive.xhtml#aee628309c26c8a02c3056fffa42aed03", null ]
    ] ],
    [ "Node", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_node.xhtml", [
      [ "~Node", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_node.xhtml#a52f9112b9ffa4fde23383ae0e19c0be1", null ],
      [ "AppendChild", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_node.xhtml#a85f627158b9e2f1a6565ffe1305e7439", null ],
      [ "AppendLight", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_node.xhtml#a229725aed9694dd14f7023d5445bbc72", null ],
      [ "AppendMesh", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_node.xhtml#a29e43db3c3bd933a51c2e99e223e41bd", null ],
      [ "NumChildren", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_node.xhtml#a353d1047251b29924de156f23e3f911a", null ],
      [ "NumMeshes", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_node.xhtml#a9bcc098d4b34c70e49e1b898b5d995bc", null ]
    ] ],
    [ "Program", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_program.xhtml", [
      [ "~Program", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_program.xhtml#a94113cbba13f1121ad70c76e6c4f0ba4", null ]
    ] ],
    [ "Sampler", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml", [
      [ "FilterType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2", [
        [ "FT_NEAREST", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2a6939890bb36dae2b7400ec07dda505a3", null ],
        [ "FT_LINEAR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2a540209ea328f7641ded2ef95340a4df6", null ],
        [ "FT_NEAREST_MIPMAP_NEAREST", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2a3ca339eb7d704e0df6a5a70a56e38a9d", null ],
        [ "FT_LINEAR_MIPMAP_NEAREST", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2adaf913049a73b76f655fee7017fd9735", null ],
        [ "FT_NEAREST_MIPMAP_LINEAR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2af04c2a7d89ec1932406044358213053f", null ],
        [ "FT_LINEAR_MIPMAP_LINEAR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a55783834d84736df773ee55e1e9068f2aeecfdb00bdb01409d41812961fca2ad8", null ]
      ] ],
      [ "WrapType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a0be78b3605d660441f31d5a90e463443", [
        [ "WT_REPEAT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a0be78b3605d660441f31d5a90e463443a75e8a28a9d155e09ff6b697429fa7a6e", null ],
        [ "WT_CLAMP_TO_EDGE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a0be78b3605d660441f31d5a90e463443a9edafbff43bdb6b2e77fab3fd1b545aa", null ],
        [ "WT_MIRRORED_REPEAT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a0be78b3605d660441f31d5a90e463443ab8da208d3e57f59504472b848fc24952", null ]
      ] ],
      [ "~Sampler", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_sampler.xhtml#a7fe992a1ce54447440a20d9b6a755d98", null ]
    ] ],
    [ "Scene", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml", [
      [ "BackgroundType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#ac17baf491cdba3613b0aa39719a3dbd8", [
        [ "BT_NONE", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#ac17baf491cdba3613b0aa39719a3dbd8a65fc5b9c2360c79b260b212430053e59", null ],
        [ "BT_SOLID", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#ac17baf491cdba3613b0aa39719a3dbd8aeea551002921bb989b3ed35678ec982b", null ],
        [ "BT_TB", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#ac17baf491cdba3613b0aa39719a3dbd8a0e9df8d9774401657f9d7aad4e18728f", null ],
        [ "BT_LR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#ac17baf491cdba3613b0aa39719a3dbd8a563f2a71e6d4083ff6d0e2e6febfac72", null ],
        [ "BT_TLBR", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#ac17baf491cdba3613b0aa39719a3dbd8acc30bd85d5eae5626281239fe84c3522", null ]
      ] ],
      [ "~Scene", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#afb0b5602239c04079581cee5013ad547", null ],
      [ "Add2DText", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#a17ec197a0df8ce135b3c0100b79c11d7", null ],
      [ "Add3DText", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#a4abd212be82d4a229706c245d8db9a35", null ],
      [ "AppendMesh", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#adea272bb6570744737a12f7f639e40fd", null ],
      [ "SetCamera", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#a032a02e7ff85707f8ae02dce0ec11ce4", null ],
      [ "SetClipPlane", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#a1de67b73e229a59c58113807e04af2dd", null ],
      [ "SetLight", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#ad59f57e366c5376b197aed0b10de4f71", null ],
      [ "SetProxyImage", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_scene.xhtml#ac53c52f457c3d6616e467438df37d621", null ]
    ] ],
    [ "Shader", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_shader.xhtml", [
      [ "~Shader", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_shader.xhtml#a237b7acbcd34bca02909196e4774a93b", null ]
    ] ],
    [ "Parameter", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml", [
      [ "ParameterType", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572c", [
        [ "PT_INT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572ca2d1bb71b03b6441e9908b149d6dd1fb3", null ],
        [ "PT_FLOAT", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572ca19c98b6589cd105e66bd34418a401781", null ],
        [ "PT_FLOAT_VEC2", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572caf1f10a2c8fd2982bf1826370bb7a0f4b", null ],
        [ "PT_FLOAT_VEC3", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572ca9e032d6885dc8956db47d4de23a046ce", null ],
        [ "PT_FLOAT_VEC4", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572ca2ee53691b02a2647b586f8325184aee9", null ],
        [ "PT_INT_VEC2", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572caada3187a9c39033ca76fd91257c1843d", null ],
        [ "PT_INT_VEC3", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572ca1f6e42c4388d7749ab49fefeaed8cc1d", null ],
        [ "PT_INT_VEC4", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572caf01904fd050d19781c08eb65e0a0c89d", null ],
        [ "PT_BOOL", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572cabb63552893274e73c04b7caf7c168cbb", null ],
        [ "PT_FLOAT_MAT3", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572ca079041140bb22dd4fe83de8e06557661", null ],
        [ "PT_FLOAT_MAT4", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572ca3ee4f3ed5774f20008423350a5baa74a", null ],
        [ "PT_SAMPLER_2D", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#a93b92cf730f9530cef13458f0b12572caae7eac8db24a1df5567994ab2062d468", null ]
      ] ],
      [ "~Parameter", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_parameter.xhtml#abc4d125c1bf4d829d86dabec43371d42", null ]
    ] ],
    [ "Texture", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml", [
      [ "TextureFormat", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#aba6db4f52b9f0a1a866bce302b6d8964", [
        [ "TF_RGB", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#aba6db4f52b9f0a1a866bce302b6d8964aaa8ea9a0e6b83932a6a882b1655e8e59", null ],
        [ "TF_RGBA", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#aba6db4f52b9f0a1a866bce302b6d8964ab39a20cf05b8cbdd813d3278664879af", null ]
      ] ],
      [ "TextureTarget", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#a97a19c95bbcdc6bbf5951636a4d70e53", [
        [ "TT_TEXTURE_2D", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#a97a19c95bbcdc6bbf5951636a4d70e53ace1a5ae468e3deb5b78b1d5ed9f61263", null ]
      ] ],
      [ "~Texture", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_texture.xhtml#ab6d512f7bbc65d8b7d201eb257189443", null ]
    ] ],
    [ "Value", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml", [
      [ "~Value", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a817255ad6a8c2c4213d828668b6d1a1f", null ],
      [ "Append", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a71a0c1673f29bd17f151d656b2e5d20c", null ],
      [ "Append", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#afba2497c06b6ddfd500c302dfd9fcbbe", null ],
      [ "elemD", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#ae85df55775fc4d616c70b8f56775ffd8", null ],
      [ "elemS", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#ab68ed89ce063017fc4edf33f238e39b9", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a727cc4b43c23e4404c88b5f4b9e7e6b1", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a86b24c5305ac68fa3edae8179f74e8a6", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a0a09a9331bc683f60336d63a8c2fa6ed", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#aeb9077e7def645a8b053eedb550c1d1c", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#ae6d698fe9c7213333f6259bd2e648cd2", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a749860d3862d60086133d74b48edd6e5", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a00142a70a3b2095c69d89326d8959ba2", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a906d5aba0c13e575910f54f5c5631fad", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#abb0e5ed0d020e7fb037473ef60f0af55", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#abdb0d8b7722cb29136fcb47da4b590f1", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#aedd6e4f026418125f3707a8c14e6dc21", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a67da789ae0d18f77a00d111e4a49e205", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#aa3fc4f41646e5266180ae461ab05ed5c", null ],
      [ "Set", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#a26b18046ec4fb4621e7b0ecde0150967", null ],
      [ "Size", "class_a_n_s_y_s_1_1_nexus_1_1_g_l_t_f_writer_1_1_value.xhtml#af29f4e14a62716a228a514f941b269cb", null ]
    ] ]
];