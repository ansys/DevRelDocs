var dvs__server__interface_8h =
[
    [ "IServer", "class_d_v_s_1_1_i_server.xhtml", "class_d_v_s_1_1_i_server" ],
    [ "CREATE_SERVER_INSTANCE", "dvs__server__interface_8h.xhtml#a947baebb085bb6a390f64b3a814934f0", null ],
    [ "DESTROY_SERVER_INSTANCE", "dvs__server__interface_8h.xhtml#adcdcbab1954ec53631a7136af7fc49b8", null ]
];