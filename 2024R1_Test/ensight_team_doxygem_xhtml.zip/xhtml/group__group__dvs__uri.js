var group__group__dvs__uri =
[
    [ "DVS URIs", "group__group__dvs__uri.xhtml#dvs_uri", "group__group__dvs__uri_dvs_uri_dup" ]
];