var group__group__dvs__reader_dvs_reader_dup =
[
    [ "DVS Reader API Overview", "group__group__dvs__reader.xhtml#dvs_reader_overview", null ],
    [ "DVS Reader Data Model", "group__group__dvs__reader.xhtml#dvs_reader_data_model", null ],
    [ "Getting started with the DVS Reader API", "group__group__dvs__reader.xhtml#dvs_reader_getting_started", null ],
    [ "DVS Reader Examples", "group__group__dvs__reader.xhtml#dvs_reader_examples", [
      [ "Hello World Example", "group__group__dvs__reader.xhtml#dvs_example_hello_world", null ],
      [ "Using Filters Example", "group__group__dvs__reader.xhtml#dvs_example_using_filters", null ],
      [ "Setting up for parallel reads of cache", "group__group__dvs__reader.xhtml#dvs_example_parallelism", null ]
    ] ]
];