var structensightservice_1_1_python_reply =
[
    [ "error", "structensightservice_1_1_python_reply.xhtml#a31138ba0be4a2af567e317a29c8b4b90", null ],
    [ "value", "structensightservice_1_1_python_reply.xhtml#a4a877b8be80e175c8a6f2f70fd7de0d6", null ]
];