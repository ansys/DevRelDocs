var structensightservice_1_1_geometry_request =
[
    [ "GeometryType", "structensightservice_1_1_geometry_request.xhtml#a6dfcd12a837a513b553fd3a9f26a1949", [
      [ "GEOMETRY_GLB", "structensightservice_1_1_geometry_request.xhtml#a6dfcd12a837a513b553fd3a9f26a1949a573d6f6381c7608c4d822817e9048e1b", null ]
    ] ],
    [ "type", "structensightservice_1_1_geometry_request.xhtml#a66eb5611c0387f5e3440d0b3a24408a0", null ]
];