var globals_dup =
[
    [ "b", "globals.xhtml", null ],
    [ "c", "globals_c.xhtml", null ],
    [ "d", "globals_d.xhtml", null ],
    [ "e", "globals_e.xhtml", null ],
    [ "f", "globals_f.xhtml", null ],
    [ "g", "globals_g.xhtml", null ],
    [ "i", "globals_i.xhtml", null ],
    [ "l", "globals_l.xhtml", null ],
    [ "m", "globals_m.xhtml", null ],
    [ "n", "globals_n.xhtml", null ],
    [ "p", "globals_p.xhtml", null ],
    [ "s", "globals_s.xhtml", null ],
    [ "t", "globals_t.xhtml", null ],
    [ "u", "globals_u.xhtml", null ],
    [ "v", "globals_v.xhtml", null ],
    [ "w", "globals_w.xhtml", null ]
];