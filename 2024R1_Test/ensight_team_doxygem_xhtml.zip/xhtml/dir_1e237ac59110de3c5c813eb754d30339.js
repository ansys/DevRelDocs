var dir_1e237ac59110de3c5c813eb754d30339 =
[
    [ "include", "dir_f4d314ac8d74478defd979fa7e44a408.xhtml", "dir_f4d314ac8d74478defd979fa7e44a408" ],
    [ "dvs_client_interface.h", "dvs__client__interface_8h.xhtml", "dvs__client__interface_8h" ],
    [ "dvs_server_interface.h", "dvs__server__interface_8h.xhtml", "dvs__server__interface_8h" ],
    [ "dynamic_visualization_store_api.h", "dynamic__visualization__store__api_8h.xhtml", "dynamic__visualization__store__api_8h" ],
    [ "dynamic_visualization_store_enums.h", "dynamic__visualization__store__enums_8h.xhtml", "dynamic__visualization__store__enums_8h" ],
    [ "dynamic_visualization_store_error_codes.h", "dynamic__visualization__store__error__codes_8h.xhtml", "dynamic__visualization__store__error__codes_8h" ],
    [ "dynamic_visualization_store_version.h", "dynamic__visualization__store__version_8h.xhtml", "dynamic__visualization__store__version_8h" ],
    [ "logger_interface.h", "logger__interface_8h.xhtml", [
      [ "ILogger", "class_d_v_s_1_1_i_logger.xhtml", "class_d_v_s_1_1_i_logger" ]
    ] ],
    [ "logger_verbose.h", "logger__verbose_8h.xhtml", [
      [ "LoggerVerbose", "class_d_v_s_1_1_logger_verbose.xhtml", "class_d_v_s_1_1_logger_verbose" ]
    ] ],
    [ "test_dvs_client.c", "test__dvs__client_8c.xhtml", "test__dvs__client_8c" ],
    [ "test_dvs_client_cxx.cpp", "test__dvs__client__cxx_8cpp.xhtml", "test__dvs__client__cxx_8cpp" ],
    [ "test_dvs_client_simple.py", "test__dvs__client__simple_8py.xhtml", null ],
    [ "test_dvs_reader.cpp", "test__dvs__reader_8cpp.xhtml", "test__dvs__reader_8cpp" ],
    [ "test_dvs_server.cpp", "test__dvs__server_8cpp.xhtml", "test__dvs__server_8cpp" ]
];