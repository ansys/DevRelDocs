var interfacefortran_1_1syscgetsetupfileinfof =
[
    [ "syscgetsetupfileinfof", "interfacefortran_1_1syscgetsetupfileinfof.xhtml#a229b1f07d15719212cf4a6f65e0a016a", null ]
];