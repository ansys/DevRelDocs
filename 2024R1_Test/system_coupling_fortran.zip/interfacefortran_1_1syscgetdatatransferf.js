var interfacefortran_1_1syscgetdatatransferf =
[
    [ "syscgetdatatransferf", "interfacefortran_1_1syscgetdatatransferf.xhtml#ac52f9b1a5b54382e682daa312d5babd2", null ]
];