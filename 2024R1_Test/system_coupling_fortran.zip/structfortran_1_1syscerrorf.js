var structfortran_1_1syscerrorf =
[
    [ "message", "structfortran_1_1syscerrorf.xhtml#a03ea72a9d280946f9411ff9c261f7fa6", null ],
    [ "retcode", "structfortran_1_1syscerrorf.xhtml#a79a9fe07cdde873d9bf5a786ee076cba", null ]
];