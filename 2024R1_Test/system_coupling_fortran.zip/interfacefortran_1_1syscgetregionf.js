var interfacefortran_1_1syscgetregionf =
[
    [ "syscgetregionf", "interfacefortran_1_1syscgetregionf.xhtml#a2033792a2361b06de6d370b17c53f187", null ],
    [ "syscgetregionf_dt", "interfacefortran_1_1syscgetregionf.xhtml#ae4a9592f42bdf1a92abf228ca710dfe6", null ],
    [ "syscgetregionf_t", "interfacefortran_1_1syscgetregionf.xhtml#a57e21d2ee2e6a7680974ea1d8c94b7c3", null ],
    [ "syscgetregionf_tm", "interfacefortran_1_1syscgetregionf.xhtml#a35c25f1de5857e61b4c3ed2966e58178", null ]
];