var classsysc_1_1Region =
[
    [ "Region", "classsysc_1_1Region.xhtml#a9a3643efd6eb393f07a5e0db931dc71d", null ],
    [ "Region", "classsysc_1_1Region.xhtml#a2252ae93ab73cff96e3ba621d9e29171", null ],
    [ "Region", "classsysc_1_1Region.xhtml#ae497ce9374217eaf46630abc28cb8ccf", null ],
    [ "Region", "classsysc_1_1Region.xhtml#a1ef115d09f9dc1c7a1670727b41f9509", null ],
    [ "Region", "classsysc_1_1Region.xhtml#ac7b2a140a74fb4a6b857336316b4dd48", null ],
    [ "addInputVariable", "classsysc_1_1Region.xhtml#a018cbfef9eee8c3d2cd3b20084783390", null ],
    [ "addOutputVariable", "classsysc_1_1Region.xhtml#a96143a5b4d943e47d335d74fa1f827be", null ],
    [ "getDisplayName", "classsysc_1_1Region.xhtml#a540f90127c8c96d04b7ed4eeaaa25ef0", null ],
    [ "getInputVariable", "classsysc_1_1Region.xhtml#a5d6cb2b4910d0c45b8a0143015d4646c", null ],
    [ "getInputVariable", "classsysc_1_1Region.xhtml#ac65f50843c983cb16e166af21c2268af", null ],
    [ "getName", "classsysc_1_1Region.xhtml#aa388e994e2e4392035b92f1090bd5b5f", null ],
    [ "getNumInputVariables", "classsysc_1_1Region.xhtml#ac7632c3c0b045c7baf3aef7aaa7a4c86", null ],
    [ "getNumOutputVariables", "classsysc_1_1Region.xhtml#ada5d320ba7226a798ac5683fd878035a", null ],
    [ "getOutputVariable", "classsysc_1_1Region.xhtml#affb8d00a64339c0c65e7db9c7d1d2797", null ],
    [ "getOutputVariable", "classsysc_1_1Region.xhtml#a732fe2faeab2833bfa77380703e0da79", null ],
    [ "getRegionDiscretizationType", "classsysc_1_1Region.xhtml#a25fc09a4236bf1cefbac4e5ff4b9736b", null ],
    [ "getTopology", "classsysc_1_1Region.xhtml#a55d078aeaec8518bbe4468e41a053c1c", null ]
];