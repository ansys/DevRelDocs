var structsysc_1_1FaceCellConnectivityData =
[
    [ "FaceCellConnectivityData", "structsysc_1_1FaceCellConnectivityData.xhtml#aa2566e5d0aa59b3fb0d79968001b371d", null ],
    [ "FaceCellConnectivityData", "structsysc_1_1FaceCellConnectivityData.xhtml#a2628d79a19f551ba099deace8d6c0625", null ],
    [ "FaceCellConnectivityData", "structsysc_1_1FaceCellConnectivityData.xhtml#a98c490d601606aab41011dc8a1d67577", null ],
    [ "FaceCellConnectivityData", "structsysc_1_1FaceCellConnectivityData.xhtml#ae53635823a4f5d5d2703bc1e5c4c3ecb", null ],
    [ "operator=", "structsysc_1_1FaceCellConnectivityData.xhtml#ae4cd9c83035945eed0e360adfe08235e", null ],
    [ "operator=", "structsysc_1_1FaceCellConnectivityData.xhtml#ae796325a0b7d80621784e3033d1eac21", null ],
    [ "cell0Ids", "structsysc_1_1FaceCellConnectivityData.xhtml#aa0ca1cf99c9e1101d81d50654f52889e", null ],
    [ "cell1Ids", "structsysc_1_1FaceCellConnectivityData.xhtml#a198df63a8595512c5f50eef276043cc3", null ]
];