/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "System Coupling 2024 R1 Participant Library:  C++ Interfaces", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "System Coupling Participant Library Capabilities", "md_02__ParticipantLibraryCapabilities.xhtml", null ],
    [ "Concepts Overview", "md_03__ConceptsAndTerminology.xhtml", null ],
    [ "Steps to Perform Mapping", "md_04__ParticipantStepsForMapping.xhtml", null ],
    [ "Steps to Set Up and Execute the Coupled Analysis", "md_05__StepsToSetupAndExecutedCoupledAnalysis.xhtml", null ],
    [ "Completing the System Coupling Participant Setup", "md_06__ParticipantSetup.xhtml", null ],
    [ "Participant Steps in a Coupled Analysis", "md_07__ParticipantStepsInCoupledAnalysis.xhtml", null ],
    [ "Command Line Arguments for Participant Solvers", "md_08__CommandLineArguments.xhtml", null ],
    [ "Execution in a Parallel Environment", "md_09__ParallelExecution.xhtml", null ],
    [ "Access to Parameter Data", "md_10__ParameterDataAccess.xhtml", null ],
    [ "Access to Heavyweight Data", "md_11__HeavyweightDataAccess.xhtml", null ],
    [ "Mesh And Point Cloud Data Access", "md_12__MeshDataAccess.xhtml", null ],
    [ "Creating Restart Points and Restarting a Coupled Analysis", "md_13__Restarts.xhtml", null ],
    [ "Multi-Region Coupling Interfaces", "md_14__Multiregion.xhtml", null ],
    [ "Debugging Tools", "md_15__DebuggingTools.xhtml", null ],
    [ "Migration Guide and Known Issues", "md_16__MigrationGuide.xhtml", null ],
    [ "Compiling, Linking, and Executing Applications That Use the Participant Library", "md_17__CompilingLinkingExecuting.xhtml", null ],
    [ "Heat Transfer in Square Channel Air Flow Tutorial", "md_18__ChannelFlowTutorial.xhtml", null ],
    [ "Oscillating Plate Damping Tutorial", "md_19__PlateDampingTutorial.xhtml", null ],
    [ "Pipe Mapping Tutorial", "md_20__PipeMappingTutorial.xhtml", null ],
    [ "Release notes for 2024 R1", "md_21__ReleaseNotes.xhtml", null ],
    [ "Topics", "topics.xhtml", "topics" ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ],
      [ "Class Index", "classes.xhtml", null ],
      [ "Class Members", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.xhtml",
"classsysc_1_1OutputVectorData.xhtml#a406d3ea15f90374c6e4c2c5a4a06f98e",
"functions_vars.xhtml"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';