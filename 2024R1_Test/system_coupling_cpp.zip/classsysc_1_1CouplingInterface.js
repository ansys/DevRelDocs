var classsysc_1_1CouplingInterface =
[
    [ "CouplingInterface", "classsysc_1_1CouplingInterface.xhtml#a606ddfa3113e3e0bf1ee7eee2b58793d", null ],
    [ "addDataTransfer", "classsysc_1_1CouplingInterface.xhtml#ab1230f4b0c7dc52fff73d1ddcd67f03e", null ],
    [ "addSideOneRegion", "classsysc_1_1CouplingInterface.xhtml#ab7a385065f0fde034baa88a88f274946", null ],
    [ "addSideTwoRegion", "classsysc_1_1CouplingInterface.xhtml#a5afdb8ffa5c06d66fe30e6f150230b67", null ],
    [ "getDataTransfer", "classsysc_1_1CouplingInterface.xhtml#aeff28058491eb4a52d5833f38b4214c7", null ],
    [ "getName", "classsysc_1_1CouplingInterface.xhtml#ac9975e59d9c18d893af5b153211e2635", null ],
    [ "getNumDataTransfers", "classsysc_1_1CouplingInterface.xhtml#a9ac1bf66c466b9567e26fdf5c2108c05", null ],
    [ "getNumSideOneRegions", "classsysc_1_1CouplingInterface.xhtml#a84873c1535d70a88096d44242c97a1b7", null ],
    [ "getNumSideTwoRegions", "classsysc_1_1CouplingInterface.xhtml#a03a32678f212092a83149ea2b0c54f20", null ],
    [ "getSideOneRegion", "classsysc_1_1CouplingInterface.xhtml#a540b82fcd3f5aa6c5e3726e429960d35", null ],
    [ "getSideTwoRegion", "classsysc_1_1CouplingInterface.xhtml#a824ed032106d36fd0202a8b6f92a8a20", null ]
];