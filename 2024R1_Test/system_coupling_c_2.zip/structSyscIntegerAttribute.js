var structSyscIntegerAttribute =
[
    [ "name", "structSyscIntegerAttribute.xhtml#ab13f95caf8c2c7b73b3c3f2435876f27", null ],
    [ "value", "structSyscIntegerAttribute.xhtml#a272f235cfc28cb256a9f5793cb3d51f4", null ]
];