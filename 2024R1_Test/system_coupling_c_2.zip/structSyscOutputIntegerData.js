var structSyscOutputIntegerData =
[
    [ "data", "structSyscOutputIntegerData.xhtml#a27cf91c94d9a2550d8697e562831e2d4", null ],
    [ "primitiveType", "structSyscOutputIntegerData.xhtml#a208237662f53658a829a9ee82cfe3b24", null ],
    [ "size", "structSyscOutputIntegerData.xhtml#a4bfb506a93651c8c2519f6dd094ae53f", null ]
];