var structSyscElementNodeConnectivityData =
[
    [ "elementNodeIds", "structSyscElementNodeConnectivityData.xhtml#a08dfd1139cb4d1b40de4480d91a87565", null ]
];