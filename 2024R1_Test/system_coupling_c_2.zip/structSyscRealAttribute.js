var structSyscRealAttribute =
[
    [ "dimensionality", "structSyscRealAttribute.xhtml#a4a2a0d3d61d37523416b353c3dc2585c", null ],
    [ "name", "structSyscRealAttribute.xhtml#a6be2003fdd58b29a31513f1025a44218", null ],
    [ "value", "structSyscRealAttribute.xhtml#ac6dd95726f82ff857471b1967c42b235", null ]
];