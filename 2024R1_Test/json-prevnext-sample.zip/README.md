# Generic JSON Example Dataset with Parent-Previous-Next Navigation Links

This is a very simple JSON dataset that encapsulates what the generic importer on the Ansys developer portal is looking for and will process. Note that your JSON output should be flattened into one directory, with subdirectories (one level) for images and other assets.

This particular importer reconstructs sidebar navigation and information hierarchy, including breadcrumbs, from the Parent-Previous-Next navigation links that are inline in each JSON file. For example, PyAnsys' Sphinx JSON output is structured exactly like this.

## Navigation
```
{"parents": [{"link": "../parent", "title": "ParentItem"}],
 "prev": {"link": "./item1", "title": "Item1"},
 "next": {"link": "./item3", "title": "Item3"},
 ```

This navigation section is mandatory in each JSON file. The JSON keys ```parents, prev, next``` are arbitrary names, you will be able to provide a map from your key names to the developer portal's targets. 

The importer will extract the parent-prev-next relationships and reconstruct a complete sidebar menu from that, as well as information hierarchy and breadcrumbs. Please be sure that your JSON export also specifies main navigation (top menu) items as parents, as all navigation within your product documentation will move into the sidebar on the developer portal.

```
"current_page_name": "ParentItem/Item2",
```

This line is optional. The importer uses the ```title``` property if the ```current_page_name``` is not supplied.

## Meta Information

```
"meta": {"last_updated": "date", "version": "version", "summary": "summary"},
```
All meta information is optional, but extremely useful to provide proper tagging on import. If last_updated is omitted, the importer will use the import date. If version is omitted, no version inforamtion will be displayed on the portal. Summary will be used for <meta name="description" entry in the HTML head section for SEO purposes, instead of the portal auto-extracting the title and first paragraph from the content.

## Content

```
 "title": "Item2",
 "body": "<h1>Item2</h1>\n<p>This section contains some text.</p><img alt=\"This is an image\" src=\"./images/image1.webp\" /></img>"
```

Both ```title``` and ```body``` as mandatory. You may name these properties differently, you will be able to provide a map from your key names to the developer portal's targets. 

The body value can contain any valid HTML, including links and image references. Please make sure that internal links and image references are relative and conform to the implied parent-prev-next hierarchy. Note that all inline style specifications will be disregarded and supplanted by the developer portal styles. In other words, if text is a heading, it must have a heading tag (h1, h2, h3, etc.), and if text is to be bold or italic it must have the appropriate HTML tag as well. HTML classes will be retained, and if classes in your source match classes and styling used in the portal, they will be honored. In particular, valid ```<code class="language-python">``` markup (substitute any other common language here) will result in appropriate code highlighting.

## Images

Images in WebP format are preferred - the developer portal team may at a future time enforce this. The developer portal also supports PNG, Jpeg, and GIF formats. Please make sure any images are optimized to the smallest possible file size while retaining legibility and clarity.

## Other key/value pairs

The importer will disregard other key/value pairs, _but_ performance will be _significantly_ better if the input data does not contain extraneous data that is not documented above. Therefore, we urge you to remove extraneous data from the JSON source during your transformation.
