var structSyscSetupInfo =
[
    [ "analysisType", "structSyscSetupInfo.xhtml#ac769cbb25b2b34dbb5bc44f281299780", null ],
    [ "dimension", "structSyscSetupInfo.xhtml#a8f4b32e8360553ac5bb5d179efb58b81", null ],
    [ "restartsSupported", "structSyscSetupInfo.xhtml#a50a3305a3b93fedcc8f4435bd43b9aa1", null ]
];