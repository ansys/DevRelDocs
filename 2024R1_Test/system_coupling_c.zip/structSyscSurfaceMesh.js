var structSyscSurfaceMesh =
[
    [ "connectivityStamp", "structSyscSurfaceMesh.xhtml#a3316249d696bd73986f538f76d8caf4b", null ],
    [ "coordinatesStamp", "structSyscSurfaceMesh.xhtml#a11d7b54aad0e70cb5a5b7f197d0fbfc0", null ],
    [ "faces", "structSyscSurfaceMesh.xhtml#a087162c1bc756237bc7fff5d6edc5a93", null ],
    [ "nodes", "structSyscSurfaceMesh.xhtml#afec3edb82f09c5907cf562a5b7561073", null ],
    [ "partitioningStamp", "structSyscSurfaceMesh.xhtml#a8f343bec777e3c98c927797e002c4182", null ],
    [ "side0", "structSyscSurfaceMesh.xhtml#a6e87f7a6198b1ca86544ea73df6235b5", null ],
    [ "side1", "structSyscSurfaceMesh.xhtml#a7b43da70685af52a3ca8444b29b769e8", null ]
];