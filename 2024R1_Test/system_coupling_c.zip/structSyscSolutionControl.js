var structSyscSolutionControl =
[
    [ "maximumIterations", "structSyscSolutionControl.xhtml#a197d10eabb539d2eff515cd3895d7b2e", null ],
    [ "minimumIterations", "structSyscSolutionControl.xhtml#af68269f003f864fb6931168f6d131478", null ]
];