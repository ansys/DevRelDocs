var classansys_1_1_project_1_1_project_storage_policy =
[
    [ "ProjectStoragePolicy", "classansys_1_1_project_1_1_project_storage_policy.xhtml#a796f624b5195e85e2e6d1438aae4e5f3", null ],
    [ "getApplicationName", "classansys_1_1_project_1_1_project_storage_policy.xhtml#a8aae9c1ab4c6ee30c9bf48fca821c5f2", null ],
    [ "getLockInfoFilename", "classansys_1_1_project_1_1_project_storage_policy.xhtml#a3198e10db4a1528ec7013e314917dd9b", null ],
    [ "getProjectSubfolderCustomName", "classansys_1_1_project_1_1_project_storage_policy.xhtml#ad11cd0726e363557d2687a9953be8914", null ],
    [ "getProjectSubfolderSuffix", "classansys_1_1_project_1_1_project_storage_policy.xhtml#afd7b7487b032863932e9ddc7f28822db", null ],
    [ "getSimFolderName", "classansys_1_1_project_1_1_project_storage_policy.xhtml#abc5273cd8bf336f2b2ef50b95a08c70a", null ],
    [ "getSubProjectMode", "classansys_1_1_project_1_1_project_storage_policy.xhtml#a96410b6d24c2160ccca6c0a1231c83e5", null ],
    [ "isLockInfoEnabled", "classansys_1_1_project_1_1_project_storage_policy.xhtml#a6f6b3aafaf32b38b045302ae533a5c58", null ],
    [ "isLockInfoOnReadOnlyEnabled", "classansys_1_1_project_1_1_project_storage_policy.xhtml#a2a5a04e54acf832efaeefdc6a1c8538a", null ],
    [ "isProjectSubfolderEnabled", "classansys_1_1_project_1_1_project_storage_policy.xhtml#a2be7b219115ccfabd10ec76eec615024", null ],
    [ "isReadOnly", "classansys_1_1_project_1_1_project_storage_policy.xhtml#a3dd58ce3f552dc734da4ee7402dae8e0", null ]
];