var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuw",
  1: "cdefglmoprstuw",
  2: "a",
  3: "abcdefghijklmnopqrstuw",
  4: "dnp",
  5: "aep",
  6: "e",
  7: "cdiuw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

