var searchData=
[
  ['concepts_20and_20terminology_0',['Concepts and Terminology',['../md_cpp_doc_02_Concepts.xhtml',1,'']]]
];
