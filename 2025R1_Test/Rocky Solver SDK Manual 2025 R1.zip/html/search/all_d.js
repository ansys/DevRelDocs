var searchData=
[
  ['kernel_0',['SPH kernel',['../glossary.xhtml#sph-kernel',1,'']]],
  ['known_20scalar_1',['Known scalar',['../glossary.xhtml#known-scalar',1,'']]]
];
