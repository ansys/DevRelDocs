var searchData=
[
  ['windows_0',['Build tools - Windows',['../getting_started.xhtml#autotoc_md6',1,'']]],
  ['windows_2010_1',['windows 10',['../usage_examples.xhtml#autotoc_md119',1,'Building in Windows 10'],['../getting_started.xhtml#autotoc_md5',1,'Prerequisites for Windows 10']]]
];
