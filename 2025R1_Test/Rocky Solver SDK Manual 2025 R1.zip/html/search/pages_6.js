var searchData=
[
  ['macros_20and_20specifiers_0',['Macros and specifiers',['../macros_and_specifiers.xhtml',1,'']]],
  ['module_20specification_1',['Module specification',['../module_specification.xhtml',1,'']]]
];
