var searchData=
[
  ['variable_20properties_0',['variable properties',['../usage_examples.xhtml#a-module-implementing-variable-properties',1,'A module implementing variable properties'],['../module_specification.xhtml#autotoc_md22',1,'Specification of variable properties']]],
  ['version_1',['Module version',['../module_specification.xhtml#module-version',1,'']]],
  ['versions_2',['Migrating between module versions',['../module_specification.xhtml#autotoc_md24',1,'']]]
];
