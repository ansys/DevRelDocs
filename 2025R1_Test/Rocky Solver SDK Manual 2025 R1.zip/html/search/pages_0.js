var searchData=
[
  ['and_20specifiers_0',['Macros and specifiers',['../macros_and_specifiers.xhtml',1,'']]]
];
