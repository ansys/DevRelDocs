var searchData=
[
  ['2025_20r1_0',['Release notes for 2025 R1',['../changelog.xhtml#autotoc_md0',1,'']]]
];
