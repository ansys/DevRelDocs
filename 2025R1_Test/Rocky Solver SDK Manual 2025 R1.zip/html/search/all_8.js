var searchData=
[
  ['file_0',['file',['../usage_examples.xhtml#autotoc_md127',1,'Module specification file'],['../usage_examples.xhtml#autotoc_md124',1,'Module specification file'],['../usage_examples.xhtml#autotoc_md122',1,'Module specification file'],['../module_specification.xhtml#autotoc_md14',1,'Structure of the specification file'],['../module_specification.xhtml#autotoc_md23',1,'The .plugin file']]],
  ['file_20cmakelists_20txt_1',['File CMakeLists.txt',['../usage_examples.xhtml#autotoc_md115',1,'']]],
  ['file_20spherical_5fregion_20cu_2',['File spherical_region.cu',['../usage_examples.xhtml#autotoc_md116',1,'']]],
  ['file_20spherical_5fregion_20pdf_3',['File spherical_region.pdf',['../usage_examples.xhtml#autotoc_md114',1,'']]],
  ['file_20spherical_5fregion_20plugin_4',['File spherical_region.plugin',['../usage_examples.xhtml#autotoc_md112',1,'']]],
  ['file_20spherical_5fregion_20py_5',['File spherical_region.py',['../usage_examples.xhtml#autotoc_md113',1,'']]],
  ['find_6',['find',['../structIRockyContactScalarsModel.xhtml#ad35ceabceb6ec8d839a3e89086643f99',1,'IRockyContactScalarsModel::find()'],['../structIRockySPHElementScalarsModel.xhtml#a08368398c992a677000337a1c6b87836',1,'IRockySPHElementScalarsModel::find()'],['../structIRockyTriangleScalarsModel.xhtml#afc273a1e67e4995f848452fda3f71c31',1,'IRockyTriangleScalarsModel::find()'],['../structIRockyParticleBreakageScalarsModel.xhtml#a00666ca9d343b8d3284975687ce4d087',1,'IRockyParticleBreakageScalarsModel::find()'],['../structIRockyParticleTransferScalarsModel.xhtml#a6d1850250b4509904702af664aed3e26',1,'IRockyParticleTransferScalarsModel::find()'],['../structIRockyParticleScalarsModel.xhtml#a2fe0d14a5fc4f803eb04374ec6d2a40f',1,'IRockyParticleScalarsModel::find()'],['../structIRockyPairScalarsModel.xhtml#a9db6d59f40d249a8bee649b0830a3cd2',1,'IRockyPairScalarsModel::find()'],['../structIRockyJointScalarsModel.xhtml#ac684ddb11f55d3edbbb5606ea6ea633a',1,'IRockyJointScalarsModel::find()'],['../structIRockyFluidScalarsModel.xhtml#a9b9a2807854efdeaea33d558210c3901',1,'IRockyFluidScalarsModel::find()'],['../structIRockyGeometryScalarsModel.xhtml#a8605e8eb24231ebdcbd9087602aa64fa',1,'IRockyGeometryScalarsModel::find()']]],
  ['find_5fpoint_5fcloud_7',['find_point_cloud',['../structIRockyModel.xhtml#ae4797d71a2b43ae408fe83e317f818b7',1,'IRockyModel']]],
  ['find_5fpoint_5fcloud_5fproperty_8',['find_point_cloud_property',['../structIRockyModel.xhtml#aabdba4a3eee5c51c75c45345f6cf6839',1,'IRockyModel']]],
  ['for_202025_20r1_9',['Release notes for 2025 R1',['../changelog.xhtml#autotoc_md0',1,'']]],
  ['for_20linux_10',['Prerequisites for Linux',['../getting_started.xhtml#autotoc_md3',1,'']]],
  ['for_20windows_2010_11',['Prerequisites for Windows 10',['../getting_started.xhtml#autotoc_md5',1,'']]],
  ['frictional_20contact_12',['Frictional contact',['../glossary.xhtml#frictional-contact',1,'']]]
];
