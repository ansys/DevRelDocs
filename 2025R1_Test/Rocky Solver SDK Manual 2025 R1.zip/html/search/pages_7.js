var searchData=
[
  ['solver_20hooks_0',['Solver hooks',['../solver_hooks.xhtml',1,'']]],
  ['specification_1',['Module specification',['../module_specification.xhtml',1,'']]],
  ['specifiers_2',['Macros and specifiers',['../macros_and_specifiers.xhtml',1,'']]],
  ['started_3',['Getting started',['../getting_started.xhtml',1,'']]]
];
