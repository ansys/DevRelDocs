var structIRockyCFDModel =
[
    [ "get_coupling_mode", "structIRockyCFDModel.xhtml#a121e67b3f5efdd1783a32a7fa642080c", null ],
    [ "get_fluid_scalars", "structIRockyCFDModel.xhtml#a001b18af80c99c01ce4baa357bac4977", null ],
    [ "is_cfd_coupling_iteration", "structIRockyCFDModel.xhtml#a733281fb5b40b3cfbf10c29869208343", null ]
];