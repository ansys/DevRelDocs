var classansys_1_1dpf_1_1MeshInfo =
[
    [ "getAvailableElementTypes", "classansys_1_1dpf_1_1MeshInfo.xhtml#a736817aee8059d944483e080a9152d0b", null ],
    [ "getSplittableBy", "classansys_1_1dpf_1_1MeshInfo.xhtml#a7a288ff55960fa0955502b51d8f84583", null ],
    [ "numberOfElements", "classansys_1_1dpf_1_1MeshInfo.xhtml#a446ad4eef444bdc799ea0c783783e863", null ],
    [ "numberOfNodes", "classansys_1_1dpf_1_1MeshInfo.xhtml#a1baa306edc0ddced75798e77f68c590a", null ],
    [ "setAvailableElementType", "classansys_1_1dpf_1_1MeshInfo.xhtml#a64932c3302954322668f319e76af6911", null ],
    [ "setnumberOfElements", "classansys_1_1dpf_1_1MeshInfo.xhtml#a01146bcc71f898d13ae42ec8b9e5f247", null ],
    [ "setnumberOfNodes", "classansys_1_1dpf_1_1MeshInfo.xhtml#a4ad70b09ecbd1f3161ebbd33dd62d399", null ],
    [ "setSplittableBy", "classansys_1_1dpf_1_1MeshInfo.xhtml#aac41382a70a99d12ccb70215685f5d00", null ]
];