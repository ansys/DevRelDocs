var indexSectionsWithContent =
{
  0: "01abcdefghijklmnopqrstuvwz",
  1: "acdefghlmopqrstuw",
  2: "a",
  3: "abcdefghijklmnopqrstuvw",
  4: "abcdefghijlmnopqrstuvwz",
  5: "dhu",
  6: "aelop",
  7: "aelrt",
  8: "cdhsuw",
  9: "01dgio"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "groups",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Modules",
  9: "Pages"
};

