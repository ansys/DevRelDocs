var searchData=
[
  ['concepts_20and_20terminology_0',['Concepts and Terminology',['../group__group__02.xhtml',1,'']]],
  ['concepts_20and_20terms_1',['Concepts and terms',['../group__group__2__concepts.xhtml',1,'']]],
  ['creating_20a_20dpf_20custom_20operator_27s_20library_2',['Creating a DPF custom operator&apos;s library',['../group__group__06__2.xhtml',1,'']]]
];
