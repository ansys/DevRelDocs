var modules =
[
    [ "Concepts and terms", "group__group__2__concepts.xhtml", "group__group__2__concepts" ],
    [ "How-tos", "group__group__4__how__tos.xhtml", "group__group__4__how__tos" ],
    [ "Starting to use DPF", "group__group__1__get__started.xhtml", "group__group__1__get__started" ]
];