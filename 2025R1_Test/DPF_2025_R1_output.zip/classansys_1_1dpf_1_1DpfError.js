var classansys_1_1dpf_1_1DpfError =
[
    [ "ErrorNature", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47f", [
      [ "eUnknown", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa7e0ab4a9ab10ba9158d691bf6b780592", null ],
      [ "eOk", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fafbbb18218f01ff212fea92a133b88e21", null ],
      [ "eComponentLoading", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa63cc3ff6720228860f33c24e18a81abf", null ],
      [ "eFileNotFound", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa6173cc22576234d0f2ff8e731269f12b", null ],
      [ "eRuntimeError", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa0c8ab336a55da58dd3370cd8ec248641", null ],
      [ "eWrongOutputType", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47facb3a3ddcc8669511fb2b9e3d7a399d91", null ],
      [ "eFailure", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47faf8acd9de5506b8d9fd2acd4aaa0d2341", null ],
      [ "eUnexpectedVoidReturn", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47faa585e53574d25bd2fb1c6e9399a4a194", null ],
      [ "eUnexpectedVoidEntity", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa4387e3722275260468e6129c30889868", null ],
      [ "eUnimplemented", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa7e1ad7229f4996867c9fb96ed8109dd5", null ],
      [ "eUserInterrupted", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa5226925956eb514eff286167bd6e2116", null ],
      [ "eLicensingFailure", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa7e497c9bbbed6bc9974b24a48c589cba", null ],
      [ "eUnimplementedAPI", "classansys_1_1dpf_1_1DpfError.xhtml#a9a3fe202cc2e46746462fdb1ce44c47fa547c1094c3159a0eb84aadd388424ca8", null ]
    ] ],
    [ "DpfError", "classansys_1_1dpf_1_1DpfError.xhtml#a6e5be6e3d3b4beb446d2182e5913e60a", null ],
    [ "clear", "classansys_1_1dpf_1_1DpfError.xhtml#a31f33e6efbff5157ba3927d1c85b92bb", null ],
    [ "isOk", "classansys_1_1dpf_1_1DpfError.xhtml#aa215db12375801e5addbe0dbf8a97533", null ],
    [ "message", "classansys_1_1dpf_1_1DpfError.xhtml#a3bc55d7c2946bf8a9bf73b025bb0cc56", null ],
    [ "nature", "classansys_1_1dpf_1_1DpfError.xhtml#afbf881f187b078bb3840dde70d263358", null ],
    [ "origin", "classansys_1_1dpf_1_1DpfError.xhtml#ae9ff17267fc46a5f8c9811add42317ff", null ],
    [ "what", "classansys_1_1dpf_1_1DpfError.xhtml#ad89a0100818b4ee541fd45f4b06da3e1", null ]
];