var classansys_1_1dpf_1_1DpfTypes =
[
    [ "callAPI", "classansys_1_1dpf_1_1DpfTypes.xhtml#aea34d37e0c080126eff70db34bf46597", null ],
    [ "describe", "classansys_1_1dpf_1_1DpfTypes.xhtml#a9977945710983bc03d2940fa007847b2", null ],
    [ "empty", "classansys_1_1dpf_1_1DpfTypes.xhtml#a39cd546c42518e2332be8f287db95459", null ],
    [ "getClient", "classansys_1_1dpf_1_1DpfTypes.xhtml#a968afd9daa0b0f13b65a2ac61369d73a", null ],
    [ "hasBeenMovedLocally", "classansys_1_1dpf_1_1DpfTypes.xhtml#a1a5634202c15404b6b24e8f50e51cb66", null ],
    [ "hasInternalObject", "classansys_1_1dpf_1_1DpfTypes.xhtml#ae198f89868d85c7db6dc1a934a1d3c15", null ],
    [ "isOnCommonAPI", "classansys_1_1dpf_1_1DpfTypes.xhtml#a9f9789ff61cc9d400a2a344830706b73", null ],
    [ "isSameObject", "classansys_1_1dpf_1_1DpfTypes.xhtml#aa64d5f8fcd7d85ad6ebf708494dbefd7", null ]
];