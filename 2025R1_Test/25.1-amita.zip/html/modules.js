var modules =
[
    [ "INITIALIZATION", "group__initialization.xhtml", "group__initialization" ],
    [ "OPERATIONS", "group__operations.xhtml", "group__operations" ],
    [ "RETRIEVE LICENSE INFO", "group__retrieve_license_info.xhtml", "group__retrieve_license_info" ],
    [ "LICENSING SHARING API", "group__context_a_p_i.xhtml", "group__context_a_p_i" ]
];