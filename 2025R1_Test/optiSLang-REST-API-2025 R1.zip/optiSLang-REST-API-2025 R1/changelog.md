## Version 2025 R1

No changes have been made compared to the previous version, 2024 R2.
