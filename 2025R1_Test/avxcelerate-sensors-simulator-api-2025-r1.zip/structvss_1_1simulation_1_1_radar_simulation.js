var structvss_1_1simulation_1_1_radar_simulation =
[
    [ "number_of_ray_reflections", "structvss_1_1simulation_1_1_radar_simulation.xhtml#a70073a61105bdd142ad080800ac22625", null ],
    [ "number_of_ray_transmissions", "structvss_1_1simulation_1_1_radar_simulation.xhtml#a36d61fdafa9f1f35f7613a8d7290c9b4", null ],
    [ "ray_density", "structvss_1_1simulation_1_1_radar_simulation.xhtml#aa85ed56a33c422d630d42f3b6c5d5cca", null ],
    [ "grid_sampling", "structvss_1_1simulation_1_1_radar_simulation.xhtml#a5d6301d6658eaa586d3468a8bc021e2d", null ],
    [ "manual_batching", "structvss_1_1simulation_1_1_radar_simulation.xhtml#a2eeb1e2e236b79be60d591c578973864", null ],
    [ "automatic_batching", "structvss_1_1simulation_1_1_radar_simulation.xhtml#a493be82dc35cd6e183f3395941a9d955", null ],
    [ "tx_waveform_report", "structvss_1_1simulation_1_1_radar_simulation.xhtml#a4b751460978e88e3350d1be39554c309", null ],
    [ "ego_vehicle_emission_blockage", "structvss_1_1simulation_1_1_radar_simulation.xhtml#a9a4f85187d9b041d2ef055ee1df35997", null ],
    [ "debug_view_parameters", "structvss_1_1simulation_1_1_radar_simulation.xhtml#aa6929e4d8cb4ad1f48a2994bb8cbcb68", null ],
    [ "max_ray_path_length_by_mode", "structvss_1_1simulation_1_1_radar_simulation.xhtml#aee51321ccb1dca97c3ce81d6a7328ff5", null ],
    [ "max_velocity_by_mode", "structvss_1_1simulation_1_1_radar_simulation.xhtml#af4271c72db93ad6fd70f2d60bc3bb043", null ]
];