var structvss_1_1_resource_identifier =
[
    [ "id", "structvss_1_1_resource_identifier.xhtml#a8680711d474d97fe9668afc54054866b", null ]
];