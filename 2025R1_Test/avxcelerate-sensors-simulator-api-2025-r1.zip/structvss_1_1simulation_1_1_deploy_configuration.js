var structvss_1_1simulation_1_1_deploy_configuration =
[
    [ "local_nodes", "structvss_1_1simulation_1_1_deploy_configuration.xhtml#a812f1b977d06f1a02ddcb2d476ebbd0b", null ],
    [ "deploy_hosts", "structvss_1_1simulation_1_1_deploy_configuration.xhtml#ae7dfdfc0987ccf6690e2ba96904cc237", null ]
];