var structvss_1_1sensor__data_1_1_camera_resolution =
[
    [ "width", "structvss_1_1sensor__data_1_1_camera_resolution.xhtml#ae438746c32555498a7db277cdaeda21d", null ],
    [ "height", "structvss_1_1sensor__data_1_1_camera_resolution.xhtml#ab1a95e5f7ab50e2c913c21329aedc712", null ]
];