var structvss_1_1feedback__control_1_1_flash_lidar_receiver =
[
    [ "lens_system", "structvss_1_1feedback__control_1_1_flash_lidar_receiver.xhtml#a1d65910e3bdf6f69c22b238e5fbc9299", null ],
    [ "resolution_in_pixels", "structvss_1_1feedback__control_1_1_flash_lidar_receiver.xhtml#a99f3342a135f634b4553905e2248004e", null ],
    [ "photo_detector", "structvss_1_1feedback__control_1_1_flash_lidar_receiver.xhtml#ab15b5a6299e3b08ebff5eb4d48d0b086", null ],
    [ "processor", "structvss_1_1feedback__control_1_1_flash_lidar_receiver.xhtml#ac4b4ff5c509cf093466dfed1bb2b895b", null ]
];