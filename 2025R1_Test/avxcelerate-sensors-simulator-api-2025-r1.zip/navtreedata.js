/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "AVxcelerate Sensors Simulator API", "index.xhtml", [
    [ "Documentation", "index.xhtml", [
      [ "Introduction", "index.xhtml#autotoc_md1", null ],
      [ "Overview", "index.xhtml#autotoc_md2", null ],
      [ "Services", "index.xhtml#autotoc_md3", [
        [ "Simulation", "index.xhtml#simulation_control_service", null ],
        [ "Resource Uploader", "index.xhtml#resource_uploader_service", null ],
        [ "Sensors Feedback Control", "index.xhtml#feedback_control_service", null ],
        [ "Lighting System Control", "index.xhtml#ls_control_service", null ],
        [ "Sensor data access", "index.xhtml#autotoc_md4", [
          [ "Notifications", "index.xhtml#notifications", null ],
          [ "Sensor data acquisition", "index.xhtml#sensor_data_acquisition", null ],
          [ "Data retention", "index.xhtml#autotoc_md5", null ],
          [ "Data format", "index.xhtml#autotoc_md6", null ]
        ] ],
        [ "Ground Truth Data Helper", "index.xhtml#autotoc_md7", [
          [ "Contribution dictionary", "index.xhtml#autotoc_md8", null ],
          [ "Pixel segmentation tag color map", "index.xhtml#autotoc_md9", null ]
        ] ]
      ] ],
      [ "Examples", "index.xhtml#examples", [
        [ "Preliminary steps", "index.xhtml#preliminary_steps", null ],
        [ "AVX internal gRPC server", "index.xhtml#create_grpc_channel", null ],
        [ "Simulation control example", "index.xhtml#simulation_control_example", [
          [ "Prerequisites", "index.xhtml#autotoc_md10", null ],
          [ "Steps", "index.xhtml#autotoc_md11", null ]
        ] ],
        [ "Resource Uploader example", "index.xhtml#resource_uploader_example", [
          [ "Prerequisites", "index.xhtml#autotoc_md12", null ],
          [ "Steps", "index.xhtml#autotoc_md13", null ]
        ] ],
        [ "Sensor Feedback Control example", "index.xhtml#feedback_control_example", [
          [ "Prerequisites", "index.xhtml#autotoc_md14", null ],
          [ "Steps", "index.xhtml#autotoc_md15", null ]
        ] ],
        [ "Lighting System Control example", "index.xhtml#ls_control_example", [
          [ "Prerequisites", "index.xhtml#autotoc_md16", null ],
          [ "Steps", "index.xhtml#autotoc_md17", null ]
        ] ],
        [ "Subscription to sensor data notifications example", "index.xhtml#sub_data_notification_example", [
          [ "Prerequisites", "index.xhtml#autotoc_md18", null ],
          [ "Steps", "index.xhtml#autotoc_md19", null ]
        ] ],
        [ "Sensor data acquisition example", "index.xhtml#sensor_data_acq_example", [
          [ "Accessing the sensor data directly from the shared memory", "index.xhtml#autotoc_md20", [
            [ "Prerequisites", "index.xhtml#autotoc_md21", null ],
            [ "Steps", "index.xhtml#autotoc_md22", null ]
          ] ],
          [ "Accessing the sensor data using the RPC", "index.xhtml#autotoc_md23", [
            [ "Prerequisites", "index.xhtml#autotoc_md24", null ],
            [ "Steps", "index.xhtml#autotoc_md25", null ]
          ] ]
        ] ],
        [ "Ground Truth Data Helper example", "index.xhtml#gt_helper_example", [
          [ "Prerequisites", "index.xhtml#autotoc_md26", null ],
          [ "Steps", "index.xhtml#autotoc_md27", null ]
        ] ]
      ] ]
    ] ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.xhtml",
"structvss_1_1feedback__control_1_1_frequency_modulated_continuous_waveform.xhtml#aeb6914a17db0ad15d9e92e25fd577a16",
"structvss_1_1sensor__data_1_1_camera_lens_output.xhtml#a4ddb69568d2cb4dcf8fd8bbf933401ad",
"structvss_1_1simulation_1_1_sensor_parameters.xhtml"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';