var structvss_1_1feedback__control_1_1_imager_resolution =
[
    [ "width", "structvss_1_1feedback__control_1_1_imager_resolution.xhtml#aad6d7fa740fd6d55f8337a3b71fa5e2b", null ],
    [ "height", "structvss_1_1feedback__control_1_1_imager_resolution.xhtml#a4342101728ac1fa43ee31ff3f6fd39be", null ]
];