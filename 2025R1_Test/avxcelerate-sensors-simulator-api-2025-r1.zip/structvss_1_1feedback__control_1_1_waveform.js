var structvss_1_1feedback__control_1_1_waveform =
[
    [ "pulse_doppler_waveform", "structvss_1_1feedback__control_1_1_waveform.xhtml#ae5075acb9d557c07671746ffa4da18e9", null ],
    [ "frequency_modulated_continuous_waveform", "structvss_1_1feedback__control_1_1_waveform.xhtml#ab36d87024ca30ccb546aa2d26e448747", null ]
];