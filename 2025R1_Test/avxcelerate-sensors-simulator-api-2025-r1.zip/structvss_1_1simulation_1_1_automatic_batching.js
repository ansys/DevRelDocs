var structvss_1_1simulation_1_1_automatic_batching =
[
    [ "max_number_of_ray_batches", "structvss_1_1simulation_1_1_automatic_batching.xhtml#a9b4158e52e07f95a4470f896079fdb2d", null ],
    [ "gpu_memory_quota", "structvss_1_1simulation_1_1_automatic_batching.xhtml#a13bce1150714582c1224822348c6f7b8", null ],
    [ "gpu_quotas", "structvss_1_1simulation_1_1_automatic_batching.xhtml#ad5f7c92a370197c4a63f9d69df164822", null ]
];