var structvss_1_1simulation_1_1_lighting_system_configuration =
[
    [ "lighting_systems", "structvss_1_1simulation_1_1_lighting_system_configuration.xhtml#a17176085ea0e623570c5f5dbf922cbbc", null ],
    [ "active_lighting_system", "structvss_1_1simulation_1_1_lighting_system_configuration.xhtml#a9638e10edd4f0c8d35906d491108e52b", null ]
];