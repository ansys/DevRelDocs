var structvss_1_1sensor__data_1_1_camera_data_entry =
[
    [ "image_data", "structvss_1_1sensor__data_1_1_camera_data_entry.xhtml#aa475a93b866b131642639183d77fc0be", null ],
    [ "ground_truth_data", "structvss_1_1sensor__data_1_1_camera_data_entry.xhtml#a0a0c93a3a466e38b6ec65ebcf1fa766b", null ],
    [ "bounding_box_2d", "structvss_1_1sensor__data_1_1_camera_data_entry.xhtml#a510dd0a2c542c13388e1fb6fcaac67bf", null ],
    [ "camera_lens_output", "structvss_1_1sensor__data_1_1_camera_data_entry.xhtml#a9da54cf42b40927d38ade678c07ff424", null ],
    [ "camera_custom_data_output", "structvss_1_1sensor__data_1_1_camera_data_entry.xhtml#ab5192e3f348800a501794b6a50b9889c", null ]
];