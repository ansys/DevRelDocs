var structvss_1_1feedback__control_1_1_mode =
[
    [ "identifier", "structvss_1_1feedback__control_1_1_mode.xhtml#a90979cdeecc9023962b2aaec60ad29ab", null ],
    [ "waveform", "structvss_1_1feedback__control_1_1_mode.xhtml#a0e5d0c3d82a97723b15b8a39261a50cc", null ],
    [ "range_doppler_processor", "structvss_1_1feedback__control_1_1_mode.xhtml#aa52f02153c26ff4466ef92f20f81195a", null ],
    [ "start_delay", "structvss_1_1feedback__control_1_1_mode.xhtml#adf3fca41a02d788fc6b0001e43fe56f6", null ],
    [ "tx_antenna_ids", "structvss_1_1feedback__control_1_1_mode.xhtml#a91887bae2eecd11f76e6710514fd9509", null ],
    [ "rx_antenna_ids", "structvss_1_1feedback__control_1_1_mode.xhtml#a51e029d0177acb5c2e16eb9227b3e3ef", null ],
    [ "activate_mode", "structvss_1_1feedback__control_1_1_mode.xhtml#a72c8613ba077caf9ed8e6d863267497b", null ],
    [ "Gain", "structvss_1_1feedback__control_1_1_mode.xhtml#ab760d4f32afb92f360b3759d7b89b3de", null ],
    [ "Noise", "structvss_1_1feedback__control_1_1_mode.xhtml#a2d734e8160eb2c4447223ddb23e5ded3", null ],
    [ "tx_weighting", "structvss_1_1feedback__control_1_1_mode.xhtml#a0dd852c3782c3a7027f42b71c11c9d75", null ]
];