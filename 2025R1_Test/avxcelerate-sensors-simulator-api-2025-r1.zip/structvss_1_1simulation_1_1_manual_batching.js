var structvss_1_1simulation_1_1_manual_batching =
[
    [ "number_of_ray_batches", "structvss_1_1simulation_1_1_manual_batching.xhtml#a353400d16fd569d8a637ef5b8e3e615f", null ],
    [ "rx_batching", "structvss_1_1simulation_1_1_manual_batching.xhtml#a8ae410483ac9a32fb75bc3ec37ab75cd", null ],
    [ "gpu_by_modes", "structvss_1_1simulation_1_1_manual_batching.xhtml#a15f4e71c164a370c56782ead8840638d", null ]
];