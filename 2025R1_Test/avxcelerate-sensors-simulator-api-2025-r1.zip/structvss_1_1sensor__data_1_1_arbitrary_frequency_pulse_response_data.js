var structvss_1_1sensor__data_1_1_arbitrary_frequency_pulse_response_data =
[
    [ "data", "structvss_1_1sensor__data_1_1_arbitrary_frequency_pulse_response_data.xhtml#adef8aaaf5f83e18feaf1caece4ee5dcd", null ],
    [ "number_of_samples", "structvss_1_1sensor__data_1_1_arbitrary_frequency_pulse_response_data.xhtml#af57e5d33172c6edc2117feca983bc6b6", null ],
    [ "rx_identifiers", "structvss_1_1sensor__data_1_1_arbitrary_frequency_pulse_response_data.xhtml#a89c04f03545d824ea2e9d8aebc429684", null ],
    [ "tx_identifiers", "structvss_1_1sensor__data_1_1_arbitrary_frequency_pulse_response_data.xhtml#af393b7384097cb93cd72ae03ee50a581", null ],
    [ "multiplexing", "structvss_1_1sensor__data_1_1_arbitrary_frequency_pulse_response_data.xhtml#a1d957607b1acb9deec5a5a0cb5c7a064", null ]
];