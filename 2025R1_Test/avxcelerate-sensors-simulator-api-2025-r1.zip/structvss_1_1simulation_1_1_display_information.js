var structvss_1_1simulation_1_1_display_information =
[
    [ "top_left_corner_position", "structvss_1_1simulation_1_1_display_information.xhtml#aa67bd52b710562d2d069ab23ba6561d6", null ],
    [ "display_only", "structvss_1_1simulation_1_1_display_information.xhtml#a576696c35d01e305e0c22c2fb8d2e28b", null ]
];