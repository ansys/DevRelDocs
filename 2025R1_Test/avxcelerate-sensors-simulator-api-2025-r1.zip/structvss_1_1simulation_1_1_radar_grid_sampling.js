var structvss_1_1simulation_1_1_radar_grid_sampling =
[
    [ "global_sampling", "structvss_1_1simulation_1_1_radar_grid_sampling.xhtml#a794c7f7d07c707b45765b5831c98e490", null ],
    [ "adaptive_sampling", "structvss_1_1simulation_1_1_radar_grid_sampling.xhtml#a819abfed1ccf2b4986c2d06b6d659b78", null ]
];