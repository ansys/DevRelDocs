var classvss_1_1data__access_1_1_sensor_data_notifier =
[
    [ "Subscribe", "classvss_1_1data__access_1_1_sensor_data_notifier.xhtml#a1e5ee15df931f9452dc4b6d8ea4250fc", null ]
];