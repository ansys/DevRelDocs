var structvss_1_1simulation_1_1_rx_batching =
[
    [ "mode_id", "structvss_1_1simulation_1_1_rx_batching.xhtml#a3f6f1a2be0d89f017fbb4ea0f255fec1", null ],
    [ "number_of_rx_batches", "structvss_1_1simulation_1_1_rx_batching.xhtml#a11fce4513300edccbe78b125d4b6287b", null ]
];