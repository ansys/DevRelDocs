var structvss_1_1sensor__data_1_1_domain =
[
    [ "size", "structvss_1_1sensor__data_1_1_domain.xhtml#ad475923a68bfa553b206984b757253fb", null ],
    [ "min_value", "structvss_1_1sensor__data_1_1_domain.xhtml#ac923871a79a7af8604f8db33f9993e71", null ],
    [ "max_value", "structvss_1_1sensor__data_1_1_domain.xhtml#a1f5a1a9c49729fe50c26c706a06e3f54", null ]
];