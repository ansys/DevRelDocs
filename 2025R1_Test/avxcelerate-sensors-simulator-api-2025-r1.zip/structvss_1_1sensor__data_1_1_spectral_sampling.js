var structvss_1_1sensor__data_1_1_spectral_sampling =
[
    [ "wavelength", "structvss_1_1sensor__data_1_1_spectral_sampling.xhtml#a5bfba3c7271c6e8d4607d11e7dc98b10", null ]
];