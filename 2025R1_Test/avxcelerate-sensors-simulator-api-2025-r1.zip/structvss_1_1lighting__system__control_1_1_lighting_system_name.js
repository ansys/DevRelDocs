var structvss_1_1lighting__system__control_1_1_lighting_system_name =
[
    [ "name", "structvss_1_1lighting__system__control_1_1_lighting_system_name.xhtml#ae32663a9755ed161a50f0273cb9ca4ec", null ]
];