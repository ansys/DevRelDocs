var structvss_1_1feedback__control_1_1_brown_radial_distortion =
[
    [ "k1", "structvss_1_1feedback__control_1_1_brown_radial_distortion.xhtml#a7638f722ea1f455a99c6f371548d4cc4", null ],
    [ "k2", "structvss_1_1feedback__control_1_1_brown_radial_distortion.xhtml#a5509741db6a51dd4278c05b9279c0f6a", null ],
    [ "k3", "structvss_1_1feedback__control_1_1_brown_radial_distortion.xhtml#ad9a684451c4908d4a045debb3c03cf26", null ]
];