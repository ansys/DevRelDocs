var structvss_1_1_object_identifier =
[
    [ "id", "structvss_1_1_object_identifier.xhtml#a093a14f66ebfacd52c3381b0c5974a9f", null ]
];