var structvss_1_1lighting__system__control_1_1_module_state =
[
    [ "module_name", "structvss_1_1lighting__system__control_1_1_module_state.xhtml#a565ad260189d51c0864dd4f2bbc98658", null ],
    [ "lamps_state", "structvss_1_1lighting__system__control_1_1_module_state.xhtml#a0f4b1ae38eebc60cd1260c9e14be9d90", null ],
    [ "position", "structvss_1_1lighting__system__control_1_1_module_state.xhtml#a491b5f0dd654556c3cf53ba972458448", null ],
    [ "orientation", "structvss_1_1lighting__system__control_1_1_module_state.xhtml#a1712e92d8a8a3a22d232e56b99ceb862", null ]
];