var structvss_1_1simulation_1_1_upload_meta_data =
[
    [ "resource_identifier", "structvss_1_1simulation_1_1_upload_meta_data.xhtml#aef069f6bd46cea43ac09d1880b09577a", null ],
    [ "values", "structvss_1_1simulation_1_1_upload_meta_data.xhtml#a2309fe7cbe50f8a1b0cb51aa98ad2176", null ]
];