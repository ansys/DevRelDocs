var structvss_1_1simulation_1_1_remote_direct_memory_access =
[
    [ "transfer_chunk_size", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#a0009bc44c7150becb61cbcdd787244dd", null ],
    [ "sender_address", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#aa1cce85118ef2acb91624764d46fcaea", null ],
    [ "sender_port", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#ab6368d05a727c6f4c7f28d37b2c7d2f6", null ],
    [ "sender_backchannel_port", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#a1f756616509786eb224c2a067452f41e", null ],
    [ "post_embedded_data_line_count", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#a07c2819eb7da8d484fd146a97fbb12c0", null ],
    [ "post_embedded_data_line_payload_size", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#a8c99fee20cfe3cccecc9dc77be48f499", null ],
    [ "pre_embedded_data_line_count", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#a680a74f1a9f34b24fd745c67c8f7cd73", null ],
    [ "pre_embedded_data_line_payload_size", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#a4185e8a2dfae1a383715b91765d4624e", null ]
];