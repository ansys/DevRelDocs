var structvss_1_1simulation_1_1_asset_info =
[
    [ "vss_identity", "structvss_1_1simulation_1_1_asset_info.xhtml#a035279d4d82f4b566ca00f77dcb66499", null ],
    [ "resource", "structvss_1_1simulation_1_1_asset_info.xhtml#a818d180c25de4f265b90bf3bd61e756f", null ]
];