var structvss_1_1data__access_1_1_sensor_metadata =
[
    [ "camera_metadata", "structvss_1_1data__access_1_1_sensor_metadata.xhtml#a362cf07db891d6c29b97fbebe3ba15a5", null ],
    [ "lidar_metadata", "structvss_1_1data__access_1_1_sensor_metadata.xhtml#ab82e6b0137ff4e5ff67137d83fb79336", null ],
    [ "radar_metadata", "structvss_1_1data__access_1_1_sensor_metadata.xhtml#abb87e738d6102784f3728315e7abf5e2", null ],
    [ "radar_debug_view_metadata", "structvss_1_1data__access_1_1_sensor_metadata.xhtml#a28a07772f6bf80e6802f64bc20ee969c", null ],
    [ "camera_feedback", "structvss_1_1data__access_1_1_sensor_metadata.xhtml#ae78dd9b220836aa63b026bba2376110a", null ],
    [ "data_serialized", "structvss_1_1data__access_1_1_sensor_metadata.xhtml#a1dabafc92ce4caa6e48002dd165a5427", null ],
    [ "deploy_host_address", "structvss_1_1data__access_1_1_sensor_metadata.xhtml#a03be01881a602039052c1e1b1b9447e4", null ],
    [ "data_access_server_port", "structvss_1_1data__access_1_1_sensor_metadata.xhtml#a40e3f170e4db2b3ab20d760be62cd0f4", null ]
];