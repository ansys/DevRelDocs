var structvss_1_1sensor__data_1_1_bounding_box2_d =
[
    [ "x_min", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#af777b5808f48501cfa848e7c139fe105", null ],
    [ "y_min", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#a0652fc37fbd303b61a183813eb2cc292", null ],
    [ "x_max", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#ace517783b0848a95a83fef9e596b3d2b", null ],
    [ "y_max", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#ae494cfe0fefb6a8f9366867e8202baeb", null ],
    [ "tag_name", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#afa5af2af615a8a9c2b0b45867cc52596", null ],
    [ "label", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#a35978cb1369d7362b667b7e143eb76f6", null ],
    [ "x_center", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#a89ea85e8dcba0b92181d99d006d9ab5b", null ],
    [ "y_center", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#a5d4f63ad6ae59513420eff9614ab0a3e", null ],
    [ "z_center", "structvss_1_1sensor__data_1_1_bounding_box2_d.xhtml#ada5dc5f88c1d659b0ba3dfbfba73ad73", null ]
];