var structvss_1_1feedback__control_1_1_field_of_view =
[
    [ "horizontal", "structvss_1_1feedback__control_1_1_field_of_view.xhtml#a60d976f1081d89407364d5ca6f20a12f", null ],
    [ "vertical", "structvss_1_1feedback__control_1_1_field_of_view.xhtml#af307fb4203ec6300ef2e4e0dafb9270c", null ]
];