var structvss_1_1data__access_1_1_camera_metadata =
[
    [ "formats", "structvss_1_1data__access_1_1_camera_metadata.xhtml#af0e3402a8f41b4f6fe1abd41627ae92c", null ],
    [ "image_width", "structvss_1_1data__access_1_1_camera_metadata.xhtml#a2e9ae9573722fdda19a6fe340fbfb643", null ],
    [ "image_height", "structvss_1_1data__access_1_1_camera_metadata.xhtml#a4a3a69aa04eb4d5eb33a7d48d01dfa5d", null ],
    [ "pixel_format", "structvss_1_1data__access_1_1_camera_metadata.xhtml#ab25de09698f9c26223c5137d9e0ef130", null ],
    [ "ground_truth_formats", "structvss_1_1data__access_1_1_camera_metadata.xhtml#a0f628c7f69377bc99d32e79c29a8462b", null ],
    [ "nb_of_2Dbounding_boxes", "structvss_1_1data__access_1_1_camera_metadata.xhtml#a014754e1af065d2a5563c31c82674528", null ]
];