var structvss_1_1lighting__system__control_1_1_lighting_system_state =
[
    [ "lighting_system_name", "structvss_1_1lighting__system__control_1_1_lighting_system_state.xhtml#af4214546b2593d8c06cb1b0d50bf3114", null ],
    [ "projectors_state", "structvss_1_1lighting__system__control_1_1_lighting_system_state.xhtml#a22d6468f660ecb67ea5a1983ff33ab85", null ]
];