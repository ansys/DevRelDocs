var structvss_1_1feedback__control_1_1_weighting_by_pulses_or_chirps =
[
    [ "weightings_by_transmitter", "structvss_1_1feedback__control_1_1_weighting_by_pulses_or_chirps.xhtml#a321e3ed5504a67c8f68609e2dfc7922f", null ]
];