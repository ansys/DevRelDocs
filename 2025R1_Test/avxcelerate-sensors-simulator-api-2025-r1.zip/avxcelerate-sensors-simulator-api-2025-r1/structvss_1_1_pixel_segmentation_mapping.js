var structvss_1_1_pixel_segmentation_mapping =
[
    [ "tag_color_map", "structvss_1_1_pixel_segmentation_mapping.xhtml#aeaaf63ddf3d693e051d8358ffd9bea3b", null ]
];