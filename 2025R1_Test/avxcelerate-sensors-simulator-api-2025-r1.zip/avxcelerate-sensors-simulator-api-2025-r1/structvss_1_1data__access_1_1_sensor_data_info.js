var structvss_1_1data__access_1_1_sensor_data_info =
[
    [ "data_id", "structvss_1_1data__access_1_1_sensor_data_info.xhtml#a426e11266c60dc41fb1c5d81e5482d87", null ],
    [ "metadata", "structvss_1_1data__access_1_1_sensor_data_info.xhtml#aab1fa3aab176202c0b21da166a99b0ff", null ]
];