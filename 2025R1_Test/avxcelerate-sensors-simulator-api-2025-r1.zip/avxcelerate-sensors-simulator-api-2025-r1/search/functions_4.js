var searchData=
[
  ['requestdata_864',['RequestData',['../classvss_1_1data__access_1_1_data_access.xhtml#a019e9686eeb9db392e20086aa8ff63f0',1,'vss::data_access::DataAccess']]],
  ['requestdatastream_865',['RequestDataStream',['../classvss_1_1data__access_1_1_data_access.xhtml#af63c79b3e02fbeea6139f232e4371191',1,'vss::data_access::DataAccess']]]
];
