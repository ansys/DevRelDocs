var indexSectionsWithContent =
{
  0: "abcdefghijklmnopqrstuvwxyz",
  1: "abcdefghiklmnoprstuvw",
  2: "v",
  3: "giklrsu",
  4: "abcdefghiklmnoprstuvwxyz",
  5: "cilmopqrs",
  6: "bcdefghijlmnoprstuvwx",
  7: "d"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Pages"
};

