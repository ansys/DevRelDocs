var searchData=
[
  ['nodedescription_766',['NodeDescription',['../structvss_1_1ground__truth__access_1_1_node_description.xhtml',1,'vss::ground_truth_access']]]
];
