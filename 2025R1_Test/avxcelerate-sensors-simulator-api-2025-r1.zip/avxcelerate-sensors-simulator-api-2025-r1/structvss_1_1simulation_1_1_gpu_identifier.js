var structvss_1_1simulation_1_1_gpu_identifier =
[
    [ "name", "structvss_1_1simulation_1_1_gpu_identifier.xhtml#a2a5aeaedb916b63f402e3867e472d660", null ],
    [ "index", "structvss_1_1simulation_1_1_gpu_identifier.xhtml#a4d73f14555f456a4a579645371b74593", null ],
    [ "bus_id", "structvss_1_1simulation_1_1_gpu_identifier.xhtml#aaf69089e9c89cff5401a52779937a5bc", null ],
    [ "uuid", "structvss_1_1simulation_1_1_gpu_identifier.xhtml#a68d397eeda4cf9f4b79539b378da8149", null ]
];