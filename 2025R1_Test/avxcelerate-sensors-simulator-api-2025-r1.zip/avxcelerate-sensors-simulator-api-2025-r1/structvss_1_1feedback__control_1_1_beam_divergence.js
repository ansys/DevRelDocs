var structvss_1_1feedback__control_1_1_beam_divergence =
[
    [ "horizontal", "structvss_1_1feedback__control_1_1_beam_divergence.xhtml#a2a4449161574262bb66096aed218cf14", null ],
    [ "vertical", "structvss_1_1feedback__control_1_1_beam_divergence.xhtml#a6a70df464828c861a708829dd0888973", null ]
];