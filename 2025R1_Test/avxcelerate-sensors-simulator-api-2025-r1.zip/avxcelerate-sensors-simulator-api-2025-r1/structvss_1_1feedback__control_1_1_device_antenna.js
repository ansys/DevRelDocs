var structvss_1_1feedback__control_1_1_device_antenna =
[
    [ "identifier", "structvss_1_1feedback__control_1_1_device_antenna.xhtml#abc351a941825bba152e7849bea532275", null ],
    [ "position", "structvss_1_1feedback__control_1_1_device_antenna.xhtml#a7047bf34477b26145e78671529a731ac", null ],
    [ "orientation", "structvss_1_1feedback__control_1_1_device_antenna.xhtml#a0f1fe8398f8491be0a6b83356b7d5be2", null ]
];