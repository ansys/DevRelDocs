var structvss_1_1feedback__control_1_1_thermal_noise_advanced_model =
[
    [ "dark_current_reference_value", "structvss_1_1feedback__control_1_1_thermal_noise_advanced_model.xhtml#a2c53e5426f66522ffafc63985d544f22", null ],
    [ "dark_current_reference_temperature", "structvss_1_1feedback__control_1_1_thermal_noise_advanced_model.xhtml#a424b4a3cba094fc9518bdf35416c7d36", null ],
    [ "imager_temperature", "structvss_1_1feedback__control_1_1_thermal_noise_advanced_model.xhtml#a11a0f5326635d8f4d8cb908955900841", null ],
    [ "dark_current_coefficient", "structvss_1_1feedback__control_1_1_thermal_noise_advanced_model.xhtml#a080dfcafedbb0c85305c122551ce862c", null ]
];