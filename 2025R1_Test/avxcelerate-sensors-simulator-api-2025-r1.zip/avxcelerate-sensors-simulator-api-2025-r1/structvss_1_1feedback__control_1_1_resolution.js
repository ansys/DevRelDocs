var structvss_1_1feedback__control_1_1_resolution =
[
    [ "horizontal", "structvss_1_1feedback__control_1_1_resolution.xhtml#a54b4f2181863ed5669a68c6183c464b1", null ],
    [ "vertical", "structvss_1_1feedback__control_1_1_resolution.xhtml#a73efc1503c3577dce2526ae306c719b2", null ]
];