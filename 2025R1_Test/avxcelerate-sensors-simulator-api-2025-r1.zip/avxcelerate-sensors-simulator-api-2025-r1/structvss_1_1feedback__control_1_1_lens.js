var structvss_1_1feedback__control_1_1_lens =
[
    [ "fisheye_polynomial_distortion", "structvss_1_1feedback__control_1_1_lens.xhtml#a50cbe047748fe3fab2c92cbe99b45946", null ],
    [ "brown_distortion", "structvss_1_1feedback__control_1_1_lens.xhtml#a6dd75ecc3ccfbad272dbf6ca6159974d", null ],
    [ "focal_length", "structvss_1_1feedback__control_1_1_lens.xhtml#a4efa534244c04ceca668728f1c47b44a", null ],
    [ "circular", "structvss_1_1feedback__control_1_1_lens.xhtml#af2d83ca54f5f501a1b79507420ffd8d6", null ],
    [ "regular_convex", "structvss_1_1feedback__control_1_1_lens.xhtml#aaff0148f5b8b073a91ef4069fd4c7674", null ],
    [ "simple_chromatic_aberration", "structvss_1_1feedback__control_1_1_lens.xhtml#abe9d9733407a5fdacef85d38e5247075", null ],
    [ "advanced_chromatic_aberration", "structvss_1_1feedback__control_1_1_lens.xhtml#a7e79c01d25853a9285d61bedc56efabe", null ]
];