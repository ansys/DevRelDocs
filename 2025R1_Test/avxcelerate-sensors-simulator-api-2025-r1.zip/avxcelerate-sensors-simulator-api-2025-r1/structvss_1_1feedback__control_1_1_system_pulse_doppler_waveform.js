var structvss_1_1feedback__control_1_1_system_pulse_doppler_waveform =
[
    [ "bandwidth", "structvss_1_1feedback__control_1_1_system_pulse_doppler_waveform.xhtml#a9e1bdcdb02a4c4f8cea368f874666f9f", null ],
    [ "number_of_frequency_samples", "structvss_1_1feedback__control_1_1_system_pulse_doppler_waveform.xhtml#afac4612845b843b91fc51dfc6189d104", null ],
    [ "pulse_interval", "structvss_1_1feedback__control_1_1_system_pulse_doppler_waveform.xhtml#a054e3157072625f6162fd6db2531ab8a", null ],
    [ "number_of_pulses_in_coherent_processing_interval", "structvss_1_1feedback__control_1_1_system_pulse_doppler_waveform.xhtml#a72650e327be178603c0df76aaa5941b2", null ]
];