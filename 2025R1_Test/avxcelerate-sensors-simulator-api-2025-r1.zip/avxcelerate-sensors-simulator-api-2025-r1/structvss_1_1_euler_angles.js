var structvss_1_1_euler_angles =
[
    [ "yaw", "structvss_1_1_euler_angles.xhtml#a888cc94a5a110bb79ed09b08349171b4", null ],
    [ "pitch", "structvss_1_1_euler_angles.xhtml#add04f3a1b9c487ae403850139fe38ba3", null ],
    [ "roll", "structvss_1_1_euler_angles.xhtml#a17c6d048a0e5d7f9c6cc2de289361d6c", null ]
];