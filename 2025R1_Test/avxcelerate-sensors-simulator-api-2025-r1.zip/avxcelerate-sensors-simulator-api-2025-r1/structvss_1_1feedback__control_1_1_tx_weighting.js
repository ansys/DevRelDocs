var structvss_1_1feedback__control_1_1_tx_weighting =
[
    [ "weightings_by_transmitter", "structvss_1_1feedback__control_1_1_tx_weighting.xhtml#ac99192275bface7eb42742c52220912a", null ],
    [ "weightings_by_pulses_or_chirps", "structvss_1_1feedback__control_1_1_tx_weighting.xhtml#a7ce108c7a90e1706e207a39e74062fe7", null ]
];