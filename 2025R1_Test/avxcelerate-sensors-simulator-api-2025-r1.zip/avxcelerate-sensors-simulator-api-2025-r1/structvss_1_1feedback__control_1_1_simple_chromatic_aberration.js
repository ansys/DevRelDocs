var structvss_1_1feedback__control_1_1_simple_chromatic_aberration =
[
    [ "focal_length", "structvss_1_1feedback__control_1_1_simple_chromatic_aberration.xhtml#a623fb6fa3b48befce461398200ebef82", null ],
    [ "wavelength_of_focal_length", "structvss_1_1feedback__control_1_1_simple_chromatic_aberration.xhtml#ac549aaa5a98ea07b86087ff104fd31c1", null ],
    [ "preset_chromatic_dispersion", "structvss_1_1feedback__control_1_1_simple_chromatic_aberration.xhtml#ae6bb0c875d174779a96a36b8650b3f5e", null ],
    [ "custom_chromatic_dispersion", "structvss_1_1feedback__control_1_1_simple_chromatic_aberration.xhtml#a9cd10c825b9f9cd4723971649d949a66", null ]
];