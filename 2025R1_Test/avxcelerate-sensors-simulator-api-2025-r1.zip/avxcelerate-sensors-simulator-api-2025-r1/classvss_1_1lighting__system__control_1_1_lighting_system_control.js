var classvss_1_1lighting__system__control_1_1_lighting_system_control =
[
    [ "Set", "classvss_1_1lighting__system__control_1_1_lighting_system_control.xhtml#afd712cf0f68936c1f76224dfdfc78b20", null ],
    [ "Get", "classvss_1_1lighting__system__control_1_1_lighting_system_control.xhtml#a350f4512f37143a5c7d4430212d092b9", null ]
];