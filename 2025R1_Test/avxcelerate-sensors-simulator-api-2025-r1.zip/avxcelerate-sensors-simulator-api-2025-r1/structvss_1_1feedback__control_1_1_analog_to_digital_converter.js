var structvss_1_1feedback__control_1_1_analog_to_digital_converter =
[
    [ "sampling_frequency", "structvss_1_1feedback__control_1_1_analog_to_digital_converter.xhtml#a76a0ffa54413fbba7b2c7449a6472134", null ],
    [ "bit_resolution", "structvss_1_1feedback__control_1_1_analog_to_digital_converter.xhtml#a6e0f521da4a167ce578a8793f8276941", null ]
];