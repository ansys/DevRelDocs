var structvss_1_1feedback__control_1_1_brown_distortion =
[
    [ "radial_distortion", "structvss_1_1feedback__control_1_1_brown_distortion.xhtml#a906b3ebeab9816a13a6f7ed92fcaaec6", null ],
    [ "tangential_distortion", "structvss_1_1feedback__control_1_1_brown_distortion.xhtml#a22c2d45c51da9a567692848f2b2f8349", null ]
];