var structvss_1_1simulation_1_1_lidar_simulation =
[
    [ "waveform", "structvss_1_1simulation_1_1_lidar_simulation.xhtml#a83c1c68bc4af8352a58e888e57449dd0", null ],
    [ "contribution", "structvss_1_1simulation_1_1_lidar_simulation.xhtml#af92bd4d6cc507e59da0dffa5bd0249ac", null ],
    [ "grid", "structvss_1_1simulation_1_1_lidar_simulation.xhtml#a83842cf7b7afa4040063c9031a82b17c", null ],
    [ "number_of_batches", "structvss_1_1simulation_1_1_lidar_simulation.xhtml#af80e7826b0ec5d66d3794cf92311c742", null ],
    [ "gpu_name", "structvss_1_1simulation_1_1_lidar_simulation.xhtml#a509612d128731b71d5bc3fdd5774d6c8", null ],
    [ "use_rgb_diffuse", "structvss_1_1simulation_1_1_lidar_simulation.xhtml#a08cc1c59ef05209f4d9b2a41ae55bbb4", null ]
];