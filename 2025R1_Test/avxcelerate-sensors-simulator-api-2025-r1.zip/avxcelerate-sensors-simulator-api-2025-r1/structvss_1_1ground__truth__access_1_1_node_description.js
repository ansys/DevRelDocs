var structvss_1_1ground__truth__access_1_1_node_description =
[
    [ "name", "structvss_1_1ground__truth__access_1_1_node_description.xhtml#a8182b88bee668dbdd378a85d28ea95ad", null ],
    [ "tags", "structvss_1_1ground__truth__access_1_1_node_description.xhtml#a59bf4044a5fa1bb67e58ba0ed3134450", null ]
];