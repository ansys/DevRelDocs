var structvss_1_1ground__truth__access_1_1_tag_description =
[
    [ "tag", "structvss_1_1ground__truth__access_1_1_tag_description.xhtml#ad06585b0252b2d5c431a333dd89b1b3f", null ],
    [ "label", "structvss_1_1ground__truth__access_1_1_tag_description.xhtml#a9d6036c2e792ddbe4308218eb3f76988", null ]
];