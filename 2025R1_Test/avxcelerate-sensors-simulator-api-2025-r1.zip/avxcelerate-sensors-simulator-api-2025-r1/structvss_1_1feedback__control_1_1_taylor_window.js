var structvss_1_1feedback__control_1_1_taylor_window =
[
    [ "side_lobe_level", "structvss_1_1feedback__control_1_1_taylor_window.xhtml#add310bfcc457aa85ce5fc742791ec420", null ]
];