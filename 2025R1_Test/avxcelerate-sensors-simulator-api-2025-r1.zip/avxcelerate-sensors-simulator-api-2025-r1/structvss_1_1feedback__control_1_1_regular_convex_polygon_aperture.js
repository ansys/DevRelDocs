var structvss_1_1feedback__control_1_1_regular_convex_polygon_aperture =
[
    [ "aperture_area", "structvss_1_1feedback__control_1_1_regular_convex_polygon_aperture.xhtml#abca6218ebda4a3ee35f6921022128069", null ],
    [ "offset_angle", "structvss_1_1feedback__control_1_1_regular_convex_polygon_aperture.xhtml#a584ac84e7311286b8387e4a105d59272", null ],
    [ "edge_number", "structvss_1_1feedback__control_1_1_regular_convex_polygon_aperture.xhtml#a1202d79d6e03fccf0f23b0c95391cab0", null ]
];