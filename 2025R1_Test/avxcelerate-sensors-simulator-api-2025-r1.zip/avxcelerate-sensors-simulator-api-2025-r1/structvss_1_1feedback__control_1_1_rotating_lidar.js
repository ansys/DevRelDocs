var structvss_1_1feedback__control_1_1_rotating_lidar =
[
    [ "rotation_speed", "structvss_1_1feedback__control_1_1_rotating_lidar.xhtml#a0d7e695db66cd06cdcbc076055bd9852", null ],
    [ "emitter", "structvss_1_1feedback__control_1_1_rotating_lidar.xhtml#aade093db53db24899b883410ae73b087", null ],
    [ "receiver", "structvss_1_1feedback__control_1_1_rotating_lidar.xhtml#a740e46af48b460a8103e8490d79bd047", null ]
];