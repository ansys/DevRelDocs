var structvss_1_1sensor__data_1_1_contribution =
[
    [ "identity", "structvss_1_1sensor__data_1_1_contribution.xhtml#ac7c1ac9a858949a9f035216f703d034c", null ],
    [ "weight", "structvss_1_1sensor__data_1_1_contribution.xhtml#a5baed38044eb5d59ea465ea8b2368639", null ]
];