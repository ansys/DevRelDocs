var structvss_1_1feedback__control_1_1_beam_shape_intensity_file =
[
    [ "intensity_file", "structvss_1_1feedback__control_1_1_beam_shape_intensity_file.xhtml#a6a05e0301ca362456e341b539f1c0980", null ],
    [ "file_type", "structvss_1_1feedback__control_1_1_beam_shape_intensity_file.xhtml#a9559b6d815de0eb9780af372a07ea995", null ]
];