var structvss_1_1feedback__control_1_1_arbitrary_system_frequency_modulated_continuous_waveform =
[
    [ "chirp_sequence", "structvss_1_1feedback__control_1_1_arbitrary_system_frequency_modulated_continuous_waveform.xhtml#a9186d60a98e909cd395f5ac8e9f6e546", null ],
    [ "ramp_rate", "structvss_1_1feedback__control_1_1_arbitrary_system_frequency_modulated_continuous_waveform.xhtml#a598f1da6b0fe0d679d8a2f7177a13953", null ],
    [ "rx_components", "structvss_1_1feedback__control_1_1_arbitrary_system_frequency_modulated_continuous_waveform.xhtml#ac3114b34e770c6b35ef0e4d894b9269e", null ]
];