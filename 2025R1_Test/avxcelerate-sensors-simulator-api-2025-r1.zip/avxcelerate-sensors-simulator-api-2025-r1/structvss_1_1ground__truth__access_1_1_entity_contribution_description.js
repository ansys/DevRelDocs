var structvss_1_1ground__truth__access_1_1_entity_contribution_description =
[
    [ "EntityID", "structvss_1_1ground__truth__access_1_1_entity_contribution_description.xhtml#abb1954a2529de8dd57e1bcab5ef652b2", null ],
    [ "asset_description", "structvss_1_1ground__truth__access_1_1_entity_contribution_description.xhtml#ac7e989fe006ad8ca4ff257de83bd5811", null ],
    [ "node_hierarchy", "structvss_1_1ground__truth__access_1_1_entity_contribution_description.xhtml#ac4f25cab8eb254cd3a4508a93a500caf", null ],
    [ "mesh_description", "structvss_1_1ground__truth__access_1_1_entity_contribution_description.xhtml#a8fcb2a137ad45ebc7467c62d533a471a", null ]
];