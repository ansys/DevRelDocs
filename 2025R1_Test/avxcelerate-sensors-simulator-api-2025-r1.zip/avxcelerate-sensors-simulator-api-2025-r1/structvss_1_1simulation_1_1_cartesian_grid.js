var structvss_1_1simulation_1_1_cartesian_grid =
[
    [ "horizontal_grid_points", "structvss_1_1simulation_1_1_cartesian_grid.xhtml#a69ea37ef59b47b897122becaff176f6c", null ],
    [ "vertical_grid_points", "structvss_1_1simulation_1_1_cartesian_grid.xhtml#a122629d1d7d1139a280ffc0d62133f9b", null ]
];