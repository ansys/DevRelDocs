var structvss_1_1feedback__control_1_1_pulse =
[
    [ "wavelength", "structvss_1_1feedback__control_1_1_pulse.xhtml#ab5e4b49d163b07c49e116319f5a7789d", null ],
    [ "shape", "structvss_1_1feedback__control_1_1_pulse.xhtml#abb092a62d75d5191fd2edc4a9112ddf2", null ],
    [ "duration", "structvss_1_1feedback__control_1_1_pulse.xhtml#a8ee76491c836a78df05b258a06277d9f", null ],
    [ "extinction_coefficient", "structvss_1_1feedback__control_1_1_pulse.xhtml#a5b44e6c50cf6f14669a352efdc9313f9", null ]
];