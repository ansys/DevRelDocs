var structvss_1_1feedback__control_1_1_feedback_control_radar_parameters =
[
    [ "tx_antennas", "structvss_1_1feedback__control_1_1_feedback_control_radar_parameters.xhtml#a4870c53387ea59d4f825c2ba4ce7e64a", null ],
    [ "rx_antennas", "structvss_1_1feedback__control_1_1_feedback_control_radar_parameters.xhtml#ab1d99b824434b4b33863c29d85d42b6d", null ],
    [ "modes", "structvss_1_1feedback__control_1_1_feedback_control_radar_parameters.xhtml#ad77d8926fd6106eb50aae6bfdb1de3d3", null ]
];