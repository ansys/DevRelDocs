var structvss_1_1simulation_1_1_environment_update =
[
    [ "date_time", "structvss_1_1simulation_1_1_environment_update.xhtml#aa1c4817b2557a886a6b1eb955ecc2331", null ],
    [ "streetLightsState", "structvss_1_1simulation_1_1_environment_update.xhtml#a55256ba6cb1cf035a9ad4e7780d8eef5", null ]
];