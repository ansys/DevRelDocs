var structvss_1_1sensor__data_1_1_tx_waveform_data =
[
    [ "data", "structvss_1_1sensor__data_1_1_tx_waveform_data.xhtml#af7bdb8ce080eebc3f3e8186ad240aad8", null ],
    [ "tx_identifiers", "structvss_1_1sensor__data_1_1_tx_waveform_data.xhtml#a59c845c9c5e1235844a0704c451064b6", null ],
    [ "number_of_values_per_sample", "structvss_1_1sensor__data_1_1_tx_waveform_data.xhtml#ae67537d0410d0c11be4eb152d7f51060", null ],
    [ "number_of_samples", "structvss_1_1sensor__data_1_1_tx_waveform_data.xhtml#a3bf05d7f85edff4ed6c238dc5972235b", null ],
    [ "number_of_pulses_or_chirps", "structvss_1_1sensor__data_1_1_tx_waveform_data.xhtml#a6510a8548af7eba09974f7f856ca70eb", null ]
];