var structvss_1_1feedback__control_1_1_pulse_doppler_waveform =
[
    [ "system_pulse_doppler_waveform", "structvss_1_1feedback__control_1_1_pulse_doppler_waveform.xhtml#ad05b00c3fb4dc12daffe5ec59fc71fb4", null ],
    [ "performance_pulse_doppler_waveform", "structvss_1_1feedback__control_1_1_pulse_doppler_waveform.xhtml#a8164682119ac5e6c366eefcdec948fec", null ],
    [ "arbitrary_system_pulse_doppler_waveform", "structvss_1_1feedback__control_1_1_pulse_doppler_waveform.xhtml#a66431a870b8d2861ff25c1a739878d42", null ]
];