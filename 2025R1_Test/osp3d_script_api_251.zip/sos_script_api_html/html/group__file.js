var group__file =
[
    [ "canonical", "group__file.xhtml#ga8b98a72819aaee1485524b72e2db4eab", null ],
    [ "copyFile", "group__file.xhtml#ga43c0665d078ffe1df1fa55dfe5dbb8d8", null ],
    [ "createDirectories", "group__file.xhtml#ga15e71a3757e5c445d1853374525bff30", null ],
    [ "exists", "group__file.xhtml#ga10d9c7723a9e8f1c4c854ac8618c4b65", null ],
    [ "isDirectory", "group__file.xhtml#ga9cee08428812e33a6b9fbf6bcb93fabf", null ],
    [ "isRegularFile", "group__file.xhtml#ga2056a4fca10b1c0adb916146ad1a51a2", null ],
    [ "relative", "group__file.xhtml#ga7b396b4263cb6f8d00dd5b0c02dba6c5", null ],
    [ "removeAll", "group__file.xhtml#ga0f399219011ea9c84280b4b1f95c58d2", null ]
];