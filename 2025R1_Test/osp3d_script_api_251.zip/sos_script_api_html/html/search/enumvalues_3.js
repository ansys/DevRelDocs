var searchData=
[
  ['design',['DESIGN',['../class_render_data.xhtml#ace34b43f7a85070c2f233cbb13e362bfa058ddfdfb3dd989380a646a626964dff',1,'RenderData']]],
  ['diff',['DIFF',['../class_compute_relative_error.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60eaa5d305f703cfce63b982a4cba74f64ec',1,'ComputeRelativeError']]]
];
