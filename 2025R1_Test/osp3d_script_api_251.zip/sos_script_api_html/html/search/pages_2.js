var searchData=
[
  ['deprecated_20list',['Deprecated List',['../deprecated.xhtml',1,'']]],
  ['data_20and_20filters',['Data and Filters',['../example_dataandfilters.xhtml',1,'lua_examples']]]
];
