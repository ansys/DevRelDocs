var searchData=
[
  ['k',['k',['../class_compute_mean_plus_sigma.xhtml#ad9b159815428db5e4cf2efa7d31d99cf',1,'ComputeMeanPlusSigma']]],
  ['kernel',['kernel',['../class_create_kriging_model.xhtml#a76cb15ad1bfa0a07b32a648c7130d223',1,'CreateKrigingModel::kernel()'],['../class_create_m_l_s_model.xhtml#ab1d4dfd9aa65780c7abd0f9b3df55bba',1,'CreateMLSModel::kernel()'],['../class_create_r_b_f_model.xhtml#adc959eb07a99a44aa7c2c4134a307170',1,'CreateRBFModel::kernel()']]],
  ['krigingkernel',['KrigingKernel',['../group__models.xhtml#ga042370e76002486e7e94f29bd4b0835c',1,'create_kriging_model.hpp']]],
  ['krigingmodel',['KrigingModel',['../class_kriging_model.xhtml',1,'KrigingModel'],['../class_kriging_model.xhtml#ad2c5630687bfd2e43bc9d4a76ab1ba92',1,'KrigingModel::KrigingModel()'],['../class_kriging_model.xhtml#a7e9c455228078e06bafb139efbf20f33',1,'KrigingModel::KrigingModel(InternalModelType *model, quality_measure::ResidualsBase *residuals, string description, PropertyList properties=PropertyList())'],['../class_kriging_model.xhtml#a1acecabebf2abee48520a25db45dc84f',1,'KrigingModel::KrigingModel(KrigingModel other)']]]
];
