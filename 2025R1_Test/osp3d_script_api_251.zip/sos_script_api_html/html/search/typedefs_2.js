var searchData=
[
  ['data_5fobject_5fkey_5fvector_5ftype',['data_object_key_vector_type',['../class_data_object_container.xhtml#a831464cbf6637a6d9426cfad4b30e1e5',1,'DataObjectContainer']]],
  ['delimiter_5fset_5ftype',['delimiter_set_type',['../class_import_c_s_v.xhtml#a7ca6b7dfb092f003a8112eab3ab69523',1,'ImportCSV']]]
];
