var searchData=
[
  ['value_5ftransformation',['value_transformation',['../class_create_kriging_model.xhtml#a850bec49118fd5e977ea5be55a59d594',1,'CreateKrigingModel::value_transformation()'],['../class_create_m_l_s_model.xhtml#a850bec49118fd5e977ea5be55a59d594',1,'CreateMLSModel::value_transformation()'],['../class_create_polynomial_model.xhtml#a850bec49118fd5e977ea5be55a59d594',1,'CreatePolynomialModel::value_transformation()'],['../class_create_r_b_f_model.xhtml#a850bec49118fd5e977ea5be55a59d594',1,'CreateRBFModel::value_transformation()']]]
];
