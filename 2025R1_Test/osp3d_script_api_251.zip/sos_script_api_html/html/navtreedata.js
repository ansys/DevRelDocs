/*
@ @licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2017 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Statistics on Structures Script API Documentation (Beta)", "index.xhtml", [
    [ "Overview", "index.xhtml", "index" ],
    [ "Module tmath", "md_doc_swig_doc_src_tmath.xhtml", null ],
    [ "Deprecated List", "deprecated.xhtml", null ],
    [ "Modules", "modules.xhtml", "modules" ]
  ] ]
];

var NAVTREEINDEX =
[
"another_lua_example__postpocess_field_data.xhtml",
"class_compute_mean_plus_sigma.xhtml#a30b1bcf63b9bdc707fea30bd96d70447",
"class_compute_variance.xhtml#ac597f6cab052d215247719908ce3cb0b",
"class_custom_model.xhtml#ac98d07dd8f7b70e16ccb9a01abf56b9c",
"class_export_reference_design.xhtml#a7aee363b2bbb561ef1d20b2aaaaf61d9",
"class_incompatible_mesh_mapper_by_projection.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a284b6ad33acf2df5fcd062adc42ad59c",
"class_matrix.xhtml#a14985545f226fa39181250a3f2616d8f",
"class_mesh_assembly.xhtml#ab61e0918d34353bb62ce870f218c1ddb",
"class_random_field_decomposition_from_samples.xhtml#a338b0447773d59620abdb12cb263ab2cabaabae290ac4993db4140a99c4002162",
"class_scalar_m_o_p2.xhtml#ab8c54941abc35581947aca7a9eec4a67",
"class_scene_manager.xhtml#a36172b6f1300b9a30ef0b5ff77d71d3e",
"class_value_type_enum.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60eaa97b2c144243b2b9d2c593ec268b62f5",
"struct_co_d.xhtml#a4a4f4dfb26f77b55280f37a0610dd5f9",
"struct_export_item_info.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a00b25c8e0cab6b1599a49ca6f47d713e",
"struct_simple_training_plan.xhtml#a2b8e899313418568acbb9ed5b2ce6ade"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';