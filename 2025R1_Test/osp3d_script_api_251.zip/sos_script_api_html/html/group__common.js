var group__common =
[
    [ "EnumTraits< ParameterImportance >", "struct_enum_traits_3_01_parameter_importance_01_4.xhtml", [
      [ "MappingType", "struct_enum_traits_3_01_parameter_importance_01_4.xhtml#a4302e093ee569d077845e0a62cff7eb8", null ],
      [ "Type", "struct_enum_traits_3_01_parameter_importance_01_4.xhtml#afafd2261c8d13bdc5434a63da18d0036", null ],
      [ "defaultName", "struct_enum_traits_3_01_parameter_importance_01_4.xhtml#a7e0424f37ceeae86e34e433a34893429", null ],
      [ "defaultValue", "struct_enum_traits_3_01_parameter_importance_01_4.xhtml#a14b8d2233990d6b89d5da214cf51156f", null ],
      [ "mapping", "struct_enum_traits_3_01_parameter_importance_01_4.xhtml#a364389563035c8c067a58d2a1461f703", null ]
    ] ],
    [ "EnumTraits< TrainingPlanType >", "struct_enum_traits_3_01_training_plan_type_01_4.xhtml", [
      [ "MappingType", "struct_enum_traits_3_01_training_plan_type_01_4.xhtml#a2907d5214ceec0838fbf99096ef01479", null ],
      [ "Type", "struct_enum_traits_3_01_training_plan_type_01_4.xhtml#afafd2261c8d13bdc5434a63da18d0036", null ],
      [ "defaultName", "struct_enum_traits_3_01_training_plan_type_01_4.xhtml#a7e0424f37ceeae86e34e433a34893429", null ],
      [ "defaultValue", "struct_enum_traits_3_01_training_plan_type_01_4.xhtml#a14b8d2233990d6b89d5da214cf51156f", null ],
      [ "mapping", "struct_enum_traits_3_01_training_plan_type_01_4.xhtml#a364389563035c8c067a58d2a1461f703", null ]
    ] ],
    [ "SerializableTraits< ParameterImportance >", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml", [
      [ "CreateRange", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml#a94ee29ff3d0e5244c388625f4355247d", null ],
      [ "SerializedType", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml#ab097986696f004853b8989b257f6bcdf", null ],
      [ "Type", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml#ae9d6c84c74502f2119fbb1e6c8f2e7b8", null ],
      [ "access", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml#a722bfc2616239aa9f198a76b73b69743", null ],
      [ "convertFrom", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml#a1d26534c31e8c5b1b9c9684c59c1a524", null ],
      [ "convertTo", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml#add861d4bddc999ecd369aa4f9709973a", null ],
      [ "name", "struct_serializable_traits_3_01_parameter_importance_01_4.xhtml#a707b939a71a610e3f3dcb789ccf014b8", null ]
    ] ],
    [ "ParameterImportance", "group__common.xhtml#gad5ca470fd07552bf1da82219827c4ec0", null ],
    [ "TrainingPlanType", "group__common.xhtml#ga8f73c0a2225e425c9ffeecb046034a43", null ]
];