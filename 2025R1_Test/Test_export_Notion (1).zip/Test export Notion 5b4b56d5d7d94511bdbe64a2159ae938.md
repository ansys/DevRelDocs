# Test export Notion

# Test

This is a test of Notion page export in markdown.

In this page there are:

# A gif

![GIF.gif](Test%20export%20Notion%205b4b56d5d7d94511bdbe64a2159ae938/GIF.gif)

## A picture

![distance.png](Test%20export%20Notion%205b4b56d5d7d94511bdbe64a2159ae938/distance.png)

And a database table

[Here is the data](Test%20export%20Notion%205b4b56d5d7d94511bdbe64a2159ae938/Here%20is%20the%20data%20b03cac5f5c86487fa188a2289e0b6159.csv)