/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Main Page",url:"index.xhtml"},
{text:"Getting Started with APIs",url:"usergroup0.xhtml",children:[
{text:"Client Initialization",url:"md__content_files__getting_started_get_client.xhtml#GettingStartedGetClient"},
{text:"Basic Checkout",url:"md__content_files__getting_started_checkout.xhtml#GettingStartedCheckout"},
{text:"Basic Checkin",url:"md__content_files__getting_started_checkin.xhtml#GettingStartedCheckin"}]},
{text:"Licensing APIs",url:"modules.xhtml"},
{text:"Licensing Sharing Mechanism",url:"usergroup1.xhtml",children:[
{text:"Overview",url:"md__content_files__licensing__contexts.xhtml#contexts"},
{text:"Getting Started with Licensing Sharing",url:"usergroup2.xhtml",children:[
{text:"Create A Sharing Context",url:"md__content_files_context.xhtml#createcontext"},
{text:"Sending information to all applications using the sharing context",url:"md__content_files__set_env.xhtml#setenvcontext"},
{text:"Close A Sharing Context",url:"md__content_files__close_context.xhtml#closecontext"}]},
{text:"Licensing Sharing API",url:"group__context_a_p_i.xhtml"},
{text:"Example Creating a different type of sharing context",url:"md__content_files__sample_context_example.xhtml#contextsample"}]},
{text:"Licensing Functionalities",url:"usergroup3.xhtml",children:[
{text:"HPC pack and pool",url:"md__content_files__h_p_c_packs_and_pools.xhtml#HpcPacksAndPools"},
{text:"Idle Timeout",url:"md__content_files_idle_timeout.xhtml#idletimeout"},
{text:"FNP Queuing",url:"md__content_files_queuing.xhtml#queuingpage"}]},
{text:"Working with environment variables",url:"md__content_files__environment.xhtml#env_var"}]}
