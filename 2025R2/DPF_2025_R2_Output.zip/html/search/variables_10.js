var searchData=
[
  ['resistance_0',['resistance',['../structansys_1_1dpf_1_1homogeneities.xhtml#af786d0dcd9ea09460f9bac626d8727bc',1,'ansys::dpf::homogeneities']]],
  ['resistivity_1',['resistivity',['../structansys_1_1dpf_1_1homogeneities.xhtml#a18eb281929be2773fa1034808732c95f',1,'ansys::dpf::homogeneities']]],
  ['result_5finfo_2',['result_info',['../structansys_1_1dpf_1_1types.xhtml#af809418d3ce134e74935fb71f67309f1',1,'ansys::dpf::types']]],
  ['rpms_3',['rpms',['../structansys_1_1dpf_1_1property__types.xhtml#ae07aa6d83c8a542d894a0a305248d739',1,'ansys::dpf::property_types']]]
];
