var searchData=
[
  ['ways_20of_20using_20dpf_0',['Ways of Using DPF',['../group__group__03.xhtml',1,'']]],
  ['writing_20a_20dpf_20operator_1',['Writing a DPF operator',['../group__group__09.xhtml',1,'']]]
];
