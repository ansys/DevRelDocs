var searchData=
[
  ['analysis_5ftype_0',['analysis_type',['../classansys_1_1dpf_1_1ResultInfo.xhtml#a7242b85e3d035f0953356a1146e742ae',1,'ansys::dpf::ResultInfo']]],
  ['apitype_1',['ApiType',['../namespaceansys_1_1dpf.xhtml#a318ab16f856ec8d2ef6e13af94a6dc56',1,'ansys::dpf']]]
];
