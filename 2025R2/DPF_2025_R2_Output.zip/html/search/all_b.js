var searchData=
[
  ['job_5fname_0',['job_name',['../classansys_1_1dpf_1_1ResultInfo.xhtml#ae6ed610647bdabcc9baab02b19462f99',1,'ansys::dpf::ResultInfo']]],
  ['joint_1',['joint',['../structansys_1_1dpf_1_1locations.xhtml#a0a7d57a4476a34178090d4fa96f0c550',1,'ansys::dpf::locations']]]
];
