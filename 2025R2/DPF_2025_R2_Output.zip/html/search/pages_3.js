var searchData=
[
  ['getting_20started_0',['Getting started',['../getting_started.xhtml',1,'']]]
];
