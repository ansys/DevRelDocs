/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "Getting started", "getting_started.xhtml", null ],
    [ "User guide", "modules.xhtml", "modules" ],
    [ "Operators", "operators_page.xhtml", null ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Typedefs", "namespacemembers_type.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Examples", "examples.xhtml", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"AveragingTest_8cpp-example.xhtml",
"classansys_1_1dpf_1_1CustomTypeFieldsContainer.xhtml#a0c1698f9c74ae209656e11454723670d",
"classansys_1_1dpf_1_1DpfVector.xhtml#acb74f526bb5e61fef09605354966ff16",
"classansys_1_1dpf_1_1FieldsContainer.xhtml#a8f56a88941a626857bb11528368f08e6",
"classansys_1_1dpf_1_1MeshesContainer.xhtml#a7a7b3e5a05bbd093a14531d846c0557a",
"classansys_1_1dpf_1_1Operator.xhtml#ac49d268562ffaa8e90535595647d203b",
"classansys_1_1dpf_1_1OperatorMain.xhtml#ae58f595e91c2daba7b7c0ebf73c700ff",
"classansys_1_1dpf_1_1ResultInfo.xhtml#ac0f80a2ea905a13dccc274790ef6cbc7",
"classansys_1_1dpf_1_1TimeFreqSupport.xhtml#a855a9819d41665a1d9177fd8f67fa3f1",
"classansys_1_1dpf_1_1Workflow.xhtml#a8943b00849c0866751571b2e059c1f1f",
"hierarchy.xhtml",
"structansys_1_1dpf_1_1elements.xhtml#a5691e11b844d29be5134f86e7dcd11dc",
"structansys_1_1dpf_1_1quantity__types.xhtml"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';