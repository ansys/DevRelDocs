var class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings =
[
    [ "calculationEngUnitsPressurePSIAorGaugeCombo", "class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings.xhtml#a520e5187b8278a07bc50a408e0ecb14e", null ],
    [ "calculationEngUnitsTemperatureForRCombo", "class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings.xhtml#aa46ce70cfc4366e8c0fee666d49a98cf", null ],
    [ "calculationOutputUnits", "class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings.xhtml#af48ec74eb534b3c1c818d6a62e8cb37c", null ],
    [ "calculationSiUnitsTemperatureCorKCombo", "class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings.xhtml#ab0430a1492d23bbe767150dc8ec1feec", null ],
    [ "calculationUnitsThermalOnlyInterfaceOrENG_SI_controlled", "class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings.xhtml#af0233dda0b7ad10e78c03ca06591f82e", null ]
];