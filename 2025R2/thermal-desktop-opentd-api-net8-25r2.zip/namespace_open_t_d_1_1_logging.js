var namespace_open_t_d_1_1_logging =
[
    [ "Logger", "class_open_t_d_1_1_logging_1_1_logger.xhtml", "class_open_t_d_1_1_logging_1_1_logger" ]
];