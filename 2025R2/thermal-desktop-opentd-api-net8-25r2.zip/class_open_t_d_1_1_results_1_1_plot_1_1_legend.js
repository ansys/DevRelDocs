var class_open_t_d_1_1_results_1_1_plot_1_1_legend =
[
    [ "Legend", "class_open_t_d_1_1_results_1_1_plot_1_1_legend.xhtml#a7b1306dd6f44ef27d5469281b06c85f5", null ],
    [ "GetLegendStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_legend.xhtml#aa1a0fc2376caa173e7ba45af451ec834", null ],
    [ "SetLegendStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_legend.xhtml#af6cc00924327885349ca8bcddac14707", null ],
    [ "Enabled", "class_open_t_d_1_1_results_1_1_plot_1_1_legend.xhtml#aa6c8c8247fa9063f474c424268f01d79", null ],
    [ "LegendStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_legend.xhtml#a7b4efd4cd1539436caa1db8b85b889c9", null ],
    [ "Title", "class_open_t_d_1_1_results_1_1_plot_1_1_legend.xhtml#aede9fedbabd6a342cd765902f543e9f9", null ]
];