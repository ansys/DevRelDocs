var namespace_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop =
[
    [ "HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply" ],
    [ "HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request" ]
];