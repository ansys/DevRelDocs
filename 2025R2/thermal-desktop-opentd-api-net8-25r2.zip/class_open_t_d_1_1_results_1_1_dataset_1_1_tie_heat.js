var class_open_t_d_1_1_results_1_1_dataset_1_1_tie_heat =
[
    [ "DUPN", "class_open_t_d_1_1_results_1_1_dataset_1_1_tie_heat.xhtml#ad73155df3fb42528b17c4929ade309e8", null ],
    [ "Heatrate", "class_open_t_d_1_1_results_1_1_dataset_1_1_tie_heat.xhtml#ab06d44e7f82ad09caac4bddf9fbfc976", null ],
    [ "QTIE", "class_open_t_d_1_1_results_1_1_dataset_1_1_tie_heat.xhtml#a73c776ebc8d4e89032545c8d007af9f3", null ],
    [ "TieInfo", "class_open_t_d_1_1_results_1_1_dataset_1_1_tie_heat.xhtml#ac0c09d25b78b8ff0d2f9765ba940d674", null ]
];