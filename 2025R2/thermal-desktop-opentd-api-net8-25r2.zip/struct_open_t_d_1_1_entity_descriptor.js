var struct_open_t_d_1_1_entity_descriptor =
[
    [ "EntityDescriptor", "struct_open_t_d_1_1_entity_descriptor.xhtml#abc83a042f4901c26e14cfceb67c387ef", null ],
    [ "EntityDescriptor", "struct_open_t_d_1_1_entity_descriptor.xhtml#afd91db6c12e60a64534ae17627c66f7d", null ],
    [ "ToString", "struct_open_t_d_1_1_entity_descriptor.xhtml#a9a7d1d232806f772695557584b606f40", null ],
    [ "Connection", "struct_open_t_d_1_1_entity_descriptor.xhtml#ab1df76ce3172582cbb80275ab857c80e", null ],
    [ "RawType", "struct_open_t_d_1_1_entity_descriptor.xhtml#a6a7d933ee64341665998a83e58a117cb", null ]
];