var class_open_t_d_1_1_optical_prop_alias_manager =
[
    [ "CreateOrUpdateAlias", "class_open_t_d_1_1_optical_prop_alias_manager.xhtml#a4b6e8f38ea75356d2f89ff248d32040d", null ],
    [ "DeleteAlias", "class_open_t_d_1_1_optical_prop_alias_manager.xhtml#abc590fdf6f9980bb54ad3d955aaa5135", null ],
    [ "GetAlias", "class_open_t_d_1_1_optical_prop_alias_manager.xhtml#a6eb956c4c04b0ebd864d3b6366be62b2", null ],
    [ "GetAliases", "class_open_t_d_1_1_optical_prop_alias_manager.xhtml#aef593026705dc8ddd96a7de87916e3d8", null ],
    [ "RenameAlias", "class_open_t_d_1_1_optical_prop_alias_manager.xhtml#ac758ed8bd30719990b4a63f5115a3966", null ]
];