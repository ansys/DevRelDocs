var class_open_t_d_1_1_td_connect_config =
[
    [ "Types", "class_open_t_d_1_1_td_connect_config.xhtml#abd41449782efbc0f8a04a6ca43a25311", [
      [ "START_NEW_TD", "class_open_t_d_1_1_td_connect_config.xhtml#abd41449782efbc0f8a04a6ca43a25311a54491a722ec3f300682eb3a6711c5995", null ],
      [ "AUTO", "class_open_t_d_1_1_td_connect_config.xhtml#abd41449782efbc0f8a04a6ca43a25311ae1f2d5134ed2543d38a0de9751cf75d9", null ],
      [ "ATTACH_TO_TD", "class_open_t_d_1_1_td_connect_config.xhtml#abd41449782efbc0f8a04a6ca43a25311a2f405afd9f53967fafd96fb5c93c1b07", null ],
      [ "INPROCESS", "class_open_t_d_1_1_td_connect_config.xhtml#abd41449782efbc0f8a04a6ca43a25311ab61d850eff77166498d04996cd33fa9b", null ]
    ] ],
    [ "TdConnectConfig", "class_open_t_d_1_1_td_connect_config.xhtml#a5ec2a1c0f115c6c2888ad08bb83f7d3e", null ],
    [ "AcadExePathname", "class_open_t_d_1_1_td_connect_config.xhtml#a3745daa68e8b7cd8e7686b7b850039ac", null ],
    [ "AcadVisible", "class_open_t_d_1_1_td_connect_config.xhtml#aec3a5664f7285fe6c7475d5998eed427", null ],
    [ "AdditionalAcadCommandline", "class_open_t_d_1_1_td_connect_config.xhtml#a850c545d2aa5fdf11cb2135d58039ce5", null ],
    [ "Address", "class_open_t_d_1_1_td_connect_config.xhtml#a5b2282c2f28b8732e5d8e1ce9c753495", null ],
    [ "AddressUsed", "class_open_t_d_1_1_td_connect_config.xhtml#a1227c57da2fcec492355667cd4109b95", null ],
    [ "DwgPathname", "class_open_t_d_1_1_td_connect_config.xhtml#a3ce352790582d8ab16e16d0bcac68657", null ],
    [ "PortUsed", "class_open_t_d_1_1_td_connect_config.xhtml#aff7e6f2d27b362d9602561b666778f7c", null ],
    [ "ShowAcadSplashScreen", "class_open_t_d_1_1_td_connect_config.xhtml#af353ea627c65cde87cb566c6c2219299", null ],
    [ "StartDirectory", "class_open_t_d_1_1_td_connect_config.xhtml#a7abfa8cdeb05154b7bd270fce1db8297", null ],
    [ "StartTimeout", "class_open_t_d_1_1_td_connect_config.xhtml#a042d71ce2c38fe9f1597116bcce6da31", null ],
    [ "Type", "class_open_t_d_1_1_td_connect_config.xhtml#a28c9457977b0f221f72006992984df17", null ]
];