var namespace_open_t_d_1_1_user_interface =
[
    [ "Forms", "namespace_open_t_d_1_1_user_interface_1_1_forms.xhtml", "namespace_open_t_d_1_1_user_interface_1_1_forms" ],
    [ "WriteEventArgs", "class_open_t_d_1_1_user_interface_1_1_write_event_args.xhtml", "class_open_t_d_1_1_user_interface_1_1_write_event_args" ]
];