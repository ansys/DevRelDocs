var class_open_t_d_1_1_post_processing_1_1_additional_text_info =
[
    [ "AdditionalTextInfo", "class_open_t_d_1_1_post_processing_1_1_additional_text_info.xhtml#a0a4a9c01f62855d6d551a8487318535c", null ],
    [ "_pathname", "class_open_t_d_1_1_post_processing_1_1_additional_text_info.xhtml#a00d93b38fc9b743e486c5a10251e6890", null ],
    [ "Pathname", "class_open_t_d_1_1_post_processing_1_1_additional_text_info.xhtml#adf6ebaab63c773c8f54dafc548bfee91", null ],
    [ "TdClassName", "class_open_t_d_1_1_post_processing_1_1_additional_text_info.xhtml#ab352578bf3691270b61651f567077073", null ]
];