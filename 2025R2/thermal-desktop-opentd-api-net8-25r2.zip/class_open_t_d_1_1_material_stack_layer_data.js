var class_open_t_d_1_1_material_stack_layer_data =
[
    [ "MaterialStackLayerData", "class_open_t_d_1_1_material_stack_layer_data.xhtml#a86a61d8b893e62a3faf12c8bcd5a8df3", null ],
    [ "ToString", "class_open_t_d_1_1_material_stack_layer_data.xhtml#a683d786253ca3cddc6b297bf337707be", null ],
    [ "Material", "class_open_t_d_1_1_material_stack_layer_data.xhtml#a957d1dbb9c386ee90951e1fd2c936c35", null ],
    [ "NumNodes", "class_open_t_d_1_1_material_stack_layer_data.xhtml#acc760f0b4241a5cd68608294ffb227cb", null ],
    [ "Thickness", "class_open_t_d_1_1_material_stack_layer_data.xhtml#a05d48f988ca3fbf0ff3d0b57f1fe2576", null ],
    [ "ThicknessExp", "class_open_t_d_1_1_material_stack_layer_data.xhtml#aedf48d44957e414e1dbc37ffd1cb7003", null ]
];