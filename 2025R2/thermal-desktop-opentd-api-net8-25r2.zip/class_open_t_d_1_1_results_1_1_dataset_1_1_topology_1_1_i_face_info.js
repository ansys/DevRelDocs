var class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info =
[
    [ "ToString", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info.xhtml#a9ca0a32f9fe0fbb7102f804d63af0c5c", null ],
    [ "FromLump", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info.xhtml#a7d5cf38b8c3522bb0f20b9fb4ef9c748", null ],
    [ "IFaceType", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info.xhtml#ac7780bb4fa02f362be8d370bae61bde0", null ],
    [ "ItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info.xhtml#a64b2f2fc8694f654db6940fd73fac7e4", null ],
    [ "SindaName", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info.xhtml#a19e3b5c549147bdf7898b596bced38db", null ],
    [ "ToLump", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info.xhtml#ac3a1bb899181ce402528eb447f030969", null ]
];