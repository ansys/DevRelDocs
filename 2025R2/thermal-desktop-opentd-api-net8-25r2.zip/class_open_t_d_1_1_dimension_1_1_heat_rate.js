var class_open_t_d_1_1_dimension_1_1_heat_rate =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_heat_rate.xhtml#a00fd26063c2e77fb9e9ea84782420213", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_heat_rate.xhtml#a4e8757f87fe436f95c0c575e9bff3f8a", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_heat_rate.xhtml#a0190c2db364091b4f8f2af0d94780995", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_heat_rate.xhtml#a4667d1dace58cb8408055ba6aa3b8dda", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_heat_rate.xhtml#aa225b25dd44ef00a4b4a04adb96c1b10", null ]
];