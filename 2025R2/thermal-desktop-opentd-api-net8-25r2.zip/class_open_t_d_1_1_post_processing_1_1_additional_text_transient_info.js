var class_open_t_d_1_1_post_processing_1_1_additional_text_transient_info =
[
    [ "AdditionalTextTransientInfo", "class_open_t_d_1_1_post_processing_1_1_additional_text_transient_info.xhtml#aea099351cbc4f76dc18d564fc1b3139e", null ],
    [ "_pathname", "class_open_t_d_1_1_post_processing_1_1_additional_text_transient_info.xhtml#a00d93b38fc9b743e486c5a10251e6890", null ],
    [ "Pathname", "class_open_t_d_1_1_post_processing_1_1_additional_text_transient_info.xhtml#adf6ebaab63c773c8f54dafc548bfee91", null ],
    [ "TdClassName", "class_open_t_d_1_1_post_processing_1_1_additional_text_transient_info.xhtml#ab352578bf3691270b61651f567077073", null ]
];