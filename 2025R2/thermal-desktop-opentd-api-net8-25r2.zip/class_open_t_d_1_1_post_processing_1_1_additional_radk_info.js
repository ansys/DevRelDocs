var class_open_t_d_1_1_post_processing_1_1_additional_radk_info =
[
    [ "DisplayTypes", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899", [
      [ "EMIT", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899a0003200b63dc933c27ae3ab0b3bfaffb", null ],
      [ "XIJ_SPACE", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899a403d1aea8094bdd3bbd56977f5f6362e", null ],
      [ "BIJ_SPACE", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899af7bbdbda8ab5059525818b35d67a1c96", null ],
      [ "NUM_RAYS", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899a1ddabb4fa80f1196a732a12f5a432e8a", null ],
      [ "XIJ_NODE", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899ac142bf4227c7f2e7173e54068a43fc0a", null ],
      [ "BIJ_NODE", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899a25dcea7c62059f9428d5a77a49ea2e72", null ],
      [ "BJI_NODE", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899a0488b2868deaae9d0f398bf37a32b29a", null ],
      [ "RADK_AS_HEATRATE", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899ad15915f8398daef33c11ad5c437c5e62", null ],
      [ "RADK_AS_HEAT_FLUX", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899a5886ecc5abf71c56dfb951f7e5c55b77", null ],
      [ "WEIGHTED_ERROR", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899ac9e745d7ff280affc4c951e7e32474fb", null ],
      [ "BIJ_SUM", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899a69bc298029658f20fe78d100a0013cfd", null ],
      [ "BIJ_INACTIVE", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a7d49fff69a5b06031c7a5bad3f8b2899ac065566bbd4e2f9bb31a8db05e984927", null ]
    ] ],
    [ "AdditionalRadkInfo", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#af1aa5dd4377ca1a05723d74e83c134f3", null ],
    [ "_pathname", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a00d93b38fc9b743e486c5a10251e6890", null ],
    [ "DbName", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a8dde312566455a4a595282557afd89e6", null ],
    [ "DisplayType", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#a6155a594da82a50c872197737355ff12", null ],
    [ "NodeName", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#aea9a0d9cdbc2cb08d8504992846a57cc", null ],
    [ "Pathname", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml#adf6ebaab63c773c8f54dafc548bfee91", null ]
];