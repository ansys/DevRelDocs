var namespace_open_t_d_1_1_results_1_1_plot_1_1_internal =
[
    [ "SimplePlotDialog", "class_open_t_d_1_1_results_1_1_plot_1_1_internal_1_1_simple_plot_dialog.xhtml", "class_open_t_d_1_1_results_1_1_plot_1_1_internal_1_1_simple_plot_dialog" ]
];