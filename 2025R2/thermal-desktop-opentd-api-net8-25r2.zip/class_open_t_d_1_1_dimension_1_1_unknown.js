var class_open_t_d_1_1_dimension_1_1_unknown =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_unknown.xhtml#adbee0e38f8bedafbb4985d5936ff52c1", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_unknown.xhtml#aea2f17d1297c3c7402e951e840b9a7f5", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_unknown.xhtml#af8b9904b3de5cdad5a3c2435728d4aef", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_unknown.xhtml#a3abeb0dfb70e0a040a9cc6c35c612a99", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_unknown.xhtml#a32fb267085cc5b5446a2193502a2abf2", null ]
];