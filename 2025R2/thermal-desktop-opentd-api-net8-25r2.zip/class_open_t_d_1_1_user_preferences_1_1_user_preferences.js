var class_open_t_d_1_1_user_preferences_1_1_user_preferences =
[
    [ "UserPreferences", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#a06731d36ce70ff5b0ac6f00fda73167e", null ],
    [ "UserPreferences", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#ab110383bf0d412a4d7beff10ecd7d1d0", null ],
    [ "GetAcceleration", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#acfd33e4eb7be62c395024451ec02bb3f", null ],
    [ "GetDwgUnits", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#ae4db3f758721aeeec64cd1e6983f6ce5", null ],
    [ "Update", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#a66b401e68da7b93b040bd0c51699d3a4", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#a311c96ee0d01f337c9911f2a4e7de049", null ],
    [ "Acceleration", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#ae39f1ff2303e6c3cf1b3944071b24ef2", null ],
    [ "Advanced", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#a8ccaa9259f14c9ae073df977f47e009c", null ],
    [ "Calculations", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#ac850816eb2e7b2949694dc76de7d0dea", null ],
    [ "GraphicsResolution", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#acf140516120e215301a292720ca245d0", null ],
    [ "GraphicsSize", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#ab42847356b52036ea62d8bdfaa79bc92", null ],
    [ "GraphicsText", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#a0d2b162b9c4f78067fa8b30413dd0aae", null ],
    [ "GraphicsVisibility", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#aab0744beb0cf36e20a92adb0efb99ce5", null ],
    [ "NeedsUpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#a012bb0c5f39ee504be222b4292f5ffc3", null ],
    [ "Sinda", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#a0def667f1f8d036616105034fe9dcd3c", null ],
    [ "Units", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml#a1db277af42c9afde8949bf996ca476d0", null ]
];