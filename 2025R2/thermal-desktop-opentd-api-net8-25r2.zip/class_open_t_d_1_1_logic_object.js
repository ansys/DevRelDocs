var class_open_t_d_1_1_logic_object =
[
    [ "LogicType", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9e", [
      [ "TRANSLATECODE", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ea44fb3536c8145c2b6cd0001effefb867", null ],
      [ "ARRAY_INTERP", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9eaa79d4f6b7a9a8e30ee94303d727ccd96", null ],
      [ "BIVAR_INTERP", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ea7b2584706a394a5d853e535bb370c79b", null ],
      [ "PID", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ea2d73559f294204a42bda2e926d094612", null ],
      [ "USERCODE", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ead113e5820e33ff51f925a3f5dbf7aca1", null ],
      [ "DIFFEQ", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ea709ba73fdddc2857de411f6eae348d7b", null ],
      [ "DIFFEQANGULAR", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9eadfc7f799d8d832c23b93b5f934e68d94", null ],
      [ "DIFFEQRPM", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ea1a5e9bbaf44f203db4f4b64a7dd259fa", null ],
      [ "COMPAREDL", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9eacb0bcdd6dce9496cabe901f8fb45dc34", null ],
      [ "USER_ARRAY", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ea719921666c82ae312d9082594eebe4ae", null ],
      [ "SUBCOMPLQ", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9eaa25de14206e2b8316327da0f22c13f01", null ],
      [ "FORTRANARRAY", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ea7d33999b8d21874b0ab1f73ff9f58f49", null ],
      [ "MAXLOGICTYPE", "class_open_t_d_1_1_logic_object.xhtml#a284f97e5fd43816d9037affd5bb18c9ea83f272b71616c425115ee76a4775b04e", null ]
    ] ],
    [ "LogicObject", "class_open_t_d_1_1_logic_object.xhtml#ae55e238ed77d918d20fb2886bb7999b3", null ],
    [ "CreateIn", "class_open_t_d_1_1_logic_object.xhtml#ad3c6f84b8d14bb15435e1cba84af8e88", null ],
    [ "SetFrom", "class_open_t_d_1_1_logic_object.xhtml#aa2e0aa2793e95a56891ef59fb4843ca2", null ],
    [ "ToString", "class_open_t_d_1_1_logic_object.xhtml#a5c340328029b903ad8480a6a7dda1f85", null ],
    [ "Update", "class_open_t_d_1_1_logic_object.xhtml#a1f424c1741c072e95b6846c018a1fb4b", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_logic_object.xhtml#ac93d4821f111c73c7eaf95fc7c27d73b", null ],
    [ "UpdateIn", "class_open_t_d_1_1_logic_object.xhtml#a1e5228ce309c9a85ec09e8119318024d", null ],
    [ "TdProxy", "class_open_t_d_1_1_logic_object.xhtml#a0da16592e6b635ca0def27b355d669b3", null ],
    [ "Comment", "class_open_t_d_1_1_logic_object.xhtml#a5be337c63042b60e8fa1e9467d028dda", null ],
    [ "EnabledExp", "class_open_t_d_1_1_logic_object.xhtml#a892165742428b0fb10d53b52df1c40e6", null ],
    [ "GroupName", "class_open_t_d_1_1_logic_object.xhtml#a6de31d1fc41caa3729fcebc660268283", null ],
    [ "Handle", "class_open_t_d_1_1_logic_object.xhtml#ae9743ddd8cf8500cb8c1edefd96f0ab8", null ],
    [ "Submodel", "class_open_t_d_1_1_logic_object.xhtml#aea12dd68d8f3537ab7c59aa30fe4933a", null ],
    [ "Type", "class_open_t_d_1_1_logic_object.xhtml#a44e8f37e9600deec3f61e570c591fc7d", null ]
];