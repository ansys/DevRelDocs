var namespaces_dup =
[
    [ "Ansys", "namespace_ansys.xhtml", "namespace_ansys" ],
    [ "OpenTD", "namespace_open_t_d.xhtml", "namespace_open_t_d" ]
];