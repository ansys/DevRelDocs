var class_open_t_d_1_1_post_processing_1_1_dataset_manager =
[
    [ "DatasetManager", "class_open_t_d_1_1_post_processing_1_1_dataset_manager.xhtml#ac3918f7bea73d4afe1bae7c55f14f6b9", null ],
    [ "CreateDataset", "class_open_t_d_1_1_post_processing_1_1_dataset_manager.xhtml#a676243e3bd070e9076ce3ef88b69b201", null ],
    [ "DeleteDataset", "class_open_t_d_1_1_post_processing_1_1_dataset_manager.xhtml#a75fc394ef1a9882a1eeabdc6c90d7ce7", null ],
    [ "GetCurrentDataset", "class_open_t_d_1_1_post_processing_1_1_dataset_manager.xhtml#ad9623154b7262b92cc6f5eeeac154b63", null ],
    [ "GetDataset", "class_open_t_d_1_1_post_processing_1_1_dataset_manager.xhtml#a6b065a3a463263f75e2aeda048bcf710", null ],
    [ "GetDatasets", "class_open_t_d_1_1_post_processing_1_1_dataset_manager.xhtml#a10e8afd5838b28af9593de1ed70c53b2", null ]
];