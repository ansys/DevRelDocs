var class_open_t_d_1_1_results_1_1_dataset_1_1_functional_u_d_f_a_reader =
[
    [ "FunctionalUDFAReader", "class_open_t_d_1_1_results_1_1_dataset_1_1_functional_u_d_f_a_reader.xhtml#ab9327185fdfb5abf0aa224e2c99d9d75", null ],
    [ "GetCharUserArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_functional_u_d_f_a_reader.xhtml#a4842d884b4e4dc2f8f5f0dc1cdf47562", null ],
    [ "GetIntegerUserArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_functional_u_d_f_a_reader.xhtml#a6e722a2e377a795b127b86f4c180bc28", null ],
    [ "GetLogicalUserArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_functional_u_d_f_a_reader.xhtml#a25e2447194484d7569a6512ef9cf06b7", null ],
    [ "GetRealUserArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_functional_u_d_f_a_reader.xhtml#acec846f208534de9fb80bec9b4209419", null ],
    [ "GetUserArrayNames", "class_open_t_d_1_1_results_1_1_dataset_1_1_functional_u_d_f_a_reader.xhtml#a27846830f938b9dba612eed41b89d7f1", null ]
];