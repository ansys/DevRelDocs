var class_open_t_d_1_1_dimension_1_1_angle =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_angle.xhtml#ad236d7466f913b509676eb1e1f52a60a", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_angle.xhtml#a9405adb075c46335bc80ecf64ec05bee", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_angle.xhtml#abee247330cae5b11a707a38e5ec2a4ed", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_angle.xhtml#a796c826eb6b8fbaeee69a0643a332df6", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_angle.xhtml#a3d4cdb91724f58a295a92139ccdd0884", null ]
];