var hierarchy =
[
    [ "OpenTD.AddIn.AddInContext", "class_open_t_d_1_1_add_in_1_1_add_in_context.xhtml", null ],
    [ "OpenTD.PostProcessing.AdditionalDatasetInfoHolder", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml", null ],
    [ "OpenTD.Internal.Communication.AdditionalUnitsSettings", "class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings.xhtml", null ],
    [ "OpenTD.RadCAD.FdSolid.AnalysisGroupSolidInfo", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_analysis_group_solid_info.xhtml", null ],
    [ "OpenTD.RadCAD.AnalysisGroupSurfaceInfo", "class_open_t_d_1_1_rad_c_a_d_1_1_analysis_group_surface_info.xhtml", null ],
    [ "OpenTD.RadCAD.AnalysisGroupVolumetricInfo", "class_open_t_d_1_1_rad_c_a_d_1_1_analysis_group_volumetric_info.xhtml", null ],
    [ "OpenTD.AutocadConfig", "class_open_t_d_1_1_autocad_config.xhtml", null ],
    [ "OpenTD.AutocadLauncher", "class_open_t_d_1_1_autocad_launcher.xhtml", null ],
    [ "OpenTD.AutocadVariableData", "class_open_t_d_1_1_autocad_variable_data.xhtml", null ],
    [ "OpenTD.Results.Plot.AxisStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml", null ],
    [ "OpenTD.BivariateArrayData", "class_open_t_d_1_1_bivariate_array_data.xhtml", null ],
    [ "OpenTD.Results.Class1", "class_open_t_d_1_1_results_1_1_class1.xhtml", null ],
    [ "grpc.ClientBase", null, [
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.ThermalDesktop.ThermalDesktopClient", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_thermal_desktop_1_1_thermal_desktop_client.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.ThermalDesktop.ThermalDesktopClient", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_thermal_desktop_1_1_thermal_desktop_client.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.ThermalDesktop.ThermalDesktopClient", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_thermal_desktop_1_1_thermal_desktop_client.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.ThermalDesktop.ThermalDesktopClient", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_thermal_desktop_1_1_thermal_desktop_client.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.CompareAssertion", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml", null ],
    [ "OpenTD.Results.Dataset.ConductorHeat", "class_open_t_d_1_1_results_1_1_dataset_1_1_conductor_heat.xhtml", null ],
    [ "OpenTD.Connection", "class_open_t_d_1_1_connection.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.CoordinateSystem", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_coordinate_system.xhtml", null ],
    [ "OpenTD.Results.Dataset.DataItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml", null ],
    [ "OpenTD.DimensionlessVector3d", "class_open_t_d_1_1_dimensionless_vector3d.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.Domain", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_domain.xhtml", null ],
    [ "OpenTD.Domains", "class_open_t_d_1_1_domains.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.EdgeDomain", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_edge_domain.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.EdgeSpec", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_edge_spec.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.Element", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_element.xhtml", [
      [ "OpenTD.RadCAD.FEModel.SolidElement", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_solid_element.xhtml", null ],
      [ "OpenTD.RadCAD.FEModel.SurfaceElement", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_surface_element.xhtml", null ]
    ] ],
    [ "OpenTD.EntityDescriptor", "struct_open_t_d_1_1_entity_descriptor.xhtml", null ],
    [ "EventArgs", null, [
      [ "OpenTD.AddIn.ProgressEventArgs", "class_open_t_d_1_1_add_in_1_1_progress_event_args.xhtml", null ],
      [ "OpenTD.UserInterface.WriteEventArgs", "class_open_t_d_1_1_user_interface_1_1_write_event_args.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.Exceedance", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml", null ],
    [ "OpenTD.Results.Dataset.ExceedancePlot", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance_plot.xhtml", null ],
    [ "Exception", null, [
      [ "OpenTD.OpenTDException", "class_open_t_d_1_1_open_t_d_exception.xhtml", [
        [ "OpenTD.BadDataException", "class_open_t_d_1_1_bad_data_exception.xhtml", null ]
      ] ]
    ] ],
    [ "OpenTD.ExportNodeInfoOptionsData", "class_open_t_d_1_1_export_node_info_options_data.xhtml", null ],
    [ "OpenTD.Expressible< T >", "struct_open_t_d_1_1_expressible-1-g.xhtml", null ],
    [ "OpenTD.RadCAD.Face", "class_open_t_d_1_1_rad_c_a_d_1_1_face.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.FaceDomain", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_face_domain.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.FaceSpec", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_face_spec.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.FEMesh", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_f_e_mesh.xhtml", null ],
    [ "OpenTD.Utility.FileWatcher", "class_open_t_d_1_1_utility_1_1_file_watcher.xhtml", null ],
    [ "Form", null, [
      [ "OpenTD.Results.Plot.Internal.SimplePlotDialog", "class_open_t_d_1_1_results_1_1_plot_1_1_internal_1_1_simple_plot_dialog.xhtml", null ],
      [ "OpenTD.UserInterface.Forms.OutputDialog", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_dialog.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.FullStandardDataSubtype", "struct_open_t_d_1_1_results_1_1_dataset_1_1_full_standard_data_subtype.xhtml", null ],
    [ "OpenTD.Results.Plot.Grid", "class_open_t_d_1_1_results_1_1_plot_1_1_grid.xhtml", null ],
    [ "OpenTD.Results.Dataset.HeatratesBetween", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml", null ],
    [ "OpenTD.AddIn.IAddIn", "interface_open_t_d_1_1_add_in_1_1_i_add_in.xhtml", null ],
    [ "OpenTD.Results.Dataset.IAutoComment", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_auto_comment.xhtml", [
      [ "OpenTD.Results.Dataset.AutoCommenter", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_commenter.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array.xhtml", [
        [ "OpenTD.Results.Dataset.DerivedDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_derived_data_array.xhtml", [
          [ "OpenTD.Results.Dataset.FormulaDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_formula_data_array.xhtml", null ],
          [ "OpenTD.Results.Dataset.OneSubtypeDerivedDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_one_subtype_derived_data_array.xhtml", [
            [ "OpenTD.Results.Dataset.AverageDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_average_data_array.xhtml", null ],
            [ "OpenTD.Results.Dataset.MaxDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_max_data_array.xhtml", null ],
            [ "OpenTD.Results.Dataset.MinDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_min_data_array.xhtml", null ],
            [ "OpenTD.Results.Dataset.SumDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_sum_data_array.xhtml", null ],
            [ "OpenTD.Results.Dataset.WeightedAverageDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_weighted_average_data_array.xhtml", null ]
          ] ],
          [ "OpenTD.Results.Dataset.SelectOneDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_select_one_data_array.xhtml", [
            [ "OpenTD.Results.Dataset.SelectMaxDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_select_max_data_array.xhtml", null ],
            [ "OpenTD.Results.Dataset.SelectMinDataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_select_min_data_array.xhtml", null ]
          ] ]
        ] ]
      ] ],
      [ "OpenTD.Results.Dataset.DataArrayCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_collection.xhtml", null ],
      [ "OpenTD.Results.Dataset.Dataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_dataset.xhtml", [
        [ "OpenTD.Results.Dataset.RecordFocusedDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_record_focused_dataset.xhtml", [
          [ "OpenTD.Results.Dataset.CSR", "class_open_t_d_1_1_results_1_1_dataset_1_1_c_s_r.xhtml", null ],
          [ "OpenTD.Results.Dataset.DerivedDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_derived_dataset.xhtml", [
            [ "OpenTD.Results.Dataset.ConcatenatedDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_concatenated_dataset.xhtml", null ],
            [ "OpenTD.Results.Dataset.DatasetSlice", "class_open_t_d_1_1_results_1_1_dataset_1_1_dataset_slice.xhtml", null ]
          ] ],
          [ "OpenTD.Results.Dataset.SaveFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_save_file.xhtml", null ],
          [ "OpenTD.Results.Dataset.SaveXFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_save_x_file.xhtml", null ]
        ] ],
        [ "OpenTD.Results.Dataset.SimpleDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_simple_dataset.xhtml", [
          [ "OpenTD.Results.Dataset.SpreadsheetDataFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_spreadsheet_data_file.xhtml", null ],
          [ "OpenTD.Results.Dataset.TextTransientFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_text_transient_file.xhtml", null ]
        ] ]
      ] ],
      [ "OpenTD.Results.Dataset.ItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml", null ],
      [ "OpenTD.Results.Dataset.ItemIdentifierCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier_collection.xhtml", null ],
      [ "OpenTD.Results.Plot.Axis", "class_open_t_d_1_1_results_1_1_plot_1_1_axis.xhtml", null ],
      [ "OpenTD.Results.Plot.Plot2d", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d.xhtml", [
        [ "OpenTD.Results.Plot.SimplePlot", "class_open_t_d_1_1_results_1_1_plot_1_1_simple_plot.xhtml", null ]
      ] ],
      [ "OpenTD.Results.Plot.Series2d", "class_open_t_d_1_1_results_1_1_plot_1_1_series2d.xhtml", null ],
      [ "OpenTD.Results.Plot.Series2dCollection", "class_open_t_d_1_1_results_1_1_plot_1_1_series2d_collection.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.IAutoName", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_auto_name.xhtml", [
      [ "OpenTD.Results.Dataset.AutoNamer", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_namer.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataArrayCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_collection.xhtml", null ],
      [ "OpenTD.Results.Dataset.Dataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_dataset.xhtml", null ],
      [ "OpenTD.Results.Dataset.IDataset", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_dataset.xhtml", [
        [ "OpenTD.Results.Dataset.CSR", "class_open_t_d_1_1_results_1_1_dataset_1_1_c_s_r.xhtml", null ],
        [ "OpenTD.Results.Dataset.ConcatenatedDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_concatenated_dataset.xhtml", null ],
        [ "OpenTD.Results.Dataset.Dataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_dataset.xhtml", null ],
        [ "OpenTD.Results.Dataset.DatasetSlice", "class_open_t_d_1_1_results_1_1_dataset_1_1_dataset_slice.xhtml", null ],
        [ "OpenTD.Results.Dataset.DerivedDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_derived_dataset.xhtml", null ],
        [ "OpenTD.Results.Dataset.RecordFocusedDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_record_focused_dataset.xhtml", null ],
        [ "OpenTD.Results.Dataset.SaveFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_save_file.xhtml", null ],
        [ "OpenTD.Results.Dataset.SaveXFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_save_x_file.xhtml", null ],
        [ "OpenTD.Results.Dataset.SimpleDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_simple_dataset.xhtml", null ],
        [ "OpenTD.Results.Dataset.SpreadsheetDataFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_spreadsheet_data_file.xhtml", null ],
        [ "OpenTD.Results.Dataset.TextTransientFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_text_transient_file.xhtml", null ]
      ] ],
      [ "OpenTD.Results.Dataset.ItemIdentifierCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier_collection.xhtml", null ],
      [ "OpenTD.Results.Plot.Axis", "class_open_t_d_1_1_results_1_1_plot_1_1_axis.xhtml", null ],
      [ "OpenTD.Results.Plot.Plot2d", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d.xhtml", null ],
      [ "OpenTD.Results.Plot.Series2d", "class_open_t_d_1_1_results_1_1_plot_1_1_series2d.xhtml", null ],
      [ "OpenTD.Results.Plot.Series2dCollection", "class_open_t_d_1_1_results_1_1_plot_1_1_series2d_collection.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.IBrowser", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_browser.xhtml", null ],
    [ "pb.IBufferMessage", null, [
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", null ]
    ] ],
    [ "ICollection", null, [
      [ "OpenTD.Results.Dataset.DataArrayCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_collection.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataItemIdentifierCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier_collection.xhtml", null ],
      [ "OpenTD.Results.Dataset.ItemIdentifierCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier_collection.xhtml", null ],
      [ "OpenTD.Results.Plot.Series2dCollection", "class_open_t_d_1_1_results_1_1_plot_1_1_series2d_collection.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.ICompareData", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_compare_data.xhtml", [
      [ "OpenTD.Results.Dataset.CompareData", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_data.xhtml", [
        [ "OpenTD.Results.Dataset.PercentDifferenceCompareData", "class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data.xhtml", null ]
      ] ],
      [ "OpenTD.Results.Dataset.PercentDifferenceCompareData", "class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.IComparerInput", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input.xhtml", [
      [ "OpenTD.Results.Dataset.Comparer", "class_open_t_d_1_1_results_1_1_dataset_1_1_comparer.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.IComparerOutput", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_output.xhtml", [
      [ "OpenTD.Results.Dataset.Comparer", "class_open_t_d_1_1_results_1_1_dataset_1_1_comparer.xhtml", null ]
    ] ],
    [ "ICRLogger", null, [
      [ "OpenTD.Logging.Logger", "class_open_t_d_1_1_logging_1_1_logger.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.Topology.IDatasetTopology", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml", null ],
    [ "OpenTD.IDbIterator", "interface_open_t_d_1_1_i_db_iterator.xhtml", [
      [ "OpenTD.XRefDBIterator", "class_open_t_d_1_1_x_ref_d_b_iterator.xhtml", null ]
    ] ],
    [ "OpenTD.RadCAD.FEModel.IdDomain", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_id_domain.xhtml", null ],
    [ "OpenTD.Dimension.IDimension", "interface_open_t_d_1_1_dimension_1_1_i_dimension.xhtml", [
      [ "OpenTD.Dimension.Angle", "class_open_t_d_1_1_dimension_1_1_angle.xhtml", null ],
      [ "OpenTD.Dimension.Area", "class_open_t_d_1_1_dimension_1_1_area.xhtml", null ],
      [ "OpenTD.Dimension.CondPerArea", "class_open_t_d_1_1_dimension_1_1_cond_per_area.xhtml", null ],
      [ "OpenTD.Dimension.CondPerLength", "class_open_t_d_1_1_dimension_1_1_cond_per_length.xhtml", null ],
      [ "OpenTD.Dimension.Conductance", "class_open_t_d_1_1_dimension_1_1_conductance.xhtml", null ],
      [ "OpenTD.Dimension.Current", "class_open_t_d_1_1_dimension_1_1_current.xhtml", null ],
      [ "OpenTD.Dimension.Density", "class_open_t_d_1_1_dimension_1_1_density.xhtml", null ],
      [ "OpenTD.Dimension.Dimensionless", "class_open_t_d_1_1_dimension_1_1_dimensionless.xhtml", null ],
      [ "OpenTD.Dimension.DynamicViscosity", "class_open_t_d_1_1_dimension_1_1_dynamic_viscosity.xhtml", null ],
      [ "OpenTD.Dimension.Energy", "class_open_t_d_1_1_dimension_1_1_energy.xhtml", null ],
      [ "OpenTD.Dimension.EnergyPerArea", "class_open_t_d_1_1_dimension_1_1_energy_per_area.xhtml", null ],
      [ "OpenTD.Dimension.EnergyPerLength", "class_open_t_d_1_1_dimension_1_1_energy_per_length.xhtml", null ],
      [ "OpenTD.Dimension.EnergyPerMass", "class_open_t_d_1_1_dimension_1_1_energy_per_mass.xhtml", null ],
      [ "OpenTD.Dimension.Enthalpy", "class_open_t_d_1_1_dimension_1_1_enthalpy.xhtml", null ],
      [ "OpenTD.Dimension.Entropy", "class_open_t_d_1_1_dimension_1_1_entropy.xhtml", null ],
      [ "OpenTD.Dimension.Flux", "class_open_t_d_1_1_dimension_1_1_flux.xhtml", null ],
      [ "OpenTD.Dimension.Force", "class_open_t_d_1_1_dimension_1_1_force.xhtml", null ],
      [ "OpenTD.Dimension.Gravity", "class_open_t_d_1_1_dimension_1_1_gravity.xhtml", null ],
      [ "OpenTD.Dimension.HeatRate", "class_open_t_d_1_1_dimension_1_1_heat_rate.xhtml", null ],
      [ "OpenTD.Dimension.HeatRatePerVolume", "class_open_t_d_1_1_dimension_1_1_heat_rate_per_volume.xhtml", null ],
      [ "OpenTD.Dimension.Inertial", "class_open_t_d_1_1_dimension_1_1_inertial.xhtml", null ],
      [ "OpenTD.Dimension.InversePressure", "class_open_t_d_1_1_dimension_1_1_inverse_pressure.xhtml", null ],
      [ "OpenTD.Dimension.InverseVolume", "class_open_t_d_1_1_dimension_1_1_inverse_volume.xhtml", null ],
      [ "OpenTD.Dimension.Mass", "class_open_t_d_1_1_dimension_1_1_mass.xhtml", null ],
      [ "OpenTD.Dimension.MassFlowRate", "class_open_t_d_1_1_dimension_1_1_mass_flow_rate.xhtml", null ],
      [ "OpenTD.Dimension.MassFlowratePerEnthalpy", "class_open_t_d_1_1_dimension_1_1_mass_flowrate_per_enthalpy.xhtml", null ],
      [ "OpenTD.Dimension.MassFlowratePerPressure", "class_open_t_d_1_1_dimension_1_1_mass_flowrate_per_pressure.xhtml", null ],
      [ "OpenTD.Dimension.MassFlux", "class_open_t_d_1_1_dimension_1_1_mass_flux.xhtml", null ],
      [ "OpenTD.Dimension.MassPerLength", "class_open_t_d_1_1_dimension_1_1_mass_per_length.xhtml", null ],
      [ "OpenTD.Dimension.ModelLength", "class_open_t_d_1_1_dimension_1_1_model_length.xhtml", null ],
      [ "OpenTD.Dimension.MomentOfInertia", "class_open_t_d_1_1_dimension_1_1_moment_of_inertia.xhtml", null ],
      [ "OpenTD.Dimension.OrbitLength", "class_open_t_d_1_1_dimension_1_1_orbit_length.xhtml", null ],
      [ "OpenTD.Dimension.OrbitVelocity", "class_open_t_d_1_1_dimension_1_1_orbit_velocity.xhtml", null ],
      [ "OpenTD.Dimension.Pressure", "class_open_t_d_1_1_dimension_1_1_pressure.xhtml", null ],
      [ "OpenTD.Dimension.PressurePerVolume", "class_open_t_d_1_1_dimension_1_1_pressure_per_volume.xhtml", null ],
      [ "OpenTD.Dimension.Resistivity", "class_open_t_d_1_1_dimension_1_1_resistivity.xhtml", null ],
      [ "OpenTD.Dimension.Rotation", "class_open_t_d_1_1_dimension_1_1_rotation.xhtml", null ],
      [ "OpenTD.Dimension.SpecificHeat", "class_open_t_d_1_1_dimension_1_1_specific_heat.xhtml", null ],
      [ "OpenTD.Dimension.StefanBoltzmann", "class_open_t_d_1_1_dimension_1_1_stefan_boltzmann.xhtml", null ],
      [ "OpenTD.Dimension.SurfaceTension", "class_open_t_d_1_1_dimension_1_1_surface_tension.xhtml", null ],
      [ "OpenTD.Dimension.Temp", "class_open_t_d_1_1_dimension_1_1_temp.xhtml", null ],
      [ "OpenTD.Dimension.TempAbs", "class_open_t_d_1_1_dimension_1_1_temp_abs.xhtml", null ],
      [ "OpenTD.Dimension.ThermalMass", "class_open_t_d_1_1_dimension_1_1_thermal_mass.xhtml", null ],
      [ "OpenTD.Dimension.Time", "class_open_t_d_1_1_dimension_1_1_time.xhtml", null ],
      [ "OpenTD.Dimension.Torque", "class_open_t_d_1_1_dimension_1_1_torque.xhtml", null ],
      [ "OpenTD.Dimension.Unknown", "class_open_t_d_1_1_dimension_1_1_unknown.xhtml", null ],
      [ "OpenTD.Dimension.Velocity", "class_open_t_d_1_1_dimension_1_1_velocity.xhtml", null ],
      [ "OpenTD.Dimension.Voltage", "class_open_t_d_1_1_dimension_1_1_voltage.xhtml", null ],
      [ "OpenTD.Dimension.VoltsPerTemp", "class_open_t_d_1_1_dimension_1_1_volts_per_temp.xhtml", null ],
      [ "OpenTD.Dimension.Volume", "class_open_t_d_1_1_dimension_1_1_volume.xhtml", null ],
      [ "OpenTD.Dimension.VolumeFlowRate", "class_open_t_d_1_1_dimension_1_1_volume_flow_rate.xhtml", null ]
    ] ],
    [ "IDisposable", null, [
      [ "OpenTD.Results.Dataset.SaveXFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_save_x_file.xhtml", null ]
    ] ],
    [ "OpenTD.IDomainManager", "interface_open_t_d_1_1_i_domain_manager.xhtml", null ],
    [ "IEnumerable", null, [
      [ "OpenTD.Results.Dataset.CompareSuite", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataArray", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataArrayCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_collection.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataItemIdentifierCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier_collection.xhtml", null ],
      [ "OpenTD.Results.Dataset.ItemIdentifierCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier_collection.xhtml", null ],
      [ "OpenTD.Results.Plot.Series2dCollection", "class_open_t_d_1_1_results_1_1_plot_1_1_series2d_collection.xhtml", null ]
    ] ],
    [ "IEnumerator", null, [
      [ "OpenTD.Results.Dataset.DataArrayEnumerator", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_enumerator.xhtml", null ]
    ] ],
    [ "IEquatable", null, [
      [ "OpenTD.Results.Dataset.DataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml", null ],
      [ "OpenTD.Results.Dataset.Topology.SindaName", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml", null ],
      [ "OpenTD.UnitsData", "class_open_t_d_1_1_units_data.xhtml", null ],
      [ "OpenTD.UnitsDefData", "class_open_t_d_1_1_units_def_data.xhtml", null ]
    ] ],
    [ "OpenTD.Dimension.IGetSetSI", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i.xhtml", [
      [ "OpenTD.Dimension.Dimensional< T >", "struct_open_t_d_1_1_dimension_1_1_dimensional-1-g.xhtml", null ],
      [ "OpenTD.Dimension.DimensionalIfPositive< T >", "struct_open_t_d_1_1_dimension_1_1_dimensional_if_positive-1-g.xhtml", null ]
    ] ],
    [ "OpenTD.Dimension.IGetSetSIList", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i_list.xhtml", [
      [ "OpenTD.Dimension.DimensionalIfPositiveList< T >", "class_open_t_d_1_1_dimension_1_1_dimensional_if_positive_list-1-g.xhtml", null ],
      [ "OpenTD.Dimension.DimensionalList< T >", "class_open_t_d_1_1_dimension_1_1_dimensional_list-1-g.xhtml", null ]
    ] ],
    [ "OpenTD.Dimension.IGetSetSIList2", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i_list2.xhtml", [
      [ "OpenTD.Dimension.DimensionalList2< T >", "class_open_t_d_1_1_dimension_1_1_dimensional_list2-1-g.xhtml", null ]
    ] ],
    [ "IList", null, [
      [ "OpenTD.Results.Dataset.CompareSuite", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataArrayCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_collection.xhtml", null ],
      [ "OpenTD.Results.Dataset.DataItemIdentifierCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier_collection.xhtml", null ],
      [ "OpenTD.Results.Dataset.ItemIdentifierCollection", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier_collection.xhtml", null ],
      [ "OpenTD.Results.Plot.Series2dCollection", "class_open_t_d_1_1_results_1_1_plot_1_1_series2d_collection.xhtml", null ],
      [ "OpenTD.Utility.UniqueItemList< T >", "class_open_t_d_1_1_utility_1_1_unique_item_list-1-g.xhtml", null ]
    ] ],
    [ "pb.IMessage", null, [
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloReply", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_reply.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", null ],
      [ "Ansys.Api.ThermalDesktop.V0.ThermalDesktop.HelloRequest", "class_ansys_1_1_api_1_1_thermal_desktop_1_1_v0_1_1_thermal_desktop_1_1_hello_request.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.Topology.IObjectInfoBase", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_object_info_base.xhtml", [
      [ "OpenTD.Results.Dataset.Topology.IConductorInfo", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_conductor_info.xhtml", null ],
      [ "OpenTD.Results.Dataset.Topology.IFTieInfo", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_f_tie_info.xhtml", null ],
      [ "OpenTD.Results.Dataset.Topology.IIFaceInfo", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_i_face_info.xhtml", [
        [ "OpenTD.Results.Dataset.Topology.IFaceInfo", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info.xhtml", null ]
      ] ],
      [ "OpenTD.Results.Dataset.Topology.ILumpInfo", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_lump_info.xhtml", null ],
      [ "OpenTD.Results.Dataset.Topology.INodeInfo", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_node_info.xhtml", null ],
      [ "OpenTD.Results.Dataset.Topology.IPathInfo", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_path_info.xhtml", [
        [ "OpenTD.Results.Dataset.Topology.PathInfo", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_path_info.xhtml", null ]
      ] ],
      [ "OpenTD.Results.Dataset.Topology.ITieInfo", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_tie_info.xhtml", null ],
      [ "OpenTD.Results.Dataset.Topology.ObjectInfoBase", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_object_info_base.xhtml", [
        [ "OpenTD.Results.Dataset.Topology.IFaceInfo", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_face_info.xhtml", null ],
        [ "OpenTD.Results.Dataset.Topology.PathInfo", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_path_info.xhtml", null ]
      ] ]
    ] ],
    [ "OpenTD.AddIn.IProgressReporter", "interface_open_t_d_1_1_add_in_1_1_i_progress_reporter.xhtml", [
      [ "OpenTD.AddIn.ProgressToken", "class_open_t_d_1_1_add_in_1_1_progress_token.xhtml", null ]
    ] ],
    [ "OpenTD.IReassignable", "interface_open_t_d_1_1_i_reassignable.xhtml", [
      [ "OpenTD.OpenTDObject", "class_open_t_d_1_1_open_t_d_object.xhtml", [
        [ "OpenTD.CaseSetData", "class_open_t_d_1_1_case_set_data.xhtml", [
          [ "OpenTD.CaseSet", "class_open_t_d_1_1_case_set.xhtml", null ]
        ] ],
        [ "OpenTD.DbObject", "class_open_t_d_1_1_db_object.xhtml", [
          [ "OpenTD.RadCAD.Orbit", "class_open_t_d_1_1_rad_c_a_d_1_1_orbit.xhtml", null ],
          [ "OpenTD.TdDbEntityData", "class_open_t_d_1_1_td_db_entity_data.xhtml", [
            [ "OpenTD.AcEllipse", "class_open_t_d_1_1_ac_ellipse.xhtml", null ],
            [ "OpenTD.Arc", "class_open_t_d_1_1_arc.xhtml", null ],
            [ "OpenTD.Circle", "class_open_t_d_1_1_circle.xhtml", null ],
            [ "OpenTD.FloCAD.Compartment", "class_open_t_d_1_1_flo_c_a_d_1_1_compartment.xhtml", null ],
            [ "OpenTD.FloCAD.RcCappmpData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_cappmp_data.xhtml", [
              [ "OpenTD.FloCAD.Cappmp", "class_open_t_d_1_1_flo_c_a_d_1_1_cappmp.xhtml", null ]
            ] ],
            [ "OpenTD.FloCAD.RcFTieData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_f_tie_data.xhtml", [
              [ "OpenTD.FloCAD.FTie", "class_open_t_d_1_1_flo_c_a_d_1_1_f_tie.xhtml", null ]
            ] ],
            [ "OpenTD.FloCAD.RcIFaceData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_i_face_data.xhtml", [
              [ "OpenTD.FloCAD.IFace", "class_open_t_d_1_1_flo_c_a_d_1_1_i_face.xhtml", null ]
            ] ],
            [ "OpenTD.FloCAD.RcLumpData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_lump_data.xhtml", [
              [ "OpenTD.FloCAD.Lump", "class_open_t_d_1_1_flo_c_a_d_1_1_lump.xhtml", null ]
            ] ],
            [ "OpenTD.FloCAD.RcPathData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_path_data.xhtml", [
              [ "OpenTD.FloCAD.Path", "class_open_t_d_1_1_flo_c_a_d_1_1_path.xhtml", null ]
            ] ],
            [ "OpenTD.FloCAD.RcPortData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_port_data.xhtml", [
              [ "OpenTD.FloCAD.Port", "class_open_t_d_1_1_flo_c_a_d_1_1_port.xhtml", [
                [ "OpenTD.FloCAD.FkLocator", "class_open_t_d_1_1_flo_c_a_d_1_1_fk_locator.xhtml", null ],
                [ "OpenTD.FloCAD.Tee", "class_open_t_d_1_1_flo_c_a_d_1_1_tee.xhtml", null ]
              ] ]
            ] ],
            [ "OpenTD.FloCAD.RcTieData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_tie_data.xhtml", [
              [ "OpenTD.FloCAD.Tie", "class_open_t_d_1_1_flo_c_a_d_1_1_tie.xhtml", null ]
            ] ],
            [ "OpenTD.Helix", "class_open_t_d_1_1_helix.xhtml", null ],
            [ "OpenTD.LineData", "class_open_t_d_1_1_line_data.xhtml", [
              [ "OpenTD.Line", "class_open_t_d_1_1_line.xhtml", null ]
            ] ],
            [ "OpenTD.Measure", "class_open_t_d_1_1_measure.xhtml", null ],
            [ "OpenTD.MeshDisplayer", "class_open_t_d_1_1_mesh_displayer.xhtml", [
              [ "OpenTD.PostProcessing.DataMapper", "class_open_t_d_1_1_post_processing_1_1_data_mapper.xhtml", null ],
              [ "OpenTD.RadCAD.FEMeshImporter", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_mesh_importer.xhtml", null ]
            ] ],
            [ "OpenTD.Polyline", "class_open_t_d_1_1_polyline.xhtml", null ],
            [ "OpenTD.Polyline3d", "class_open_t_d_1_1_polyline3d.xhtml", null ],
            [ "OpenTD.PressureLoad", "class_open_t_d_1_1_pressure_load.xhtml", null ],
            [ "OpenTD.RadCAD.FEM.RcSolidElement", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_rc_solid_element.xhtml", [
              [ "OpenTD.RadCAD.FEM.LinearBrick", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_brick.xhtml", null ],
              [ "OpenTD.RadCAD.FEM.LinearPyramid", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_pyramid.xhtml", null ],
              [ "OpenTD.RadCAD.FEM.LinearTet", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_tet.xhtml", null ],
              [ "OpenTD.RadCAD.FEM.LinearWedge", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_wedge.xhtml", null ],
              [ "OpenTD.RadCAD.FEM.QuadraticBrick", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_brick.xhtml", null ],
              [ "OpenTD.RadCAD.FEM.QuadraticPyramid", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_pyramid.xhtml", null ],
              [ "OpenTD.RadCAD.FEM.QuadraticTet", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_tet.xhtml", null ],
              [ "OpenTD.RadCAD.FEM.QuadraticWedge", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_wedge.xhtml", null ]
            ] ],
            [ "OpenTD.RadCAD.FdSolid.RcFdSolidData", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_rc_fd_solid_data.xhtml", [
              [ "OpenTD.RadCAD.FdSolid.SolidBrick", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_brick.xhtml", null ],
              [ "OpenTD.RadCAD.FdSolid.SolidCone", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_cone.xhtml", null ],
              [ "OpenTD.RadCAD.FdSolid.SolidCylinder", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_cylinder.xhtml", null ],
              [ "OpenTD.RadCAD.FdSolid.SolidEllipsoid", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_ellipsoid.xhtml", null ],
              [ "OpenTD.RadCAD.FdSolid.SolidSphere", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_sphere.xhtml", null ]
            ] ],
            [ "OpenTD.RadCAD.RcArticulatorData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_articulator_data.xhtml", [
              [ "OpenTD.RadCAD.Assembly", "class_open_t_d_1_1_rad_c_a_d_1_1_assembly.xhtml", null ],
              [ "OpenTD.RadCAD.RcTrackerData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_tracker_data.xhtml", [
                [ "OpenTD.RadCAD.Tracker", "class_open_t_d_1_1_rad_c_a_d_1_1_tracker.xhtml", null ]
              ] ]
            ] ],
            [ "OpenTD.RadCAD.RcEntityData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_entity_data.xhtml", [
              [ "OpenTD.FloCAD.RcPipeData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_pipe_data.xhtml", [
                [ "OpenTD.FloCAD.Pipe", "class_open_t_d_1_1_flo_c_a_d_1_1_pipe.xhtml", null ]
              ] ],
              [ "OpenTD.RadCAD.FEM.RcSurfaceElement", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_rc_surface_element.xhtml", [
                [ "OpenTD.RadCAD.FEM.LinearQuad", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_quad.xhtml", null ],
                [ "OpenTD.RadCAD.FEM.LinearTri", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_tri.xhtml", null ],
                [ "OpenTD.RadCAD.FEM.QuadraticQuad", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_quad.xhtml", null ],
                [ "OpenTD.RadCAD.FEM.QuadraticTri", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_tri.xhtml", null ]
              ] ],
              [ "OpenTD.RadCAD.Polygon", "class_open_t_d_1_1_rad_c_a_d_1_1_polygon.xhtml", null ],
              [ "OpenTD.RadCAD.RcConicData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_conic_data.xhtml", [
                [ "OpenTD.RadCAD.EllipticCylinder", "class_open_t_d_1_1_rad_c_a_d_1_1_elliptic_cylinder.xhtml", null ],
                [ "OpenTD.RadCAD.RcConeData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_cone_data.xhtml", [
                  [ "OpenTD.RadCAD.Cone", "class_open_t_d_1_1_rad_c_a_d_1_1_cone.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcCylinderData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_cylinder_data.xhtml", [
                  [ "OpenTD.RadCAD.Cylinder", "class_open_t_d_1_1_rad_c_a_d_1_1_cylinder.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcDiskData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_disk_data.xhtml", [
                  [ "OpenTD.RadCAD.Disk", "class_open_t_d_1_1_rad_c_a_d_1_1_disk.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcEllipseData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_ellipse_data.xhtml", [
                  [ "OpenTD.RadCAD.Ellipse", "class_open_t_d_1_1_rad_c_a_d_1_1_ellipse.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcEllipsoidData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_ellipsoid_data.xhtml", [
                  [ "OpenTD.RadCAD.Ellipsoid", "class_open_t_d_1_1_rad_c_a_d_1_1_ellipsoid.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcEllipticConeData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_elliptic_cone_data.xhtml", [
                  [ "OpenTD.RadCAD.EllipticCone", "class_open_t_d_1_1_rad_c_a_d_1_1_elliptic_cone.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcOffsetParaboloidData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_offset_paraboloid_data.xhtml", [
                  [ "OpenTD.RadCAD.OffsetParaboloid", "class_open_t_d_1_1_rad_c_a_d_1_1_offset_paraboloid.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcOgiveData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_ogive_data.xhtml", [
                  [ "OpenTD.RadCAD.Ogive", "class_open_t_d_1_1_rad_c_a_d_1_1_ogive.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcParabolicTroughData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_parabolic_trough_data.xhtml", [
                  [ "OpenTD.RadCAD.ParabolicTrough", "class_open_t_d_1_1_rad_c_a_d_1_1_parabolic_trough.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcParaboloidData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_paraboloid_data.xhtml", [
                  [ "OpenTD.RadCAD.Paraboloid", "class_open_t_d_1_1_rad_c_a_d_1_1_paraboloid.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcRectangleData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_rectangle_data.xhtml", [
                  [ "OpenTD.RadCAD.Rectangle", "class_open_t_d_1_1_rad_c_a_d_1_1_rectangle.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcScarfedConeData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_scarfed_cone_data.xhtml", [
                  [ "OpenTD.RadCAD.ScarfedCone", "class_open_t_d_1_1_rad_c_a_d_1_1_scarfed_cone.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcScarfedCylinderData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_scarfed_cylinder_data.xhtml", [
                  [ "OpenTD.RadCAD.ScarfedCylinder", "class_open_t_d_1_1_rad_c_a_d_1_1_scarfed_cylinder.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcSphereData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_sphere_data.xhtml", [
                  [ "OpenTD.RadCAD.Sphere", "class_open_t_d_1_1_rad_c_a_d_1_1_sphere.xhtml", null ]
                ] ],
                [ "OpenTD.RadCAD.RcTorusData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_torus_data.xhtml", [
                  [ "OpenTD.RadCAD.Torus", "class_open_t_d_1_1_rad_c_a_d_1_1_torus.xhtml", null ]
                ] ]
              ] ],
              [ "OpenTD.RadCAD.RcMeshFDData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_mesh_f_d_data.xhtml", [
                [ "OpenTD.RadCAD.MeshFD", "class_open_t_d_1_1_rad_c_a_d_1_1_mesh_f_d.xhtml", null ]
              ] ]
            ] ],
            [ "OpenTD.RcConductorData", "class_open_t_d_1_1_rc_conductor_data.xhtml", [
              [ "OpenTD.Conductor", "class_open_t_d_1_1_conductor.xhtml", null ]
            ] ],
            [ "OpenTD.RcConnData", "class_open_t_d_1_1_rc_conn_data.xhtml", [
              [ "OpenTD.Contactor", "class_open_t_d_1_1_contactor.xhtml", null ],
              [ "OpenTD.RcTecData", "class_open_t_d_1_1_rc_tec_data.xhtml", [
                [ "OpenTD.Tec", "class_open_t_d_1_1_tec.xhtml", null ]
              ] ]
            ] ],
            [ "OpenTD.RcHeatLoadData", "class_open_t_d_1_1_rc_heat_load_data.xhtml", [
              [ "OpenTD.HeatLoad", "class_open_t_d_1_1_heat_load.xhtml", null ]
            ] ],
            [ "OpenTD.RcHeaterData", "class_open_t_d_1_1_rc_heater_data.xhtml", [
              [ "OpenTD.Heater", "class_open_t_d_1_1_heater.xhtml", null ]
            ] ],
            [ "OpenTD.RcNodeData", "class_open_t_d_1_1_rc_node_data.xhtml", [
              [ "OpenTD.Node", "class_open_t_d_1_1_node.xhtml", null ]
            ] ],
            [ "OpenTD.Spline", "class_open_t_d_1_1_spline.xhtml", null ],
            [ "OpenTD.TdTextData", "class_open_t_d_1_1_td_text_data.xhtml", [
              [ "OpenTD.Text", "class_open_t_d_1_1_text.xhtml", null ]
            ] ]
          ] ]
        ] ],
        [ "OpenTD.LayerData", "class_open_t_d_1_1_layer_data.xhtml", [
          [ "OpenTD.Layer", "class_open_t_d_1_1_layer.xhtml", null ]
        ] ],
        [ "OpenTD.LogicObject", "class_open_t_d_1_1_logic_object.xhtml", [
          [ "OpenTD.RcArrayInterpolationData", "class_open_t_d_1_1_rc_array_interpolation_data.xhtml", [
            [ "OpenTD.ArrayInterpolation", "class_open_t_d_1_1_array_interpolation.xhtml", null ]
          ] ],
          [ "OpenTD.RcLogicUDFACollectionData", "class_open_t_d_1_1_rc_logic_u_d_f_a_collection_data.xhtml", [
            [ "OpenTD.UDFACollection", "class_open_t_d_1_1_u_d_f_a_collection.xhtml", null ]
          ] ],
          [ "OpenTD.RcLogicUserArrayData", "class_open_t_d_1_1_rc_logic_user_array_data.xhtml", [
            [ "OpenTD.UserArray", "class_open_t_d_1_1_user_array.xhtml", null ]
          ] ],
          [ "OpenTD.RcLogicUserCodeData", "class_open_t_d_1_1_rc_logic_user_code_data.xhtml", [
            [ "OpenTD.UserCode", "class_open_t_d_1_1_user_code.xhtml", null ]
          ] ],
          [ "OpenTD.RcPIDData", "class_open_t_d_1_1_rc_p_i_d_data.xhtml", [
            [ "OpenTD.PID", "class_open_t_d_1_1_p_i_d.xhtml", null ]
          ] ]
        ] ],
        [ "OpenTD.MeasureMappingTolerances", "class_open_t_d_1_1_measure_mapping_tolerances.xhtml", null ],
        [ "OpenTD.RcNotesData", "class_open_t_d_1_1_rc_notes_data.xhtml", [
          [ "OpenTD.Notes", "class_open_t_d_1_1_notes.xhtml", null ]
        ] ],
        [ "OpenTD.UniqueNameObject", "class_open_t_d_1_1_unique_name_object.xhtml", [
          [ "OpenTD.MaterialStackData", "class_open_t_d_1_1_material_stack_data.xhtml", [
            [ "OpenTD.MaterialStack", "class_open_t_d_1_1_material_stack.xhtml", null ]
          ] ],
          [ "OpenTD.PostProcessing.Dataset", "class_open_t_d_1_1_post_processing_1_1_dataset.xhtml", null ],
          [ "OpenTD.RadCAD.OpticalPropsData", "class_open_t_d_1_1_rad_c_a_d_1_1_optical_props_data.xhtml", [
            [ "OpenTD.RadCAD.OpticalProps", "class_open_t_d_1_1_rad_c_a_d_1_1_optical_props.xhtml", null ]
          ] ],
          [ "OpenTD.SubmodelData", "class_open_t_d_1_1_submodel_data.xhtml", [
            [ "OpenTD.FloCAD.FluidSubmodelData", "class_open_t_d_1_1_flo_c_a_d_1_1_fluid_submodel_data.xhtml", [
              [ "OpenTD.FloCAD.FluidSubmodel", "class_open_t_d_1_1_flo_c_a_d_1_1_fluid_submodel.xhtml", null ]
            ] ],
            [ "OpenTD.Submodel", "class_open_t_d_1_1_submodel.xhtml", null ]
          ] ],
          [ "OpenTD.SymbolData", "class_open_t_d_1_1_symbol_data.xhtml", [
            [ "OpenTD.Symbol", "class_open_t_d_1_1_symbol.xhtml", null ]
          ] ],
          [ "OpenTD.ThermoPropsData", "class_open_t_d_1_1_thermo_props_data.xhtml", [
            [ "OpenTD.ThermoProps", "class_open_t_d_1_1_thermo_props.xhtml", null ]
          ] ]
        ] ]
      ] ],
      [ "OpenTD.PostProcessing.DataMapper", "class_open_t_d_1_1_post_processing_1_1_data_mapper.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.ISimpleDataset", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_simple_dataset.xhtml", [
      [ "OpenTD.Results.Dataset.SimpleDataset", "class_open_t_d_1_1_results_1_1_dataset_1_1_simple_dataset.xhtml", null ],
      [ "OpenTD.Results.Dataset.SpreadsheetDataFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_spreadsheet_data_file.xhtml", null ],
      [ "OpenTD.Results.Dataset.TextTransientFile", "class_open_t_d_1_1_results_1_1_dataset_1_1_text_transient_file.xhtml", null ]
    ] ],
    [ "OpenTD.Internal.Communication.ITdCommander", "interface_open_t_d_1_1_internal_1_1_communication_1_1_i_td_commander.xhtml", null ],
    [ "OpenTD.ITdConsole", "interface_open_t_d_1_1_i_td_console.xhtml", [
      [ "OpenTD.ThermalDesktop", "class_open_t_d_1_1_thermal_desktop.xhtml", null ]
    ] ],
    [ "OpenTD.ITdDerived", "interface_open_t_d_1_1_i_td_derived.xhtml", [
      [ "OpenTD.AdditionalRadiationTaskData", "class_open_t_d_1_1_additional_radiation_task_data.xhtml", null ],
      [ "OpenTD.AggregateComponentData", "class_open_t_d_1_1_aggregate_component_data.xhtml", null ],
      [ "OpenTD.AggregateData", "class_open_t_d_1_1_aggregate_data.xhtml", null ],
      [ "OpenTD.CaseSetData", "class_open_t_d_1_1_case_set_data.xhtml", null ],
      [ "OpenTD.CaseSetManagerOptions", "class_open_t_d_1_1_case_set_manager_options.xhtml", null ],
      [ "OpenTD.ExpressionArrayClass2Data", "class_open_t_d_1_1_expression_array_class2_data.xhtml", null ],
      [ "OpenTD.ExpressionArrayClassData", "class_open_t_d_1_1_expression_array_class_data.xhtml", null ],
      [ "OpenTD.ExpressionData", "class_open_t_d_1_1_expression_data.xhtml", null ],
      [ "OpenTD.FloCAD.Bay", "class_open_t_d_1_1_flo_c_a_d_1_1_bay.xhtml", null ],
      [ "OpenTD.FloCAD.Compartment", "class_open_t_d_1_1_flo_c_a_d_1_1_compartment.xhtml", null ],
      [ "OpenTD.FloCAD.CompartmentTie", "class_open_t_d_1_1_flo_c_a_d_1_1_compartment_tie.xhtml", null ],
      [ "OpenTD.FloCAD.FkLocator", "class_open_t_d_1_1_flo_c_a_d_1_1_fk_locator.xhtml", null ],
      [ "OpenTD.FloCAD.PipeStdSignatureData", "class_open_t_d_1_1_flo_c_a_d_1_1_pipe_std_signature_data.xhtml", null ],
      [ "OpenTD.FloCAD.PipeTie", "class_open_t_d_1_1_flo_c_a_d_1_1_pipe_tie.xhtml", null ],
      [ "OpenTD.FloCAD.RcCappmpData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_cappmp_data.xhtml", null ],
      [ "OpenTD.FloCAD.RcFTieData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_f_tie_data.xhtml", null ],
      [ "OpenTD.FloCAD.RcIFaceData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_i_face_data.xhtml", null ],
      [ "OpenTD.FloCAD.RcLumpData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_lump_data.xhtml", null ],
      [ "OpenTD.FloCAD.RcPathData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_path_data.xhtml", null ],
      [ "OpenTD.FloCAD.RcPipeData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_pipe_data.xhtml", null ],
      [ "OpenTD.FloCAD.RcPortData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_port_data.xhtml", null ],
      [ "OpenTD.FloCAD.RcTieData", "class_open_t_d_1_1_flo_c_a_d_1_1_rc_tie_data.xhtml", null ],
      [ "OpenTD.FloCAD.Tee", "class_open_t_d_1_1_flo_c_a_d_1_1_tee.xhtml", null ],
      [ "OpenTD.FluintLogicData", "class_open_t_d_1_1_fluint_logic_data.xhtml", null ],
      [ "OpenTD.KickerData", "class_open_t_d_1_1_kicker_data.xhtml", null ],
      [ "OpenTD.LogicObject", "class_open_t_d_1_1_logic_object.xhtml", null ],
      [ "OpenTD.MaterialStackData", "class_open_t_d_1_1_material_stack_data.xhtml", null ],
      [ "OpenTD.MaterialStackLayerData", "class_open_t_d_1_1_material_stack_layer_data.xhtml", null ],
      [ "OpenTD.Measure", "class_open_t_d_1_1_measure.xhtml", null ],
      [ "OpenTD.NetworkLogicData", "class_open_t_d_1_1_network_logic_data.xhtml", null ],
      [ "OpenTD.NetworkLogicUnits", "class_open_t_d_1_1_network_logic_units.xhtml", null ],
      [ "OpenTD.NodeBreakdownData", "class_open_t_d_1_1_node_breakdown_data.xhtml", null ],
      [ "OpenTD.PostProcessing.AdditionalCompareInfo", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml", null ],
      [ "OpenTD.PostProcessing.AdditionalDatasetInfo", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info.xhtml", [
        [ "OpenTD.PostProcessing.AdditionalCompareInfo", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml", null ],
        [ "OpenTD.PostProcessing.AdditionalHeatFlowInfo", "class_open_t_d_1_1_post_processing_1_1_additional_heat_flow_info.xhtml", null ],
        [ "OpenTD.PostProcessing.AdditionalHeatFlowMapInfo", "class_open_t_d_1_1_post_processing_1_1_additional_heat_flow_map_info.xhtml", null ],
        [ "OpenTD.PostProcessing.AdditionalHeatrateInfo", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml", null ],
        [ "OpenTD.PostProcessing.AdditionalRadkInfo", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml", null ],
        [ "OpenTD.PostProcessing.AdditionalSindaInfo", "class_open_t_d_1_1_post_processing_1_1_additional_sinda_info.xhtml", null ],
        [ "OpenTD.PostProcessing.AdditionalTextInfo", "class_open_t_d_1_1_post_processing_1_1_additional_text_info.xhtml", null ],
        [ "OpenTD.PostProcessing.AdditionalTextTransientInfo", "class_open_t_d_1_1_post_processing_1_1_additional_text_transient_info.xhtml", null ]
      ] ],
      [ "OpenTD.PostProcessing.AdditionalHeatFlowInfo", "class_open_t_d_1_1_post_processing_1_1_additional_heat_flow_info.xhtml", null ],
      [ "OpenTD.PostProcessing.AdditionalHeatFlowMapInfo", "class_open_t_d_1_1_post_processing_1_1_additional_heat_flow_map_info.xhtml", null ],
      [ "OpenTD.PostProcessing.AdditionalHeatrateInfo", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml", null ],
      [ "OpenTD.PostProcessing.AdditionalRadkInfo", "class_open_t_d_1_1_post_processing_1_1_additional_radk_info.xhtml", null ],
      [ "OpenTD.PostProcessing.AdditionalSindaInfo", "class_open_t_d_1_1_post_processing_1_1_additional_sinda_info.xhtml", null ],
      [ "OpenTD.PostProcessing.AdditionalTextInfo", "class_open_t_d_1_1_post_processing_1_1_additional_text_info.xhtml", null ],
      [ "OpenTD.PostProcessing.AdditionalTextTransientInfo", "class_open_t_d_1_1_post_processing_1_1_additional_text_transient_info.xhtml", null ],
      [ "OpenTD.PostProcessing.DataMapper", "class_open_t_d_1_1_post_processing_1_1_data_mapper.xhtml", null ],
      [ "OpenTD.PostProcessing.Dataset", "class_open_t_d_1_1_post_processing_1_1_dataset.xhtml", null ],
      [ "OpenTD.PostProcessing.StressThermalGroupAssociation", "class_open_t_d_1_1_post_processing_1_1_stress_thermal_group_association.xhtml", null ],
      [ "OpenTD.PressureLoad", "class_open_t_d_1_1_pressure_load.xhtml", null ],
      [ "OpenTD.Quaternion", "class_open_t_d_1_1_quaternion.xhtml", null ],
      [ "OpenTD.RadCAD.EllipticCylinder", "class_open_t_d_1_1_rad_c_a_d_1_1_elliptic_cylinder.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.LinearBrick", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_brick.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.LinearPyramid", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_pyramid.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.LinearQuad", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_quad.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.LinearTet", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_tet.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.LinearTri", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_tri.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.LinearWedge", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_linear_wedge.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.QuadraticBrick", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_brick.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.QuadraticPyramid", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_pyramid.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.QuadraticQuad", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_quad.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.QuadraticTet", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_tet.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.QuadraticTri", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_tri.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.QuadraticWedge", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_quadratic_wedge.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.RcSolidElement", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_rc_solid_element.xhtml", null ],
      [ "OpenTD.RadCAD.FEM.RcSurfaceElement", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_m_1_1_rc_surface_element.xhtml", null ],
      [ "OpenTD.RadCAD.FdSolid.RcFdSolidData", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_rc_fd_solid_data.xhtml", null ],
      [ "OpenTD.RadCAD.FdSolid.SolidBrick", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_brick.xhtml", null ],
      [ "OpenTD.RadCAD.FdSolid.SolidCone", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_cone.xhtml", null ],
      [ "OpenTD.RadCAD.FdSolid.SolidCylinder", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_cylinder.xhtml", null ],
      [ "OpenTD.RadCAD.FdSolid.SolidEllipsoid", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_ellipsoid.xhtml", null ],
      [ "OpenTD.RadCAD.FdSolid.SolidSphere", "class_open_t_d_1_1_rad_c_a_d_1_1_fd_solid_1_1_solid_sphere.xhtml", null ],
      [ "OpenTD.RadCAD.GlobalContact", "class_open_t_d_1_1_rad_c_a_d_1_1_global_contact.xhtml", null ],
      [ "OpenTD.RadCAD.OpticalPropsData", "class_open_t_d_1_1_rad_c_a_d_1_1_optical_props_data.xhtml", null ],
      [ "OpenTD.RadCAD.Orbit", "class_open_t_d_1_1_rad_c_a_d_1_1_orbit.xhtml", null ],
      [ "OpenTD.RadCAD.OrbitDateTime", "class_open_t_d_1_1_rad_c_a_d_1_1_orbit_date_time.xhtml", null ],
      [ "OpenTD.RadCAD.OrbitParameters", "class_open_t_d_1_1_rad_c_a_d_1_1_orbit_parameters.xhtml", null ],
      [ "OpenTD.RadCAD.PlanetParameters", "class_open_t_d_1_1_rad_c_a_d_1_1_planet_parameters.xhtml", null ],
      [ "OpenTD.RadCAD.RcArticulatorData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_articulator_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcConeData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_cone_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcConicData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_conic_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcCylinderData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_cylinder_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcDiskData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_disk_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcEllipseData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_ellipse_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcEllipsoidData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_ellipsoid_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcEllipticConeData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_elliptic_cone_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcEntityData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_entity_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcMeshFDData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_mesh_f_d_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcOffsetParaboloidData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_offset_paraboloid_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcOgiveData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_ogive_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcParabolicTroughData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_parabolic_trough_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcParaboloidData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_paraboloid_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcRectangleData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_rectangle_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcScarfedConeData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_scarfed_cone_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcScarfedCylinderData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_scarfed_cylinder_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcSphereData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_sphere_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcTorusData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_torus_data.xhtml", null ],
      [ "OpenTD.RadCAD.RcTrackerData", "class_open_t_d_1_1_rad_c_a_d_1_1_rc_tracker_data.xhtml", null ],
      [ "OpenTD.RadCAD.TempVsWaveLengthData", "class_open_t_d_1_1_rad_c_a_d_1_1_temp_vs_wave_length_data.xhtml", null ],
      [ "OpenTD.RadiationTaskData", "class_open_t_d_1_1_radiation_task_data.xhtml", null ],
      [ "OpenTD.RcArrayInterpolationData", "class_open_t_d_1_1_rc_array_interpolation_data.xhtml", null ],
      [ "OpenTD.RcConductorData", "class_open_t_d_1_1_rc_conductor_data.xhtml", null ],
      [ "OpenTD.RcConnData", "class_open_t_d_1_1_rc_conn_data.xhtml", null ],
      [ "OpenTD.RcHeatLoadData", "class_open_t_d_1_1_rc_heat_load_data.xhtml", null ],
      [ "OpenTD.RcHeaterData", "class_open_t_d_1_1_rc_heater_data.xhtml", null ],
      [ "OpenTD.RcHeaterSenseData", "class_open_t_d_1_1_rc_heater_sense_data.xhtml", null ],
      [ "OpenTD.RcLogicUDFACollectionData", "class_open_t_d_1_1_rc_logic_u_d_f_a_collection_data.xhtml", null ],
      [ "OpenTD.RcLogicUserArrayData", "class_open_t_d_1_1_rc_logic_user_array_data.xhtml", null ],
      [ "OpenTD.RcLogicUserCodeData", "class_open_t_d_1_1_rc_logic_user_code_data.xhtml", null ],
      [ "OpenTD.RcNodeData", "class_open_t_d_1_1_rc_node_data.xhtml", null ],
      [ "OpenTD.RcNotesData", "class_open_t_d_1_1_rc_notes_data.xhtml", null ],
      [ "OpenTD.RcPIDData", "class_open_t_d_1_1_rc_p_i_d_data.xhtml", null ],
      [ "OpenTD.RcTecData", "class_open_t_d_1_1_rc_tec_data.xhtml", null ],
      [ "OpenTD.RegisterData", "class_open_t_d_1_1_register_data.xhtml", null ],
      [ "OpenTD.SindaControlData", "class_open_t_d_1_1_sinda_control_data.xhtml", null ],
      [ "OpenTD.SindaOptionsData", "class_open_t_d_1_1_sinda_options_data.xhtml", null ],
      [ "OpenTD.SolverControlData", "class_open_t_d_1_1_solver_control_data.xhtml", null ],
      [ "OpenTD.SolverDesignData", "class_open_t_d_1_1_solver_design_data.xhtml", null ],
      [ "OpenTD.SymbolData", "class_open_t_d_1_1_symbol_data.xhtml", null ],
      [ "OpenTD.TdDbEntityData", "class_open_t_d_1_1_td_db_entity_data.xhtml", null ],
      [ "OpenTD.TdTextData", "class_open_t_d_1_1_td_text_data.xhtml", null ],
      [ "OpenTD.ThermalLogicData", "class_open_t_d_1_1_thermal_logic_data.xhtml", null ],
      [ "OpenTD.ThermoPropsData", "class_open_t_d_1_1_thermo_props_data.xhtml", null ],
      [ "OpenTD.UDFA", "class_open_t_d_1_1_u_d_f_a.xhtml", null ],
      [ "OpenTD.UnitsData", "class_open_t_d_1_1_units_data.xhtml", null ],
      [ "OpenTD.UnitsDefData", "class_open_t_d_1_1_units_def_data.xhtml", null ],
      [ "OpenTD.UserPreferences.AdvancedPreferences", "class_open_t_d_1_1_user_preferences_1_1_advanced_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.CalculationsPreferences", "class_open_t_d_1_1_user_preferences_1_1_calculations_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.GraphicsResolutionPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.GraphicsSizePreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_size_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.GraphicsTextPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_text_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.GraphicsVisibilityPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_visibility_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.SindaPreferences", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.UnitsPreferences", "class_open_t_d_1_1_user_preferences_1_1_units_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.UserPreferences", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.IUDFAManager", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_manager.xhtml", [
      [ "OpenTD.Results.Dataset.UDFAManager", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager.xhtml", null ]
    ] ],
    [ "OpenTD.Results.Dataset.IUDFAReader", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_reader.xhtml", [
      [ "OpenTD.Results.Dataset.FunctionalUDFAReader", "class_open_t_d_1_1_results_1_1_dataset_1_1_functional_u_d_f_a_reader.xhtml", null ]
    ] ],
    [ "OpenTD.IUpdatable", "interface_open_t_d_1_1_i_updatable.xhtml", [
      [ "OpenTD.CaseSetManager", "class_open_t_d_1_1_case_set_manager.xhtml", null ],
      [ "OpenTD.CaseSetManagerOptions", "class_open_t_d_1_1_case_set_manager_options.xhtml", null ],
      [ "OpenTD.OpenTDObject", "class_open_t_d_1_1_open_t_d_object.xhtml", null ],
      [ "OpenTD.PostProcessing.DataMapper", "class_open_t_d_1_1_post_processing_1_1_data_mapper.xhtml", null ],
      [ "OpenTD.PostProcessing.Dataset", "class_open_t_d_1_1_post_processing_1_1_dataset.xhtml", null ],
      [ "OpenTD.UCS", "class_open_t_d_1_1_u_c_s.xhtml", null ],
      [ "OpenTD.UserPreferences.Acceleration", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml", null ],
      [ "OpenTD.UserPreferences.AdvancedPreferences", "class_open_t_d_1_1_user_preferences_1_1_advanced_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.CalculationsPreferences", "class_open_t_d_1_1_user_preferences_1_1_calculations_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.GraphicsResolutionPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.GraphicsSizePreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_size_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.GraphicsTextPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_text_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.GraphicsVisibilityPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_visibility_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.SindaPreferences", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.UnitsPreferences", "class_open_t_d_1_1_user_preferences_1_1_units_preferences.xhtml", null ],
      [ "OpenTD.UserPreferences.UserPreferences", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml", null ]
    ] ],
    [ "OpenTD.AddIn.IUserBreak", "interface_open_t_d_1_1_add_in_1_1_i_user_break.xhtml", [
      [ "OpenTD.AddIn.UserBreak", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml", null ]
    ] ],
    [ "OpenTD.RadCAD.FEModel.LayerData", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_layer_data.xhtml", null ],
    [ "OpenTD.Results.Plot.Legend", "class_open_t_d_1_1_results_1_1_plot_1_1_legend.xhtml", null ],
    [ "OpenTD.Results.Plot.LegendStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml", null ],
    [ "List", null, [
      [ "OpenTD.Dimension.DimensionalIfPositiveList< T >", "class_open_t_d_1_1_dimension_1_1_dimensional_if_positive_list-1-g.xhtml", null ],
      [ "OpenTD.Dimension.DimensionalList2< T >", "class_open_t_d_1_1_dimension_1_1_dimensional_list2-1-g.xhtml", null ],
      [ "OpenTD.Dimension.DimensionalList< T >", "class_open_t_d_1_1_dimension_1_1_dimensional_list-1-g.xhtml", null ],
      [ "OpenTD.ListSI", "class_open_t_d_1_1_list_s_i.xhtml", null ]
    ] ],
    [ "OpenTD.LogicObjects", "class_open_t_d_1_1_logic_objects.xhtml", null ],
    [ "OpenTD.Matrix3d", "class_open_t_d_1_1_matrix3d.xhtml", [
      [ "OpenTD.UCS", "class_open_t_d_1_1_u_c_s.xhtml", null ]
    ] ],
    [ "OpenTD.MergeNodesOptionsData", "class_open_t_d_1_1_merge_nodes_options_data.xhtml", null ],
    [ "OpenTD.Model", "class_open_t_d_1_1_model.xhtml", null ],
    [ "OpenTD.NameData", "class_open_t_d_1_1_name_data.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.Node", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_node.xhtml", null ],
    [ "OpenTD.Results.Dataset.NodeConductorHeatrates", "class_open_t_d_1_1_results_1_1_dataset_1_1_node_conductor_heatrates.xhtml", null ],
    [ "OpenTD.Results.Dataset.NodeHeatrates", "class_open_t_d_1_1_results_1_1_dataset_1_1_node_heatrates.xhtml", null ],
    [ "OpenTD.Results.Dataset.NodeTieHeatrates", "class_open_t_d_1_1_results_1_1_dataset_1_1_node_tie_heatrates.xhtml", null ],
    [ "OpenTD.NurbsData", "class_open_t_d_1_1_nurbs_data.xhtml", null ],
    [ "OpenTD.OpticalPropAliasManager", "class_open_t_d_1_1_optical_prop_alias_manager.xhtml", null ],
    [ "OpenTD.FloCAD.PipeStdUtility", "class_open_t_d_1_1_flo_c_a_d_1_1_pipe_std_utility.xhtml", null ],
    [ "OpenTD.Results.Plot.Plot2dStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml", null ],
    [ "OpenTD.Point2d", "class_open_t_d_1_1_point2d.xhtml", null ],
    [ "OpenTD.Point3d", "class_open_t_d_1_1_point3d.xhtml", null ],
    [ "OpenTD.PolylineVertex", "class_open_t_d_1_1_polyline_vertex.xhtml", null ],
    [ "OpenTD.Utility.PropertyMap", "class_open_t_d_1_1_utility_1_1_property_map.xhtml", null ],
    [ "OpenTD.RadCAD.FEModel.Quaternion", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_quaternion.xhtml", null ],
    [ "OpenTD.RadCAD.RadiationAnalysisGroupManager", "class_open_t_d_1_1_rad_c_a_d_1_1_radiation_analysis_group_manager.xhtml", null ],
    [ "OpenTD.Utility.RootedPathname", "struct_open_t_d_1_1_utility_1_1_rooted_pathname.xhtml", null ],
    [ "OpenTD.Script", "class_open_t_d_1_1_script.xhtml", null ],
    [ "OpenTD.SelectionOptions", "class_open_t_d_1_1_selection_options.xhtml", null ],
    [ "OpenTD.Results.Plot.Series2dStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_series2d_style.xhtml", null ],
    [ "OpenTD.SindaCyclicData", "class_open_t_d_1_1_sinda_cyclic_data.xhtml", null ],
    [ "OpenTD.StackAliasManager", "class_open_t_d_1_1_stack_alias_manager.xhtml", null ],
    [ "OpenTD.Internal.Communication.StatusData", "class_open_t_d_1_1_internal_1_1_communication_1_1_status_data.xhtml", null ],
    [ "OpenTD.SubmodelNameData", "class_open_t_d_1_1_submodel_name_data.xhtml", null ],
    [ "OpenTD.TdConnectConfig", "class_open_t_d_1_1_td_connect_config.xhtml", null ],
    [ "OpenTD.TdConnected", "class_open_t_d_1_1_td_connected.xhtml", [
      [ "OpenTD.AddIn.ProgressBar", "class_open_t_d_1_1_add_in_1_1_progress_bar.xhtml", null ],
      [ "OpenTD.AddIn.UserBreak", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml", null ],
      [ "OpenTD.BatchControl", "class_open_t_d_1_1_batch_control.xhtml", null ],
      [ "OpenTD.CaseSetManager", "class_open_t_d_1_1_case_set_manager.xhtml", null ],
      [ "OpenTD.CaseSetManagerOptions", "class_open_t_d_1_1_case_set_manager_options.xhtml", null ],
      [ "OpenTD.DynamicSindaStatus", "class_open_t_d_1_1_dynamic_sinda_status.xhtml", null ],
      [ "OpenTD.PostProcessing.DatasetManager", "class_open_t_d_1_1_post_processing_1_1_dataset_manager.xhtml", null ],
      [ "OpenTD.UserPreferences.Preferences", "class_open_t_d_1_1_user_preferences_1_1_preferences.xhtml", [
        [ "OpenTD.UserPreferences.Acceleration", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml", null ],
        [ "OpenTD.UserPreferences.AdvancedPreferences", "class_open_t_d_1_1_user_preferences_1_1_advanced_preferences.xhtml", null ],
        [ "OpenTD.UserPreferences.CalculationsPreferences", "class_open_t_d_1_1_user_preferences_1_1_calculations_preferences.xhtml", null ],
        [ "OpenTD.UserPreferences.GraphicsResolutionPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml", null ],
        [ "OpenTD.UserPreferences.GraphicsSizePreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_size_preferences.xhtml", null ],
        [ "OpenTD.UserPreferences.GraphicsTextPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_text_preferences.xhtml", null ],
        [ "OpenTD.UserPreferences.GraphicsVisibilityPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_visibility_preferences.xhtml", null ],
        [ "OpenTD.UserPreferences.SindaPreferences", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml", null ],
        [ "OpenTD.UserPreferences.UnitsPreferences", "class_open_t_d_1_1_user_preferences_1_1_units_preferences.xhtml", null ],
        [ "OpenTD.UserPreferences.UserPreferences", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml", null ]
      ] ]
    ] ],
    [ "OpenTD.ThermoPropAliasManager", "class_open_t_d_1_1_thermo_prop_alias_manager.xhtml", null ],
    [ "OpenTD.Results.Dataset.TieHeat", "class_open_t_d_1_1_results_1_1_dataset_1_1_tie_heat.xhtml", null ],
    [ "OpenTD.TimeoutProperties", "class_open_t_d_1_1_timeout_properties.xhtml", null ],
    [ "OpenTD.Transformation", "class_open_t_d_1_1_transformation.xhtml", null ],
    [ "OpenTD.Results.Dataset.UDFADescriptor", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor.xhtml", null ],
    [ "UserControl", null, [
      [ "OpenTD.UserInterface.Forms.OutputBox", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml", null ]
    ] ],
    [ "OpenTD.Vector3d", "class_open_t_d_1_1_vector3d.xhtml", null ],
    [ "OpenTD.VisibilityManager", "class_open_t_d_1_1_visibility_manager.xhtml", null ],
    [ "OpenTD.XrefInfo", "class_open_t_d_1_1_xref_info.xhtml", null ]
];