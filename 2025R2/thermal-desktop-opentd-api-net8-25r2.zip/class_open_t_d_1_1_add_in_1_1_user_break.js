var class_open_t_d_1_1_add_in_1_1_user_break =
[
    [ "UserBreak", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml#aeff6588cf4c56e7f6be8c9484aeffeb8", null ],
    [ "BreakRequested", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml#a2c3777c4a71e1c7fc986a6b437e4ceaa", null ],
    [ "ConfirmationOff", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml#a555d32a40e3a70c9a456720914bb0ab3", null ],
    [ "ConfirmationOn", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml#aa3b455be06e2ef18377c5a1450454d27", null ],
    [ "Disable", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml#ae3aeb4584c0b122aabfb70f4c0e03d22", null ],
    [ "Enable", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml#a4df01ed8a96a8980abc7e1a883824ddc", null ]
];