var struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance_plot =
[
    [ "ExceedancePlot", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance_plot.xhtml#afdd731fba74a17b489476832ef11e257", null ],
    [ "DataItemId", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance_plot.xhtml#a6cacbb9233b02c892f358d79e395a94a", null ],
    [ "Index", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance_plot.xhtml#aac4d26c7dca072637975cf8679b39912", null ],
    [ "PercentDifference", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance_plot.xhtml#a1141e338690b3514fb1e7970d712d5c1", null ],
    [ "Plot", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance_plot.xhtml#ad5e6e8394335e44958668df6c22e1fa6", null ],
    [ "Subtype", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance_plot.xhtml#a6af7f79b4cddb232809eafa6bae1befd", null ]
];