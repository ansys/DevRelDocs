var class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box =
[
    [ "OutputBox", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml#ac71bd349fbaba8c0ecd35e7fbac235d0", null ],
    [ "Dispose", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml#af9fe5b2843ae49161c669195b707a39d", null ],
    [ "Write", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml#aa1ed82b58b66a99faf9cfb479cd355cd", null ],
    [ "WriteLine", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml#a5491636be10c83b299d542602641c441", null ],
    [ "Caption", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml#ac7f873a6327d8eae60be5bcc42e589fe", null ],
    [ "CopyButtonEnabled", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml#a72699eb7173a0fc2229940a8a80db5e9", null ],
    [ "OutputText", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml#ac9bfb870489cc3fa1c3f9a74fc247d49", null ],
    [ "SaveButtonEnabled", "class_open_t_d_1_1_user_interface_1_1_forms_1_1_output_box.xhtml#a9fc392f777fb6eaaf2ea9549defc932f", null ]
];