var class_open_t_d_1_1_dimension_1_1_time =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_time.xhtml#a762c1cd23575637ab1cac00a440b83a5", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_time.xhtml#a59d24ad4e1c8b466fc36dc79255efbd2", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_time.xhtml#adfac91fe3bdbb96ce30c4cbb364e976c", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_time.xhtml#afcdafe7d2c696164306e69719a1344a2", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_time.xhtml#aea85d49c038c83ebad68ce386c0a73db", null ]
];