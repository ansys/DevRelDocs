var interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i_list =
[
    [ "GetValuesSI", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i_list.xhtml#a7a0e97785f1638f0ada5977b598f788d", null ],
    [ "SetValuesSI", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i_list.xhtml#a35c0d32f873978deb048b139e677f090", null ]
];