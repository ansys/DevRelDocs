var class_open_t_d_1_1_results_1_1_plot_1_1_legend_style =
[
    [ "LegendStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a4c11a2eccdf0982e6fc9f3e31fd6e041", null ],
    [ "BorderColor", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#ac5ed6adc79bc1d0eae4bd79bd349e1f6", null ],
    [ "BorderDashStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#aed35207234e052d7f4c49ee09f083f0f", null ],
    [ "BorderWidth", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a3c4d8b7a53097fa4b33deecd2cff83f3", null ],
    [ "ItemFont", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a9807292ff71040931b2e842d927d2746", null ],
    [ "ItemOrder", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a7e1a6f102f04fe05290e81e25a281f80", null ],
    [ "Position", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a9421716aa37f27ef07d94eca38d4ad7c", null ],
    [ "SecondaryPosition", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a65e3ffab2e5da9c983e783436da4c971", null ],
    [ "TableStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a240ab471629dc7703385018acb2ba99a", null ],
    [ "TitleColor", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a174539a187213d17b2d93160459a6674", null ],
    [ "TitleFont", "class_open_t_d_1_1_results_1_1_plot_1_1_legend_style.xhtml#a3c94dd71ac2964a6b3e95ae5aef0d6e5", null ]
];