var interface_open_t_d_1_1_i_td_derived =
[
    [ "TdClassName", "interface_open_t_d_1_1_i_td_derived.xhtml#ab352578bf3691270b61651f567077073", null ],
    [ "TdSourcePathname", "interface_open_t_d_1_1_i_td_derived.xhtml#aedb4a0e9a04da354a1ba217ab8eb3952", null ],
    [ "TdVersion", "interface_open_t_d_1_1_i_td_derived.xhtml#a540e52884cbd5b43255ead47985b233c", null ]
];