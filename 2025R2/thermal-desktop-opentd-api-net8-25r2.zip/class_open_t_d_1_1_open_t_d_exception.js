var class_open_t_d_1_1_open_t_d_exception =
[
    [ "OpenTDException", "class_open_t_d_1_1_open_t_d_exception.xhtml#ad52b3de814205dd7ab0443f4e11386b7", null ],
    [ "OpenTDException", "class_open_t_d_1_1_open_t_d_exception.xhtml#a651339f1084e02c5b9119b319ef7c551", null ],
    [ "OpenTDException", "class_open_t_d_1_1_open_t_d_exception.xhtml#acc242c6bc3ca5d33d87c8e8393d4cab4", null ],
    [ "Show", "class_open_t_d_1_1_open_t_d_exception.xhtml#a6bb2b77da552eb26ba97565479a04b95", null ],
    [ "statusData", "class_open_t_d_1_1_open_t_d_exception.xhtml#acd1273917399f662bfd8a18135305de7", null ]
];