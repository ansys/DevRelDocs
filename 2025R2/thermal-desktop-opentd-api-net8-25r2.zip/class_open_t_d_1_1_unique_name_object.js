var class_open_t_d_1_1_unique_name_object =
[
    [ "CreateIn", "class_open_t_d_1_1_unique_name_object.xhtml#a9805906b2a067b0ec475e7b6513a8d4f", null ],
    [ "ModifyName", "class_open_t_d_1_1_unique_name_object.xhtml#a1343e99cd573893ee16d36c337fde7b1", null ],
    [ "ProxyRename", "class_open_t_d_1_1_unique_name_object.xhtml#af31349d8cc1cd5714747fdb836717a3e", null ],
    [ "Rename", "class_open_t_d_1_1_unique_name_object.xhtml#ab83691a4d2f3bd34519f9372cfc73951", null ],
    [ "SetFrom", "class_open_t_d_1_1_unique_name_object.xhtml#aa2e0aa2793e95a56891ef59fb4843ca2", null ],
    [ "ToString", "class_open_t_d_1_1_unique_name_object.xhtml#af373d173d2d75fd2b4c6edb8ee4165b2", null ],
    [ "Update", "class_open_t_d_1_1_unique_name_object.xhtml#a3197588bb4f42e3ec88659349dbf4905", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_unique_name_object.xhtml#a61901cd5539657cbd9989fcfa361b8e7", null ],
    [ "UpdateIn", "class_open_t_d_1_1_unique_name_object.xhtml#a1e5228ce309c9a85ec09e8119318024d", null ],
    [ "TdProxy", "class_open_t_d_1_1_unique_name_object.xhtml#a0da16592e6b635ca0def27b355d669b3", null ],
    [ "_n", "class_open_t_d_1_1_unique_name_object.xhtml#a4546becfb33773b2b9d0ae2264c9dd2d", null ],
    [ "Name", "class_open_t_d_1_1_unique_name_object.xhtml#a81ee04aec6314a6dd404826b41564162", null ]
];