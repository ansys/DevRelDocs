var class_open_t_d_1_1_stack_alias_manager =
[
    [ "CreateOrUpdateAlias", "class_open_t_d_1_1_stack_alias_manager.xhtml#aef3aef4081f5c73d48fd9d54cc9edcaf", null ],
    [ "DeleteAlias", "class_open_t_d_1_1_stack_alias_manager.xhtml#a35c637daa027517d5698aaefd5537f30", null ],
    [ "GetAlias", "class_open_t_d_1_1_stack_alias_manager.xhtml#a1266cefef2a312f3ae24c8f64c89e84f", null ],
    [ "GetAliases", "class_open_t_d_1_1_stack_alias_manager.xhtml#ad6eee5d0d8fe2103cc39eb58bfd8b14b", null ],
    [ "RenameAlias", "class_open_t_d_1_1_stack_alias_manager.xhtml#a76193d8c37ece789cb9b9ad87e47e76e", null ]
];