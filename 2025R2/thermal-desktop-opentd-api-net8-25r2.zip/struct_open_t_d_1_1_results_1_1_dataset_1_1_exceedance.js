var struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance =
[
    [ "Exceedance", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#abc053277a5aa6ed901e84281d264267c", null ],
    [ "ToString", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#a3f459d2889f252f0bd9b56bacb0c5adc", null ],
    [ "Index", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#a518b586a0c5d54a2eba7d32a4e564890", null ],
    [ "Name", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#ae81fa249e307c08f1e1966bb501ff639", null ],
    [ "PercentDifference", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#aa6cd9ac23fe2369f26c23e23c600fe12", null ],
    [ "RecA", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#aefefb416dd72fa1408cf761a22954e58", null ],
    [ "RecB", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#a83f0d398227cfd0a537c842abcf5d9b0", null ],
    [ "TimeA", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#a4fd1940fccef181b2e543f600cd98abb", null ],
    [ "TimeB", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#ada678996e34125ed2958428fb65bc589", null ],
    [ "ValueA", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#a8e2f673b96aa139d7a178e8475c52f4d", null ],
    [ "ValueB", "struct_open_t_d_1_1_results_1_1_dataset_1_1_exceedance.xhtml#a9835baa14f9094afa9699f4af57d7e87", null ]
];