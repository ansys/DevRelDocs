var class_open_t_d_1_1_timeout_properties =
[
    [ "TimeoutProperties", "class_open_t_d_1_1_timeout_properties.xhtml#ab87b7193b3b9087beefe9f74b942222d", null ],
    [ "TimeoutProperties", "class_open_t_d_1_1_timeout_properties.xhtml#af35819be4c2e7c30475361a6b931bb57", null ],
    [ "DelayMs", "class_open_t_d_1_1_timeout_properties.xhtml#adc53b3bebc3cb7a36f9a380ab0f88dc0", null ],
    [ "NumberOfTries", "class_open_t_d_1_1_timeout_properties.xhtml#a40404a0e2dcca4af5857fba723d3f3b1", null ]
];