var class_open_t_d_1_1_sinda_options_data =
[
    [ "SindaOptionsData", "class_open_t_d_1_1_sinda_options_data.xhtml#a8ffab5f0a1746733f33f8cf1c5c36295", null ],
    [ "AdditionalUserInput", "class_open_t_d_1_1_sinda_options_data.xhtml#a8fefa46e5ae9340ea6d8fe057bacb580", null ],
    [ "AllowMixedArrays", "class_open_t_d_1_1_sinda_options_data.xhtml#a55134b172faa68a049d38932630de940", null ],
    [ "ListAllInputToPpOut", "class_open_t_d_1_1_sinda_options_data.xhtml#a81276d07190514ae7ef1008141538359", null ],
    [ "OutputFilename", "class_open_t_d_1_1_sinda_options_data.xhtml#a9ee2f8e847d800716e87d81ebfa765f4", null ],
    [ "PrintPageLineFeeds", "class_open_t_d_1_1_sinda_options_data.xhtml#a4f163d904591388a1e36b4a1c7839942", null ],
    [ "REDB", "class_open_t_d_1_1_sinda_options_data.xhtml#a3b1c5a52b2757fd9aea68c45465832ad", null ],
    [ "RsiFilename", "class_open_t_d_1_1_sinda_options_data.xhtml#a2fac49c08560080b85069fea9a726b91", null ],
    [ "RsoFilename", "class_open_t_d_1_1_sinda_options_data.xhtml#aaf329f7645c92200b4776d391ed79dfa", null ],
    [ "SaveFilename", "class_open_t_d_1_1_sinda_options_data.xhtml#a456b7332c051e4bba02000dfd397417a", null ],
    [ "User1FileActive", "class_open_t_d_1_1_sinda_options_data.xhtml#a7006fe093227b8cf896c99006a7ffc5f", null ],
    [ "User1Filename", "class_open_t_d_1_1_sinda_options_data.xhtml#a4a42ccd504b378ab5980656ff0409d1d", null ],
    [ "User2FileActive", "class_open_t_d_1_1_sinda_options_data.xhtml#ac01d5d2e25d39e60782970aca655a044", null ],
    [ "User2Filename", "class_open_t_d_1_1_sinda_options_data.xhtml#acaf7877e1eac763db8b990c987cc0303", null ],
    [ "User3FileActive", "class_open_t_d_1_1_sinda_options_data.xhtml#a74985dfb4fdc9619a37f2830d8f390f9", null ],
    [ "User3Filename", "class_open_t_d_1_1_sinda_options_data.xhtml#a1a348b0a2b262bc617c60729d58c8023", null ],
    [ "User4FileActive", "class_open_t_d_1_1_sinda_options_data.xhtml#a762e4702e5d5546b859bc1ed35a9e0d4", null ],
    [ "User4Filename", "class_open_t_d_1_1_sinda_options_data.xhtml#ad94f2e0600a4bbd7735b762811873547", null ],
    [ "User5FileActive", "class_open_t_d_1_1_sinda_options_data.xhtml#afeddff572c4f69b7531ffe3063b9209e", null ],
    [ "User5Filename", "class_open_t_d_1_1_sinda_options_data.xhtml#a6efdec006d72722417e447a3956f4245", null ]
];