var interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_manager =
[
    [ "GetAsDoubles", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_manager.xhtml#a3e647194e24ec476b31d3720a58d4237", null ],
    [ "GetCharacterData", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_manager.xhtml#a56cf82e764c8cf19730f3af8e5e4d3a5", null ],
    [ "GetCharUdcaData", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_manager.xhtml#a674008bb9fe72fbb1992c4f5b664f4a6", null ],
    [ "GetDescriptor", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_manager.xhtml#aa2c60a08bd51317fa0060400f3be1280", null ],
    [ "GetDescriptorsAtRecord", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_manager.xhtml#a3154b1d5eca4675c64a1d2fc5da733d7", null ],
    [ "Descriptors", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_manager.xhtml#a432d4aac6170d2639e8a454e3ce93d6f", null ]
];