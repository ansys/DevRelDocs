var class_open_t_d_1_1_bad_data_exception =
[
    [ "BadDataException", "class_open_t_d_1_1_bad_data_exception.xhtml#a7c3e01453e0c9a50c46e9a5fe8fd9a1a", null ],
    [ "Show", "class_open_t_d_1_1_bad_data_exception.xhtml#a6bb2b77da552eb26ba97565479a04b95", null ],
    [ "statusData", "class_open_t_d_1_1_bad_data_exception.xhtml#acd1273917399f662bfd8a18135305de7", null ]
];