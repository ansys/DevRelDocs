var class_open_t_d_1_1_layer_data =
[
    [ "LayerData", "class_open_t_d_1_1_layer_data.xhtml#a6dbeacf62810d6447bbefed5b83ae076", null ],
    [ "LayerData", "class_open_t_d_1_1_layer_data.xhtml#a625ad3616fb1613746e9a177b1b6611f", null ],
    [ "CreateIn", "class_open_t_d_1_1_layer_data.xhtml#af37ba70d37945525f286df994377053f", null ],
    [ "SetFrom", "class_open_t_d_1_1_layer_data.xhtml#aa2e0aa2793e95a56891ef59fb4843ca2", null ],
    [ "ToString", "class_open_t_d_1_1_layer_data.xhtml#a873e16c0ae5f0c9052f5818032065602", null ],
    [ "Update", "class_open_t_d_1_1_layer_data.xhtml#a2ccf9e9a0f064aa28a7346eaed881621", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_layer_data.xhtml#a4e2948fd7d46970a73e642a31e0d8e86", null ],
    [ "UpdateIn", "class_open_t_d_1_1_layer_data.xhtml#a1e5228ce309c9a85ec09e8119318024d", null ],
    [ "TdProxy", "class_open_t_d_1_1_layer_data.xhtml#a0da16592e6b635ca0def27b355d669b3", null ],
    [ "ColorIndex", "class_open_t_d_1_1_layer_data.xhtml#afa9a0a7c95f0e5777ff1fcb9a06c746c", null ],
    [ "Current", "class_open_t_d_1_1_layer_data.xhtml#a24eb8882e3465b6f5a84a3c46b50e953", null ],
    [ "Frozen", "class_open_t_d_1_1_layer_data.xhtml#a090d574ef83c46da9e387ef6165a23a2", null ],
    [ "Handle", "class_open_t_d_1_1_layer_data.xhtml#a4ae081ff77dea9973916f5cf17ed088c", null ],
    [ "Locked", "class_open_t_d_1_1_layer_data.xhtml#a53d3c34fd869211810f6b418b5f4bb46", null ],
    [ "Name", "class_open_t_d_1_1_layer_data.xhtml#ab9184bc2b4f1866bfa5b2b78ed8b0b5e", null ],
    [ "Off", "class_open_t_d_1_1_layer_data.xhtml#a605d3ca1ad8fff7c689eea223f3d5c1e", null ]
];