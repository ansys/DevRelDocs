var interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input =
[
    [ "CompareJustFinalRecord", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input.xhtml#a4bea191390ea2193df713d671473f3f1", null ],
    [ "DatasetA", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input.xhtml#a382c20c8329346af749d45b51b971276", null ],
    [ "DatasetB", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input.xhtml#a6d97ab621c008b6ac2e61a01d68d6237", null ],
    [ "RecNumsA", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input.xhtml#acf9fda601761b15b479a09a26b90ae54", null ],
    [ "RecNumsB", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input.xhtml#a1c3790ae5fafc5a611e80622567176f4", null ],
    [ "TimesA", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input.xhtml#aea0c19eff23bb96399ac6efd679900ba", null ],
    [ "TimesB", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_comparer_input.xhtml#a978b2a7a36146a4084fe6e0f914804d2", null ]
];