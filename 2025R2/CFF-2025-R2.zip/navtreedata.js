/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Ansys Common Fluids Format SDK Reference", "index.xhtml", [
    [ "Ansys Common Fluids Format SDK", "index.xhtml", [
      [ "Introduction to the Ansys Common Fluids Format SDK", "index.xhtml#CFFSDKIntro", null ],
      [ "Application Programming Interface", "index.xhtml#API", [
        [ "Prerequisites for using the Application Programming Interface", "index.xhtml#Prerequestites", null ],
        [ "Overview", "index.xhtml#BriefAPIOverview", null ]
      ] ],
      [ "Data Models", "index.xhtml#DataModels", null ],
      [ "Files", "index.xhtml#Files", [
        [ "File Formats", "index.xhtml#FileFormats", null ]
      ] ],
      [ "Examples", "index.xhtml#Examples", null ]
    ] ],
    [ "Ansys Common Fluids API", "_c_f_f_a_p_i.xhtml", "_c_f_f_a_p_i" ],
    [ "Changelog", "changelog.xhtml", [
      [ "Release 2025 R2", "changelog.xhtml#v252", [
        [ "Added Methods", "changelog.xhtml#added", null ],
        [ "Deprecated Methods", "changelog.xhtml#deprecated", null ]
      ] ]
    ] ],
    [ "Ansys Common Fluids Data Models", "_data_models_overview.xhtml", "_data_models_overview" ],
    [ "Ansys Common Fluids Examples", "_c_f_f_s_d_k_examples.xhtml", [
      [ "Introduction", "_c_f_f_s_d_k_examples.xhtml#ExamplesIntro", [
        [ "Instructions to Build Examples", "_c_f_f_s_d_k_examples.xhtml#BuildInstructions", null ],
        [ "Reading Case and Data Files using C++ API", "_c_f_f_s_d_k_examples.xhtml#ImportExample", null ],
        [ "Writing Case and Data Files using C++ API", "_c_f_f_s_d_k_examples.xhtml#ExportExample", null ],
        [ "Reading Settings Using C++ API", "_c_f_f_s_d_k_examples.xhtml#SettingImportExample", null ],
        [ "Reading Discrete Phase Model (DPM) Particle Data Using C++ API", "_c_f_f_s_d_k_examples.xhtml#Particles", null ],
        [ "Reading a CFF file Using C API", "_c_f_f_s_d_k_examples.xhtml#CImportExample", null ],
        [ "Writing a CFF File Using C API", "_c_f_f_s_d_k_examples.xhtml#CExportExample", null ]
      ] ]
    ] ],
    [ "Ansys Common Fluids File Formats", "_file_formats_overview.xhtml", [
      [ "CFF File Formats", "_file_formats_overview.xhtml#FileFormatsIntro", [
        [ "CFF Project Format", "_file_formats_overview.xhtml#CFFProject", null ],
        [ "CFF Restart Format", "_file_formats_overview.xhtml#CFFRestart", null ],
        [ "CFF Post Format", "_file_formats_overview.xhtml#CFFPost", null ],
        [ "Important Notes on Processing Files Containing CFF Restart and CFF Post Data", "_file_formats_overview.xhtml#FFFormatNodes", null ]
      ] ]
    ] ],
    [ "Modules", "modules.xhtml", "modules" ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Functions", "namespacemembers_func.xhtml", null ],
        [ "Variables", "namespacemembers_vars.xhtml", null ],
        [ "Typedefs", "namespacemembers_type.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ],
      [ "Class Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Class Members", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_build_and_usage.xhtml",
"classansys_1_1_cff_base.xhtml#acaf3eef987d98a7af34c15b9b7954abc",
"classansys_1_1_cff_consumer.xhtml#a4dd882895c9baffbe018fb43a19fb1a3",
"classansys_1_1_cff_consumer.xhtml#ab02d01a0319c77ec3e29c603727abe83",
"classansys_1_1_cff_file_provider.xhtml#a7e0e067f10b0abcd65187528174211fd",
"classansys_1_1_cff_provider.xhtml#a387c2dc11a5c9ac4750b01e7d8bc3d71",
"classansys_1_1_cff_provider.xhtml#a9117ca1379a97b5fa7b1856058314c1c",
"classansys_1_1_cff_provider.xhtml#aec3ee0d10ddc84c1e7e4d3c8c72df56e",
"classansys_1_1_project_1_1_metadata.xhtml#aacd269f8408622db2061c364927f4e7b",
"classansys_1_1_project_1_1_project.xhtml#afe6dccd1d416c6e84967a68107af8515",
"classansys_1_1_project_1_1_run.xhtml#ab2fbdaed6b5ec4a4a5ff52df8a64b86da55f71554265fa2b739c33e46cf5bd26e",
"classansys_1_1_project_1_1_sim_base.xhtml#a0b6fee750eeb02e8068640758c6d8b0d",
"classansys_1_1_project_1_1_u_r_l.xhtml#ac1ced383f9b4e25d43c8b927a93423cf",
"group__typedefs.xhtml#ga34b3a7b0ee367c0bb505a000568524b7"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';