var classansys_1_1_cff_file_provider =
[
    [ "~CffFileProvider", "classansys_1_1_cff_file_provider.xhtml#a7e0e067f10b0abcd65187528174211fd", null ],
    [ "closeData", "classansys_1_1_cff_file_provider.xhtml#af9965e67687f5dbbaa8a93e435d51c5e", null ],
    [ "endReading", "classansys_1_1_cff_file_provider.xhtml#a00724b02c346637341945f21c9c6cc7c", null ],
    [ "getDatasetNameOfPhase", "classansys_1_1_cff_file_provider.xhtml#a308352d8f5e118e1c2db0f8e2e0424a5", null ],
    [ "getDatasetNameOfVariable", "classansys_1_1_cff_file_provider.xhtml#ad52f2e90551459db5025035789615f38", null ],
    [ "openData", "classansys_1_1_cff_file_provider.xhtml#a3d7ee57760a725f6a246ab53c1d7c54a", null ],
    [ "startReading", "classansys_1_1_cff_file_provider.xhtml#a80f6009e97e3a51b718be37582aefd3d", null ],
    [ "startReading", "classansys_1_1_cff_file_provider.xhtml#a0a1b2b94647f44bb81da61b5918c3e73", null ]
];