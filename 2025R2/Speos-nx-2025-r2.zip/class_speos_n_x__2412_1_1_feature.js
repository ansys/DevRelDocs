var class_speos_n_x__2412_1_1_feature =
[
    [ "Delete", "class_speos_n_x__2412_1_1_feature.xhtml#ac8cc8aecad6e8d51e18f35cf0127f99c", null ],
    [ "Update", "class_speos_n_x__2412_1_1_feature.xhtml#a51f0e84116935db637796345d15b353d", null ]
];