var class_speos_n_x__2412_1_1_folder_builder =
[
    [ "Add", "class_speos_n_x__2412_1_1_folder_builder.xhtml#a3edde4a5462dcfe792466658461faea7", null ],
    [ "Insert", "class_speos_n_x__2412_1_1_folder_builder.xhtml#ac018548ba37f67d204490f4206c6ffe4", null ],
    [ "IsCompatible", "class_speos_n_x__2412_1_1_folder_builder.xhtml#a69d01418cd8ff56cad7fe5412477c828", null ],
    [ "Remove", "class_speos_n_x__2412_1_1_folder_builder.xhtml#a12f4e2916ea81a1db85709bc53d9d0fe", null ]
];