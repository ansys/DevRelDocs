var class_speos_n_x__2412_1_1_result_l_x_p_builder =
[
    [ "CreateAreaEllipse", "class_speos_n_x__2412_1_1_result_l_x_p_builder.xhtml#a0d05427c0224b15030ab59bf1d4b6557", null ],
    [ "CreateAreaPolygon", "class_speos_n_x__2412_1_1_result_l_x_p_builder.xhtml#aae698d0462cfeaf3930e7b7c97fee602", null ],
    [ "CreateAreaRectangle", "class_speos_n_x__2412_1_1_result_l_x_p_builder.xhtml#a93d372b89be2b49b441fe2bd7d3038e1", null ],
    [ "RetrieveMeasureValue", "class_speos_n_x__2412_1_1_result_l_x_p_builder.xhtml#a4a67938bf70b21e0e258b9e63391a252", null ]
];