var classansys_1_1dpf_1_1Context =
[
    [ "EDpfLicenseContext", "classansys_1_1dpf_1_1Context.xhtml#a1149672f0fad6470e3533a15d358baef", [
      [ "eNone", "classansys_1_1dpf_1_1Context.xhtml#a1149672f0fad6470e3533a15d358baefabe988781e4e1de1c6a36fb698afbbe1f", null ],
      [ "eEntryLevel", "classansys_1_1dpf_1_1Context.xhtml#a1149672f0fad6470e3533a15d358baefa3524bc6ef2b323544131910a168307e4", null ],
      [ "ePremium", "classansys_1_1dpf_1_1Context.xhtml#a1149672f0fad6470e3533a15d358baefaac9bc97d5be545de7d5d731807e6238b", null ]
    ] ],
    [ "PluginLoadErrorMode", "classansys_1_1dpf_1_1Context.xhtml#a89c9954b0806e1ffbefd5d413d44a8e3", [
      [ "eSilent", "classansys_1_1dpf_1_1Context.xhtml#a89c9954b0806e1ffbefd5d413d44a8e3a1bca7792b0764f5436105430db6f5f91", null ],
      [ "eReportFirst", "classansys_1_1dpf_1_1Context.xhtml#a89c9954b0806e1ffbefd5d413d44a8e3af61fe2506df3f2bd107cfb1d8b4fa566", null ],
      [ "eReportAll", "classansys_1_1dpf_1_1Context.xhtml#a89c9954b0806e1ffbefd5d413d44a8e3a826fa616dd3899272e97b80a5c73dabc", null ]
    ] ],
    [ "Context", "classansys_1_1dpf_1_1Context.xhtml#ae26354fe1dea7b2691e115275704278b", null ],
    [ "defaultContext", "classansys_1_1dpf_1_1Context.xhtml#a05d1af3aea226b6cb8547d1d56c9c146", null ],
    [ "entryContext", "classansys_1_1dpf_1_1Context.xhtml#a30b9265329478de651ae53b753831bc4", null ],
    [ "errorOnPluginLoad", "classansys_1_1dpf_1_1Context.xhtml#ab36cb19d02596f0c9e84670632a7567c", null ],
    [ "getContext", "classansys_1_1dpf_1_1Context.xhtml#af4b49f2ed79e09c7d20d59895d52c139", null ],
    [ "getLicenseContext", "classansys_1_1dpf_1_1Context.xhtml#a75bf6a9e641e9c9f24d61ef6364672c8", null ],
    [ "getSetupFilePath", "classansys_1_1dpf_1_1Context.xhtml#a8e69df73d5d7695a12619e98bb4ef82b", null ],
    [ "premiumContext", "classansys_1_1dpf_1_1Context.xhtml#a8416bcd2b6a76249a97bf259851aa121", null ],
    [ "standaloneContext", "classansys_1_1dpf_1_1Context.xhtml#a327ad3dde1ba5c314c34d5b2552156f9", null ],
    [ "userDefinedContext", "classansys_1_1dpf_1_1Context.xhtml#af2efd2673fef4ce34b56f85dad9d5520", null ],
    [ "withEntryLevelLicense", "classansys_1_1dpf_1_1Context.xhtml#a6848f3f755ec83e57544e688182d534d", null ],
    [ "withErrorOnPluginLoad", "classansys_1_1dpf_1_1Context.xhtml#a5fe6bfb18b6d33dd88f16bb006bb0d8c", null ],
    [ "withPremiumLicense", "classansys_1_1dpf_1_1Context.xhtml#a33a89b830c012a1563bf6534d5de7d48", null ]
];