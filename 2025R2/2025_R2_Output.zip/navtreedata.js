/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "Getting started", "getting_started.xhtml", null ],
    [ "User guide", "modules.xhtml", "modules" ],
    [ "Operators", "operators_page.xhtml", null ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Typedefs", "namespacemembers_type.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", "functions_vars" ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Examples", "examples.xhtml", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"AveragingTest_8cpp-example.xhtml",
"classansys_1_1dpf_1_1CustomTypeFieldsContainer.xhtml",
"classansys_1_1dpf_1_1DpfTypes.xhtml#a9977945710983bc03d2940fa007847b2",
"classansys_1_1dpf_1_1FieldDefinition.xhtml#af7d513babc5f529f1ba3e324f5e0b60a",
"classansys_1_1dpf_1_1MeshedRegion.xhtml#aed167b03463f42d94d424797529eccad",
"classansys_1_1dpf_1_1Operator.xhtml#ab8effed66eaf13176c6d68eb3fd2c11f",
"classansys_1_1dpf_1_1OperatorMain.xhtml#ad28e17d0d720aa99a30bce78623963fc",
"classansys_1_1dpf_1_1ResultInfo.xhtml#a8d15940ba2e8825a0eae2239a65f2311",
"classansys_1_1dpf_1_1TimeFreqSupport.xhtml#a16e1c71584c44429329b23360b537630",
"classansys_1_1dpf_1_1Workflow.xhtml#a7a07e03ab9fd7ec733fd0972818eef28",
"functions_p.xhtml",
"structansys_1_1dpf_1_1TypeDescriptor.xhtml",
"structansys_1_1dpf_1_1locations.xhtml#acfb36fa3e6c22d12b971fdf941d6dab8"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';