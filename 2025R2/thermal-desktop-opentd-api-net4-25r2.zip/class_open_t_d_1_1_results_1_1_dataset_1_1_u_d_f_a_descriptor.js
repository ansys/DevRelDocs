var class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor =
[
    [ "UDFADescriptor", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor.xhtml#a606ab52d324644ac5075ea510d7e3ca0", null ],
    [ "Equals", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor.xhtml#add511637e960ead255652f455efd4f03", null ],
    [ "GetHashCode", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor.xhtml#adeca1e69975d41965c75e370489c46f0", null ],
    [ "Name", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor.xhtml#a2f60c03366626fa3b02a042d0197d058", null ],
    [ "Size", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor.xhtml#a5657d604cd0783be5cf6c1e8510da4b9", null ],
    [ "Subtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor.xhtml#a4260422987d3b7cc00bca4e6aea58419", null ],
    [ "UDFAType", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_descriptor.xhtml#a4815569f1fe21583019cc0a7f54d9af8", null ]
];