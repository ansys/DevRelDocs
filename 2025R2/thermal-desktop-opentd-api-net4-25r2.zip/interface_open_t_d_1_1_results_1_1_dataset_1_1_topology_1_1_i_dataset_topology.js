var interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology =
[
    [ "GetConductorList", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a1f37125464bfcb0f35d2d19fa879aaae", null ],
    [ "GetFTie", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#ad6f4162039dcc8c26ed52257f39d9c5a", null ],
    [ "GetIFace", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a4b0d3eb99d4fb578109f6fe6a6d2b8a5", null ],
    [ "GetLump", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a8504afda6506da66bffd1b110f631019", null ],
    [ "GetNode", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#aad15574012d9e88e5810c45ebeeeeab5", null ],
    [ "GetPath", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a1564fa492129834a15b66a749200b14b", null ],
    [ "GetSubmodelConductors", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a8a390aabb39de75cc8e26b6f6ed7e3c5", null ],
    [ "GetSubmodelFTies", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a69cb6cf95c766fe14cfa60319012193e", null ],
    [ "GetSubmodelIFaces", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a192b242dbcbba62b2161b86d59758f66", null ],
    [ "GetSubmodelLumps", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a1e4a7a34db522f1ee632d2e2293632c5", null ],
    [ "GetSubmodelNodes", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a60a83353eacec4682a0527f1e26c6758", null ],
    [ "GetSubmodelPaths", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a8d6d4e564968d758875f15960c203ca1", null ],
    [ "GetSubmodelTies", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#adb84664e9c357e707f5e2ed52150de29", null ],
    [ "GetTie", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#acbf9b814752b4c99ac03298d501e7505", null ],
    [ "Conductors", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a72f6c34110b38dab890b6168e1176ae5", null ],
    [ "FTies", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a15c1e0cc8d6e482ccc1cd9f868bc8ef3", null ],
    [ "IFaces", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a91099dae0d7ee99b0449c21a5aefee95", null ],
    [ "Lumps", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a945119ad0bacb985971e23be88ff269b", null ],
    [ "Nodes", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#ad6c6a808f98da3165d0a117e64c9fb47", null ],
    [ "Paths", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a2516d68a99da470c6e7d8a1ac052f11d", null ],
    [ "Ties", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_dataset_topology.xhtml#a08bcadb9e94ce2ca19d5323a34422a1f", null ]
];