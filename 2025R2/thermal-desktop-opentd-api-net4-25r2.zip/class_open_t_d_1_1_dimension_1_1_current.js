var class_open_t_d_1_1_dimension_1_1_current =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_current.xhtml#a4ca7d4c6ca4dee6d612c4ba8f8d44815", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_current.xhtml#a75f2eb4882c35632b09fd09cf4fbf0a7", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_current.xhtml#ab97088eed4305b6c4fe3ed9c6d7ce02f", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_current.xhtml#a1be7a884a69a767a2725f5ddabecd2df", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_current.xhtml#aa97f8a316efcff835d5c65f1b56f6ae6", null ]
];