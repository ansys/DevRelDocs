var interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_node_info =
[
    [ "Conductors", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_node_info.xhtml#ae572840acbd12841930b39825c35710b", null ],
    [ "ItemIdentifier", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_node_info.xhtml#aecda9a8daeb6a4deb0004989c234f6da", null ],
    [ "NodeType", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_node_info.xhtml#acdd477229fefb7956ffca128242348ba", null ],
    [ "Offset", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_node_info.xhtml#a8ec4937353a50914360db55e441e8772", null ],
    [ "SindaName", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_node_info.xhtml#a3ab97edc014acb89da92ca8b3e1b8a32", null ],
    [ "Ties", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_node_info.xhtml#a2a7f1575be1b0ca8f011c9ca3b4dc280", null ]
];