var class_open_t_d_1_1_rc_heater_sense_data =
[
    [ "HeaterSenseTypes", "class_open_t_d_1_1_rc_heater_sense_data.xhtml#a87fce69b7f81bc1333efb32593c1e371", [
      [ "AVERAGE_WEIGHTED_AREA", "class_open_t_d_1_1_rc_heater_sense_data.xhtml#a87fce69b7f81bc1333efb32593c1e371ab15ac44a9a43ab17e0656fd46e7d9b45", null ],
      [ "MAXIMUM_TEMPERATURE", "class_open_t_d_1_1_rc_heater_sense_data.xhtml#a87fce69b7f81bc1333efb32593c1e371a5be47042d2a462e9a638d759cb2f3187", null ],
      [ "MINIMUM_TEMPERATURE", "class_open_t_d_1_1_rc_heater_sense_data.xhtml#a87fce69b7f81bc1333efb32593c1e371a7aedc81698533a7faa21775ce0b2feb7", null ],
      [ "USER_INPUT_LOGIC", "class_open_t_d_1_1_rc_heater_sense_data.xhtml#a87fce69b7f81bc1333efb32593c1e371ae35dc75ead2a83114236ce0621e987de", null ]
    ] ],
    [ "RcHeaterSenseData", "class_open_t_d_1_1_rc_heater_sense_data.xhtml#a347a0f19275f65870de6e0a81720e7cf", null ],
    [ "HeaterSenseType", "class_open_t_d_1_1_rc_heater_sense_data.xhtml#a078fad4c50782824d86a378a1bf3c3d8", null ],
    [ "UserLogic", "class_open_t_d_1_1_rc_heater_sense_data.xhtml#ab4f7a14aff597d484549488f5196284c", null ]
];