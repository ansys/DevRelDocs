var class_open_t_d_1_1_solver_design_data =
[
    [ "SolverDesignData", "class_open_t_d_1_1_solver_design_data.xhtml#a520af66719ebf0082e6ae6d3f68df313", null ],
    [ "comment", "class_open_t_d_1_1_solver_design_data.xhtml#a147eb69affc4d91d21411d9c93e0056a", null ],
    [ "disabled", "class_open_t_d_1_1_solver_design_data.xhtml#a5338b24def35e440137443002ebf7cb0", null ],
    [ "maxValue", "class_open_t_d_1_1_solver_design_data.xhtml#a674d77c899d0f7835a0aaf5e79f71ac4", null ],
    [ "maxValueExp", "class_open_t_d_1_1_solver_design_data.xhtml#a82a737a1119b04a59c46a4f269b99a7d", null ],
    [ "minValue", "class_open_t_d_1_1_solver_design_data.xhtml#a32bf30b30e4a69840fff8845c8459415", null ],
    [ "minValueExp", "class_open_t_d_1_1_solver_design_data.xhtml#a1daf9b924c025332a555467d53b56df1", null ],
    [ "name", "class_open_t_d_1_1_solver_design_data.xhtml#a70f15408b2370e3f609ec40745550466", null ],
    [ "useMax", "class_open_t_d_1_1_solver_design_data.xhtml#a95cf6a305ff0aa0d75228b4b14e096e6", null ],
    [ "useMin", "class_open_t_d_1_1_solver_design_data.xhtml#a0fecba24462badd5c6414153609116a9", null ]
];