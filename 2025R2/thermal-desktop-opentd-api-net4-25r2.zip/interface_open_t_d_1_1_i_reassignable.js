var interface_open_t_d_1_1_i_reassignable =
[
    [ "CreateIn", "interface_open_t_d_1_1_i_reassignable.xhtml#a94cbc52d002a10e44f5dc2daaf9c87db", null ],
    [ "UpdateIn", "interface_open_t_d_1_1_i_reassignable.xhtml#a90dffde7dd442e9d940f9e5c5fabde14", null ]
];