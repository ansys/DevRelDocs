var class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences =
[
    [ "GraphicsResolutionPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml#a6feab6cc64241b1df47c8adbac24df3b", null ],
    [ "GraphicsResolutionPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml#a38957c2312b6933e69a6aa5ca7b3e142", null ],
    [ "Update", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml#a34ea03e62f3ca8ee87c7d43c5d1b5e05", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml#a1ada99d86aa33136d867fae5ae83b534", null ],
    [ "facetRes", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml#a71ee73f0fe98e19f9a4f941fa68d6bc6", null ],
    [ "maxSurfaceFacetsPerFullCircle", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml#a0621d533fc47ccfa244b0065d0dae0be", null ],
    [ "NeedsUpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml#a012bb0c5f39ee504be222b4292f5ffc3", null ],
    [ "pipeDegPerPointIndex", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml#a9e5978f26483562c9882457d3851512d", null ]
];