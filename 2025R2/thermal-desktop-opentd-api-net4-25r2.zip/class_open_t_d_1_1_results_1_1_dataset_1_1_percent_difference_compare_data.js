var class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data =
[
    [ "PercentDifferenceCompareData", "class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data.xhtml#a89704dfbce50164ed71a0ef34b7e4e10", null ],
    [ "Compare", "class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data.xhtml#a1274110116ab774d95b910295ec9b9a6", null ],
    [ "ComparerInput", "class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data.xhtml#ab28b92faca48552bd62d7b4ecca18215", null ],
    [ "ComparerOutput", "class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data.xhtml#ad5d75637e9bd0c8a2d1f3f575dedcaaf", null ],
    [ "Floor", "class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data.xhtml#a8c92ef9fcb92aa9a4b6fdde741079059", null ],
    [ "PercentTol", "class_open_t_d_1_1_results_1_1_dataset_1_1_percent_difference_compare_data.xhtml#acd196836c14cd782b1ba0b8c158eb4eb", null ]
];