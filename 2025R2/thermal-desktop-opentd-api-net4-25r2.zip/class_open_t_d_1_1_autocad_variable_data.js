var class_open_t_d_1_1_autocad_variable_data =
[
    [ "Types", "class_open_t_d_1_1_autocad_variable_data.xhtml#a4b79f509bf7ac6d97b6fb348bed01f49", [
      [ "UNKONWN", "class_open_t_d_1_1_autocad_variable_data.xhtml#a4b79f509bf7ac6d97b6fb348bed01f49ad49ba727353cb597da5cb66600f3588c", null ],
      [ "INT", "class_open_t_d_1_1_autocad_variable_data.xhtml#a4b79f509bf7ac6d97b6fb348bed01f49a53f93baa3057821107c750323892fa92", null ],
      [ "DOUBLE", "class_open_t_d_1_1_autocad_variable_data.xhtml#a4b79f509bf7ac6d97b6fb348bed01f49afd3e4ece78a7d422280d5ed379482229", null ],
      [ "STRING", "class_open_t_d_1_1_autocad_variable_data.xhtml#a4b79f509bf7ac6d97b6fb348bed01f49a63b588d5559f64f89a416e656880b949", null ]
    ] ],
    [ "AutocadVariableData", "class_open_t_d_1_1_autocad_variable_data.xhtml#a6cb5bfbaf5923deb7132281d54e3d1b8", null ],
    [ "Name", "class_open_t_d_1_1_autocad_variable_data.xhtml#a15d205a32d055c61eeb75759adca8ddd", null ],
    [ "Type", "class_open_t_d_1_1_autocad_variable_data.xhtml#a9b0a95858f4fa675cf5c1bf47dd3b7af", null ],
    [ "ValueDouble", "class_open_t_d_1_1_autocad_variable_data.xhtml#a44de94a474f4c6ee006b12e6208ca721", null ],
    [ "ValueInt", "class_open_t_d_1_1_autocad_variable_data.xhtml#a826946048cca76855316c32440be6b92", null ],
    [ "ValueString", "class_open_t_d_1_1_autocad_variable_data.xhtml#a7f08ded585216395245f8dae7c52319e", null ]
];