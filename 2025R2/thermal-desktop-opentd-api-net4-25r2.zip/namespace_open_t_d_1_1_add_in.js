var namespace_open_t_d_1_1_add_in =
[
    [ "AddInContext", "class_open_t_d_1_1_add_in_1_1_add_in_context.xhtml", "class_open_t_d_1_1_add_in_1_1_add_in_context" ],
    [ "IAddIn", "interface_open_t_d_1_1_add_in_1_1_i_add_in.xhtml", "interface_open_t_d_1_1_add_in_1_1_i_add_in" ],
    [ "IProgressReporter", "interface_open_t_d_1_1_add_in_1_1_i_progress_reporter.xhtml", "interface_open_t_d_1_1_add_in_1_1_i_progress_reporter" ],
    [ "IUserBreak", "interface_open_t_d_1_1_add_in_1_1_i_user_break.xhtml", "interface_open_t_d_1_1_add_in_1_1_i_user_break" ],
    [ "ProgressBar", "class_open_t_d_1_1_add_in_1_1_progress_bar.xhtml", "class_open_t_d_1_1_add_in_1_1_progress_bar" ],
    [ "ProgressEventArgs", "class_open_t_d_1_1_add_in_1_1_progress_event_args.xhtml", "class_open_t_d_1_1_add_in_1_1_progress_event_args" ],
    [ "ProgressToken", "class_open_t_d_1_1_add_in_1_1_progress_token.xhtml", "class_open_t_d_1_1_add_in_1_1_progress_token" ],
    [ "UserBreak", "class_open_t_d_1_1_add_in_1_1_user_break.xhtml", "class_open_t_d_1_1_add_in_1_1_user_break" ]
];