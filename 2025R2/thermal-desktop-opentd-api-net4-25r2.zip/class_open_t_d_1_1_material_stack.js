var class_open_t_d_1_1_material_stack =
[
    [ "CreateIn", "class_open_t_d_1_1_material_stack.xhtml#aeb39d949254194ff19cc39fc189eb035", null ],
    [ "ModifyName", "class_open_t_d_1_1_material_stack.xhtml#a1343e99cd573893ee16d36c337fde7b1", null ],
    [ "ProxyRename", "class_open_t_d_1_1_material_stack.xhtml#a0f2ff397d309e08b18f5306569ff40e2", null ],
    [ "Rename", "class_open_t_d_1_1_material_stack.xhtml#ab83691a4d2f3bd34519f9372cfc73951", null ],
    [ "SetFrom", "class_open_t_d_1_1_material_stack.xhtml#aa2e0aa2793e95a56891ef59fb4843ca2", null ],
    [ "ToString", "class_open_t_d_1_1_material_stack.xhtml#af373d173d2d75fd2b4c6edb8ee4165b2", null ],
    [ "Update", "class_open_t_d_1_1_material_stack.xhtml#a191f3dbcf4c04507f99fa5fee3870166", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_material_stack.xhtml#ab4316c6698c12908e4563f6722b50862", null ],
    [ "UpdateIn", "class_open_t_d_1_1_material_stack.xhtml#a1e5228ce309c9a85ec09e8119318024d", null ],
    [ "TdProxy", "class_open_t_d_1_1_material_stack.xhtml#a0da16592e6b635ca0def27b355d669b3", null ],
    [ "_n", "class_open_t_d_1_1_material_stack.xhtml#a4546becfb33773b2b9d0ae2264c9dd2d", null ],
    [ "Comment", "class_open_t_d_1_1_material_stack.xhtml#a93da4e1189a5dfba7825077c21f89a56", null ],
    [ "GenerateLateralConductors", "class_open_t_d_1_1_material_stack.xhtml#a2b57c6858159ba85a3957283292edff2", null ],
    [ "Layers", "class_open_t_d_1_1_material_stack.xhtml#ad72839a5fa60c97f91991c9265afaaa1", null ],
    [ "Name", "class_open_t_d_1_1_material_stack.xhtml#a81ee04aec6314a6dd404826b41564162", null ]
];