var class_open_t_d_1_1_user_preferences_1_1_preferences =
[
    [ "NeedsUpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_preferences.xhtml#a012bb0c5f39ee504be222b4292f5ffc3", null ]
];