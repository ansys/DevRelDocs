var class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder =
[
    [ "AdditionalDatasetInfoHolder", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#a566eadf1c52a2ab52a60f84e9c439dd6", null ],
    [ "GetDatasetReader", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#acf5472c5ff8dee25479534a7b47779cd", null ],
    [ "Compare", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#ac8abea207923f75835222bb583c972a2", null ],
    [ "HeatFlow", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#aea24167ede2a7555ae4598a9569ad26d", null ],
    [ "HeatFlowMap", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#a3cd2fa3aaafa1e384dd158de0a650317", null ],
    [ "Heatrate", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#a009bf2739d0d20886296a5148620d187", null ],
    [ "Radk", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#afa80f84a3bdc629cf522ca85fe67e29d", null ],
    [ "Sinda", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#a695cd78cb678a8212b60632408e73924", null ],
    [ "Text", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#af32b15b269051e60df27671cb0fb57e2", null ],
    [ "TextTransient", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info_holder.xhtml#a13b7cb2aa48a4cd142ece9bbc0e17872", null ]
];