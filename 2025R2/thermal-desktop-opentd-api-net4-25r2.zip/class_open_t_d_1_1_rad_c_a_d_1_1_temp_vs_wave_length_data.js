var class_open_t_d_1_1_rad_c_a_d_1_1_temp_vs_wave_length_data =
[
    [ "TempVsWaveLengthData", "class_open_t_d_1_1_rad_c_a_d_1_1_temp_vs_wave_length_data.xhtml#a3e7d4e9a21994472570cebac2deca951", null ],
    [ "data", "class_open_t_d_1_1_rad_c_a_d_1_1_temp_vs_wave_length_data.xhtml#afd4b98b4f534aa754385220d3b4f958c", null ],
    [ "offOrOn", "class_open_t_d_1_1_rad_c_a_d_1_1_temp_vs_wave_length_data.xhtml#a2b89ed69bdbfe8328f8ee7df341f9e7e", null ],
    [ "temperatures", "class_open_t_d_1_1_rad_c_a_d_1_1_temp_vs_wave_length_data.xhtml#ad7a3f580eef53ab817fea0321e07e50e", null ],
    [ "waveLengths", "class_open_t_d_1_1_rad_c_a_d_1_1_temp_vs_wave_length_data.xhtml#a9bfeff9ac24dfba39c0d274635e53649", null ]
];