var class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_enumerator =
[
    [ "DataArrayEnumerator", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_enumerator.xhtml#aa8d6b4f4c9a6e8b25a0fd1de9fc41139", null ],
    [ "Dispose", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_enumerator.xhtml#aede3155cccc469f0f42ba149609082d7", null ],
    [ "Dispose", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_enumerator.xhtml#a779c2e32f89196d0923f0294690cf96a", null ],
    [ "MoveNext", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_enumerator.xhtml#a34d1ba46ef47779ab0f7568154ec5b9e", null ],
    [ "Reset", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_enumerator.xhtml#a9b392435bac8af3e5f6a0d7b77a50c00", null ],
    [ "Current", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_array_enumerator.xhtml#a1c4775d73912b6a82d2eea4712471094", null ]
];