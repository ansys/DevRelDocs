var class_open_t_d_1_1_rad_c_a_d_1_1_global_contact =
[
    [ "fluxPerLengthOrAbsolute", "class_open_t_d_1_1_rad_c_a_d_1_1_global_contact.xhtml#aab25ab5e72008d0355faf336b10c76bd", null ],
    [ "useContact", "class_open_t_d_1_1_rad_c_a_d_1_1_global_contact.xhtml#abeada218347ec1ebff44105baffbf0a0", null ],
    [ "value", "class_open_t_d_1_1_rad_c_a_d_1_1_global_contact.xhtml#a952d8f525f02bfb2ce8da928feb71775", null ],
    [ "valueExp", "class_open_t_d_1_1_rad_c_a_d_1_1_global_contact.xhtml#ac4854296eaa2d405d8edbfbff723bae6", null ]
];