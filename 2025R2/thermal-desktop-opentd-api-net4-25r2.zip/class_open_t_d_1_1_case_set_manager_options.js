var class_open_t_d_1_1_case_set_manager_options =
[
    [ "DuplicateNodes", "class_open_t_d_1_1_case_set_manager_options.xhtml#a079c11b40ab55f3e9e6a92c628a76ee6", [
      [ "PROMPT_IF_FOUND", "class_open_t_d_1_1_case_set_manager_options.xhtml#a079c11b40ab55f3e9e6a92c628a76ee6a6ea4ae4e5bdfb840c0ed79d452b2dcd7", null ],
      [ "ALLOW_IN_MODEL", "class_open_t_d_1_1_case_set_manager_options.xhtml#a079c11b40ab55f3e9e6a92c628a76ee6a6293888fbbae000288ebe64c5d9a703b", null ],
      [ "AUTO_RENUMBER", "class_open_t_d_1_1_case_set_manager_options.xhtml#a079c11b40ab55f3e9e6a92c628a76ee6ab62557b4b57dca5fd1b987c299e732c4", null ]
    ] ],
    [ "CaseSetManagerOptions", "class_open_t_d_1_1_case_set_manager_options.xhtml#ade86a90629d8e6b95569c34a065319ae", null ],
    [ "CaseSetManagerOptions", "class_open_t_d_1_1_case_set_manager_options.xhtml#af7169396f5a4f43c452ede3c98b8af21", null ],
    [ "Update", "class_open_t_d_1_1_case_set_manager_options.xhtml#af51557f9437cf65c5c4c3766f7480fad", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_case_set_manager_options.xhtml#a737462070e85b7c4d47f1f6b42fb891d", null ],
    [ "BatchControl", "class_open_t_d_1_1_case_set_manager_options.xhtml#a924085ccb13f9614acbb1ad3d69bdc88", null ],
    [ "duplicateNodes", "class_open_t_d_1_1_case_set_manager_options.xhtml#a69d0b68fa6e2a7ec97c5e2114b121fd5", null ],
    [ "ExpectedDupNodes", "class_open_t_d_1_1_case_set_manager_options.xhtml#af1dd7a44e052de62b4c532a78f4a1fbf", null ],
    [ "LowerPriority", "class_open_t_d_1_1_case_set_manager_options.xhtml#a36cfcda8f4406d4d54a9089da89b75b8", null ],
    [ "RunBatch", "class_open_t_d_1_1_case_set_manager_options.xhtml#abda2d1c05dd731b6893d36e88e6868bf", null ],
    [ "SaveDwg", "class_open_t_d_1_1_case_set_manager_options.xhtml#a11851b779d88cb4a32c308269926820d", null ],
    [ "ShowTextScreenDuringRun", "class_open_t_d_1_1_case_set_manager_options.xhtml#a6296bf448dba351db6596213c8c0ce9b", null ]
];