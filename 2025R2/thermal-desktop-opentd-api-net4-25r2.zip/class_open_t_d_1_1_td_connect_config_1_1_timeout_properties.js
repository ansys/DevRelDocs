var class_open_t_d_1_1_td_connect_config_1_1_timeout_properties =
[
    [ "DelayMs", "class_open_t_d_1_1_td_connect_config_1_1_timeout_properties.xhtml#a6eea9467ebd3a7c6af6b7aa5c35cf06f", null ],
    [ "NumberOfTries", "class_open_t_d_1_1_td_connect_config_1_1_timeout_properties.xhtml#a880c83812dfbeab7ae78b7f67f2bd6da", null ]
];