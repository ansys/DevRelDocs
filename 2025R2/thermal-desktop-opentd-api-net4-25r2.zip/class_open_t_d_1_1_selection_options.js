var class_open_t_d_1_1_selection_options =
[
    [ "SelectionOptions", "class_open_t_d_1_1_selection_options.xhtml#a77f1a7bde9e97c6317bd981d98e85fda", null ],
    [ "AllowedAcadTypes", "class_open_t_d_1_1_selection_options.xhtml#ad21ee57666799a0c08ba6ccbd832805e", null ],
    [ "AllowedDomainTypes", "class_open_t_d_1_1_selection_options.xhtml#a601a3cfe8287514b04ec9c3a910b4b9f", null ],
    [ "EnableDomains", "class_open_t_d_1_1_selection_options.xhtml#aa4ccd3674fd0602b40391a9e0b3e1011", null ],
    [ "EnableFilterDialog", "class_open_t_d_1_1_selection_options.xhtml#ab8e10585e720189ad2516d199f5d28b1", null ],
    [ "EnableGroupSelection", "class_open_t_d_1_1_selection_options.xhtml#aec1e341a5248eac84a29780f3605180a", null ],
    [ "EnableModelBrowserSelection", "class_open_t_d_1_1_selection_options.xhtml#a4e59a3fe49a54fce8ef9d3152c94f2cd", null ],
    [ "ForceSingleOperation", "class_open_t_d_1_1_selection_options.xhtml#ad827c5d3158a09f4f16075275053c6ba", null ],
    [ "Prompt", "class_open_t_d_1_1_selection_options.xhtml#a102a34ca93c0e311cb3154708a989d5a", null ]
];