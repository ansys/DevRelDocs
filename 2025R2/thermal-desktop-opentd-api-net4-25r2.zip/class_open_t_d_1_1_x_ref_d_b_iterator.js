var class_open_t_d_1_1_x_ref_d_b_iterator =
[
    [ "XRefDBIterator", "class_open_t_d_1_1_x_ref_d_b_iterator.xhtml#a60ef2f363d24c8ade7bd2c3d8131fe7c", null ],
    [ "DbObject", "class_open_t_d_1_1_x_ref_d_b_iterator.xhtml#a837a740ab9d60fc34390423ab594a074", null ],
    [ "Done", "class_open_t_d_1_1_x_ref_d_b_iterator.xhtml#a974b0f7325cde2c27fb0fcc7268a1cb0", null ],
    [ "Step", "class_open_t_d_1_1_x_ref_d_b_iterator.xhtml#a3a96afb7cb67a1d3043117ac37f39783", null ]
];