var class_open_t_d_1_1_dimension_1_1_torque =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_torque.xhtml#a6f449271ca5919df4b849097b1f8482e", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_torque.xhtml#a2abd98975ffc13eb8a476d9b7c3ffeaf", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_torque.xhtml#a8317d72f5c5cc7517f0e390a978bd9a0", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_torque.xhtml#ae730f498d654f4a3d1442fdefd44af26", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_torque.xhtml#a075f41332b8e07e363e246e7926d470e", null ]
];