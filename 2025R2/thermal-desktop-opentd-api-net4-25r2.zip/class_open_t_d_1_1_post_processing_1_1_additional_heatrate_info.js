var class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info =
[
    [ "SourceTypes", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254", [
      [ "TOTAL_ABS", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254a0cc54f4b5c48a75701797c03f26c9777", null ],
      [ "DIRECT_INC", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254a54d62b41d60269a008b4a0936572e0d1", null ],
      [ "NUMBER_OF_RAYS", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254a1cab6735fba67c7c2cdf45de9a58c424", null ],
      [ "TIME_AVG_TOTAL_ABS", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254a0bf4bf2ffdf377ccbdf403f924659224", null ],
      [ "DIRECT_ABS", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254a741013204ef2fe02b828a94d0607af4a", null ],
      [ "REFLECT_ABS", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254af4b03a77f39331c65a7b36904c3b4626", null ],
      [ "DIRECT_ERROR", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254aa4d57e99289b7174aad4f9cc45406131", null ],
      [ "ABSORBED_ERROR", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af786c6dc5ec65f925132bd315db46254a1d7e94677bdafdd6c41e16e8dfd4f835", null ]
    ] ],
    [ "AdditionalHeatrateInfo", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#a63f496e71d9d5076b092fb4be8d77844", null ],
    [ "_pathname", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#a00d93b38fc9b743e486c5a10251e6890", null ],
    [ "Albedo", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#ad61517bee445937b211a987f47584988", null ],
    [ "DiffuseSkyAlbedo", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#a58e059d02888034364ea9efdba783744", null ],
    [ "DiffuseSkyIR", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#a7885d2c0bef31c19f5da3f3f9f7849d9", null ],
    [ "DiffuseSkySolar", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af5e876e03c28986fc84910947ae93f21", null ],
    [ "DivideByArea", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#af828ec5b9fb9701bb5fbb94bcfceebae", null ],
    [ "Pathname", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#adf6ebaab63c773c8f54dafc548bfee91", null ],
    [ "Planetshine", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#a2265dabb536c9c044b89176d3a2b7fd7", null ],
    [ "Solar", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#a6eb4744ba6e8dca9f458b4e9c25aec2a", null ],
    [ "SourceType", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#a3954ec6fa57d26bd55e466f703b50203", null ],
    [ "TdClassName", "class_open_t_d_1_1_post_processing_1_1_additional_heatrate_info.xhtml#ab352578bf3691270b61651f567077073", null ]
];