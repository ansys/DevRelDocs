var class_open_t_d_1_1_bivariate_array_data =
[
    [ "BivariateArrayData", "class_open_t_d_1_1_bivariate_array_data.xhtml#ae2f124b0750d23895b1ac08dc0a4c3df", null ],
    [ "BivariateArrayData", "class_open_t_d_1_1_bivariate_array_data.xhtml#a8020855f5b683035779f325cd77ba2f3", null ],
    [ "Value", "class_open_t_d_1_1_bivariate_array_data.xhtml#ad90ff99321054794b1ad368200ce92cd", null ],
    [ "xValues", "class_open_t_d_1_1_bivariate_array_data.xhtml#a93277638fd7cc0f9cedcbff630b04fc6", null ],
    [ "yValues", "class_open_t_d_1_1_bivariate_array_data.xhtml#a00d676d30d62b32ee82960a35da1c2ec", null ],
    [ "zValues", "class_open_t_d_1_1_bivariate_array_data.xhtml#a69967547e90aa2c32cae55df3484567f", null ]
];