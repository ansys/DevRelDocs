var class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion =
[
    [ "CompareAssertion", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml#a2f2f5485e8226fdc934d82218a1ea514", null ],
    [ "CompareAssertion", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml#a63d36a653db726206341f02592e64e37", null ],
    [ "ResetResult", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml#a0b6bbf9a19598e6a53a09af167b32bb8", null ],
    [ "TestAssertion", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml#a166cb4492bf26039de990b2e9be87393", null ],
    [ "AssertDatasetsSame", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml#ae53bfe4337ed4ade231d0a058eda5cde", null ],
    [ "Comparer", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml#a6d8ce061ea3c62f60796c909e29c67de", null ],
    [ "Message", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml#ac0af4b17ffe219b2665f2c2b96c3baf1", null ],
    [ "Success", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_assertion.xhtml#a2221cabf460f8efb5ebc840c36e80687", null ]
];