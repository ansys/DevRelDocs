var class_open_t_d_1_1_nurbs_data =
[
    [ "NurbsData", "class_open_t_d_1_1_nurbs_data.xhtml#acc7401ed859b61d1dc2752009c20d9f5", null ],
    [ "Closed", "class_open_t_d_1_1_nurbs_data.xhtml#ad203f2d5d0d26b12b155c6fae634e29f", null ],
    [ "ControlPoints", "class_open_t_d_1_1_nurbs_data.xhtml#ae350f2947362bd34dc177a248150d245", null ],
    [ "ControlPointTolerance", "class_open_t_d_1_1_nurbs_data.xhtml#a894a994478f7ff87e6ba41960f9cfdfa", null ],
    [ "Degree", "class_open_t_d_1_1_nurbs_data.xhtml#aaf208589c85e11444168728069753a7e", null ],
    [ "Knots", "class_open_t_d_1_1_nurbs_data.xhtml#a691ebcef2e3739d0fa5e5694613d98f3", null ],
    [ "KnotTolerance", "class_open_t_d_1_1_nurbs_data.xhtml#af2e2f6a0cf3a75a9b710fc24a6c0dac2", null ],
    [ "Periodic", "class_open_t_d_1_1_nurbs_data.xhtml#a6dce4a65dcd8ba11d4b521478a8f79ee", null ],
    [ "Rational", "class_open_t_d_1_1_nurbs_data.xhtml#a423254502138ddf0103da6b89d3aec8a", null ],
    [ "Weights", "class_open_t_d_1_1_nurbs_data.xhtml#a2415f5654d64dd108882222a73f36777", null ]
];