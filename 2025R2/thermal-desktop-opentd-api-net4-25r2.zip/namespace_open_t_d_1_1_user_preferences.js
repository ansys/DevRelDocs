var namespace_open_t_d_1_1_user_preferences =
[
    [ "Acceleration", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml", "class_open_t_d_1_1_user_preferences_1_1_acceleration" ],
    [ "AdvancedPreferences", "class_open_t_d_1_1_user_preferences_1_1_advanced_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_advanced_preferences" ],
    [ "CalculationsPreferences", "class_open_t_d_1_1_user_preferences_1_1_calculations_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_calculations_preferences" ],
    [ "GraphicsResolutionPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_graphics_resolution_preferences" ],
    [ "GraphicsSizePreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_size_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_graphics_size_preferences" ],
    [ "GraphicsTextPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_text_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_graphics_text_preferences" ],
    [ "GraphicsVisibilityPreferences", "class_open_t_d_1_1_user_preferences_1_1_graphics_visibility_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_graphics_visibility_preferences" ],
    [ "Preferences", "class_open_t_d_1_1_user_preferences_1_1_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_preferences" ],
    [ "SindaPreferences", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences" ],
    [ "UnitsPreferences", "class_open_t_d_1_1_user_preferences_1_1_units_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_units_preferences" ],
    [ "UserPreferences", "class_open_t_d_1_1_user_preferences_1_1_user_preferences.xhtml", "class_open_t_d_1_1_user_preferences_1_1_user_preferences" ]
];