var interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_conductor_info =
[
    [ "FromNode", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_conductor_info.xhtml#a506366d32be57961b38fd40bda71ed7c", null ],
    [ "IsRad", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_conductor_info.xhtml#af76448a8234c10afd4ae7fa2157b9d56", null ],
    [ "ItemIdentifier", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_conductor_info.xhtml#aecda9a8daeb6a4deb0004989c234f6da", null ],
    [ "Offset", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_conductor_info.xhtml#a592917c660dcc4d23c95b5cf28b1e4fb", null ],
    [ "SindaName", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_conductor_info.xhtml#a3ab97edc014acb89da92ca8b3e1b8a32", null ],
    [ "ToNode", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_conductor_info.xhtml#aa9b638bdb76ed88a14ae0136b63bf113", null ]
];