var class_open_t_d_1_1_case_set_manager =
[
    [ "CaseSetManager", "class_open_t_d_1_1_case_set_manager.xhtml#a727fdc6fb75205ef2fcf78858525a421", null ],
    [ "Add", "class_open_t_d_1_1_case_set_manager.xhtml#a3d850fc8e8e45e31376f56a82e47791c", null ],
    [ "Delete", "class_open_t_d_1_1_case_set_manager.xhtml#a2d6685652f4fd2afd3894e4afcf42910", null ],
    [ "GetCaseSets", "class_open_t_d_1_1_case_set_manager.xhtml#a2d8fd24a900de6bd5520a3b11748e534", null ],
    [ "IsCaseRunning", "class_open_t_d_1_1_case_set_manager.xhtml#a515ad34f6486161111d7cab17f64aa47", null ],
    [ "Rename", "class_open_t_d_1_1_case_set_manager.xhtml#a61761ff35dca0540eec74c28f02bb051", null ],
    [ "Run", "class_open_t_d_1_1_case_set_manager.xhtml#a7de51d83a27f910b402123c2bc92a6d3", null ],
    [ "Run", "class_open_t_d_1_1_case_set_manager.xhtml#a395ee6fa6edc924e7a7cfc0eb81aaca7", null ],
    [ "Update", "class_open_t_d_1_1_case_set_manager.xhtml#a5709fd246dfbed52a029f3b621d03ec0", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_case_set_manager.xhtml#aff0927db6de95d73b60c22cd91091792", null ],
    [ "Options", "class_open_t_d_1_1_case_set_manager.xhtml#a1fac0495361317962ee9baea4398e85c", null ]
];