var indexSectionsWithContent =
{
  0: "acdehimnops",
  1: "acdehimnops"
};

var indexSectionNames =
{
  0: "all",
  1: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Pages"
};

