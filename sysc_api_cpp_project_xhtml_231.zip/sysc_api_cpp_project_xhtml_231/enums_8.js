var searchData=
[
  ['regiondiscretizationtype_0',['RegionDiscretizationType',['../group__SystemCouplingParticipantAPIs.xhtml#ga59080d26b5838a6c678ee5f0d6ff63a4',1,'sysc']]]
];
