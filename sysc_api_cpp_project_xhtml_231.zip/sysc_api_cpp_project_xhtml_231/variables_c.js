var searchData=
[
  ['setupfilename_0',['setupFileName',['../structsysc_1_1SetupFileInfo.xhtml#acf9bd8de151bb98c37844bce125c20d0',1,'sysc::SetupFileInfo']]],
  ['starttime_1',['startTime',['../structsysc_1_1TimeStep.xhtml#a115810021ec63279be6a82d5deb853c2',1,'sysc::TimeStep']]]
];
