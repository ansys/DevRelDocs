var searchData=
[
  ['isinvalid_0',['isInvalid',['../structsysc_1_1MeshValidityStatus.xhtml#a3ee3cb844b3594fb7c3be7fce89a4f62',1,'sysc::MeshValidityStatus']]],
  ['isvalid_1',['isValid',['../structsysc_1_1ValidityStatus.xhtml#ac45ce7d05d6ab0126511da670f3e10a9',1,'sysc::ValidityStatus']]]
];
