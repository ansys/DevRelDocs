var structsysc_1_1ValidityStatus =
[
    [ "ValidityStatus", "structsysc_1_1ValidityStatus.xhtml#a45833f599239b5ec57232fd73ee127b5", null ],
    [ "isValid", "structsysc_1_1ValidityStatus.xhtml#ac45ce7d05d6ab0126511da670f3e10a9", null ],
    [ "message", "structsysc_1_1ValidityStatus.xhtml#ad78928b787427d9c0edf9e7a1e3d857c", null ]
];