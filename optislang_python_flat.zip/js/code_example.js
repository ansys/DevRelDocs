function copy_to_clipboard(ev) {
    let container = ev.target.parentElement.parentElement;
    let example = container.querySelector("pre");

    try {
        navigator.clipboard.writeText(example.innerText)
    } catch (e) {
        //
    }

};


var items = document.querySelectorAll('.example__button');

for (var i = 0, len = items.length; i < len; i++) {
    items[i].addEventListener("click", copy_to_clipboard)
}
