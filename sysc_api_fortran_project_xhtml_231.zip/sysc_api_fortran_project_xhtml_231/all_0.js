var searchData=
[
  ['access_20to_20heavyweight_20data_0',['Access to Heavyweight Data',['../md_10_HeavyweightDataAccess.xhtml',1,'']]]
];
