/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "ANSYS Chemkin/CFD API", "index.html", [
    [ "Ansys Chemkin/CFD API Guidelines for Usage", "_usage.html", [
      [ "General Example of Callng Sequence", "_usage.html#ExCallingSeq", null ],
      [ "Dynamic Adaptive Chemistry Example Calling Sequence", "_usage.html#exDACcallingseq", null ],
      [ "Dynamic Cell Clustering Example Calling Sequence", "_usage.html#exDCCcallingseq", null ],
      [ "Particle Tracking Example Calling Sequence", "_usage.html#exParticleCallingSeq", null ]
    ] ],
    [ "Ansys Chemkin/CFD API Working with Reaction Mechanisms", "_mechanisms.html", [
      [ "Thermodynamic Property Database", "_mechanisms.html#ThermoDB", null ],
      [ "Gas-phase Kinetics Input", "_mechanisms.html#GPKinInput", [
        [ "Element Data", "_mechanisms.html#ElemData", null ],
        [ "Species Data", "_mechanisms.html#Species", null ],
        [ "Thermodynamic Data (Optional)", "_mechanisms.html#thermoOptional", null ],
        [ "Reaction Data", "_mechanisms.html#ReactData", [
          [ "Reaction Line", "_mechanisms.html#ReactionLine", null ],
          [ "Reaction Strings and Rate Coefficients", "_mechanisms.html#RxnStrings-RateCoeff", null ],
          [ "Auxiliary Reaction Data", "_mechanisms.html#AuxRxnData", null ],
          [ "Chebyshev Polynomial Rate Expressions", "_mechanisms.html#ChebPolyRate", null ],
          [ "Error Checks", "_mechanisms.html#ckcfdErrorChecks", null ]
        ] ]
      ] ],
      [ "Surface Kinetics Input", "_mechanisms.html#SurfKinInput", [
        [ "Material Declaration", "_mechanisms.html#MatDeclar", null ],
        [ "Site Data", "_mechanisms.html#SiteData", null ],
        [ "Bulk Data", "_mechanisms.html#BulkData", null ],
        [ "Thermodynamic Data", "_mechanisms.html#ThermoData", null ],
        [ "Surface Reaction Mechanism Description", "_mechanisms.html#SurfRxnMech", [
          [ "The REACTION Line", "_mechanisms.html#RxnLine", null ],
          [ "Surface Reaction Data", "_mechanisms.html#SurfRxnData", null ],
          [ "Surface Reaction Auxiliary Data", "_mechanisms.html#SurfRxnAux", null ],
          [ "Unit Conversion for Pre-exponential Factor", "_mechanisms.html#UnitConvPreFac", null ]
        ] ],
        [ "Error Checks", "_mechanisms.html#ErrCheck", null ],
        [ "Mechanisms with Multiple Materials", "_mechanisms.html#MechsMultiMaterials", null ]
      ] ],
      [ "Transport Input", "_mechanisms.html#TransInput", null ]
    ] ],
    [ "Ansys Chemkin/CFD API References", "_refs.html", null ],
    [ "Todo List", "todo.html", null ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_k_i_netics_8hpp.html",
"_k_i_netics_8hpp.html#a98323f0a3cb8df2c69a70a84b505ddd3"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';