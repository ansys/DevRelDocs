var structIRockyPairScalars =
[
    [ "add_scalar", "structIRockyPairScalars.xhtml#ac4629dbc764141b132b43a4ed53c1412", null ],
    [ "get_scalar", "structIRockyPairScalars.xhtml#a2115866634ce54e7425ab949bb87d006", null ],
    [ "max_scalar", "structIRockyPairScalars.xhtml#ac5e39d90b8b54baf30023e7665d55555", null ],
    [ "set_scalar", "structIRockyPairScalars.xhtml#a5b7525f5f3d361571c0a2de51c61f189", null ]
];