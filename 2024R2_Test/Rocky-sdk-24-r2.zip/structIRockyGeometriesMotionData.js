var structIRockyGeometriesMotionData =
[
    [ "get_geometry", "structIRockyGeometriesMotionData.xhtml#a97350213657a5dfca98e787a4200ccc7", null ],
    [ "get_geometry", "structIRockyGeometriesMotionData.xhtml#a36a8aa9aa2bd497f7381980b78c83cb9", null ],
    [ "get_number_of_geometries", "structIRockyGeometriesMotionData.xhtml#a089856efc3afdea2fdf9c90652e411e8", null ],
    [ "has_linked_motion_frame", "structIRockyGeometriesMotionData.xhtml#a0a9f25ad715ac525854a83d7b591100f", null ]
];