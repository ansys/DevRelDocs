var structasset__preparation_1_1v3_1_1material_1_1_layer =
[
    [ "no_layer", "structasset__preparation_1_1v3_1_1material_1_1_layer.xhtml#a5a5fbcf0c6bf7579b05bafa4283f164c", null ],
    [ "lambertian_layer", "structasset__preparation_1_1v3_1_1material_1_1_layer.xhtml#afcef726175335e478f0dc82361df8101", null ],
    [ "mirror_layer", "structasset__preparation_1_1v3_1_1material_1_1_layer.xhtml#aff8dc17ed2625c818e261489c3ede9ff", null ],
    [ "optical_polish_layer", "structasset__preparation_1_1v3_1_1material_1_1_layer.xhtml#ae00c2d473a2751d1afedd5e59aaa577f", null ],
    [ "library_layer", "structasset__preparation_1_1v3_1_1material_1_1_layer.xhtml#a122a3bd9a2458ddb6d7bedf4ea365edc", null ],
    [ "rendering_layer", "structasset__preparation_1_1v3_1_1material_1_1_layer.xhtml#a6e1e05c2577512465f2ef982bb2e94f2", null ]
];