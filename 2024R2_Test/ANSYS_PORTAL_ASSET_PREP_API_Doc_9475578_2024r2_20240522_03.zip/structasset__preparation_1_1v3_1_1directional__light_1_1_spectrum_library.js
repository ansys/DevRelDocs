var structasset__preparation_1_1v3_1_1directional__light_1_1_spectrum_library =
[
    [ "spectrum_identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_spectrum_library.xhtml#af9548acef0ab0fa4cb7ad72ad01143fd", null ]
];