var structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_chunks_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_chunks_request.xhtml#a40b66bb1a3674c62840d07031bc7a4fc", null ],
    [ "type", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_chunks_request.xhtml#aa0660dd97d9a1aee0ee02705fa9018ed", null ]
];