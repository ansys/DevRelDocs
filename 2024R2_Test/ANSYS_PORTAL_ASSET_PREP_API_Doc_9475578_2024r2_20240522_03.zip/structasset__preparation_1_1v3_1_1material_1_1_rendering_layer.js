var structasset__preparation_1_1v3_1_1material_1_1_rendering_layer =
[
    [ "specular_properties", "structasset__preparation_1_1v3_1_1material_1_1_rendering_layer.xhtml#a0239b8930f917f66b6e01a474477502a", null ],
    [ "roughness_properties", "structasset__preparation_1_1v3_1_1material_1_1_rendering_layer.xhtml#ac368d101d5a802bb030e883089607f08", null ],
    [ "diffuse_properties", "structasset__preparation_1_1v3_1_1material_1_1_rendering_layer.xhtml#a5be54fe0075120b6817093f85f40a926", null ],
    [ "normal_properties", "structasset__preparation_1_1v3_1_1material_1_1_rendering_layer.xhtml#aea4f70105e37c987d116596c61278bc9", null ],
    [ "anisotropy_properties", "structasset__preparation_1_1v3_1_1material_1_1_rendering_layer.xhtml#a130911ce389a93ca0d798d37243a0aa7", null ],
    [ "mask_properties", "structasset__preparation_1_1v3_1_1material_1_1_rendering_layer.xhtml#a47ebad1efe76bb4b77f37a1f2a7397c9", null ]
];