var structasset__preparation_1_1v3_1_1common_1_1_status =
[
    [ "code", "structasset__preparation_1_1v3_1_1common_1_1_status.xhtml#aacdf978bf9d71cc1fca7391dad46035e", null ],
    [ "feedback_message", "structasset__preparation_1_1v3_1_1common_1_1_status.xhtml#a406be80632bed642e23a4f1f1d6b5b6e", null ],
    [ "level", "structasset__preparation_1_1v3_1_1common_1_1_status.xhtml#a93f1f3290c7018702c8849a10cd9f36b", null ]
];