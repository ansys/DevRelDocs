var structasset__preparation_1_1v3_1_1directional__light_1_1_directional_light_properties =
[
    [ "sun", "structasset__preparation_1_1v3_1_1directional__light_1_1_directional_light_properties.xhtml#a1f41b4092af0bf37f65c9d7873f90097", null ],
    [ "custom", "structasset__preparation_1_1v3_1_1directional__light_1_1_directional_light_properties.xhtml#a53e5d64aab545e333f2926ec5b1abd13", null ],
    [ "no_shadow", "structasset__preparation_1_1v3_1_1directional__light_1_1_directional_light_properties.xhtml#aaaaa3e4cc35fe4fc3ade18bddf3180c2", null ],
    [ "dynamic_accurate_shadows", "structasset__preparation_1_1v3_1_1directional__light_1_1_directional_light_properties.xhtml#a86eec562f31b95f5196fb45dd1339442", null ]
];