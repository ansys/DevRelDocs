var structasset__preparation_1_1v3_1_1scene__tree_1_1_update_directional_light_instance_request =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_directional_light_instance_request.xhtml#ade6c90a7ed449933444de0ae781b6b41", null ],
    [ "instance_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_directional_light_instance_request.xhtml#a908ed40c37c225f7aad796a905836275", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_directional_light_instance_request.xhtml#af21d1145f0d042e8038f6ebb2eaebb02", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_directional_light_instance_request.xhtml#a9d84a9ca79bfa42d535fc9e43576b191", null ]
];