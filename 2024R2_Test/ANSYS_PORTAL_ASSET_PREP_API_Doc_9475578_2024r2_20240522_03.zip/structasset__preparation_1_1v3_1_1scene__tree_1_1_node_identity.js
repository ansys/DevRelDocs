var structasset__preparation_1_1v3_1_1scene__tree_1_1_node_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_node_identity.xhtml#ac8ad0099063e54cc7c3e6126d0c9d1fb", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_node_identity.xhtml#a5a8c72e8a107c32a7dd33eed07c8e35e", null ]
];