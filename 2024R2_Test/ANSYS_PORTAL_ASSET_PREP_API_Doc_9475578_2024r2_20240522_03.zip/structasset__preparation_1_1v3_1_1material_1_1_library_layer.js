var structasset__preparation_1_1v3_1_1material_1_1_library_layer =
[
    [ "surface_state_identifier", "structasset__preparation_1_1v3_1_1material_1_1_library_layer.xhtml#af7db621dab97fdef245983b950e71dac", null ],
    [ "diffuse_properties", "structasset__preparation_1_1v3_1_1material_1_1_library_layer.xhtml#a31697f05d50bd6af6581ad2dcb09a35f", null ],
    [ "normal_properties", "structasset__preparation_1_1v3_1_1material_1_1_library_layer.xhtml#a54c5541bfd239980b675d43bac70ff0f", null ],
    [ "anisotropy_properties", "structasset__preparation_1_1v3_1_1material_1_1_library_layer.xhtml#a034c318c09f92a2a0f0fed8850d0a447", null ],
    [ "mask_properties", "structasset__preparation_1_1v3_1_1material_1_1_library_layer.xhtml#a57f29dc31618a545ba0ee922ae6f8fc2", null ]
];