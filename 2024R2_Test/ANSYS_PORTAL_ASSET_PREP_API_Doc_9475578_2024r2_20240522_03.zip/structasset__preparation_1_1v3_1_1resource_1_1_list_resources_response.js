var structasset__preparation_1_1v3_1_1resource_1_1_list_resources_response =
[
    [ "identifiers", "structasset__preparation_1_1v3_1_1resource_1_1_list_resources_response.xhtml#a1064ae935d0bf0f0841fc619abb97e53", null ],
    [ "status", "structasset__preparation_1_1v3_1_1resource_1_1_list_resources_response.xhtml#ac6aab0544595823a15d0a973f4486320", null ]
];