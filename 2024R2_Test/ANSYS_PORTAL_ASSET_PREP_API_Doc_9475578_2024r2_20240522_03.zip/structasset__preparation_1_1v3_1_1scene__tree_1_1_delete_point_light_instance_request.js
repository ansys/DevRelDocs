var structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_point_light_instance_request =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_point_light_instance_request.xhtml#ae207bf89fc4348b054174e182f51a002", null ],
    [ "instance_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_point_light_instance_request.xhtml#ac95eb5e4f4ef04f2c6565e2fdb7ebc9b", null ]
];