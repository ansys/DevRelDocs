var namespaceasset__preparation_1_1v3_1_1hdri__sky =
[
    [ "CreateHdriSkyRequest", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_request.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_request" ],
    [ "CreateHdriSkyResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_response" ],
    [ "CreateHdriSkyStateRequest", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_request.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_request" ],
    [ "CreateHdriSkyStateResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_response" ],
    [ "DeleteHdriSkyRequest", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_request.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_request" ],
    [ "DeleteHdriSkyResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_response" ],
    [ "DeleteHdriSkyStateRequest", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_state_request.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_state_request" ],
    [ "DeleteHdriSkyStateResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_state_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_state_response" ],
    [ "GetHdriSkyRequest", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_request.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_request" ],
    [ "GetHdriSkyResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_response" ],
    [ "GetHdriSkyStateRequest", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_request.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_request" ],
    [ "GetHdriSkyStateResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_response" ],
    [ "HdriSkyIdentity", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_identity.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_identity" ],
    [ "HdriSkyPreparation", "classasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_preparation.xhtml", "classasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_preparation" ],
    [ "HdriSkyProperties", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties" ],
    [ "ListHdriSkiesResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_list_hdri_skies_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_list_hdri_skies_response" ],
    [ "UpdateHdriSkyRequest", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_request.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_request" ],
    [ "UpdateHdriSkyResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_response" ],
    [ "UpdateHdriSkyStateRequest", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_request.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_request" ],
    [ "UpdateHdriSkyStateResponse", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_response.xhtml", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_response" ]
];