var structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_identity.xhtml#a8b25097c1e90a05ac0cadcc088b3f3b7", null ],
    [ "name", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_identity.xhtml#a9024a00c62bcb9d13515f4c96476fb33", null ]
];