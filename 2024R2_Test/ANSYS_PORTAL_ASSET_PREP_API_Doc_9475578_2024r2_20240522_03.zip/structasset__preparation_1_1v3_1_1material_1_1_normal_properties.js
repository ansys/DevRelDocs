var structasset__preparation_1_1v3_1_1material_1_1_normal_properties =
[
    [ "no_normal", "structasset__preparation_1_1v3_1_1material_1_1_normal_properties.xhtml#a320ef40acac683026a7e0c014228c532", null ],
    [ "texture", "structasset__preparation_1_1v3_1_1material_1_1_normal_properties.xhtml#a224e03bb9cb7bd1dabbff280e4f2ddfa", null ]
];