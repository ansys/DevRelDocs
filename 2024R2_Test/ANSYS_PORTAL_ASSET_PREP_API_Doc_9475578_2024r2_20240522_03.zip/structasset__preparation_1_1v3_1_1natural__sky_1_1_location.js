var structasset__preparation_1_1v3_1_1natural__sky_1_1_location =
[
    [ "latitude", "structasset__preparation_1_1v3_1_1natural__sky_1_1_location.xhtml#a0f8b964cf6a63b335def98a5a8b3c456", null ],
    [ "longitude", "structasset__preparation_1_1v3_1_1natural__sky_1_1_location.xhtml#a0fc913bc4d5a961e8e089b9d72102faa", null ],
    [ "cardinal_direction", "structasset__preparation_1_1v3_1_1natural__sky_1_1_location.xhtml#a2d06481ff2e1d4889e732d9a5c9dfee9", null ]
];