var structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_request.xhtml#a821f5d61341107c5d4b8179ef3982d2b", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_request.xhtml#a7495eb750bd68d7fb4816e09fe49ab78", null ],
    [ "base_state_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_request.xhtml#a3e37c1db87cdd3e5892311358fbf3ce1", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_request.xhtml#a806dbd31322eaa7c3c08644485043965", null ]
];