var structasset__preparation_1_1v3_1_1geometry_1_1_delete_material_part_request =
[
    [ "geometry_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_delete_material_part_request.xhtml#a8b2508fda1242a638ac3b77d81077c03", null ],
    [ "material_part_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_delete_material_part_request.xhtml#ae60b37ac5af9c6c364a35815ddaa9e10", null ]
];