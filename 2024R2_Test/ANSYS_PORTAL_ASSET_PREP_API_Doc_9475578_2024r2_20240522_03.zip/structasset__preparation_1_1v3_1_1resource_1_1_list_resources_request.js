var structasset__preparation_1_1v3_1_1resource_1_1_list_resources_request =
[
    [ "type", "structasset__preparation_1_1v3_1_1resource_1_1_list_resources_request.xhtml#a9fbcd97ed490bd14c3a0b2b05453ac67", null ]
];