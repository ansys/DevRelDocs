var structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_response =
[
    [ "status", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_response.xhtml#a48087a87ed6deaaf8ffa726be79164f8", null ]
];