var structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_response.xhtml#a51be68989223973244faa18d5d42c0be", null ],
    [ "status", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_response.xhtml#a0fdeb89928ff00fe602add7c3c85ef5c", null ]
];