var structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_state_request.xhtml#ada50f3a2b5999eb45509edda15285d67", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_state_request.xhtml#a3194ae54d5e28bcba60b4c125fec669a", null ]
];