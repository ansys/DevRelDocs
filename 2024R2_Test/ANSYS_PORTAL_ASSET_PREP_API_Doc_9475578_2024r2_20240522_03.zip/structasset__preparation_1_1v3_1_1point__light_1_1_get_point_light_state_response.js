var structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_state_response.xhtml#a0b11afeff27f3b837c4f1fa54d107350", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_state_response.xhtml#aa61bdca3bcde8a2bcb982f8d52266197", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_state_response.xhtml#a3ce2793164cc7d5c24eeffd6a509d591", null ],
    [ "status", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_state_response.xhtml#ae93e00b4b6a5954d0767f9bfe5c1a553", null ]
];