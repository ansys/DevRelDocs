var structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_request.xhtml#a482afa73e696c80d781c38b66ce04915", null ]
];