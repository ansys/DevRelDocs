var structasset__preparation_1_1v3_1_1point__light_1_1_point_light_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_identity.xhtml#ab809d817e2f1e8cd3e6e07eac75eefba", null ],
    [ "name", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_identity.xhtml#a5d3394354f476acf07bcd50d35de246d", null ]
];