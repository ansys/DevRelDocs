var structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_request.xhtml#a14940a50b0ce1a4fd6601e8b1bcd528f", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_request.xhtml#a4fde7cf5d27226a3d94d8fc411a303b5", null ]
];