var structasset__preparation_1_1v3_1_1point__light_1_1_gaussian_diagram =
[
    [ "x", "structasset__preparation_1_1v3_1_1point__light_1_1_gaussian_diagram.xhtml#a01dccdb4db4203d94df7ad3a4ec71fbe", null ],
    [ "y", "structasset__preparation_1_1v3_1_1point__light_1_1_gaussian_diagram.xhtml#aa0f1ce8de1974351e25f2a48da945d6c", null ]
];