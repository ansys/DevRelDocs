var structasset__preparation_1_1v3_1_1material_1_1_create_material_request =
[
    [ "name", "structasset__preparation_1_1v3_1_1material_1_1_create_material_request.xhtml#a490d2e3eb7422dd162817821395cbcba", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1material_1_1_create_material_request.xhtml#aa095ac851f5dec5d60b1e03052c72697", null ]
];