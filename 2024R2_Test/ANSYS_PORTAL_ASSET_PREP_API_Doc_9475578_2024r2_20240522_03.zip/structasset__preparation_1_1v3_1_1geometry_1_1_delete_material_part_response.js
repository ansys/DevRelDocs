var structasset__preparation_1_1v3_1_1geometry_1_1_delete_material_part_response =
[
    [ "status", "structasset__preparation_1_1v3_1_1geometry_1_1_delete_material_part_response.xhtml#a5bdb3e65768ed817dc399c85341f4f1b", null ]
];