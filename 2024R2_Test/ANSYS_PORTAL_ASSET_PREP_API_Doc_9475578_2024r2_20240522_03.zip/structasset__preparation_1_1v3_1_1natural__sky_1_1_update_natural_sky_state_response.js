var structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_state_response =
[
    [ "state_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_state_response.xhtml#abe0b8ce211b96c5a1b86ce72401d9eed", null ],
    [ "status", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_state_response.xhtml#a5bd7d7e27967a72f81c608240b20f535", null ]
];