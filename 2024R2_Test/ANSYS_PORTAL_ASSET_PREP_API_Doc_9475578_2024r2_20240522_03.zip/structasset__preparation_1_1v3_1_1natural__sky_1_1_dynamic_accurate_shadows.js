var structasset__preparation_1_1v3_1_1natural__sky_1_1_dynamic_accurate_shadows =
[
    [ "shadow_offset_ratio", "structasset__preparation_1_1v3_1_1natural__sky_1_1_dynamic_accurate_shadows.xhtml#af68934f42c70a48754ecdc383ecf259e", null ],
    [ "shadow_radius", "structasset__preparation_1_1v3_1_1natural__sky_1_1_dynamic_accurate_shadows.xhtml#a6b7d19e6d16d94f279c442236e7b57d9", null ],
    [ "softness", "structasset__preparation_1_1v3_1_1natural__sky_1_1_dynamic_accurate_shadows.xhtml#adf14f3b6174901cb45d4d0156e3bf046", null ],
    [ "resolution", "structasset__preparation_1_1v3_1_1natural__sky_1_1_dynamic_accurate_shadows.xhtml#a54aa86be53f6d582432d5ad1c873f9d2", null ],
    [ "near_field_precision", "structasset__preparation_1_1v3_1_1natural__sky_1_1_dynamic_accurate_shadows.xhtml#aee75483abe8eff07e938c7d1fb86bfbd", null ]
];