var structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_request.xhtml#ae25b776ce9455236fc30d34dd704c3e0", null ],
    [ "name", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_request.xhtml#a4068880c007ed842877cb28bd55c2c4e", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_request.xhtml#a4a64debb3f8b6d39b3660f5d90398b93", null ]
];