var structasset__preparation_1_1v3_1_1point__light_1_1_spectrum_library =
[
    [ "spectrum_identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_spectrum_library.xhtml#af8629815b9ba844160ff71efcb3a2467", null ]
];