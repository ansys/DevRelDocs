var structasset__preparation_1_1v3_1_1scene__tree_1_1_update_point_light_instance_request =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_point_light_instance_request.xhtml#ad2dd6a297d3e6af95c32917e353c1005", null ],
    [ "instance_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_point_light_instance_request.xhtml#a7cfe4e7cd59a71ee479248d22d8a88a9", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_point_light_instance_request.xhtml#a2acece253d2023e391194ac752b2b215", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_point_light_instance_request.xhtml#a894b286345f3f0e393bc716ee27cdd34", null ]
];