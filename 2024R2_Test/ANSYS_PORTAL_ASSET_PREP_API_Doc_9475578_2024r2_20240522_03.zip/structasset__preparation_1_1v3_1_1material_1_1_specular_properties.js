var structasset__preparation_1_1v3_1_1material_1_1_specular_properties =
[
    [ "color_rgb", "structasset__preparation_1_1v3_1_1material_1_1_specular_properties.xhtml#ac86a69a63ce5be3e2ff12ae67a0b4974", null ],
    [ "color_hsv", "structasset__preparation_1_1v3_1_1material_1_1_specular_properties.xhtml#a8923e02456280c1a550882646c20d52f", null ],
    [ "texture", "structasset__preparation_1_1v3_1_1material_1_1_specular_properties.xhtml#a8441f91d200995caae0bd5d976c848ac", null ]
];