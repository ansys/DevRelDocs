var structasset__preparation_1_1v3_1_1material_1_1_get_material_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_get_material_state_response.xhtml#af84cea551106c4ad0b91bbfb9129b481", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1material_1_1_get_material_state_response.xhtml#ac2f7b3deec95c4b0c246da004a587a62", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1material_1_1_get_material_state_response.xhtml#af32f8b80d74e13ad6ec5f229070fd010", null ],
    [ "status", "structasset__preparation_1_1v3_1_1material_1_1_get_material_state_response.xhtml#ab6528a03e88d3b4dea66dc18260c3591", null ]
];