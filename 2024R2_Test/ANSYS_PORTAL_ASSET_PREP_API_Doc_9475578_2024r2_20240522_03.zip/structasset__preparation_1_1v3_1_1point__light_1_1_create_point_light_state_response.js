var structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_response.xhtml#aa5fcab88c755f8bc171dafa00873fbae", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_response.xhtml#a50181a1f57d8ed0b9a7354de5605b356", null ],
    [ "status", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_response.xhtml#afcb3e4ad00c0f08acd7fd10bfe303487", null ]
];