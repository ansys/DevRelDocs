var structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_state_request.xhtml#a3cfe2ceb0368ffc60a1794506a0b2752", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_delete_hdri_sky_state_request.xhtml#a15c2b5afa22a1d13563085bed904d086", null ]
];