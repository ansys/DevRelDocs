var structasset__preparation_1_1v3_1_1material_1_1_reflection_effect =
[
    [ "reflectivity", "structasset__preparation_1_1v3_1_1material_1_1_reflection_effect.xhtml#a08f630ecc5c24e42e81aac94d6fb4d74", null ],
    [ "size", "structasset__preparation_1_1v3_1_1material_1_1_reflection_effect.xhtml#ab282af6ffb4d073f3e0390c715af5281", null ],
    [ "index_of_refraction", "structasset__preparation_1_1v3_1_1material_1_1_reflection_effect.xhtml#abc6e5b20010a55d7c7b65cafc2f5394a", null ]
];