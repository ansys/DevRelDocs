var structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_response.xhtml#a16306f80f91af8feed3b608faeee8217", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_response.xhtml#a63a2057b61b4765be26d1e13bb7c632d", null ],
    [ "status", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_response.xhtml#a66399a8beec2564c3810be50a54fcfa0", null ]
];