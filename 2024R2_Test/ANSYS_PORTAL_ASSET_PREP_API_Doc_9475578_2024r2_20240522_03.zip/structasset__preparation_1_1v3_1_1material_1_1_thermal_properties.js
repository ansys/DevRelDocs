var structasset__preparation_1_1v3_1_1material_1_1_thermal_properties =
[
    [ "emissivity", "structasset__preparation_1_1v3_1_1material_1_1_thermal_properties.xhtml#a4c7a8b150b6505fc67682009b3ca529f", null ],
    [ "emissivity_variation_texture_identifier", "structasset__preparation_1_1v3_1_1material_1_1_thermal_properties.xhtml#a009dc45eb6391a657648eadc811b3a89", null ],
    [ "emissivity_variation_uv_channel", "structasset__preparation_1_1v3_1_1material_1_1_thermal_properties.xhtml#a159f12178a2eda775351e45f179b8f1a", null ],
    [ "emissivity_variation_amplitude", "structasset__preparation_1_1v3_1_1material_1_1_thermal_properties.xhtml#a96e7e7080d8b3dc288d94a3e0c1d332e", null ],
    [ "reflection_coefficient", "structasset__preparation_1_1v3_1_1material_1_1_thermal_properties.xhtml#abbb1a430efc0cc8ffba0ac1f5dd45dc5", null ],
    [ "shininess", "structasset__preparation_1_1v3_1_1material_1_1_thermal_properties.xhtml#a148edd73b069c695a178fb51e6e2ea6b", null ],
    [ "thermal_coefficient", "structasset__preparation_1_1v3_1_1material_1_1_thermal_properties.xhtml#a31534a839678bebaa6b47c096a6deb75", null ]
];