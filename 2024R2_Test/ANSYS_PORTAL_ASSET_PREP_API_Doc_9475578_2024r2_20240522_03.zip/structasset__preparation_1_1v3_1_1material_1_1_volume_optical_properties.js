var structasset__preparation_1_1v3_1_1material_1_1_volume_optical_properties =
[
    [ "opaque", "structasset__preparation_1_1v3_1_1material_1_1_volume_optical_properties.xhtml#aa64557e72198d38631ae6f29b0bccd7c", null ],
    [ "optic", "structasset__preparation_1_1v3_1_1material_1_1_volume_optical_properties.xhtml#a1819061ffbf05f697bdb5d56ae94a365", null ],
    [ "volume_optical_library", "structasset__preparation_1_1v3_1_1material_1_1_volume_optical_properties.xhtml#a015ecc6ed7a24a521356ceb8af7b065f", null ],
    [ "fast_transmission_gathering", "structasset__preparation_1_1v3_1_1material_1_1_volume_optical_properties.xhtml#a0886dfd58185a65da3c3de0e4213d183", null ]
];