var structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_request.xhtml#aca4221c5f5ff03314ff2dcfd4b4bc79f", null ]
];