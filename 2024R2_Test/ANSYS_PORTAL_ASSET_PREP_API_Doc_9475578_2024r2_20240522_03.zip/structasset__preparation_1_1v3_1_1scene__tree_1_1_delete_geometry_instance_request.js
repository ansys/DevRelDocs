var structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_geometry_instance_request =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_geometry_instance_request.xhtml#aa4c90fb7610df54a1e9071c60c546ef5", null ],
    [ "instance_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_geometry_instance_request.xhtml#a3bdd9ed6137a7fd93af20d110e75f605", null ]
];