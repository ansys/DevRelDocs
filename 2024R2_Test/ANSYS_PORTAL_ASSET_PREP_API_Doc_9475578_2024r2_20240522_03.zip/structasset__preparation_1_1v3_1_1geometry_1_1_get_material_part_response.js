var structasset__preparation_1_1v3_1_1geometry_1_1_get_material_part_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1geometry_1_1_get_material_part_response.xhtml#a62ce3bfcd5590491a34723ccc339e2d8", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1geometry_1_1_get_material_part_response.xhtml#a13b7af6c4b34295267e922a790c0d5a4", null ],
    [ "status", "structasset__preparation_1_1v3_1_1geometry_1_1_get_material_part_response.xhtml#a8cc355458d95470f5c28fc95f1d677e3", null ]
];