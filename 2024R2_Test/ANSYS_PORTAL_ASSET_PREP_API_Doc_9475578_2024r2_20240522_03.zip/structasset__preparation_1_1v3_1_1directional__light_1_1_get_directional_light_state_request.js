var structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_state_request.xhtml#a28b6ed751a3854d63f75469d3a266b6c", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_state_request.xhtml#a23611f8509f5e29988dfe6daf51b7274", null ]
];