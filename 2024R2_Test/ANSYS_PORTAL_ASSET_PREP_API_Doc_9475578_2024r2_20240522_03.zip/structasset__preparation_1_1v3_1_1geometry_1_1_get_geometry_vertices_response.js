var structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_vertices_response =
[
    [ "vertices", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_vertices_response.xhtml#a74d740854d6fc2d9e56b03534e24f647", null ],
    [ "status", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_vertices_response.xhtml#a2900e3c37962eac9847075d6c2b6dde1", null ]
];