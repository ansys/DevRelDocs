var structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_identity.xhtml#a60acd42544c48c67178a11b8e69b443a", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_identity.xhtml#a8db3a5ef905ea51d96af9131f785a1f3", null ]
];