var structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_request.xhtml#a95ca402ffd03cadadbc26b621a323727", null ],
    [ "name", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_request.xhtml#ab15a47cedcf066fa4999bbbef0329493", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_request.xhtml#aeccefbdc0ee970ca8f85b32e1b1fdfd6", null ]
];