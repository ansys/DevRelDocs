var structasset__preparation_1_1v3_1_1scene__tree_1_1_create_node_request =
[
    [ "scene_tree_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_node_request.xhtml#a6fa3d807fa2efa66b7d0a374b67dd69b", null ],
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_node_request.xhtml#aee60f3ed811fa04641a149058baaceb1", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_node_request.xhtml#a7efe3586e250a1bcf4af4a808a0b12e0", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_node_request.xhtml#a6c3958734dd2aba01813397ea5cfdbc6", null ]
];