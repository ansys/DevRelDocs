var structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_state_request.xhtml#ab357f9236507bcd94c06ff63a50a7dad", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_state_request.xhtml#aca77c70ee74d652716f33793ae0e40e2", null ],
    [ "state_new_name", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_state_request.xhtml#adab9f0ec1741bc51fa248d831a660523", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_state_request.xhtml#ac3ce6f61d13d1c733a581881f7880850", null ]
];