var structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties =
[
    [ "texture_identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties.xhtml#a3dc632b62ca305639f5b5f7ae142c9e8", null ],
    [ "projection_type", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties.xhtml#a945f0e08afa941e180ed284af78ede5b", null ],
    [ "ground_radius", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties.xhtml#a097ffdd4053a6c3b98f61d5ffc4cc682", null ],
    [ "orientation", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties.xhtml#a1338e1d40f0f5d62dbea97c5887afb7a", null ],
    [ "luminance_factor", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties.xhtml#a6368fd8c1bf2386e114e332f210cb6a7", null ],
    [ "ambient_factor", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_properties.xhtml#a21a3d9e49a5178d0ed2c420ceb49ef6f", null ]
];