var structasset__preparation_1_1v3_1_1directional__light_1_1_black_body =
[
    [ "temperature", "structasset__preparation_1_1v3_1_1directional__light_1_1_black_body.xhtml#a7f1488d2e846d005c67542adad963f7f", null ]
];