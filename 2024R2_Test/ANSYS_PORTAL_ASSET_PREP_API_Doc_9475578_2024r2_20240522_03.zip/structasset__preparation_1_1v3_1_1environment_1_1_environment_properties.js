var structasset__preparation_1_1v3_1_1environment_1_1_environment_properties =
[
    [ "scene_tree", "structasset__preparation_1_1v3_1_1environment_1_1_environment_properties.xhtml#a7133dfe1a616392addf03f4af6aa47d8", null ],
    [ "added_skies", "structasset__preparation_1_1v3_1_1environment_1_1_environment_properties.xhtml#a2cc4096f79ec6390a75abacb23f52c9c", null ],
    [ "removed_skies", "structasset__preparation_1_1v3_1_1environment_1_1_environment_properties.xhtml#a645524d8f6c2c524ed10c839ef88e70b", null ],
    [ "no_active_sky", "structasset__preparation_1_1v3_1_1environment_1_1_environment_properties.xhtml#abe5862153f3ebf6fc18a1777a23cced9", null ],
    [ "active_natural_sky", "structasset__preparation_1_1v3_1_1environment_1_1_environment_properties.xhtml#a6db6d9783fe269b964aeab04615dde41", null ],
    [ "active_hdri_sky", "structasset__preparation_1_1v3_1_1environment_1_1_environment_properties.xhtml#a6518de09a31a86844d7eb541a01e2bf3", null ]
];