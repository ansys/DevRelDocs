var structasset__preparation_1_1v3_1_1common_1_1_properties =
[
    [ "label", "structasset__preparation_1_1v3_1_1common_1_1_properties.xhtml#a66ffed744c9ec3a7936767b1283715dd", null ],
    [ "name", "structasset__preparation_1_1v3_1_1common_1_1_properties.xhtml#a651906ad930bb65f229153b7b91eef90", null ],
    [ "identifier", "structasset__preparation_1_1v3_1_1common_1_1_properties.xhtml#ac145b24ef14896d4b08f1fde9e86a68d", null ],
    [ "position", "structasset__preparation_1_1v3_1_1common_1_1_properties.xhtml#aab173954eb75b12ce507c6bbc84f63c5", null ],
    [ "irradiance_map_identifier", "structasset__preparation_1_1v3_1_1common_1_1_properties.xhtml#ac4a978cd90c5a90fb276fda3fa5637d0", null ]
];