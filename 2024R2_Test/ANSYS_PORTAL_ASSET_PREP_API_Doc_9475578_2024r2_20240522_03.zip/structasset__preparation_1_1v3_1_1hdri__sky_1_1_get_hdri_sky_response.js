var structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_response.xhtml#a88776cf05b9e13de19373819a9e69d22", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_response.xhtml#aa1054862ca99a3a86d4a87c82f53adb3", null ],
    [ "state_names", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_response.xhtml#a7a0506f75b0af8ae52059e18ff6da896", null ],
    [ "status", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_response.xhtml#a486de016b35a0ed70a142ebb318869d6", null ]
];