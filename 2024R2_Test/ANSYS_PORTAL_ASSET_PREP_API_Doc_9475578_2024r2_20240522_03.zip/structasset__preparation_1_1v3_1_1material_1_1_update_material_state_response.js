var structasset__preparation_1_1v3_1_1material_1_1_update_material_state_response =
[
    [ "state_name", "structasset__preparation_1_1v3_1_1material_1_1_update_material_state_response.xhtml#a4712ea770364faff3c5bc697af160579", null ],
    [ "status", "structasset__preparation_1_1v3_1_1material_1_1_update_material_state_response.xhtml#af23366f7d189f0a03dd49cf1b31cfe79", null ]
];