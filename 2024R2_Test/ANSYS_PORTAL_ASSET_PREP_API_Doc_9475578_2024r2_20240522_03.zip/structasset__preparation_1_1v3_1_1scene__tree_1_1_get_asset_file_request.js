var structasset__preparation_1_1v3_1_1scene__tree_1_1_get_asset_file_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_get_asset_file_request.xhtml#a644ef9b244a3589cc2d14196fbf4eac3", null ],
    [ "file_path", "structasset__preparation_1_1v3_1_1scene__tree_1_1_get_asset_file_request.xhtml#a2654e2452d2b597e15b3d9fd92aedba0", null ],
    [ "overwrite", "structasset__preparation_1_1v3_1_1scene__tree_1_1_get_asset_file_request.xhtml#afacd6b5d85e7960a319b10db0295532a", null ]
];