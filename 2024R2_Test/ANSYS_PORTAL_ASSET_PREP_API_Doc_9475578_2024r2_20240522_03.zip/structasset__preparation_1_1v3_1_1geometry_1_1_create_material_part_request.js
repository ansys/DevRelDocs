var structasset__preparation_1_1v3_1_1geometry_1_1_create_material_part_request =
[
    [ "geometry_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_create_material_part_request.xhtml#a6534bd34a80b4c824e20c8506830cb0f", null ],
    [ "name", "structasset__preparation_1_1v3_1_1geometry_1_1_create_material_part_request.xhtml#a06392b17f5a04f6c75ae096b29360dfc", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1geometry_1_1_create_material_part_request.xhtml#a531d25301911d456bce34a3129f4f2a2", null ]
];