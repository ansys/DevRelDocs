var structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_request.xhtml#aa5798ef7d6e0fdc0b880b0f87b82a81f", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_request.xhtml#a4d58dcd4b0e11e67b6401960552cb594", null ],
    [ "base_state_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_request.xhtml#aa727c1072268d590e2ea0eb701bc98fb", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_request.xhtml#afbf404883bca62c595890c45eff54f5a", null ]
];