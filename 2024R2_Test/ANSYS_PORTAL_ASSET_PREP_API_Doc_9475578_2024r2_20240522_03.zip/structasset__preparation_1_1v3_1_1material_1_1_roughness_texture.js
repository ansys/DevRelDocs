var structasset__preparation_1_1v3_1_1material_1_1_roughness_texture =
[
    [ "map_identifier", "structasset__preparation_1_1v3_1_1material_1_1_roughness_texture.xhtml#a586c23899374338973463029ece13ee0", null ],
    [ "map_uv_channel", "structasset__preparation_1_1v3_1_1material_1_1_roughness_texture.xhtml#ac3912298ece38b30b3264ffce99252e0", null ],
    [ "intensity", "structasset__preparation_1_1v3_1_1material_1_1_roughness_texture.xhtml#a9e01cd690dece5cfd70f790f6147824b", null ]
];