var structasset__preparation_1_1v3_1_1material_1_1_diffuse_texture =
[
    [ "map_identifier", "structasset__preparation_1_1v3_1_1material_1_1_diffuse_texture.xhtml#a2b47aabec4e3189132d2517ce190ac58", null ],
    [ "map_uv_channel", "structasset__preparation_1_1v3_1_1material_1_1_diffuse_texture.xhtml#a433410caa92cd249ce4075506832d255", null ],
    [ "alpha_uv_channel", "structasset__preparation_1_1v3_1_1material_1_1_diffuse_texture.xhtml#a4d53453365bc0bfb10b2fefbdf214535", null ]
];