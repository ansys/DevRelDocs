var structasset__preparation_1_1v3_1_1directional__light_1_1_directional_light_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_directional_light_identity.xhtml#a5e2c63c85f945239fe803041f9bcb81c", null ],
    [ "name", "structasset__preparation_1_1v3_1_1directional__light_1_1_directional_light_identity.xhtml#a536eab6e0683291d2b222eb470180aef", null ]
];