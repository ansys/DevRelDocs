var structasset__preparation_1_1v3_1_1scene__tree_1_1_node_properties =
[
    [ "transform", "structasset__preparation_1_1v3_1_1scene__tree_1_1_node_properties.xhtml#ae9e0f2514f4d714ae46d5c67422c375c", null ],
    [ "visibility", "structasset__preparation_1_1v3_1_1scene__tree_1_1_node_properties.xhtml#aa3523386db66334d212896d13493d737", null ],
    [ "removed_tags", "structasset__preparation_1_1v3_1_1scene__tree_1_1_node_properties.xhtml#a3f125dd9ed7cd84f836165e4bdc1d53f", null ],
    [ "added_tags", "structasset__preparation_1_1v3_1_1scene__tree_1_1_node_properties.xhtml#a0e5b7b0456b901c0b9034d16869ed2f4", null ]
];