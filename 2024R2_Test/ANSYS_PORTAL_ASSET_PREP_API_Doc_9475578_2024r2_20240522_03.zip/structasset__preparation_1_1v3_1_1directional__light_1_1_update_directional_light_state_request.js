var structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_state_request.xhtml#aad8ddef982e254ccd15be01ceaec9465", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_state_request.xhtml#a46da82cf93c30905f1e14b08e3c41580", null ],
    [ "state_new_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_state_request.xhtml#a2ee73f450f9652ee125fa306e739d37b", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_state_request.xhtml#a7388ee83e7f068e5a4bc76d83d26cd49", null ]
];