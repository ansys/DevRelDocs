var structasset__preparation_1_1v3_1_1common_1_1_chunk =
[
    [ "metadata", "structasset__preparation_1_1v3_1_1common_1_1_chunk.xhtml#a3d287aec03d018d939048ba73a776a7e", null ],
    [ "bytes", "structasset__preparation_1_1v3_1_1common_1_1_chunk.xhtml#a190c2b0aa5fc26072b771b5d3254d372", null ]
];