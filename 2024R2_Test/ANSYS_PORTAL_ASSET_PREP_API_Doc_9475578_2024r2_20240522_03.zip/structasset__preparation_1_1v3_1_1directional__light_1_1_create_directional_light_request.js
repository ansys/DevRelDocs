var structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_request =
[
    [ "name", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_request.xhtml#a76c094f01255213ebba2f120e57ba40f", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_request.xhtml#aa3b09bde03d5437e400beb92ebf39991", null ]
];