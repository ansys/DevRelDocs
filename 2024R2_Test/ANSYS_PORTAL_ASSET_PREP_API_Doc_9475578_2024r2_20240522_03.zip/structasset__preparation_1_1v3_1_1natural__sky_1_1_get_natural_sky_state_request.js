var structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_state_request.xhtml#ae43c28db697ebd45a495160ddf30fbac", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_state_request.xhtml#a5dddc86606bea56644d8d2941cd1bf9a", null ]
];