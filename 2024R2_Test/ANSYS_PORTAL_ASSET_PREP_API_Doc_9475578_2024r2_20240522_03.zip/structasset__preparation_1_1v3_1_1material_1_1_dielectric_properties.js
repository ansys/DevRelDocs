var structasset__preparation_1_1v3_1_1material_1_1_dielectric_properties =
[
    [ "dielectric_material_identifier", "structasset__preparation_1_1v3_1_1material_1_1_dielectric_properties.xhtml#aa8834b147e1be8bbcfadcbb874576720", null ]
];