var structasset__preparation_1_1v3_1_1material_1_1_create_material_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1material_1_1_create_material_response.xhtml#a0e445f1ca3008d8e1b6f7903cc61e358", null ],
    [ "status", "structasset__preparation_1_1v3_1_1material_1_1_create_material_response.xhtml#a7c08e7725357031f3d4673157ce17bc7", null ]
];