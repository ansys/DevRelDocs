var namespaceasset__preparation_1_1v3 =
[
    [ "common", "namespaceasset__preparation_1_1v3_1_1common.xhtml", "namespaceasset__preparation_1_1v3_1_1common" ],
    [ "directional_light", "namespaceasset__preparation_1_1v3_1_1directional__light.xhtml", "namespaceasset__preparation_1_1v3_1_1directional__light" ],
    [ "environment", "namespaceasset__preparation_1_1v3_1_1environment.xhtml", "namespaceasset__preparation_1_1v3_1_1environment" ],
    [ "geometry", "namespaceasset__preparation_1_1v3_1_1geometry.xhtml", "namespaceasset__preparation_1_1v3_1_1geometry" ],
    [ "hdri_sky", "namespaceasset__preparation_1_1v3_1_1hdri__sky.xhtml", "namespaceasset__preparation_1_1v3_1_1hdri__sky" ],
    [ "information", "namespaceasset__preparation_1_1v3_1_1information.xhtml", "namespaceasset__preparation_1_1v3_1_1information" ],
    [ "material", "namespaceasset__preparation_1_1v3_1_1material.xhtml", "namespaceasset__preparation_1_1v3_1_1material" ],
    [ "natural_sky", "namespaceasset__preparation_1_1v3_1_1natural__sky.xhtml", "namespaceasset__preparation_1_1v3_1_1natural__sky" ],
    [ "point_light", "namespaceasset__preparation_1_1v3_1_1point__light.xhtml", "namespaceasset__preparation_1_1v3_1_1point__light" ],
    [ "reset", "namespaceasset__preparation_1_1v3_1_1reset.xhtml", "namespaceasset__preparation_1_1v3_1_1reset" ],
    [ "resource", "namespaceasset__preparation_1_1v3_1_1resource.xhtml", "namespaceasset__preparation_1_1v3_1_1resource" ],
    [ "scene_tree", "namespaceasset__preparation_1_1v3_1_1scene__tree.xhtml", "namespaceasset__preparation_1_1v3_1_1scene__tree" ],
    [ "surface_source", "namespaceasset__preparation_1_1v3_1_1surface__source.xhtml", "namespaceasset__preparation_1_1v3_1_1surface__source" ]
];