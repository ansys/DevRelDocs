var structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_response =
[
    [ "state_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_response.xhtml#a54cedf76ab21cf816f5a2d211f265d04", null ],
    [ "status", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_response.xhtml#aef450b34275e4f369a0f41400d3947d3", null ]
];