var structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_request.xhtml#a8a87ab4356511bae8ea04b82a7158a2c", null ],
    [ "name", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_request.xhtml#ac3431e79b0e62fa78c2bd1b00467603b", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_request.xhtml#a6c4ff756404be6f7baf9254827a2c9b0", null ]
];