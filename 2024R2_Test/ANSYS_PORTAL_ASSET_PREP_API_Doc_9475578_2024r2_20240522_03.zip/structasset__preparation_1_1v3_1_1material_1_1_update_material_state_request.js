var structasset__preparation_1_1v3_1_1material_1_1_update_material_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_update_material_state_request.xhtml#aa5d1a8b6b938fd004345d0af7439737b", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1material_1_1_update_material_state_request.xhtml#abacdd56bc649276ae4dd4a55ac1bce97", null ],
    [ "state_new_name", "structasset__preparation_1_1v3_1_1material_1_1_update_material_state_request.xhtml#afb83d3a54135886ffcb1a3fe635b78a7", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1material_1_1_update_material_state_request.xhtml#a02a549ed8bf75d0f0c61bbb54583d412", null ]
];