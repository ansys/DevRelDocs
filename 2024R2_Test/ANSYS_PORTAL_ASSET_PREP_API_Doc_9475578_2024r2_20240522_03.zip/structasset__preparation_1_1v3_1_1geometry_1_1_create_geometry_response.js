var structasset__preparation_1_1v3_1_1geometry_1_1_create_geometry_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1geometry_1_1_create_geometry_response.xhtml#a2bf6d839387132b374c85f36267bc951", null ],
    [ "status", "structasset__preparation_1_1v3_1_1geometry_1_1_create_geometry_response.xhtml#acb6924fb1cb52432d9e3e2cc6974bc73", null ]
];