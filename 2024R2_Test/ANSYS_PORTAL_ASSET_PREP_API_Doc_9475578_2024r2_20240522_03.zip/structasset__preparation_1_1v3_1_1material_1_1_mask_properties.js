var structasset__preparation_1_1v3_1_1material_1_1_mask_properties =
[
    [ "color", "structasset__preparation_1_1v3_1_1material_1_1_mask_properties.xhtml#a105aaa7660fed35c7637fa2440b9beea", null ],
    [ "texture", "structasset__preparation_1_1v3_1_1material_1_1_mask_properties.xhtml#aecb9bc84f2d61d92a54dd160d2284ffb", null ]
];