var structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_response.xhtml#a7b1d3d7058e85556b346a2a0ecf7bbf1", null ],
    [ "status", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_response.xhtml#a7b180d3ea1841fddf0fcf98934ffda34", null ]
];