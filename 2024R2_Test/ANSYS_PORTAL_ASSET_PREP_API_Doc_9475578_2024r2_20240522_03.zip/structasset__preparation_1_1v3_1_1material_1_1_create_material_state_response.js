var structasset__preparation_1_1v3_1_1material_1_1_create_material_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_create_material_state_response.xhtml#a9a8b6cb14c50dafac53340cb41e5632a", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1material_1_1_create_material_state_response.xhtml#a0f56efce5ac58a785dafe4ff3a62232d", null ],
    [ "status", "structasset__preparation_1_1v3_1_1material_1_1_create_material_state_response.xhtml#a447e27bd2239794bfa2ad0bef4f247be", null ]
];