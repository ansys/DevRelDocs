var structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_identity.xhtml#a60317e7acad23668d8b28ccf37aa9302", null ],
    [ "name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_hdri_sky_identity.xhtml#a242ee4bc9d9e58b56a42ed2eb8a71c8f", null ]
];