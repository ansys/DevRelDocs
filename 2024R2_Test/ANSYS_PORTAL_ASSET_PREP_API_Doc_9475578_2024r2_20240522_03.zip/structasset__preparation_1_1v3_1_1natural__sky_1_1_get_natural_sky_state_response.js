var structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_state_response.xhtml#a075799e972d5d48c08a3b246d3cd01e9", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_state_response.xhtml#ad490fc78661ce0be29abd601975e3f57", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_state_response.xhtml#a860cfd6ec1bdf54ee8248104acf7f9d4", null ],
    [ "status", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_state_response.xhtml#a268738961fc097d7d9772e85078d28bc", null ]
];