var structasset__preparation_1_1v3_1_1material_1_1_get_material_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_get_material_request.xhtml#a7132bf1fafee7bdc053d0d91aedb0cd7", null ]
];