var structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_vertices_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_vertices_request.xhtml#a3253b1b472fdf504062019ef44232b0f", null ]
];