var structasset__preparation_1_1v3_1_1natural__sky_1_1_delete_natural_sky_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_delete_natural_sky_state_request.xhtml#a52882fcbe9c5158df06fa86c2f1f3943", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_delete_natural_sky_state_request.xhtml#a69400a63515df9f43eec61c173401b40", null ]
];