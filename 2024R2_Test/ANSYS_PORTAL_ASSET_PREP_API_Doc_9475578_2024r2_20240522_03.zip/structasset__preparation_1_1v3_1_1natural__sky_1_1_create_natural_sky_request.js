var structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_request =
[
    [ "name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_request.xhtml#ad224ecd6191034a3909c262d5d4de648", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_request.xhtml#a54a0c11d7240bd7785f2c3a948f3f227", null ]
];