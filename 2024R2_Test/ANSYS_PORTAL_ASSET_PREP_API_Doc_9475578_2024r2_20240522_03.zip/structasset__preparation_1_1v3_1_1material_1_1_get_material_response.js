var structasset__preparation_1_1v3_1_1material_1_1_get_material_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1material_1_1_get_material_response.xhtml#a209b9b372fd6a21546c319920991ebfa", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1material_1_1_get_material_response.xhtml#a387dfc0d53955bf61c8ed34bcc8e089e", null ],
    [ "state_names", "structasset__preparation_1_1v3_1_1material_1_1_get_material_response.xhtml#a06998b04d0ca815ce9586619264668d0", null ],
    [ "status", "structasset__preparation_1_1v3_1_1material_1_1_get_material_response.xhtml#a5843c59f6dea1f038df78d973337e74a", null ]
];