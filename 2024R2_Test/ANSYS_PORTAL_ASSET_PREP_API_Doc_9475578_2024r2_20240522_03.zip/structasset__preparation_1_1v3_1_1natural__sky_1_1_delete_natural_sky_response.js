var structasset__preparation_1_1v3_1_1natural__sky_1_1_delete_natural_sky_response =
[
    [ "status", "structasset__preparation_1_1v3_1_1natural__sky_1_1_delete_natural_sky_response.xhtml#a1bd581e689719eab496fe527b0cb1355", null ]
];