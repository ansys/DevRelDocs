var structasset__preparation_1_1v3_1_1material_1_1_roughness_properties =
[
    [ "texture", "structasset__preparation_1_1v3_1_1material_1_1_roughness_properties.xhtml#afd86a50949d90ea181fa310f3838d0ee", null ],
    [ "color", "structasset__preparation_1_1v3_1_1material_1_1_roughness_properties.xhtml#a4a17d2a77b3e0fecfcf98d41fd17288f", null ]
];