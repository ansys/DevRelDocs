var structasset__preparation_1_1v3_1_1material_1_1_lambertian_layer =
[
    [ "absorption", "structasset__preparation_1_1v3_1_1material_1_1_lambertian_layer.xhtml#aec8bbe1f6731c92df8e02416d0c6e6ae", null ],
    [ "diffuse_properties", "structasset__preparation_1_1v3_1_1material_1_1_lambertian_layer.xhtml#a03774b596debf7a37744b2a8e218dbc4", null ],
    [ "normal_properties", "structasset__preparation_1_1v3_1_1material_1_1_lambertian_layer.xhtml#ad2f3768bbedf6d3f4da913e33b0e525f", null ],
    [ "anisotropy_properties", "structasset__preparation_1_1v3_1_1material_1_1_lambertian_layer.xhtml#a5d3ce850598aea03332b257b1e6a9b07", null ],
    [ "mask_properties", "structasset__preparation_1_1v3_1_1material_1_1_lambertian_layer.xhtml#a39f52b212462e0d746a3308a8816e166", null ]
];