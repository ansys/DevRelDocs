var structasset__preparation_1_1v3_1_1material_1_1_list_materials_response =
[
    [ "materials", "structasset__preparation_1_1v3_1_1material_1_1_list_materials_response.xhtml#a1372bf0f68de0ffd6ca19361c035c247", null ],
    [ "status", "structasset__preparation_1_1v3_1_1material_1_1_list_materials_response.xhtml#a77afe6641be054feae94447895219a80", null ]
];