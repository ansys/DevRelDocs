var structasset__preparation_1_1v3_1_1surface__source_1_1_source_properties =
[
    [ "surface_source", "structasset__preparation_1_1v3_1_1surface__source_1_1_source_properties.xhtml#a79ee27d5a88e42e1a1b07701d648f5f4", null ],
    [ "display_source", "structasset__preparation_1_1v3_1_1surface__source_1_1_source_properties.xhtml#a9354af3a961121fb63d1058abaf5914d", null ]
];