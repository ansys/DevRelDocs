var structasset__preparation_1_1v3_1_1material_1_1_get_material_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_get_material_state_request.xhtml#a653e6a1cd4aaae1bfe19bb100d22401a", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1material_1_1_get_material_state_request.xhtml#a9a3b68ac12aab49bbf0dbba30b5605c3", null ]
];