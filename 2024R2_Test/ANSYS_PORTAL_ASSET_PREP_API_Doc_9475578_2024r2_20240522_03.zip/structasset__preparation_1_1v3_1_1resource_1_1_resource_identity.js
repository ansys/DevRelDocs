var structasset__preparation_1_1v3_1_1resource_1_1_resource_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1resource_1_1_resource_identity.xhtml#ade820d3dcc41de648bbf2c02f9f294e2", null ],
    [ "type", "structasset__preparation_1_1v3_1_1resource_1_1_resource_identity.xhtml#ac711f8e5ea2a328a19e6838398a77673", null ],
    [ "name", "structasset__preparation_1_1v3_1_1resource_1_1_resource_identity.xhtml#af248c60fbd610ed79d4e00970ee0133a", null ]
];