var structasset__preparation_1_1v3_1_1material_1_1_anisotropy_texture =
[
    [ "map_identifier", "structasset__preparation_1_1v3_1_1material_1_1_anisotropy_texture.xhtml#a876b08c37ac0f238902730ee6133a727", null ],
    [ "map_uv_channel", "structasset__preparation_1_1v3_1_1material_1_1_anisotropy_texture.xhtml#ad7b92f03952247eadfc1bb321486edd3", null ]
];