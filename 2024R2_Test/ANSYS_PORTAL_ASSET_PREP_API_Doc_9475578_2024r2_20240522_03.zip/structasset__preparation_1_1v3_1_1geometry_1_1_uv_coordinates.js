var structasset__preparation_1_1v3_1_1geometry_1_1_uv_coordinates =
[
    [ "x", "structasset__preparation_1_1v3_1_1geometry_1_1_uv_coordinates.xhtml#a7bc83a0c132996f759a80877de54e269", null ],
    [ "y", "structasset__preparation_1_1v3_1_1geometry_1_1_uv_coordinates.xhtml#ae3893a87e56a16f2091ecd499ccfd59a", null ]
];