var structasset__preparation_1_1v3_1_1material_1_1_library_volume_optical_properties =
[
    [ "volume_material_identifier", "structasset__preparation_1_1v3_1_1material_1_1_library_volume_optical_properties.xhtml#af5ae69236d781957b4ba3ec1367c80ea", null ]
];