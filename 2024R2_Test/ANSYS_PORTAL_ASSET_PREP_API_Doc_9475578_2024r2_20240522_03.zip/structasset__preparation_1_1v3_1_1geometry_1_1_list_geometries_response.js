var structasset__preparation_1_1v3_1_1geometry_1_1_list_geometries_response =
[
    [ "geometries", "structasset__preparation_1_1v3_1_1geometry_1_1_list_geometries_response.xhtml#af0942aa3b5f93e40dcf8ba5bf885f869", null ],
    [ "status", "structasset__preparation_1_1v3_1_1geometry_1_1_list_geometries_response.xhtml#a519c43dba16c3c7221a5f73ca52c3cbf", null ]
];