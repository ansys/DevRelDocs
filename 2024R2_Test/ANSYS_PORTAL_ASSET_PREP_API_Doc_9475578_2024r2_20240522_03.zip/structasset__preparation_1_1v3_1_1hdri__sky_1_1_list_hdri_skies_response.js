var structasset__preparation_1_1v3_1_1hdri__sky_1_1_list_hdri_skies_response =
[
    [ "skies", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_list_hdri_skies_response.xhtml#a08f0bf09d5c5a1cb5204f38baafa2e7a", null ],
    [ "status", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_list_hdri_skies_response.xhtml#ae449f15a87f81d2c038f3540fc31f379", null ]
];