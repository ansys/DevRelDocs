var structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_directional_light_instance_request =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_directional_light_instance_request.xhtml#a7800052e548e4c99467c94b85beaa506", null ],
    [ "instance_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_directional_light_instance_request.xhtml#aa9d28e0621383041ef5519aab4d51cef", null ]
];