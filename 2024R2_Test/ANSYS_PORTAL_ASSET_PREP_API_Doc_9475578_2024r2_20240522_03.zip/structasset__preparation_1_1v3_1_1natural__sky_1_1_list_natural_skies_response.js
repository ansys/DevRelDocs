var structasset__preparation_1_1v3_1_1natural__sky_1_1_list_natural_skies_response =
[
    [ "skies", "structasset__preparation_1_1v3_1_1natural__sky_1_1_list_natural_skies_response.xhtml#a59e9a0476272087e471de6ba9cd30f24", null ],
    [ "status", "structasset__preparation_1_1v3_1_1natural__sky_1_1_list_natural_skies_response.xhtml#a9700cafd493d23d521db27cc2b90c8b2", null ]
];