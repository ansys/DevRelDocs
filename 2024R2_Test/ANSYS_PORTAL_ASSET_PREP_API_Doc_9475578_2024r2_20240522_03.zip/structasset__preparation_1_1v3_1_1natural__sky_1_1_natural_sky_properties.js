var structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_properties =
[
    [ "time", "structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_properties.xhtml#a4c4eeb4d678fda3ee6ee512dc0153b41", null ],
    [ "date", "structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_properties.xhtml#a4e60a7577d87e2e3186c4a487f6dc5dd", null ],
    [ "location", "structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_properties.xhtml#afc5b2e6fcbdedb69597d0e96835fdd45", null ],
    [ "ambient_conditions", "structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_properties.xhtml#a44f1aa8a6ba1859b0568b6dbad03a2f3", null ],
    [ "no_shadow", "structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_properties.xhtml#a732e2113c4d5ddca772aac81541c88c5", null ],
    [ "dynamic_accurate_shadows", "structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_properties.xhtml#a9acaeb7805f1bb84a88287714824b4f8", null ]
];