var structasset__preparation_1_1v3_1_1environment_1_1_sky_lists =
[
    [ "hdri_skies", "structasset__preparation_1_1v3_1_1environment_1_1_sky_lists.xhtml#ade96049ac894919b0a42bb0f98be8781", null ],
    [ "natural_skies", "structasset__preparation_1_1v3_1_1environment_1_1_sky_lists.xhtml#a0361abb2f31c9c78d1424eb24a40cf18", null ]
];