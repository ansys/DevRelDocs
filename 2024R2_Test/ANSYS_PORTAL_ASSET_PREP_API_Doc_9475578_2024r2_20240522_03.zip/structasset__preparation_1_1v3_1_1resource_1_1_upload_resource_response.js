var structasset__preparation_1_1v3_1_1resource_1_1_upload_resource_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1resource_1_1_upload_resource_response.xhtml#a21035324cd744eab07646cba1099d1e6", null ],
    [ "status", "structasset__preparation_1_1v3_1_1resource_1_1_upload_resource_response.xhtml#ab5d0c2ee28b9121a06f79e6aa280f847", null ]
];