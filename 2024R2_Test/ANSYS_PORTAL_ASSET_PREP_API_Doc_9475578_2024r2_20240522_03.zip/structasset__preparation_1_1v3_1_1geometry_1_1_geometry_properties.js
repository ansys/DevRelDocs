var structasset__preparation_1_1v3_1_1geometry_1_1_geometry_properties =
[
    [ "winding_order", "structasset__preparation_1_1v3_1_1geometry_1_1_geometry_properties.xhtml#aef3782f63e40f5f13c3b489670749a60", null ],
    [ "has_binormals", "structasset__preparation_1_1v3_1_1geometry_1_1_geometry_properties.xhtml#a074bf199a483f4f76171d72f08676b9d", null ],
    [ "has_tangents", "structasset__preparation_1_1v3_1_1geometry_1_1_geometry_properties.xhtml#a691d23de558da9521777cadee9d35a7c", null ],
    [ "uv_count", "structasset__preparation_1_1v3_1_1geometry_1_1_geometry_properties.xhtml#a7e9c25df92bf5f07e00ee7b7a772b92f", null ]
];