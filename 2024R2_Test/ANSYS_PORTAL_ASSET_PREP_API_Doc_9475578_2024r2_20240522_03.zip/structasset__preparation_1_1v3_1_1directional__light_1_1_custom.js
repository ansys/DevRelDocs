var structasset__preparation_1_1v3_1_1directional__light_1_1_custom =
[
    [ "exitance", "structasset__preparation_1_1v3_1_1directional__light_1_1_custom.xhtml#ae65e35ece99b2b5331074385f63f5285", null ],
    [ "spectrum_library", "structasset__preparation_1_1v3_1_1directional__light_1_1_custom.xhtml#ab7f99670794fafb421994f0d927ca1b1", null ],
    [ "black_body", "structasset__preparation_1_1v3_1_1directional__light_1_1_custom.xhtml#a1dab03af33b34241a92a95c01e4ceafa", null ],
    [ "monochromatic", "structasset__preparation_1_1v3_1_1directional__light_1_1_custom.xhtml#a27ae8fbdea5ac36dc601da8a95ed9841", null ]
];