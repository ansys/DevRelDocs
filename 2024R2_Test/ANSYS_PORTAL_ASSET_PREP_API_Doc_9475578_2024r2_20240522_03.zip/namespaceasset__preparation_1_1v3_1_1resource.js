var namespaceasset__preparation_1_1v3_1_1resource =
[
    [ "DeleteResourceRequest", "structasset__preparation_1_1v3_1_1resource_1_1_delete_resource_request.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_delete_resource_request" ],
    [ "DeleteResourceResponse", "structasset__preparation_1_1v3_1_1resource_1_1_delete_resource_response.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_delete_resource_response" ],
    [ "DownloadResourceAsChunksRequest", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_chunks_request.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_chunks_request" ],
    [ "DownloadResourceAsFileRequest", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_request.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_request" ],
    [ "DownloadResourceAsFileResponse", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_response.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_response" ],
    [ "ListResourcesRequest", "structasset__preparation_1_1v3_1_1resource_1_1_list_resources_request.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_list_resources_request" ],
    [ "ListResourcesResponse", "structasset__preparation_1_1v3_1_1resource_1_1_list_resources_response.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_list_resources_response" ],
    [ "ResourceIdentity", "structasset__preparation_1_1v3_1_1resource_1_1_resource_identity.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_resource_identity" ],
    [ "ResourcePreparation", "classasset__preparation_1_1v3_1_1resource_1_1_resource_preparation.xhtml", "classasset__preparation_1_1v3_1_1resource_1_1_resource_preparation" ],
    [ "UploadResourceResponse", "structasset__preparation_1_1v3_1_1resource_1_1_upload_resource_response.xhtml", "structasset__preparation_1_1v3_1_1resource_1_1_upload_resource_response" ]
];