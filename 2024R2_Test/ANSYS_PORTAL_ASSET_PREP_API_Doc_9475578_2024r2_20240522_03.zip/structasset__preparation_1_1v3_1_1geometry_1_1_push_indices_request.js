var structasset__preparation_1_1v3_1_1geometry_1_1_push_indices_request =
[
    [ "geometry_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_push_indices_request.xhtml#a3773d687841288029b55af89763453f0", null ],
    [ "indices", "structasset__preparation_1_1v3_1_1geometry_1_1_push_indices_request.xhtml#a00f8b49c8caf819fbff4448f04a3cc01", null ]
];