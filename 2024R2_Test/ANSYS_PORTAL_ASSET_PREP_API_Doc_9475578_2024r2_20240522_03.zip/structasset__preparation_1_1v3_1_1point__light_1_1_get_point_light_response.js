var structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_response.xhtml#a4376628ba229145e88c9da71b352b4eb", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_response.xhtml#a9248601a47311fadbd70c2daf211da32", null ],
    [ "state_names", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_response.xhtml#a7f53f799b913144e13f5999c20facaef", null ],
    [ "status", "structasset__preparation_1_1v3_1_1point__light_1_1_get_point_light_response.xhtml#a9cfb33f440be36b0ad0e9fdb15475482", null ]
];