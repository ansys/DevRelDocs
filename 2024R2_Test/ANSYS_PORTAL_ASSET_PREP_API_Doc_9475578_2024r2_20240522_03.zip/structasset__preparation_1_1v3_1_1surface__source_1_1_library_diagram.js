var structasset__preparation_1_1v3_1_1surface__source_1_1_library_diagram =
[
    [ "diagram_identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_library_diagram.xhtml#a3349f00f87faf3b54770e5bdfc8124db", null ],
    [ "offset", "structasset__preparation_1_1v3_1_1surface__source_1_1_library_diagram.xhtml#ae23d5b1c3bc0e8eecbbc92f34f8e59e1", null ]
];