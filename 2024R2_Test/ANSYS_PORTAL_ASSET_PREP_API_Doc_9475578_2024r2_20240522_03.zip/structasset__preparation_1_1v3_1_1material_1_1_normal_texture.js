var structasset__preparation_1_1v3_1_1material_1_1_normal_texture =
[
    [ "map_identifier", "structasset__preparation_1_1v3_1_1material_1_1_normal_texture.xhtml#adcebe75c552c31359209907ba9d43b1e", null ],
    [ "map_uv_channel", "structasset__preparation_1_1v3_1_1material_1_1_normal_texture.xhtml#aafda93475a58d27396301bae83afce16", null ],
    [ "intensity", "structasset__preparation_1_1v3_1_1material_1_1_normal_texture.xhtml#a458c55e8be74fb6feaf80dd665623a85", null ]
];