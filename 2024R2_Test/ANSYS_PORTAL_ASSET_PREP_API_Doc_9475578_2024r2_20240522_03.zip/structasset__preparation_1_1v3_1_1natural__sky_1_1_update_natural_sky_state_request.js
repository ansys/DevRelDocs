var structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_state_request.xhtml#ad3fb7fcb041981c058713db0ef896826", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_state_request.xhtml#a0908a9bd58e1dff461939397eaa54bdf", null ],
    [ "state_new_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_state_request.xhtml#a872dc11f6533dc9f8053042d3bae284c", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_state_request.xhtml#a93b444a18b119f08c1a4702972c1ddd7", null ]
];