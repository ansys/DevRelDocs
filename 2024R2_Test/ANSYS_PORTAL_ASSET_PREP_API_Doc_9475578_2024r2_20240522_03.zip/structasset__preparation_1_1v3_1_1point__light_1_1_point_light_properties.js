var structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties =
[
    [ "intensity", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties.xhtml#a43ef8886014d5d1933c583bd7b5cbfd8", null ],
    [ "spectrum_library", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties.xhtml#a11fc596b209fa26a3adb4453947a6c4d", null ],
    [ "black_body", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties.xhtml#ad3306fa5205573f9cd7778aa80d435d7", null ],
    [ "monochromatic", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties.xhtml#ad336457a8be58ddeabc2eae58c6bc6df", null ],
    [ "no_shadow", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties.xhtml#aff2b0e74e2b7c517cffbab3c09c4bb94", null ],
    [ "static_shadows", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties.xhtml#a264b76bef3a45c7a33f9bca236623fb3", null ],
    [ "dynamic_shadows", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties.xhtml#a28cde849716286e6fda67458154eb560", null ],
    [ "rendering", "structasset__preparation_1_1v3_1_1point__light_1_1_point_light_properties.xhtml#aecde62fdf27bdb30b3bb2c58fa3780bc", null ]
];