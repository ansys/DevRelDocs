var structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_response.xhtml#a4e3b43fa56c6d9a777c1b64818a7d484", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_response.xhtml#aa80d4c0ae85a932fd41142815bd08429", null ],
    [ "status", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_state_response.xhtml#af55e561c564aad59aa683274dd7d9faa", null ]
];