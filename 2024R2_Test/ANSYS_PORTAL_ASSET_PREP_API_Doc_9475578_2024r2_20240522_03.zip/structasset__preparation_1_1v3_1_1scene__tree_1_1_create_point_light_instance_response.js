var structasset__preparation_1_1v3_1_1scene__tree_1_1_create_point_light_instance_response =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_point_light_instance_response.xhtml#a2a86ab4a5d82b33effb425f058677de5", null ],
    [ "instance_identity", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_point_light_instance_response.xhtml#a93ac3fce8d14b9c9ea33de909f108312", null ],
    [ "status", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_point_light_instance_response.xhtml#af0a125b288302e6468f824deec4a7373", null ]
];