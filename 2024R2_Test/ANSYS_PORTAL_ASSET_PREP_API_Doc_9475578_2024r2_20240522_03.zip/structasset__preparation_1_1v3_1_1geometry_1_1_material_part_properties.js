var structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties =
[
    [ "transparency_mode", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#a9edbc3e68aa86d15e7ac8c89dfd87602", null ],
    [ "surface_source_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#a05ec5a6fd1ccca29895ff2475a929b80", null ],
    [ "material_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#a53b37efd2c680647ae405273ea4b8f78", null ],
    [ "start_index", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#a9e43279dafd887d32958888c60907f58", null ],
    [ "indices_count", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#a4d85e5e1748da4ac7a8f5655f8a4e184", null ],
    [ "temperature_variation_texture_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#a1fcf22b47c2fc8c2baa5d55365581973", null ],
    [ "temperature_variation_uv_channel", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#adcefeef9c2ef4a0fc60874b178ecc54a", null ],
    [ "temperature_variation_amplitude", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#aa33988c275158c00f82ae7f037457202", null ],
    [ "removed_tags", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#ae285509d5f4b737cdb9f11677651eb28", null ],
    [ "added_tags", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_properties.xhtml#a882ea82b0a5c8f8e8e97e784c521420a", null ]
];