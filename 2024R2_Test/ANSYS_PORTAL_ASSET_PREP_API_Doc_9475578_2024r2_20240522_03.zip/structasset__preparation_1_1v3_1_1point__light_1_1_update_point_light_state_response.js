var structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_state_response =
[
    [ "state_name", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_state_response.xhtml#aa0d1cc4d395e27047df54e7627fc63b3", null ],
    [ "status", "structasset__preparation_1_1v3_1_1point__light_1_1_update_point_light_state_response.xhtml#a7feb17c0bedc735ef73f08c7a085af2f", null ]
];