var structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_request.xhtml#a90762e78f5622dbf0fccba28a95aec84", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_request.xhtml#a13098ff4bdfda669b54625ff359c1ccf", null ],
    [ "base_state_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_request.xhtml#a8c90ac928fd00a17b6ac35c07d06c342", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_request.xhtml#a3f1c69e1c3fba50d914edfab24a77b7c", null ]
];