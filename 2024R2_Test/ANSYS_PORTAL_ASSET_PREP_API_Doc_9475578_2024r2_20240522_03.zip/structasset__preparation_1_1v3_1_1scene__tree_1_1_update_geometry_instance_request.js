var structasset__preparation_1_1v3_1_1scene__tree_1_1_update_geometry_instance_request =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_geometry_instance_request.xhtml#aaf5541eb906413178f0ace6c6f5d9b27", null ],
    [ "instance_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_geometry_instance_request.xhtml#a2ec22ddfb5ff74f5d76d8018641ade6d", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_geometry_instance_request.xhtml#a3b0c170aec7cdf953a02ae7d974e42cd", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_geometry_instance_request.xhtml#a5251833fb0d6ebbeded2fb981e5e5964", null ]
];