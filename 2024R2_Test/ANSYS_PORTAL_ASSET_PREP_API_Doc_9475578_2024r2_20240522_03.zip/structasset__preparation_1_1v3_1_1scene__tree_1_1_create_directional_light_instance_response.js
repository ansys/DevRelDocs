var structasset__preparation_1_1v3_1_1scene__tree_1_1_create_directional_light_instance_response =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_directional_light_instance_response.xhtml#a19fd04d61aeda8814e0989ca6ed29e1a", null ],
    [ "instance_identity", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_directional_light_instance_response.xhtml#a692937cdc7e35ecdaade1c7307230054", null ],
    [ "status", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_directional_light_instance_response.xhtml#a83d4804c539c98301b51afd4d2d21b6d", null ]
];