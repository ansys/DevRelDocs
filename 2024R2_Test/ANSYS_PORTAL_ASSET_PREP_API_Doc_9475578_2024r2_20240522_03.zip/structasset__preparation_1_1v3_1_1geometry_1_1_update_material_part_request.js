var structasset__preparation_1_1v3_1_1geometry_1_1_update_material_part_request =
[
    [ "geometry_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_update_material_part_request.xhtml#ab72d1b0bf3ea1db40c18d89e1f30b455", null ],
    [ "material_part_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_update_material_part_request.xhtml#a3de3888ec62aee7ee6002f24057d087c", null ],
    [ "name", "structasset__preparation_1_1v3_1_1geometry_1_1_update_material_part_request.xhtml#abf37faf2a2af9b91e87648b2a9dba8b7", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1geometry_1_1_update_material_part_request.xhtml#a90f05dd50341f057ecb0fb44f85788b0", null ]
];