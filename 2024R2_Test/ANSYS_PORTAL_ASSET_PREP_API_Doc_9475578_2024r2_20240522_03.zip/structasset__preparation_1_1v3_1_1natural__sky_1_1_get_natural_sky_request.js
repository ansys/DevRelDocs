var structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_request.xhtml#afefc3f44788f075fa697b57d57496f1c", null ]
];