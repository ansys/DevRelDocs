var classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation =
[
    [ "CreatePointLight", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#ad8a5a55a63f741a1d8b0212e431ff7d6", null ],
    [ "GetPointLight", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#a547cd20295a5858ae5862414c9fee959", null ],
    [ "ListPointLights", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#a11cbf10b763127930a1111ffa3b9388d", null ],
    [ "UpdatePointLight", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#a70bb2c7bbc291c82c81e7ec0451d324b", null ],
    [ "DeletePointLight", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#a0bdaae739890424ba67dfd1dc93b963e", null ],
    [ "CreatePointLightState", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#aef844abdb66eb05d7592239e60786b5f", null ],
    [ "GetPointLightState", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#a03eb04e93556fb36124f7d3a9a1cbcdf", null ],
    [ "UpdatePointLightState", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#a7ddee84a086f91345b96044c26df8743", null ],
    [ "DeletePointLightState", "classasset__preparation_1_1v3_1_1point__light_1_1_point_light_preparation.xhtml#a28924c368c18f5e0854a68753e38df81", null ]
];