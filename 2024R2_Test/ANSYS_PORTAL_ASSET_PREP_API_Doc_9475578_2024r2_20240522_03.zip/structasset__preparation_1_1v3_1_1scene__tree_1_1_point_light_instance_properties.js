var structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_properties =
[
    [ "point_light_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_properties.xhtml#a6c3569cfdf96ef7ebbd35364b96080b1", null ],
    [ "transform", "structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_properties.xhtml#a4c6704506db800f256f4617849d8c06b", null ],
    [ "visibility", "structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_properties.xhtml#a8743f89f77f858738c6cbbb162d11fb5", null ],
    [ "removed_tags", "structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_properties.xhtml#a11a1e40222cda28c221e3ff7b993cb1b", null ],
    [ "added_tags", "structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_properties.xhtml#afae330068b4e33f157c71fcc9a1b3987", null ]
];