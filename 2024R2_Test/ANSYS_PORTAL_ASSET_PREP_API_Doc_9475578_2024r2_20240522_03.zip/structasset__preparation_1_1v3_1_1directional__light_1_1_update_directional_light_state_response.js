var structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_state_response =
[
    [ "state_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_state_response.xhtml#a138831a08c93f1fcaf8c38723fea7e18", null ],
    [ "status", "structasset__preparation_1_1v3_1_1directional__light_1_1_update_directional_light_state_response.xhtml#a44a47d7d3a1ae3911cd1c0512b9691e3", null ]
];