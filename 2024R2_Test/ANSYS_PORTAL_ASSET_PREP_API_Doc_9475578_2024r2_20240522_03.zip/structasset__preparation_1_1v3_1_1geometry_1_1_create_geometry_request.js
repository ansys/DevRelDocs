var structasset__preparation_1_1v3_1_1geometry_1_1_create_geometry_request =
[
    [ "name", "structasset__preparation_1_1v3_1_1geometry_1_1_create_geometry_request.xhtml#a56c171bb469662a77bfa93908311b676", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1geometry_1_1_create_geometry_request.xhtml#af183632980e778d65d345835719dfc72", null ]
];