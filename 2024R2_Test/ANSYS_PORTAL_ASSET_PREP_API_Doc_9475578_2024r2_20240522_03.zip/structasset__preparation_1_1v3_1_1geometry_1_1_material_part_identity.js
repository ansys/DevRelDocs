var structasset__preparation_1_1v3_1_1geometry_1_1_material_part_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_identity.xhtml#ab250a1206aa45f17ed50757aeb83d66c", null ],
    [ "name", "structasset__preparation_1_1v3_1_1geometry_1_1_material_part_identity.xhtml#a8a32e56424db527620b24433d8e44deb", null ]
];