var structasset__preparation_1_1v3_1_1geometry_1_1_vertex =
[
    [ "x_position", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a73a33da7702e17581d3476e7454edcfd", null ],
    [ "y_position", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a00aef9be78dc8dc7bf6c17ae2d0695d8", null ],
    [ "z_position", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#afb978b6505e1e55a42ad283e98ed8602", null ],
    [ "x_normal", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a9b0acbe91bcbef946774572d2bb5cad1", null ],
    [ "y_normal", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a16a769572c99108c853cdcc41c4852b3", null ],
    [ "z_normal", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a48935c0d191e4ec7c5da139f7f422dc8", null ],
    [ "x_binormal", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a199cc6784dedaf18c61c9e84adc55a58", null ],
    [ "y_binormal", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#aacc1b7443aa79a8e6deffd392f60dda2", null ],
    [ "z_binormal", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a45e0cff2e3ed2d86032502293b5f52e7", null ],
    [ "x_tangent", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a0c6e843d4281ff137d8029633ecf6972", null ],
    [ "y_tangent", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#a4b0294d5d53747b373f8f4da296e8353", null ],
    [ "z_tangent", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#ac67fcff5ed6bb44e07f6b6bdf412220c", null ],
    [ "uv_coordinates", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#ac2d514c2c60a473d7e512077ad81e92a", null ],
    [ "ambient_occlusion", "structasset__preparation_1_1v3_1_1geometry_1_1_vertex.xhtml#ac9152bb4b7e552725bf1b347cbf77339", null ]
];