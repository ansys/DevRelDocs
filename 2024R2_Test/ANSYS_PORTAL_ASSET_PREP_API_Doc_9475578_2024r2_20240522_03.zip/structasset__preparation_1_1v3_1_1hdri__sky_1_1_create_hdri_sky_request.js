var structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_request =
[
    [ "name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_request.xhtml#a79f9440ea20937d66d6d1efcffd0f4e7", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_request.xhtml#a9084970410452804cba2cce7580b8055", null ]
];