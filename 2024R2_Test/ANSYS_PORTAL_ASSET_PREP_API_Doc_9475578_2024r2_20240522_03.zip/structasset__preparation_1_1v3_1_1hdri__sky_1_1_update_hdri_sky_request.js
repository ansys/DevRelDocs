var structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_request.xhtml#aa3f96c8e50cdb7ae9e2a6390061be000", null ],
    [ "name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_request.xhtml#af11265375fc65de8aec03d5adc272899", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_request.xhtml#a93297f511fa75e4b8119467326c38a1f", null ]
];