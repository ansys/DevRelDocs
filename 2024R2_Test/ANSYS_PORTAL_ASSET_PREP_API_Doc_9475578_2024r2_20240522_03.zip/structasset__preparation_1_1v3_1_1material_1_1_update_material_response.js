var structasset__preparation_1_1v3_1_1material_1_1_update_material_response =
[
    [ "status", "structasset__preparation_1_1v3_1_1material_1_1_update_material_response.xhtml#afef70397e77e0cd6763d5d70f60e70a1", null ]
];