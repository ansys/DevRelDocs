var structasset__preparation_1_1v3_1_1point__light_1_1_list_point_lights_response =
[
    [ "point_lights", "structasset__preparation_1_1v3_1_1point__light_1_1_list_point_lights_response.xhtml#aaad292170af96aa8e32652439b9a2f7a", null ],
    [ "status", "structasset__preparation_1_1v3_1_1point__light_1_1_list_point_lights_response.xhtml#a71da205604abb161c81e1b25dfd5ff14", null ]
];