var structasset__preparation_1_1v3_1_1material_1_1_material_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_material_identity.xhtml#a4e996e4d025de4082cd6fc583f7e48f9", null ],
    [ "name", "structasset__preparation_1_1v3_1_1material_1_1_material_identity.xhtml#ade33e4323f7f55582a8a9394f3290f78", null ]
];