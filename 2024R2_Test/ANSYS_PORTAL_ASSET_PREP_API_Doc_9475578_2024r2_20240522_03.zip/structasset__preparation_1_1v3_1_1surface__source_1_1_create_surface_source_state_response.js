var structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_response.xhtml#a4ced86780a232034265ad263a6a66275", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_response.xhtml#a6306854cff588db421e19c39fa05cc36", null ],
    [ "status", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_state_response.xhtml#ad0eed9f8303e724aa55a9aa13b2f7d3f", null ]
];