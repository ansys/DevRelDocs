var structasset__preparation_1_1v3_1_1surface__source_1_1_get_surface_source_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_get_surface_source_state_request.xhtml#aef74d9cabaaa36dcdcbe32e9423046cd", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_get_surface_source_state_request.xhtml#acb13364802f68e45f908699cbd56ee7a", null ]
];