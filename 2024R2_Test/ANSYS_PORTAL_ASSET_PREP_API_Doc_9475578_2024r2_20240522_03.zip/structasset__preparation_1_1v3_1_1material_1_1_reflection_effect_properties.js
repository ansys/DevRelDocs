var structasset__preparation_1_1v3_1_1material_1_1_reflection_effect_properties =
[
    [ "no_reflection_effect", "structasset__preparation_1_1v3_1_1material_1_1_reflection_effect_properties.xhtml#adf8a4d91851de3bf89961d4364389988", null ],
    [ "scene_hdri", "structasset__preparation_1_1v3_1_1material_1_1_reflection_effect_properties.xhtml#a1f042cd801129e46fdc5d0788e6eaa6b", null ]
];