var structasset__preparation_1_1v3_1_1directional__light_1_1_dynamic_accurate_shadows =
[
    [ "shadow_offset_ratio", "structasset__preparation_1_1v3_1_1directional__light_1_1_dynamic_accurate_shadows.xhtml#a8b40807f68ed7b03ce9fa89d7e431c0a", null ],
    [ "shadow_radius", "structasset__preparation_1_1v3_1_1directional__light_1_1_dynamic_accurate_shadows.xhtml#a6f2d280e28c429e61730514399641d37", null ],
    [ "softness", "structasset__preparation_1_1v3_1_1directional__light_1_1_dynamic_accurate_shadows.xhtml#ac3f1c00b975a26d8fca745ed70d05a6f", null ],
    [ "resolution", "structasset__preparation_1_1v3_1_1directional__light_1_1_dynamic_accurate_shadows.xhtml#a00e3a57a5c959e343f3ecb15d8709e15", null ],
    [ "near_field_precision", "structasset__preparation_1_1v3_1_1directional__light_1_1_dynamic_accurate_shadows.xhtml#aba7ac5bcf85e35c1b3a56545718a3e03", null ]
];