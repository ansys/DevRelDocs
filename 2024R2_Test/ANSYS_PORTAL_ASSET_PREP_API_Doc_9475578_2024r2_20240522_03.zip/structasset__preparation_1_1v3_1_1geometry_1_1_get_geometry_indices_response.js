var structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_indices_response =
[
    [ "indices", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_indices_response.xhtml#a85a55e746dfedf627e89653d09c2df73", null ],
    [ "status", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_indices_response.xhtml#a9b78a182b0d33883aa2b30c41a80d6ac", null ]
];