var structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_identity.xhtml#addfbba4112325ccf0e79ecee3a1b25ab", null ],
    [ "name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_natural_sky_identity.xhtml#a850c2d7b842c2fdaa5079bb4b8314845", null ]
];