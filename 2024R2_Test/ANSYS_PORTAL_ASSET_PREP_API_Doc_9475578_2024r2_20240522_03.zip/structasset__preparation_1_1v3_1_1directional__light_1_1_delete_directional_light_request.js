var structasset__preparation_1_1v3_1_1directional__light_1_1_delete_directional_light_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_delete_directional_light_request.xhtml#af0b789ac9df7cac18f48c64f569cdb37", null ]
];