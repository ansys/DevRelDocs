var structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_response.xhtml#a74a8716736d9ee389f73eb3c698f17b8", null ],
    [ "status", "structasset__preparation_1_1v3_1_1directional__light_1_1_create_directional_light_response.xhtml#a25f74cb14b7400495a57c2daf5c238a8", null ]
];