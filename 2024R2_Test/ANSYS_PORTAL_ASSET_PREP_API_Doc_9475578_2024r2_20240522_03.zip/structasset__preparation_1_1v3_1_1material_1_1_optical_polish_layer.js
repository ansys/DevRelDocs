var structasset__preparation_1_1v3_1_1material_1_1_optical_polish_layer =
[
    [ "diffuse_properties", "structasset__preparation_1_1v3_1_1material_1_1_optical_polish_layer.xhtml#a39a76526c010c53647128c7089332dfd", null ],
    [ "normal_properties", "structasset__preparation_1_1v3_1_1material_1_1_optical_polish_layer.xhtml#a50e2bf38970938bc152619e2d67f4b6b", null ],
    [ "anisotropy_properties", "structasset__preparation_1_1v3_1_1material_1_1_optical_polish_layer.xhtml#a4d279e82ad3430e67a5165539ac21869", null ],
    [ "mask_properties", "structasset__preparation_1_1v3_1_1material_1_1_optical_polish_layer.xhtml#a5dfd2cb3696bbd8ce9bb9db3cacb47c9", null ]
];