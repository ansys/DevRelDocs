var structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_properties =
[
    [ "geometry_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_properties.xhtml#aa4f2d25cc31e1f178a64035437986236", null ],
    [ "transform", "structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_properties.xhtml#a81803ea3e9b4fc73efe97525152df132", null ],
    [ "visibility", "structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_properties.xhtml#a3501c8b6961d0970c90e1eafba1f5577", null ],
    [ "thermal_properties", "structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_properties.xhtml#ac3895a8438e4608602ff7533f7ee5a7e", null ],
    [ "removed_tags", "structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_properties.xhtml#a042ebbd6966066f4800daf1342b8afbf", null ],
    [ "added_tags", "structasset__preparation_1_1v3_1_1scene__tree_1_1_geometry_instance_properties.xhtml#a7f34c7de30e08a842eefd27bc10b518b", null ]
];