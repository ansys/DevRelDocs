var structasset__preparation_1_1v3_1_1material_1_1_diffuse_properties =
[
    [ "color_rgb", "structasset__preparation_1_1v3_1_1material_1_1_diffuse_properties.xhtml#a51aed3dda3b4e24b692cd984714840b4", null ],
    [ "color_hsv", "structasset__preparation_1_1v3_1_1material_1_1_diffuse_properties.xhtml#a757c85ba17c2412ad14f5fcf93b0e95f", null ],
    [ "texture", "structasset__preparation_1_1v3_1_1material_1_1_diffuse_properties.xhtml#aea8bb06029db92591131ab56ee019b08", null ]
];