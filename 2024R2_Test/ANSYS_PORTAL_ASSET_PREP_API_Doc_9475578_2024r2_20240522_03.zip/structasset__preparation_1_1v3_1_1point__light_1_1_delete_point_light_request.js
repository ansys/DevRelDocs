var structasset__preparation_1_1v3_1_1point__light_1_1_delete_point_light_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_delete_point_light_request.xhtml#ab159857bfddae1f6f93d4e782690dce4", null ]
];