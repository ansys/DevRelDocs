var structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_response.xhtml#ad43863402ab16bb1448bcf8afe3e4730", null ],
    [ "status", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_response.xhtml#adfe47d348feac8952965533721c1087b", null ]
];