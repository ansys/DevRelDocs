var structasset__preparation_1_1v3_1_1point__light_1_1_black_body =
[
    [ "temperature", "structasset__preparation_1_1v3_1_1point__light_1_1_black_body.xhtml#a87a296a77c508f916c5d9a49d1f4c9f7", null ]
];