var structasset__preparation_1_1v3_1_1geometry_1_1_get_material_part_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_get_material_part_request.xhtml#ae62d3f59e14a301612f0a9784199def5", null ]
];