var structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution =
[
    [ "joint", "structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution.xhtml#a4ece76c55fb0685a336737904a1f18f7", null ],
    [ "disjoint_flux_distribution", "structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution.xhtml#a56ad1d9f519896711a745cf2a69be255", null ],
    [ "orientation_offset", "structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution.xhtml#aadd6ebe33c0d080db09d0aa230c29447", null ],
    [ "position_offset", "structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution.xhtml#ac083643c3189465becc835f1f84126ac", null ],
    [ "rendering", "structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution.xhtml#a8686b4add2f583a83cb1c75ba30b837a", null ],
    [ "no_shadow", "structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution.xhtml#ab5146182e79f7f54be0cc7490334521e", null ],
    [ "static_shadows", "structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution.xhtml#ab14309e0e008d644403d65890887cbb8", null ],
    [ "dynamic_shadows", "structasset__preparation_1_1v3_1_1surface__source_1_1_lighting_contribution.xhtml#ad956cdf2123904333d5c545f56653036", null ]
];