var structasset__preparation_1_1v3_1_1material_1_1_create_material_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_create_material_state_request.xhtml#ab674211cb035bd851888773d002f95c7", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1material_1_1_create_material_state_request.xhtml#a74f675a90fb2db1db23ab2cfae6603da", null ],
    [ "base_state_name", "structasset__preparation_1_1v3_1_1material_1_1_create_material_state_request.xhtml#a6f6ddb473408cd574450bf41cf5d24a9", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1material_1_1_create_material_state_request.xhtml#a23716fca62ff2ce5650abae100d83ddb", null ]
];