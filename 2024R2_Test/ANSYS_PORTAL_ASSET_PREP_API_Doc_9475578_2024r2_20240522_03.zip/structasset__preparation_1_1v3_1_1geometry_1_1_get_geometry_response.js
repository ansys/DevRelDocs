var structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_response.xhtml#a96789880abcd1e969dafaf46fd4f6aa2", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_response.xhtml#a40471e01e72a815f2e5db9e24645a40e", null ],
    [ "material_parts", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_response.xhtml#a07798f9d84da0ebce8bbde6e8e38a891", null ],
    [ "status", "structasset__preparation_1_1v3_1_1geometry_1_1_get_geometry_response.xhtml#ab8166afe2585db9eeaff1b6226cc5641", null ]
];