var structasset__preparation_1_1v3_1_1scene__tree_1_1_thermal_properties =
[
    [ "no_custom_temperature", "structasset__preparation_1_1v3_1_1scene__tree_1_1_thermal_properties.xhtml#a9c54badb2abd1955efb79f5100b0356b", null ],
    [ "custom_temperature", "structasset__preparation_1_1v3_1_1scene__tree_1_1_thermal_properties.xhtml#a2f9b48d745461a8e4528b8ca451e3a89", null ]
];