var structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_request =
[
    [ "name", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_request.xhtml#a6942461511be437bf70fc40dd0ef3d04", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1surface__source_1_1_create_surface_source_request.xhtml#a4f3654fc99ac5a60c04fbee43b9de0be", null ]
];