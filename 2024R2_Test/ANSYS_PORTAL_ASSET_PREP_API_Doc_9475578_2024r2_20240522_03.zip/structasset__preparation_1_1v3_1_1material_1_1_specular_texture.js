var structasset__preparation_1_1v3_1_1material_1_1_specular_texture =
[
    [ "map_identifier", "structasset__preparation_1_1v3_1_1material_1_1_specular_texture.xhtml#a5a587c2672a3a5df6a246a46dc16eed7", null ],
    [ "map_uv_channel", "structasset__preparation_1_1v3_1_1material_1_1_specular_texture.xhtml#aa8bb420c344144daa44f3944169eb801", null ],
    [ "intensity", "structasset__preparation_1_1v3_1_1material_1_1_specular_texture.xhtml#a6e5617070dbc6e05e44cd746326a0006", null ]
];