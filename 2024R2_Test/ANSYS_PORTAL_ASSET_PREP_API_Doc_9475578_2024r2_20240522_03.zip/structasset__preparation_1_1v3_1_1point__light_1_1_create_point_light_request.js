var structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_request =
[
    [ "name", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_request.xhtml#add4f1ca2c19cf9468a2a5f81e3804ef9", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_request.xhtml#a8aa8ff5d087f7de7eb82b36e633bc8c9", null ]
];