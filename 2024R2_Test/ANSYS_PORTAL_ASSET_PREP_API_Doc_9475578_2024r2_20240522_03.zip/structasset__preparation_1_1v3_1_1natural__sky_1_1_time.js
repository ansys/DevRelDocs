var structasset__preparation_1_1v3_1_1natural__sky_1_1_time =
[
    [ "hours", "structasset__preparation_1_1v3_1_1natural__sky_1_1_time.xhtml#a4a39d332fb57d31f8602fc110fa6a4ad", null ],
    [ "minutes", "structasset__preparation_1_1v3_1_1natural__sky_1_1_time.xhtml#a920884d73a28eaa478ce7657e9773948", null ]
];