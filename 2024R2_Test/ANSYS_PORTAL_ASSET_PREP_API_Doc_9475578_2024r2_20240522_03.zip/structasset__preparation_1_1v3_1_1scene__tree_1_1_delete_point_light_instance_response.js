var structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_point_light_instance_response =
[
    [ "status", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_point_light_instance_response.xhtml#a5bf804831c01050fdd817bc7ee7e589a", null ]
];