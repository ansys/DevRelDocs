var structasset__preparation_1_1v3_1_1scene__tree_1_1_directional_light_instance_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_directional_light_instance_identity.xhtml#a05996ad035dfbcb6bfb132eb6adcac54", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_directional_light_instance_identity.xhtml#afb731dfd0e14846322762d113293f5ed", null ]
];