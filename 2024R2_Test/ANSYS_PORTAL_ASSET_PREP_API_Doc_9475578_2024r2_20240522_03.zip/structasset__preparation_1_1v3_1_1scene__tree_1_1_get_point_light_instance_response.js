var structasset__preparation_1_1v3_1_1scene__tree_1_1_get_point_light_instance_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1scene__tree_1_1_get_point_light_instance_response.xhtml#addfc43160e1d22d43269fe5de4109e88", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1scene__tree_1_1_get_point_light_instance_response.xhtml#a272577e3ea4e6a3ce48f07fcf3376841", null ],
    [ "status", "structasset__preparation_1_1v3_1_1scene__tree_1_1_get_point_light_instance_response.xhtml#a22ff705be439da8c155c998d35226297", null ]
];