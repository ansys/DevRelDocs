var structasset__preparation_1_1v3_1_1common_1_1_tag_identity =
[
    [ "basic_type", "structasset__preparation_1_1v3_1_1common_1_1_tag_identity.xhtml#adb46861d0c423a1f8675cb3b3678910d", null ],
    [ "lighting_type", "structasset__preparation_1_1v3_1_1common_1_1_tag_identity.xhtml#a0a41b7a7bf08ae58d50cd919d6c13f43", null ],
    [ "name", "structasset__preparation_1_1v3_1_1common_1_1_tag_identity.xhtml#a905ab4e4721ff5b4d6ecc487af974869", null ]
];