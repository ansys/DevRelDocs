var structasset__preparation_1_1v3_1_1material_1_1_surface_optical_properties =
[
    [ "texture_normalization", "structasset__preparation_1_1v3_1_1material_1_1_surface_optical_properties.xhtml#a1413d7db3bfce68c41874bb622af24c4", null ],
    [ "layer_1", "structasset__preparation_1_1v3_1_1material_1_1_surface_optical_properties.xhtml#a09a777dac02030378983eabd2e2b2a07", null ],
    [ "layer_2", "structasset__preparation_1_1v3_1_1material_1_1_surface_optical_properties.xhtml#a5e2e2a55e7335d86b5f1618eda232e5d", null ],
    [ "layer_3", "structasset__preparation_1_1v3_1_1material_1_1_surface_optical_properties.xhtml#a315fc1ded8340fd9718fd2bdd6966fa3", null ]
];