var structasset__preparation_1_1v3_1_1material_1_1_anisotropy_properties =
[
    [ "no_anisotropy", "structasset__preparation_1_1v3_1_1material_1_1_anisotropy_properties.xhtml#a3510f18dbf536e7d4b6b5e374900bd4f", null ],
    [ "texture", "structasset__preparation_1_1v3_1_1material_1_1_anisotropy_properties.xhtml#adef12aa5d6f3ed488d8f648ad22230db", null ],
    [ "color", "structasset__preparation_1_1v3_1_1material_1_1_anisotropy_properties.xhtml#a2521526bc0b366560361532ec1b29c0b", null ]
];