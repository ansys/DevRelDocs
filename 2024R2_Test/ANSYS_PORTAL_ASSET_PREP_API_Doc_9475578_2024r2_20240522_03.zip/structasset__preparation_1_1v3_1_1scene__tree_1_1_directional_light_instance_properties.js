var structasset__preparation_1_1v3_1_1scene__tree_1_1_directional_light_instance_properties =
[
    [ "directional_light_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_directional_light_instance_properties.xhtml#a20cd0a5d1799fad00660e842703f07d8", null ],
    [ "transform", "structasset__preparation_1_1v3_1_1scene__tree_1_1_directional_light_instance_properties.xhtml#aa6e1568477a6299da9a779e2da155ac3", null ],
    [ "visibility", "structasset__preparation_1_1v3_1_1scene__tree_1_1_directional_light_instance_properties.xhtml#ad4cc250396c02190fad746b997c61b10", null ]
];