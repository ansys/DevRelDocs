var structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_identity.xhtml#adb182789b00e409e108c55a4ca35b29b", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_point_light_instance_identity.xhtml#a0a412ab3e13fd1af71e3864ce538f80f", null ]
];