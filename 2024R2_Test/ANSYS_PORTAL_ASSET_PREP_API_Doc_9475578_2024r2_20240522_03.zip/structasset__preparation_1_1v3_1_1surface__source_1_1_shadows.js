var structasset__preparation_1_1v3_1_1surface__source_1_1_shadows =
[
    [ "near_clip", "structasset__preparation_1_1v3_1_1surface__source_1_1_shadows.xhtml#a024f26ade69d3743bb3a647b989fc49d", null ],
    [ "shadows_offset_ratio", "structasset__preparation_1_1v3_1_1surface__source_1_1_shadows.xhtml#a123569357e09fe1021d631d5fe2810b0", null ],
    [ "softness", "structasset__preparation_1_1v3_1_1surface__source_1_1_shadows.xhtml#a0f970cbcc002e1da00610c6332bd0429", null ]
];