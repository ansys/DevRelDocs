var structasset__preparation_1_1v3_1_1material_1_1_update_material_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_update_material_request.xhtml#af1614906137a65ad19c5ce7629e85d99", null ],
    [ "name", "structasset__preparation_1_1v3_1_1material_1_1_update_material_request.xhtml#ac5073f3247928d75c2ff867a38bfaffa", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1material_1_1_update_material_request.xhtml#ae2a12b892d99f54f4e1fd74bf415c675", null ]
];