var structasset__preparation_1_1v3_1_1surface__source_1_1_get_surface_source_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_get_surface_source_state_response.xhtml#a6e8df2bdeca1b503ce0f2a28e26f75fc", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_get_surface_source_state_response.xhtml#ae1f82ef3c020ef0c6e36a0ad43620929", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1surface__source_1_1_get_surface_source_state_response.xhtml#a79493c48df528f64484385f4b9d3e05d", null ],
    [ "status", "structasset__preparation_1_1v3_1_1surface__source_1_1_get_surface_source_state_response.xhtml#a4b6ae33bff8a25f738728927d7b62acd", null ]
];