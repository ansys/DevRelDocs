var structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_request.xhtml#a1460cb4a3ac88a7ff3e5090f022cf649", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_request.xhtml#a478fe4261ba0275e328ecc1538974593", null ],
    [ "base_state_name", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_request.xhtml#a8fb01e6bb99d82d89d6aeeab86f25747", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_state_request.xhtml#a4a2811c4ac22c829f010d1f1334e5545", null ]
];