var structasset__preparation_1_1v3_1_1resource_1_1_delete_resource_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1resource_1_1_delete_resource_request.xhtml#a36615fe572df24687731613fe5307441", null ],
    [ "type", "structasset__preparation_1_1v3_1_1resource_1_1_delete_resource_request.xhtml#ae847a47a57b25a6413a5ad49aa6170c5", null ]
];