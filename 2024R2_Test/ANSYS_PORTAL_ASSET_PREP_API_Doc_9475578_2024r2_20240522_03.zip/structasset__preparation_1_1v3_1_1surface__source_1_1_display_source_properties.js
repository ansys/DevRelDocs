var structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties =
[
    [ "luminance", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#a37eda1a898652aee2e43f13ce73e4117", null ],
    [ "angular_precision", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#ab80b6a73ec09e92e0bea59b7fae84169", null ],
    [ "lambertian", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#aa8acb35856d48f77f5132830ad4dccf3", null ],
    [ "diagram_library", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#a85546dec82af1f0bf97e80c4dd934df6", null ],
    [ "gaussian", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#ad322dc9871ec77a328dcf884df392258", null ],
    [ "reverse_direction", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#afa61d207b9ad4c8e9a580945d6534249", null ],
    [ "no_contribution", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#a58965f786ad01822d576fc02150b60ac", null ],
    [ "lighting_contribution", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#acede9d26c2261ee18b3ef6000365173f", null ],
    [ "spectrum_library", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#ad4ae355df39b57ee9dc7894d6f8bd5dc", null ],
    [ "black_body", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#a20b055ee2d22a63703773fc1b4722985", null ],
    [ "monochromatic", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#a82053a7dd6ce08eb15050248acf5f5f4", null ],
    [ "texture_identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#a6b94fd3827ad57a7a377849a0a5e0acd", null ],
    [ "uv_channel", "structasset__preparation_1_1v3_1_1surface__source_1_1_display_source_properties.xhtml#ade3596622859996b487a9d3a9833cc39", null ]
];