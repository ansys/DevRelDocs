var structasset__preparation_1_1v3_1_1scene__tree_1_1_update_point_light_instance_response =
[
    [ "status", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_point_light_instance_response.xhtml#a175c9f2b512e1101418511456e07f478", null ]
];