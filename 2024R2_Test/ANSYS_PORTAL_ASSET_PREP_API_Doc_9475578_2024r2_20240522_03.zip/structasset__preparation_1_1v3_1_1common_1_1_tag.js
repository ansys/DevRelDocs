var structasset__preparation_1_1v3_1_1common_1_1_tag =
[
    [ "basic_type", "structasset__preparation_1_1v3_1_1common_1_1_tag.xhtml#a638624bdae8b0b2dbe0f980ca3ede3d2", null ],
    [ "lighting_type", "structasset__preparation_1_1v3_1_1common_1_1_tag.xhtml#a2339bdf054ac9406ee49526a70bf6f34", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1common_1_1_tag.xhtml#a52fbc62e96ea00bb942a7421d27e2643", null ]
];