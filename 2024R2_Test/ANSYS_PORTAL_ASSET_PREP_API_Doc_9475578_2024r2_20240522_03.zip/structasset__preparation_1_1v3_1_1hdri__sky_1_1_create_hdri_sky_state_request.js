var structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_request.xhtml#aeb33201e76122a44e692542d5be66e30", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_request.xhtml#a8f6ca2f0e430390c48e1b0c5dd2e3477", null ],
    [ "base_state_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_request.xhtml#ac437add84595927dd7b08f3d6d01bf73", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_create_hdri_sky_state_request.xhtml#a3392aeebccb7e9e303c1f473decc7c36", null ]
];