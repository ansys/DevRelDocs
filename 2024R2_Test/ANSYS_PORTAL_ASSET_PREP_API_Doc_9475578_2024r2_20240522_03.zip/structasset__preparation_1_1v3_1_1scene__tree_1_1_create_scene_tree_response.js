var structasset__preparation_1_1v3_1_1scene__tree_1_1_create_scene_tree_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_scene_tree_response.xhtml#a0a465dc75a506fb2a3eda38b353987cd", null ],
    [ "status", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_scene_tree_response.xhtml#a09bd3cee506b115aa650f95c5b9b2bbd", null ]
];