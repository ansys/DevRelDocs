var structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties =
[
    [ "flux", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#aa2e8001d014ccf712b029924ac9d3fd5", null ],
    [ "angular_precision", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#afe074f65b3eedba123470cfc5a7d39b6", null ],
    [ "lambertian", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#a4e2892932ebaa3544110356e3734caab", null ],
    [ "diagram_library", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#acc190f6904e652b55ab7c9593273b58f", null ],
    [ "gaussian", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#adc84c6d5e7d5cde703e3f328675d67da", null ],
    [ "reverse_direction", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#a3590013ebe4c5e00d605feaf8720def8", null ],
    [ "no_contribution", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#a69d191ec3769275df3d929ec026d8c47", null ],
    [ "lighting_contribution", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#a854e889289022b2a8e1e2257109111b2", null ],
    [ "spectrum_library", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#ae1af081791cb5e7fca6a505493c0d54b", null ],
    [ "black_body", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#a55622ea2feee9f629e87461d1e806b54", null ],
    [ "monochromatic", "structasset__preparation_1_1v3_1_1surface__source_1_1_surface_source_properties.xhtml#a358c0372d41ad420edd08852b082334d", null ]
];