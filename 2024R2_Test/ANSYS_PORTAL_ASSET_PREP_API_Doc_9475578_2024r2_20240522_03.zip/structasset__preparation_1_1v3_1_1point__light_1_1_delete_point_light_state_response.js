var structasset__preparation_1_1v3_1_1point__light_1_1_delete_point_light_state_response =
[
    [ "status", "structasset__preparation_1_1v3_1_1point__light_1_1_delete_point_light_state_response.xhtml#a06c5fd2e1c89d511be15d00b1923a80c", null ]
];