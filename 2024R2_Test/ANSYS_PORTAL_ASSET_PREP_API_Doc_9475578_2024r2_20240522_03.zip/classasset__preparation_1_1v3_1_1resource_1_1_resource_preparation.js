var classasset__preparation_1_1v3_1_1resource_1_1_resource_preparation =
[
    [ "UploadResource", "classasset__preparation_1_1v3_1_1resource_1_1_resource_preparation.xhtml#afb079f16c14c3ada6395aa15a8ffcb4f", null ],
    [ "DownloadResourceAsChunks", "classasset__preparation_1_1v3_1_1resource_1_1_resource_preparation.xhtml#a2fe59a9f4be67af90c1315d1a8ed3cf2", null ],
    [ "DownloadResourceAsFile", "classasset__preparation_1_1v3_1_1resource_1_1_resource_preparation.xhtml#ad325e3300ef27b087e3b26f8a97d5dbc", null ],
    [ "ListResources", "classasset__preparation_1_1v3_1_1resource_1_1_resource_preparation.xhtml#af0736c4a8cb4cdc328d78951b44d76e0", null ],
    [ "DeleteResource", "classasset__preparation_1_1v3_1_1resource_1_1_resource_preparation.xhtml#ad95074413af82666a3ce394dd90d7384", null ]
];