var structasset__preparation_1_1v3_1_1geometry_1_1_update_geometry_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_update_geometry_request.xhtml#a519e92eb0c68b3e09a7d957349978e5e", null ],
    [ "name", "structasset__preparation_1_1v3_1_1geometry_1_1_update_geometry_request.xhtml#a660de2a8e089e8b02181852a71648a23", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1geometry_1_1_update_geometry_request.xhtml#ac12051fc6e5cb1aa09d583c7195e6f48", null ]
];