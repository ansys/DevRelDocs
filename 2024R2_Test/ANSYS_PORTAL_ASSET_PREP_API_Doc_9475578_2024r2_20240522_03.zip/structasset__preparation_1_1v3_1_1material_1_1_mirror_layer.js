var structasset__preparation_1_1v3_1_1material_1_1_mirror_layer =
[
    [ "reflectivity", "structasset__preparation_1_1v3_1_1material_1_1_mirror_layer.xhtml#a7cd1a75e782a59aed2c554bd0eead1d7", null ],
    [ "diffuse_properties", "structasset__preparation_1_1v3_1_1material_1_1_mirror_layer.xhtml#a1a818103e783b9c819fb6fe4038b8d89", null ],
    [ "normal_properties", "structasset__preparation_1_1v3_1_1material_1_1_mirror_layer.xhtml#a814e666ddeede20d957a96a5bc4d548a", null ],
    [ "anisotropy_properties", "structasset__preparation_1_1v3_1_1material_1_1_mirror_layer.xhtml#ab1c20d0f4037da2946314748fea6c2a7", null ],
    [ "mask_properties", "structasset__preparation_1_1v3_1_1material_1_1_mirror_layer.xhtml#a655d4980f902a8208deb08f1727240c3", null ]
];