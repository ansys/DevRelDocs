var structasset__preparation_1_1v3_1_1surface__source_1_1_delete_surface_source_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_delete_surface_source_state_request.xhtml#a7f33aa9fd4038538b732a576778bfec1", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_delete_surface_source_state_request.xhtml#a03c1803f0e8c8c49e066612944aabbf6", null ]
];