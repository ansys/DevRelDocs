var structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_node_request =
[
    [ "scene_tree_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_node_request.xhtml#a1090568016e81cfa18531be283d46612", null ],
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_node_request.xhtml#a255f559f43610f1716f8ad3dbc96dcc8", null ],
    [ "identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_delete_node_request.xhtml#a710c0ec88ea421c018265b596f04812f", null ]
];