var structasset__preparation_1_1v3_1_1directional__light_1_1_delete_directional_light_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_delete_directional_light_state_request.xhtml#a3f5236e16631d72c0e14edb0c172444d", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_delete_directional_light_state_request.xhtml#a219565199af18a2a57c9b209a8ba84ba", null ]
];