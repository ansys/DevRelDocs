var structasset__preparation_1_1v3_1_1natural__sky_1_1_ambient_conditions =
[
    [ "turbidity", "structasset__preparation_1_1v3_1_1natural__sky_1_1_ambient_conditions.xhtml#a4c07aa51d5ef7f7ebdc7b2d28e4c5669", null ],
    [ "ambient_temperature", "structasset__preparation_1_1v3_1_1natural__sky_1_1_ambient_conditions.xhtml#aadbf0aac6d1e153deeb123d96388b80f", null ],
    [ "relative_humidity", "structasset__preparation_1_1v3_1_1natural__sky_1_1_ambient_conditions.xhtml#a89bf63c705e6092e17df062bcdeb58a9", null ],
    [ "no_override", "structasset__preparation_1_1v3_1_1natural__sky_1_1_ambient_conditions.xhtml#ae65f904195dd3ba9bd9e9eaff027e7ca", null ],
    [ "max_solar_warming", "structasset__preparation_1_1v3_1_1natural__sky_1_1_ambient_conditions.xhtml#a506b870dd35b3ed2dfdfde5351e7b8e0", null ],
    [ "mean_road_emissivity", "structasset__preparation_1_1v3_1_1natural__sky_1_1_ambient_conditions.xhtml#aefd5c90fc339af5e92f3a618e875d064", null ]
];