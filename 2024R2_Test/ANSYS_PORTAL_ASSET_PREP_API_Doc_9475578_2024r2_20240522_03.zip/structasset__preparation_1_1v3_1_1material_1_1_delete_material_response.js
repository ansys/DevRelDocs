var structasset__preparation_1_1v3_1_1material_1_1_delete_material_response =
[
    [ "status", "structasset__preparation_1_1v3_1_1material_1_1_delete_material_response.xhtml#a71eb4a79589bd0b9e9bdf96c8b8a02bc", null ]
];