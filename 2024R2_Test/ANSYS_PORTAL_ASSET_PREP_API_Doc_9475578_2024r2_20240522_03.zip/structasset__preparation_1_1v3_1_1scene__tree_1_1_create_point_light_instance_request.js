var structasset__preparation_1_1v3_1_1scene__tree_1_1_create_point_light_instance_request =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_point_light_instance_request.xhtml#ae79e309fc20c75b95648859b08069805", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_point_light_instance_request.xhtml#a40c40f00296300a07db1867a6e7f97a0", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_point_light_instance_request.xhtml#a6eed9ad015887eaf36f4276184a7ea38", null ]
];