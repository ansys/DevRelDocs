var structasset__preparation_1_1v3_1_1scene__tree_1_1_update_scene_tree_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_scene_tree_request.xhtml#a8ade329a5e2f1a1f10ac0436ab7b7fcc", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_update_scene_tree_request.xhtml#a4cda6a55891e7ba2b8b16da9fb88c382", null ]
];