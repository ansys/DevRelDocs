var structasset__preparation_1_1v3_1_1material_1_1_delete_material_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_delete_material_state_request.xhtml#a6f6ea1e731a139a0e63ad585ed66e2ab", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1material_1_1_delete_material_state_request.xhtml#a4ee777a1796d34b062ef5445f7adc355", null ]
];