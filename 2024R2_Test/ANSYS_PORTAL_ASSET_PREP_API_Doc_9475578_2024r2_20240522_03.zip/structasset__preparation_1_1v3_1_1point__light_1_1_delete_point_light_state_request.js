var structasset__preparation_1_1v3_1_1point__light_1_1_delete_point_light_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1point__light_1_1_delete_point_light_state_request.xhtml#ae7b299806f7d25bcfb2d6dd54533ee48", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1point__light_1_1_delete_point_light_state_request.xhtml#a2b66d531735edceccb3757398b6228db", null ]
];