var structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_request.xhtml#a65bd7269210097faaa76118f94b932c2", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_request.xhtml#a43fbfce28c260d35fdd66926a54a8582", null ],
    [ "state_new_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_request.xhtml#aa22c2e329578f31fb3e637f1e20ba90d", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_update_hdri_sky_state_request.xhtml#a0d7b0a3a5397e9906eee49d321d18b16", null ]
];