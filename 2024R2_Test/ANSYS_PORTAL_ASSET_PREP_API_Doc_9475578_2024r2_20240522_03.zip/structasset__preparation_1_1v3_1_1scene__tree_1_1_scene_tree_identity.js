var structasset__preparation_1_1v3_1_1scene__tree_1_1_scene_tree_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_scene_tree_identity.xhtml#a5594748cca3abceba066447cf437f218", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_scene_tree_identity.xhtml#a2dc02ec4b54db806220aebc9daf4e95b", null ]
];