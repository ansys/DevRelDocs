var structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_state_response.xhtml#adf697ee19e436ab67166770a1bc20cfb", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_state_response.xhtml#afe54bdcfcd22d834f62fa9cdf0519f44", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_state_response.xhtml#afab9e19398077cc39f9dc3943fb1e0da", null ],
    [ "status", "structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_state_response.xhtml#ace7c72b8e030336612a53a0bd05355d2", null ]
];