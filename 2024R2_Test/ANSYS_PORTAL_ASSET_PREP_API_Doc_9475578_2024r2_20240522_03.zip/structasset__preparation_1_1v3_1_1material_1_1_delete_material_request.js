var structasset__preparation_1_1v3_1_1material_1_1_delete_material_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1material_1_1_delete_material_request.xhtml#acec7809d17e602e7ee27950145a5f371", null ]
];