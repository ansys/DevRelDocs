var structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_state_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_state_request.xhtml#a21f23dd530365140506cc682be918ddb", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_state_request.xhtml#ac69e55dab2c28b55c3b8128be56a7b60", null ],
    [ "state_new_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_state_request.xhtml#a7a6dc873065dcd59d83769fca9a51973", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_state_request.xhtml#a28b6b86fa2591963b3f44fd282ee173b", null ]
];