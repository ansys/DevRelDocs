var structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_response.xhtml#ac0de65dbbfd0bd6a45f5abbf6f952a8f", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_response.xhtml#a307d9cc42d99c31b3b60b5de7ab010ee", null ],
    [ "state_properties", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_response.xhtml#a05ce6adf36822c6f5c6b5abff702aec8", null ],
    [ "status", "structasset__preparation_1_1v3_1_1hdri__sky_1_1_get_hdri_sky_state_response.xhtml#a3e01b210a2c53abe895e2cf8db2dbc2d", null ]
];