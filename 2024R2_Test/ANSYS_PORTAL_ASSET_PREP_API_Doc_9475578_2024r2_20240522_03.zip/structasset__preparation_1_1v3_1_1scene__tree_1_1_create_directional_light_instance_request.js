var structasset__preparation_1_1v3_1_1scene__tree_1_1_create_directional_light_instance_request =
[
    [ "node_identifier", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_directional_light_instance_request.xhtml#a36d1989b32d7a843f8af0eb783e5d22a", null ],
    [ "name", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_directional_light_instance_request.xhtml#ac07cba1c4b0e63e334a1b9dd010c59fe", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1scene__tree_1_1_create_directional_light_instance_request.xhtml#a0a6dd54fe586055818da14ef10e338bd", null ]
];