var structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_state_response =
[
    [ "state_name", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_state_response.xhtml#a3b50acf3d50b501a41b03d8a4cfa3403", null ],
    [ "status", "structasset__preparation_1_1v3_1_1surface__source_1_1_update_surface_source_state_response.xhtml#a5dbfcd4b1527fd028bb9737141763694", null ]
];