var structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_response.xhtml#a5937aed984fc89ffebd37866ba5291ae", null ],
    [ "status", "structasset__preparation_1_1v3_1_1point__light_1_1_create_point_light_response.xhtml#a0e3d5af29b8eccbbc8b567dcbebb8190", null ]
];