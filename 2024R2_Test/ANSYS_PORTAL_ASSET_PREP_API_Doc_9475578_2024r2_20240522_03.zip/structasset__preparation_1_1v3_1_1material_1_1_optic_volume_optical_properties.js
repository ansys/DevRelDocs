var structasset__preparation_1_1v3_1_1material_1_1_optic_volume_optical_properties =
[
    [ "absorption", "structasset__preparation_1_1v3_1_1material_1_1_optic_volume_optical_properties.xhtml#a904e7828524c32fea543cfee5f473523", null ],
    [ "refractive_index", "structasset__preparation_1_1v3_1_1material_1_1_optic_volume_optical_properties.xhtml#ac3ff747c0bb076a407161f7904f96789", null ],
    [ "constringency", "structasset__preparation_1_1v3_1_1material_1_1_optic_volume_optical_properties.xhtml#a4da81e7a6a7e51beeab2a7b8699b5f86", null ]
];