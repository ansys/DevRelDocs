var structasset__preparation_1_1v3_1_1geometry_1_1_geometry_identity =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_geometry_identity.xhtml#ac41693b997a40d33d3ec99262573af20", null ],
    [ "name", "structasset__preparation_1_1v3_1_1geometry_1_1_geometry_identity.xhtml#a05fc5fa23a3f558105b5cc345e202f2c", null ]
];