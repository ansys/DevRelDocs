var structasset__preparation_1_1v3_1_1geometry_1_1_push_vertices_request =
[
    [ "geometry_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_push_vertices_request.xhtml#a3fb22fe3321202aaf5047c4d6ccffdd0", null ],
    [ "vertices", "structasset__preparation_1_1v3_1_1geometry_1_1_push_vertices_request.xhtml#a776c2bf9eca7864e81ffe85502956f92", null ]
];