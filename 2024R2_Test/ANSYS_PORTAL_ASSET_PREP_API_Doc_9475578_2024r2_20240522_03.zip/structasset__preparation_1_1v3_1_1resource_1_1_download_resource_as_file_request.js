var structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_request.xhtml#ab436a3d25e8894f145c5d3f9d6590448", null ],
    [ "type", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_request.xhtml#a01e7238d92103e5657dceef32f278b10", null ],
    [ "file_path", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_request.xhtml#a4fd211cee6074ff8a6e88185692d29d9", null ],
    [ "overwrite", "structasset__preparation_1_1v3_1_1resource_1_1_download_resource_as_file_request.xhtml#a5ed8a342c9e854dc9ed592c040ef85cb", null ]
];