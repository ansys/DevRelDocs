var structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_response =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_response.xhtml#aa1f5d2fe5fb930be81fcc5311c68d4f5", null ],
    [ "state_name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_response.xhtml#a27f736024a07ebfcc88ecd387e89943e", null ],
    [ "status", "structasset__preparation_1_1v3_1_1natural__sky_1_1_create_natural_sky_state_response.xhtml#af59402f9c5fe457b5d25aa19c1c4de2b", null ]
];