var structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_response =
[
    [ "identity", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_response.xhtml#a12019972014a64ce055616def1d8d42d", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_response.xhtml#a6bce3dd99991edda672ec1f36ae262e4", null ],
    [ "state_names", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_response.xhtml#af26e7a6c98ec6ef2b52625fc59c5bb64", null ],
    [ "status", "structasset__preparation_1_1v3_1_1natural__sky_1_1_get_natural_sky_response.xhtml#af7d1adf8dbc07c9f82a847558408b618", null ]
];