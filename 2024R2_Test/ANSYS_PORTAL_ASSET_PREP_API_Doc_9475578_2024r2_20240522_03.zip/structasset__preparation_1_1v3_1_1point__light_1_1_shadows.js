var structasset__preparation_1_1v3_1_1point__light_1_1_shadows =
[
    [ "near_clip", "structasset__preparation_1_1v3_1_1point__light_1_1_shadows.xhtml#a101c2f39ef1df1f3c3c0c29e5ffaf845", null ],
    [ "shadows_offset_ratio", "structasset__preparation_1_1v3_1_1point__light_1_1_shadows.xhtml#a1e9706726e7be840f7a0f27d2bae53a5", null ],
    [ "softness", "structasset__preparation_1_1v3_1_1point__light_1_1_shadows.xhtml#aab3af630f5898f8a8928e1f83d34b9b3", null ]
];