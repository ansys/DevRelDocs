var structasset__preparation_1_1v3_1_1material_1_1_mask_texture =
[
    [ "map_identifier", "structasset__preparation_1_1v3_1_1material_1_1_mask_texture.xhtml#a062685fd74e5ac1911c464bf83df5d32", null ],
    [ "map_uv_channel", "structasset__preparation_1_1v3_1_1material_1_1_mask_texture.xhtml#af75f1af4650af2f3db1bcae633f3d475", null ]
];