var structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1directional__light_1_1_get_directional_light_request.xhtml#a92dba71835b010eaf0e1a2905cedde83", null ]
];