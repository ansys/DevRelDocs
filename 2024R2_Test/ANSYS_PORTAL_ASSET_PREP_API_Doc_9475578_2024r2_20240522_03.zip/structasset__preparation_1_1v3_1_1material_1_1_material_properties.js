var structasset__preparation_1_1v3_1_1material_1_1_material_properties =
[
    [ "surface_optical_properties", "structasset__preparation_1_1v3_1_1material_1_1_material_properties.xhtml#ab7dbff299aaccea5ea04ab20324a2e32", null ],
    [ "volume_optical_properties", "structasset__preparation_1_1v3_1_1material_1_1_material_properties.xhtml#adfbe168b98aa14ff529e7cdbc5749876", null ],
    [ "thermal_properties", "structasset__preparation_1_1v3_1_1material_1_1_material_properties.xhtml#a09611cd1c746f76d611cf760525555ed", null ],
    [ "dielectric_properties", "structasset__preparation_1_1v3_1_1material_1_1_material_properties.xhtml#ad89af7c1b6bdc38966c05eb360137aa8", null ],
    [ "reflection_effect", "structasset__preparation_1_1v3_1_1material_1_1_material_properties.xhtml#a10b929eafd6212934d74ba041fabf156", null ]
];