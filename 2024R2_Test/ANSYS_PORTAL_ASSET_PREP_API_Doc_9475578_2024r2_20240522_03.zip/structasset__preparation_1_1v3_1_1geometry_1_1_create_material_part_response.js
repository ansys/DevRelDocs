var structasset__preparation_1_1v3_1_1geometry_1_1_create_material_part_response =
[
    [ "geometry_identifier", "structasset__preparation_1_1v3_1_1geometry_1_1_create_material_part_response.xhtml#aa475db9444ba101b825940d1719fa8a9", null ],
    [ "material_part_identity", "structasset__preparation_1_1v3_1_1geometry_1_1_create_material_part_response.xhtml#afe6d9b42550ff222590ec43107f3e1c1", null ],
    [ "status", "structasset__preparation_1_1v3_1_1geometry_1_1_create_material_part_response.xhtml#a0b378b956da73025414ea3749bbf787b", null ]
];