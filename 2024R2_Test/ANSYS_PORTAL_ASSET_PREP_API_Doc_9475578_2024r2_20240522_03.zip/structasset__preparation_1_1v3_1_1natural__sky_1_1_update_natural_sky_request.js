var structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_request =
[
    [ "identifier", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_request.xhtml#a72f945d02590adca24a69a58b6e8c4af", null ],
    [ "name", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_request.xhtml#aa17cae34cf5f153103808d4b65b0d2af", null ],
    [ "properties", "structasset__preparation_1_1v3_1_1natural__sky_1_1_update_natural_sky_request.xhtml#a316aec80f2909b268954eec005c9e2ea", null ]
];