var group__group__2__concepts =
[
    [ "Concepts and Terminology", "group__group__02.xhtml", null ],
    [ "Using DPF: Step by Step", "group__group__05.xhtml", null ],
    [ "Ways of Using DPF", "group__group__03.xhtml", null ]
];