var classansys_1_1dpf_1_1RuntimeClientConfig =
[
    [ "enableCache", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#ab83354eaf4d8646fd7d06e0f5dbdafaf", null ],
    [ "getMetadata", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#afd80c6f61d3503fff0667191937dfae8", null ],
    [ "getStreamingBufferSize", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#a31e99b0bf8468a58ca3b5bcaa1412fe6", null ],
    [ "isCacheEnabled", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#aac0f20eaf4cb412d3ef03d787ac38f06", null ],
    [ "isConnectionSecure", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#adb4e00bb129ca912c50e719176d29e59", null ],
    [ "setMetadata", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#accdb5f4e700803b8bd6b6cf8cb8623d1", null ],
    [ "setSecureConnection", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#aff6f9df92453eff0bea05c9ce2c96a3b", null ],
    [ "setStreamFloatsInsteadOfDoubles", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#a380e861289e9683a04ca84c250b0ecf7", null ],
    [ "setStreamingBufferSize", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#a286701384f2b37237c61f20d1c24eae6", null ],
    [ "streamingFloatsInsteadOfDouble", "classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#a38db32f9104c3c2884a734a7cf606ed7", null ]
];