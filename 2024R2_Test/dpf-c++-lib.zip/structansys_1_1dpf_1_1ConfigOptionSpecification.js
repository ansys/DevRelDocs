var structansys_1_1dpf_1_1ConfigOptionSpecification =
[
    [ "getDefaultValue", "structansys_1_1dpf_1_1ConfigOptionSpecification.xhtml#a451a803874ee02f8e8cba2c578fb9bdb", null ],
    [ "getDescription", "structansys_1_1dpf_1_1ConfigOptionSpecification.xhtml#a52c1ba0874464f49572045e5a4447a8b", null ],
    [ "getName", "structansys_1_1dpf_1_1ConfigOptionSpecification.xhtml#a6a87af4628268c180d7b2af80877e7a3", null ],
    [ "getTypeNames", "structansys_1_1dpf_1_1ConfigOptionSpecification.xhtml#a0f3280755b029a3d6ad7eccad74ead7a", null ]
];