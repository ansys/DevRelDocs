var structIRockyJointScalars =
[
    [ "add_scalar", "structIRockyJointScalars.xhtml#abc05fdd6e7595ea79f4fa0aeafd93552", null ],
    [ "get_scalar", "structIRockyJointScalars.xhtml#a99bd176be9958223d6dc2a9e62f7ec30", null ],
    [ "max_scalar", "structIRockyJointScalars.xhtml#a5e95059b8068dc460f40119e2a58d32f", null ],
    [ "set_scalar", "structIRockyJointScalars.xhtml#a41d7ac3675a9d3ee3e79cd79c9de1f26", null ]
];