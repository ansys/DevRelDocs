var structIRockyMaterial =
[
    [ "get_density", "structIRockyMaterial.xhtml#ac4a3805a7f95f47fbd93761d1b2013fe", null ],
    [ "get_poisson_ratio", "structIRockyMaterial.xhtml#a77ed523db8076cb87c69334481e0ad9b", null ],
    [ "get_specific_heat", "structIRockyMaterial.xhtml#ab0f6b6ddb2c899c76bad757864649a22", null ],
    [ "get_thermal_conductivity", "structIRockyMaterial.xhtml#a35481246571a954fa8954efc49631ba5", null ],
    [ "get_young_modulus", "structIRockyMaterial.xhtml#ac2296f9b2afe54b6660f584d5d937994", null ]
];