var structIRockyParticleTransferScalars =
[
    [ "add_heat_source", "structIRockyParticleTransferScalars.xhtml#a8f0eeb9e7c46b0a82b746c80f7bcc3c2", null ],
    [ "add_heat_transfer", "structIRockyParticleTransferScalars.xhtml#a698d33f0f3ed82cf1a62ff21c881fb74", null ],
    [ "add_scalar", "structIRockyParticleTransferScalars.xhtml#a20599ee8283e5adcb2af659ca7b60985", null ],
    [ "get_heat_transfer", "structIRockyParticleTransferScalars.xhtml#adb482691a11732335076edd8113087cd", null ],
    [ "get_scalar", "structIRockyParticleTransferScalars.xhtml#aa840c5918e86e974c13e7d630251c5b4", null ],
    [ "max_scalar", "structIRockyParticleTransferScalars.xhtml#a9cef39b6f42cca4284f2bd733ee4d173", null ],
    [ "set_heat_transfer", "structIRockyParticleTransferScalars.xhtml#a3990cc0e8e9d91d57cb4dd5edfebc8c1", null ],
    [ "set_scalar", "structIRockyParticleTransferScalars.xhtml#a32a00ee4ca40287266b284214e8a2c9c", null ]
];