var classIRockyPluginData =
[
    [ "get_geometry_data", "classIRockyPluginData.xhtml#ae830fad6e94d455f0e4ad57df4b981de", null ],
    [ "get_material_data", "classIRockyPluginData.xhtml#a5c7b4ed26d1a6787279d2c531444666b", null ],
    [ "get_material_interaction_data", "classIRockyPluginData.xhtml#a78c76a74cd026948ee16f3b6b4718356", null ],
    [ "get_model", "classIRockyPluginData.xhtml#ab65c417ed40c1bab14987f959c095b7d", null ],
    [ "get_number_geometries", "classIRockyPluginData.xhtml#a413adf0e206156e543c8dd170eee387e", null ],
    [ "get_number_material_interactions", "classIRockyPluginData.xhtml#a90cc066bcc4f454a5c9d21d69bf57e9e", null ],
    [ "get_number_materials", "classIRockyPluginData.xhtml#ae0a075e183d876a183d37f2c7e818ca4", null ],
    [ "get_number_particle_groups", "classIRockyPluginData.xhtml#a7a39deb0a0b9b782ad0e74e82bc027ce", null ],
    [ "get_particle_group_data", "classIRockyPluginData.xhtml#a224e42565c6730227d5f85c8d0f0004f", null ],
    [ "has_geometry_data", "classIRockyPluginData.xhtml#a46306bc4ec8fe3a85efc85c37b78fdfb", null ],
    [ "has_material_data", "classIRockyPluginData.xhtml#af8d04f332d01ab25b7a375552072db2a", null ],
    [ "has_material_interaction_data", "classIRockyPluginData.xhtml#aefed471c915106b82ca654eef4a03042", null ],
    [ "has_particle_group_data", "classIRockyPluginData.xhtml#af000e5f6b3f1d9f454233b01c8a43515", null ]
];