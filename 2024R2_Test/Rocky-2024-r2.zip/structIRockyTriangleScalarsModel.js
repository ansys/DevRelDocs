var structIRockyTriangleScalarsModel =
[
    [ "add", "structIRockyTriangleScalarsModel.xhtml#a41b8986cbde7d37e0946a3a8a8361d19", null ],
    [ "add_accumulation_scalar", "structIRockyTriangleScalarsModel.xhtml#ac3e84af17e0dfaea602eab3a7a888b83", null ],
    [ "calculate_sum_over_geometries", "structIRockyTriangleScalarsModel.xhtml#acba5f06875d88bba1d66bd829c37fb52", null ],
    [ "enable_storage_of_exchanged_heat", "structIRockyTriangleScalarsModel.xhtml#a01f4979062e25a0fb10b874f9f1f81d9", null ],
    [ "find", "structIRockyTriangleScalarsModel.xhtml#afc273a1e67e4995f848452fda3f71c31", null ],
    [ "pull_scalar_from_devices", "structIRockyTriangleScalarsModel.xhtml#a60ee5f18541c3104a7a286d244a5f896", null ],
    [ "push_scalar_to_devices", "structIRockyTriangleScalarsModel.xhtml#a1111ee6479b40ce1e086aec31c405e3e", null ],
    [ "reset", "structIRockyTriangleScalarsModel.xhtml#ae4f5d565ed2b3fa05b52f9274d542d69", null ],
    [ "reset_exchanged_heat", "structIRockyTriangleScalarsModel.xhtml#abe794fd133422249549fad8c56fee6eb", null ],
    [ "set_dimension", "structIRockyTriangleScalarsModel.xhtml#aa02d862be5d91a62af18a1b1320286e7", null ]
];