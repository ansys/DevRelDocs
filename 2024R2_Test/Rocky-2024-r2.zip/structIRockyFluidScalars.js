var structIRockyFluidScalars =
[
    [ "add_scalar", "structIRockyFluidScalars.xhtml#a536c29f3a14dc5bbed6047f43baa37ec", null ],
    [ "get_scalar", "structIRockyFluidScalars.xhtml#a75d5c92f06422a5d29704788404405d0", null ],
    [ "max_scalar", "structIRockyFluidScalars.xhtml#aaa969c416dea0ac4eb4721c5b8d75b24", null ],
    [ "set_scalar", "structIRockyFluidScalars.xhtml#aec66ca90576555d400f9c6d401b049e4", null ]
];