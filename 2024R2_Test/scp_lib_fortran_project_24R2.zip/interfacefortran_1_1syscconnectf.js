var interfacefortran_1_1syscconnectf =
[
    [ "syscconnectf", "interfacefortran_1_1syscconnectf.xhtml#a556dda14cfe0b77561b9deff6e0c9cd5", null ],
    [ "syscconnectparallelf", "interfacefortran_1_1syscconnectf.xhtml#a8d918399632b17dc8e13486058566120", null ]
];