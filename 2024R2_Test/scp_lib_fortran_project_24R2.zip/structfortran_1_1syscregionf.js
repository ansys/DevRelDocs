var structfortran_1_1syscregionf =
[
    [ "displayname", "structfortran_1_1syscregionf.xhtml#a9278aae61ed92d3128608932a9d9f464", null ],
    [ "regiondiscretizationtype", "structfortran_1_1syscregionf.xhtml#ad2df2db7ce133791a65566cc9201dd5a", null ],
    [ "regionname", "structfortran_1_1syscregionf.xhtml#a2366d44a0a98ffcc655dbc9ab4e04784", null ],
    [ "topology", "structfortran_1_1syscregionf.xhtml#a9740fa1f40245a8491bc24b4c0a6d873", null ]
];