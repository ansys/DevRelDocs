var structfortran_1_1syscoutputintegerdataf =
[
    [ "dataptr", "structfortran_1_1syscoutputintegerdataf.xhtml#a267ef1b5c835b12e571fea3d20a8ff7b", null ],
    [ "datasize", "structfortran_1_1syscoutputintegerdataf.xhtml#ac8d11b0cadefc4f138b1ef4e0ab50b2a", null ],
    [ "primitivetype", "structfortran_1_1syscoutputintegerdataf.xhtml#a41aa641a12e238b3d8a12707aa047938", null ]
];