var interfacefortran_1_1syscgetresultsinfof =
[
    [ "syscgetresultsinfof", "interfacefortran_1_1syscgetresultsinfof.xhtml#aedf7568887b92f0cfe772a39febbccac", null ]
];