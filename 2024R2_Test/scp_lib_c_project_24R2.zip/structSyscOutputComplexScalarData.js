var structSyscOutputComplexScalarData =
[
    [ "data1", "structSyscOutputComplexScalarData.xhtml#abd9b452fbcdb3e8873a49230f214367f", null ],
    [ "data2", "structSyscOutputComplexScalarData.xhtml#a9d10751192e85779a192ff20697eac77", null ],
    [ "primitiveType", "structSyscOutputComplexScalarData.xhtml#aacc2944e127d01c2063a7b6ccb129009", null ],
    [ "size", "structSyscOutputComplexScalarData.xhtml#a07857702e4d8dffa2716d229f0a25c2b", null ]
];