var structSyscResultsInfo =
[
    [ "baseFileName", "structSyscResultsInfo.xhtml#aa79e88371b089b864d993170968c2a50", null ]
];