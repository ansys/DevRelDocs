var structSyscCellData =
[
    [ "cellIds", "structSyscCellData.xhtml#a18489ae2d9c8c4098cf5d2ac229ad98e", null ],
    [ "cellNodeConnectivity", "structSyscCellData.xhtml#a8b84210695305eb77feac6d31f726650", null ],
    [ "cellTypes", "structSyscCellData.xhtml#a46f408f73e98f145d1bbf2972d3a68a5", null ]
];