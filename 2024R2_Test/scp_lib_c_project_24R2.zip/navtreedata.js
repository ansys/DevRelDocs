/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "System Coupling 2024 R2 Participant Library:  C Interfaces", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "User guide", "md_01b__Contents.xhtml", [
      [ "System Coupling Participant library capabilities", "md_02__ParticipantLibraryCapabilities.xhtml", null ],
      [ "Concepts overview", "md_03__ConceptsAndTerminology.xhtml", null ],
      [ "Standalone mapping", "md_04__ParticipantStepsForMapping.xhtml", null ],
      [ "Steps to set up and execute the coupled analysis", "md_05__StepsToSetupAndExecutedCoupledAnalysis.xhtml", null ],
      [ "Completing the System Coupling participant setup", "md_06__ParticipantSetup.xhtml", null ],
      [ "Participant steps in a coupled analysis", "md_07__ParticipantStepsInCoupledAnalysis.xhtml", null ],
      [ "Command line arguments for participant solvers", "md_08__CommandLineArguments.xhtml", null ],
      [ "Execution in a parallel environment", "md_09__ParallelExecution.xhtml", null ],
      [ "Access to parameter data", "md_10__ParameterDataAccess.xhtml", null ],
      [ "Access to heavyweight data", "md_11__HeavyweightDataAccess.xhtml", null ],
      [ "Mesh and point cloud data access", "md_12__MeshDataAccess.xhtml", null ],
      [ "Creating restart points and restarting a coupled analysis", "md_13__Restarts.xhtml", null ],
      [ "Multi-region coupling interfaces", "md_14__Multiregion.xhtml", null ],
      [ "Debugging tools", "md_15__DebuggingTools.xhtml", null ],
      [ "Migration guide and known issues", "md_16__MigrationGuide.xhtml", null ],
      [ "Compiling, linking, and executing applications that use the participant library", "md_17__CompilingLinkingExecuting.xhtml", null ],
      [ "Heat transfer in square channel air flow tutorial", "md_18__ChannelFlowTutorial.xhtml", null ],
      [ "Oscillating plate damping tutorial", "md_19__PlateDampingTutorial.xhtml", null ],
      [ "Pipe mapping tutorial", "md_20__PipeMappingTutorial.xhtml", null ]
    ] ],
    [ "Topics", "topics.xhtml", "topics" ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", null ],
        [ "Variables", "functions_vars.xhtml", null ]
      ] ]
    ] ],
    [ "Changelog", "md_21__ReleaseNotes.xhtml", null ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.xhtml",
"group__SyscParticipantLibraryCAPI.xhtml#gaedae298744b65c453c7dac3e8dc1d68a"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';