/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Introduction",url:"index.xhtml"},
{text:"User guide",url:"md_01b__Contents.xhtml",children:[
{text:"System Coupling Participant library capabilities",url:"md_02__ParticipantLibraryCapabilities.xhtml"},
{text:"Concepts overview",url:"md_03__ConceptsAndTerminology.xhtml"},
{text:"Standalone mapping",url:"md_04__ParticipantStepsForMapping.xhtml"},
{text:"Steps to set up and execute the coupled analysis",url:"md_05__StepsToSetupAndExecutedCoupledAnalysis.xhtml"},
{text:"Completing the System Coupling participant setup",url:"md_06__ParticipantSetup.xhtml"},
{text:"Participant steps in a coupled analysis",url:"md_07__ParticipantStepsInCoupledAnalysis.xhtml"},
{text:"Command line arguments for participant solvers",url:"md_08__CommandLineArguments.xhtml"},
{text:"Execution in a parallel environment",url:"md_09__ParallelExecution.xhtml"},
{text:"Access to parameter data",url:"md_10__ParameterDataAccess.xhtml"},
{text:"Access to heavyweight data",url:"md_11__HeavyweightDataAccess.xhtml"},
{text:"Mesh and point cloud data access",url:"md_12__MeshDataAccess.xhtml"},
{text:"Creating restart points and restarting a coupled analysis",url:"md_13__Restarts.xhtml"},
{text:"Multi-region coupling interfaces",url:"md_14__Multiregion.xhtml"},
{text:"Testing and debugging tools",url:"md_15__TestingDebuggingTools.xhtml"},
{text:"Migration guide and known issues",url:"md_16__MigrationGuide.xhtml"},
{text:"Compiling, linking, and executing applications that use the participant library",url:"md_17__CompilingLinkingExecuting.xhtml"},
{text:"Heat transfer in square channel air flow tutorial",url:"md_18__ChannelFlowTutorial.xhtml"},
{text:"Oscillating plate damping tutorial",url:"md_19__PlateDampingTutorial.xhtml"},
{text:"Pipe mapping tutorial",url:"md_20__PipeMappingTutorial.xhtml"}]},
{text:"Topics",url:"topics.xhtml"},
{text:"Data Structures",url:"annotated.xhtml",children:[
{text:"Data Structures",url:"annotated.xhtml"},
{text:"Data Structure Index",url:"classes.xhtml"},
{text:"Data Fields",url:"functions.xhtml",children:[
{text:"All",url:"functions.xhtml",children:[
{text:"a",url:"functions.xhtml#index_a"},
{text:"b",url:"functions.xhtml#index_b"},
{text:"c",url:"functions.xhtml#index_c"},
{text:"d",url:"functions.xhtml#index_d"},
{text:"e",url:"functions.xhtml#index_e"},
{text:"f",url:"functions.xhtml#index_f"},
{text:"i",url:"functions.xhtml#index_i"},
{text:"l",url:"functions.xhtml#index_l"},
{text:"m",url:"functions.xhtml#index_m"},
{text:"n",url:"functions.xhtml#index_n"},
{text:"p",url:"functions.xhtml#index_p"},
{text:"q",url:"functions.xhtml#index_q"},
{text:"r",url:"functions.xhtml#index_r"},
{text:"s",url:"functions.xhtml#index_s"},
{text:"t",url:"functions.xhtml#index_t"},
{text:"v",url:"functions.xhtml#index_v"}]},
{text:"Variables",url:"functions_vars.xhtml",children:[
{text:"a",url:"functions_vars.xhtml#index_a"},
{text:"b",url:"functions_vars.xhtml#index_b"},
{text:"c",url:"functions_vars.xhtml#index_c"},
{text:"d",url:"functions_vars.xhtml#index_d"},
{text:"e",url:"functions_vars.xhtml#index_e"},
{text:"f",url:"functions_vars.xhtml#index_f"},
{text:"i",url:"functions_vars.xhtml#index_i"},
{text:"l",url:"functions_vars.xhtml#index_l"},
{text:"m",url:"functions_vars.xhtml#index_m"},
{text:"n",url:"functions_vars.xhtml#index_n"},
{text:"p",url:"functions_vars.xhtml#index_p"},
{text:"q",url:"functions_vars.xhtml#index_q"},
{text:"r",url:"functions_vars.xhtml#index_r"},
{text:"s",url:"functions_vars.xhtml#index_s"},
{text:"t",url:"functions_vars.xhtml#index_t"},
{text:"v",url:"functions_vars.xhtml#index_v"}]}]}]},
{text:"Changelog",url:"md_21__ReleaseNotes.xhtml"}]}
