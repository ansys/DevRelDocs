var structSyscCouplingInterface =
[
    [ "name", "structSyscCouplingInterface.xhtml#a9e710b35f442c7e5e95c64b45df2ff24", null ]
];