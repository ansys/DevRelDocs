var structSyscPointCloud =
[
    [ "connectivityStamp", "structSyscPointCloud.xhtml#aa4379bbf1a298606cf6e1a6c3bf5c186", null ],
    [ "coordinatesStamp", "structSyscPointCloud.xhtml#ae3533d603b8bec31f67aebfe52a1c0dd", null ],
    [ "nodeCoords", "structSyscPointCloud.xhtml#ab4031cb1a5a369dff916411c7f9f88f7", null ],
    [ "nodeIds", "structSyscPointCloud.xhtml#ae200d24d8c00514493ced578df4833c6", null ],
    [ "partitioningStamp", "structSyscPointCloud.xhtml#aca4b9a3dd0f435423692745c200abb16", null ]
];