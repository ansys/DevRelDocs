/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "Getting started", "getting_started.xhtml", null ],
    [ "User guide", "modules.xhtml", "modules" ],
    [ "Operators", "operators_page.xhtml", null ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Typedefs", "namespacemembers_type.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Examples", "examples.xhtml", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"AveragingTest_8cpp-example.xhtml",
"classansys_1_1dpf_1_1CyclicSupport.xhtml#af834b226d2a2bd4bcfcf458d37a923a8",
"classansys_1_1dpf_1_1EventHandler.xhtml#aa5dbd9875e86799e977a4ef66e78d640af1894e7491fc61198867494dcc74bfac",
"classansys_1_1dpf_1_1FieldsContainer.xhtml#afd031defd3088051030347232478ee35",
"classansys_1_1dpf_1_1MeshesContainer.xhtml#a9b94613788b1ced87b9a1ad5b94dcefd",
"classansys_1_1dpf_1_1Operator.xhtml#abff1645354ccf086a67b6171b3a2301f",
"classansys_1_1dpf_1_1OperatorMain.xhtml#aefd22c45d42ee27cf4ec00cc68ae7063",
"classansys_1_1dpf_1_1ResultInfo.xhtml#ad8d61b8875d35dd7812d83b63ae68da9",
"classansys_1_1dpf_1_1TimeFreqSupport.xhtml#a21319848f5f197398148551cbb74d4a0",
"classansys_1_1dpf_1_1Workflow.xhtml#a850d7aa707b7b9017bd679defc9d2845",
"modules.xhtml",
"structansys_1_1dpf_1_1elements.xhtml#a678e9dcef96b39246445828f33e72b71",
"structansys_1_1dpf_1_1quantity__types.xhtml#ac66abf24f8860b9c74f9196ce770ec52"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';