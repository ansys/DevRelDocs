var group__group__1__get__started =
[
    [ "Creating a DPF custom operator's library", "group__group__06__2.xhtml", null ],
    [ "Using DPF capabilities in an existing project", "group__group__06__1.xhtml", null ]
];