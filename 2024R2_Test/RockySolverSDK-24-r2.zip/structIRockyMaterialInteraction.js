var structIRockyMaterialInteraction =
[
    [ "get_dynamic_friction_coefficient", "structIRockyMaterialInteraction.xhtml#ae9ce701837e46ca374d260c7b828dac7", null ],
    [ "get_minimum_restitution_coefficient", "structIRockyMaterialInteraction.xhtml#a897ea40cf65b252af203bd1e9b9a3855", null ],
    [ "get_restitution_coefficient", "structIRockyMaterialInteraction.xhtml#a83c3e5bc364c65dfc9ff275e345d369c", null ],
    [ "get_static_friction_coefficient", "structIRockyMaterialInteraction.xhtml#a4daf7d4586429504ce237697b7a7659f", null ],
    [ "get_stiffness_multiplier", "structIRockyMaterialInteraction.xhtml#af0f10152e6cba7d896304a45ed822fa8", null ],
    [ "get_tangential_stiffness_ratio", "structIRockyMaterialInteraction.xhtml#a766d1bbd19828566927faadc683b4242", null ]
];