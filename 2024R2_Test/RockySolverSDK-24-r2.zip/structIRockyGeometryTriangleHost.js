var structIRockyGeometryTriangleHost =
[
    [ "get_area", "structIRockyGeometryTriangleHost.xhtml#ab782a5e82eba4116e3fdc03086ac6e70", null ],
    [ "get_centroid", "structIRockyGeometryTriangleHost.xhtml#ae049045265b3b4d44366e60086052049", null ],
    [ "get_geometry_index", "structIRockyGeometryTriangleHost.xhtml#a90f497b2b42411676707aae7b1c73dbc", null ],
    [ "get_geometry_rotation_center", "structIRockyGeometryTriangleHost.xhtml#a35e0413744dea0b6d847172dec76ada4", null ],
    [ "get_geometry_rotational_velocity", "structIRockyGeometryTriangleHost.xhtml#a1d39d94664969c8e81279f4d395cfd7e", null ],
    [ "get_material", "structIRockyGeometryTriangleHost.xhtml#a4d4f0981020bd999343324777061578f", null ],
    [ "get_material_index", "structIRockyGeometryTriangleHost.xhtml#ab68909270e06bc1b702c11e54fc39b87", null ],
    [ "get_normal_unit_vector", "structIRockyGeometryTriangleHost.xhtml#acf71ec5c2b5cf6d20f276e3e11cf5ede", null ],
    [ "get_poisson_ratio", "structIRockyGeometryTriangleHost.xhtml#a48d3df84ac1785c1ada100faad008624", null ],
    [ "get_scalars", "structIRockyGeometryTriangleHost.xhtml#a32507720156ec81050cfe8c9179a18a2", null ],
    [ "get_temperature", "structIRockyGeometryTriangleHost.xhtml#ad63935796d98370d0164f0e700639a82", null ],
    [ "get_thermal_conductivity", "structIRockyGeometryTriangleHost.xhtml#aba16fb8ad2df2dc54ff931c091850675", null ],
    [ "get_translational_velocity", "structIRockyGeometryTriangleHost.xhtml#af55f61fe49b8582002b87e1c5d4db703", null ],
    [ "is_adiabatic", "structIRockyGeometryTriangleHost.xhtml#a296b5f25ba526e166233ecc93a361840", null ],
    [ "set_poisson_ratio", "structIRockyGeometryTriangleHost.xhtml#a53c07e03e2af77cfe1549d7ad9ac22ee", null ],
    [ "set_temperature", "structIRockyGeometryTriangleHost.xhtml#a2da990675204aa1b75f7d99d27d0edf4", null ],
    [ "set_thermal_conductivity", "structIRockyGeometryTriangleHost.xhtml#a4b7dc627f3943f1a897e28c3219da0ba", null ]
];