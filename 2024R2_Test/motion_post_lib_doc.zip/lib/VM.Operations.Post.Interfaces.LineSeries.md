# Namespace VM.Operations.Post.Interfaces.LineSeries

### Interfaces

 [IOperationsHeatMapSTFTDataViewModel](VM.Operations.Post.Interfaces.LineSeries.IOperationsHeatMapSTFTDataViewModel.md)


