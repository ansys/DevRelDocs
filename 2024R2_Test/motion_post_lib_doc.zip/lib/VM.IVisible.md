# Interface IVisible

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IVisible
```

## Properties

### IsVisible

```csharp
bool IsVisible { get; set; }
```

#### Property Value

 [bool](https://learn.microsoft.com/dotnet/api/system.boolean)


