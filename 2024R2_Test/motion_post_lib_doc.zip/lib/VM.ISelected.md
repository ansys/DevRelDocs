# Interface ISelected

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface ISelected
```

## Properties

### IsSelected

```csharp
bool IsSelected { get; set; }
```

#### Property Value

 [bool](https://learn.microsoft.com/dotnet/api/system.boolean)


