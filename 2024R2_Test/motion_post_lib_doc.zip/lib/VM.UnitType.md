# Enum UnitType

Namespace: [VM](VM.md)  
Assembly: VM.dll  

Specifies Unit Type.

```csharp
public enum UnitType
```

## Fields

`cgs = 2` 

cgs.



`customize = 4` 

customize.



`ips = 3` 

ips.



`mks = 0` 

mks.



`mmks = 1` 

mmks.




