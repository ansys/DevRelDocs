# Interface IOperationsCalculusLineDataSeriesViewModel

Namespace: [VM.Operations.Post.Interfaces](VM.Operations.Post.Interfaces.md)  
Assembly: VM.Operations.Post.dll  

```csharp
public interface IOperationsCalculusLineDataSeriesViewModel
```

## Properties

### CalculusType

Get or Set the CalculusType of Calculus. It has Differentiation, Integration.

```csharp
CalculusType CalculusType { get; set; }
```

#### Property Value

 CalculusType


