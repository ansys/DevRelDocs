# Enum EntitySelectionMode

Namespace: [VM](VM.md)  
Assembly: VM.dll  

This enumerator represent the selection mode of the view

```csharp
public enum EntitySelectionMode
```

## Fields

`Normal = 0` 

Normal selection mode



`Pick = 1` 

Pick mode




