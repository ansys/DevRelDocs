# Interface IDirectionBase

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IDirectionBase
```

## Properties

### Value

```csharp
Vector Value { get; }
```

#### Property Value

 [Vector](VM.Vector.md)

## Methods

### Reverse\(\)

```csharp
void Reverse()
```


