# Enum ReferenceTypes

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public enum ReferenceTypes
```

## Fields

`ALL = 0` 

Set parametric for Point Link and geometry.



`BASIC = 1` 

Set parametric for Point Link.



`NONE = 2` 

Can not be parametric.




