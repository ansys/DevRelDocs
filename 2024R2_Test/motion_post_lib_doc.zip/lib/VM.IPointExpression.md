# Interface IPointExpression

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IPointExpression : IPointBase, IExpression
```

#### Implements

[IPointBase](VM.IPointBase.md), 
[IExpression](VM.IExpression.md)


