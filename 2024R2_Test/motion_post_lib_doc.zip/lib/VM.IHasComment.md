# Interface IHasComment

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IHasComment
```

## Properties

### Comment

```csharp
string Comment { get; set; }
```

#### Property Value

 [string](https://learn.microsoft.com/dotnet/api/system.string)


