# Interface IHasID

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IHasID
```

## Properties

### ID

```csharp
Identifier ID { get; }
```

#### Property Value

 [Identifier](VM.Identifier.md)


