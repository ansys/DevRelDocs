# Interface IDirectionExpression

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IDirectionExpression : IDirectionBase, IExpression
```

#### Implements

[IDirectionBase](VM.IDirectionBase.md), 
[IExpression](VM.IExpression.md)


