# Enum RotationTypes

Namespace: [VM](VM.md)  
Assembly: VM.dll  

Specifies Rotation Type.

```csharp
public enum RotationTypes
```

## Fields

`EulerAngle = 0` 

EulerAngle



`FixedAngle = 1` 

FixedAngle




