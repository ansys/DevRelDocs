# Delegate ParameterConverter

Namespace: [VM.Operations.Post.Attributes](VM.Operations.Post.Attributes.md)  
Assembly: VM.Operations.Post.dll  

```csharp
public delegate object ParameterConverter(object val)
```

#### Parameters

`val` [object](https://learn.microsoft.com/dotnet/api/system.object)

#### Returns

 [object](https://learn.microsoft.com/dotnet/api/system.object)


