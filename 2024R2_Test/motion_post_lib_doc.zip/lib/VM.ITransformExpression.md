# Interface ITransformExpression

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface ITransformExpression : ITransformBase, IExpression
```

#### Implements

[ITransformBase](VM.ITransformBase.md), 
[IExpression](VM.IExpression.md)


