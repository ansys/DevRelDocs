# Enum AngleTypes

Namespace: [VM](VM.md)  
Assembly: VM.dll  

Specifies Angle Type.

```csharp
public enum AngleTypes
```

## Fields

`Degree = 0` 

Degree



`Radian = 1` 

Radian




