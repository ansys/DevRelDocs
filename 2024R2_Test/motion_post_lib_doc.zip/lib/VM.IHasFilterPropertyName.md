# Interface IHasFilterPropertyName

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IHasFilterPropertyName
```

## Properties

### FilterPropertyName

```csharp
string FilterPropertyName { get; }
```

#### Property Value

 [string](https://learn.microsoft.com/dotnet/api/system.string)


