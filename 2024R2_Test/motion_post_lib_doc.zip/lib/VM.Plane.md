# Enum Plane

Namespace: [VM](VM.md)  
Assembly: VM.dll  

Specifies type for the plane.

```csharp
public enum Plane
```

## Fields

`XY = 2` 

XY.



`XZ = 4` 

XZ.



`YX = 5` 

YX.



`YZ = 0` 

YZ.



`ZX = 1` 

ZX.



`ZY = 3` 

ZY.




