# Enum SortDirection

Namespace: [VM](VM.md)  
Assembly: VM.dll  

This enumerator represent the sort direction

```csharp
public enum SortDirection
```

## Fields

`Ascending = 0` 

Ascending



`Descending = 1` 

Descending




