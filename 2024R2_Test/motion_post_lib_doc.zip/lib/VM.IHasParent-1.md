# Interface IHasParent<T\>

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IHasParent<T>
```

#### Type Parameters

`T` 

## Properties

### Parent

```csharp
T Parent { get; }
```

#### Property Value

 T


