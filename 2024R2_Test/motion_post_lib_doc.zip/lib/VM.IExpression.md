# Interface IExpression

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IExpression
```

## Properties

### String

```csharp
string String { get; set; }
```

#### Property Value

 [string](https://learn.microsoft.com/dotnet/api/system.string)


