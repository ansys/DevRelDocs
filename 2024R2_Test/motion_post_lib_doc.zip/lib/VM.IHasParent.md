# Interface IHasParent

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IHasParent
```

## Properties

### Parent

```csharp
object Parent { get; }
```

#### Property Value

 [object](https://learn.microsoft.com/dotnet/api/system.object)


