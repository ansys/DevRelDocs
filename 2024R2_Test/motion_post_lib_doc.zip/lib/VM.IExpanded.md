# Interface IExpanded

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IExpanded
```

## Properties

### IsExpanded

```csharp
bool IsExpanded { get; set; }
```

#### Property Value

 [bool](https://learn.microsoft.com/dotnet/api/system.boolean)


