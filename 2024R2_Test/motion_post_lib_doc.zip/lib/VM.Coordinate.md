# Enum Coordinate

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public enum Coordinate
```

## Fields

`Position = 3` 

Position.



`X = 0` 

X.



`Y = 1` 

Y.



`Z = 2` 

Z.




