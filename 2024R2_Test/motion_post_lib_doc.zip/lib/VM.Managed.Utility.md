# Namespace VM.Managed.Utility

### Classes

 [Convert](VM.Managed.Utility.Convert.md)

This class is to represent the special convert.


