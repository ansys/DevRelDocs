# Interface IIdentifier

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IIdentifier
```

## Properties

### First

```csharp
uint First { get; set; }
```

#### Property Value

 [uint](https://learn.microsoft.com/dotnet/api/system.uint32)


