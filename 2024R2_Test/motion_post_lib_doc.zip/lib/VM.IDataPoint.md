# Interface IDataPoint

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IDataPoint
```

## Properties

### X

```csharp
double X { get; set; }
```

#### Property Value

 [double](https://learn.microsoft.com/dotnet/api/system.double)

### Y

```csharp
double Y { get; set; }
```

#### Property Value

 [double](https://learn.microsoft.com/dotnet/api/system.double)


