# Interface IHasExpressionEvaluator

Namespace: [VM](VM.md)  
Assembly: VM.dll  

```csharp
public interface IHasExpressionEvaluator
```

## Properties

### ExpressionEvaluator

```csharp
IExpressionEvaluator ExpressionEvaluator { get; }
```

#### Property Value

 [IExpressionEvaluator](VM.IExpressionEvaluator.md)


