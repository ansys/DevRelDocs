var classsysc_1_1DataTransfer =
[
    [ "DataTransfer", "classsysc_1_1DataTransfer.xhtml#a9a4412f47dbd13ece79d35b0876ace13", null ],
    [ "getSideOneVariable", "classsysc_1_1DataTransfer.xhtml#ab8142869f0ec725f8f3d06a73a043684", null ],
    [ "getSideTwoVariable", "classsysc_1_1DataTransfer.xhtml#a482db261458815e4bb79c3f5a680738d", null ],
    [ "getSourceSide", "classsysc_1_1DataTransfer.xhtml#a7788b20c57fe5479500101f705d0aaf8", null ],
    [ "getSourceVariable", "classsysc_1_1DataTransfer.xhtml#aa60c024787bf5956a251bef61e75b1a2", null ],
    [ "getTargetSide", "classsysc_1_1DataTransfer.xhtml#a737e25f50bae13a64f047a7b84d5e378", null ],
    [ "getTargetVariable", "classsysc_1_1DataTransfer.xhtml#a4739ad73891b33eef85d5df8b4c6898b", null ]
];