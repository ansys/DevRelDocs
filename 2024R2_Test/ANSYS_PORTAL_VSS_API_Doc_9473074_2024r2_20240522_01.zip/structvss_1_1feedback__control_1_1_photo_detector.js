var structvss_1_1feedback__control_1_1_photo_detector =
[
    [ "responsivity", "structvss_1_1feedback__control_1_1_photo_detector.xhtml#af768300aaac0474138c4e62bf482b6fb", null ],
    [ "max_current", "structvss_1_1feedback__control_1_1_photo_detector.xhtml#a75e8d9b10d17ca9d225927bf97910ad8", null ],
    [ "noise_standard_deviation", "structvss_1_1feedback__control_1_1_photo_detector.xhtml#a930d6441bc9601544a2263b50b25e5bc", null ]
];