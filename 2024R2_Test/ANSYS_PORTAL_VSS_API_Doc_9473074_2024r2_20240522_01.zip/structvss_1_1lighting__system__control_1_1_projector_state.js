var structvss_1_1lighting__system__control_1_1_projector_state =
[
    [ "projector_name", "structvss_1_1lighting__system__control_1_1_projector_state.xhtml#aea26637c87a2da27ba1ed89d67d9caea", null ],
    [ "modules_state", "structvss_1_1lighting__system__control_1_1_projector_state.xhtml#a271b67339a23493274196d4be3e907d0", null ],
    [ "position", "structvss_1_1lighting__system__control_1_1_projector_state.xhtml#aad4acd85f0e76852a3218b69ceedb9e8", null ],
    [ "orientation", "structvss_1_1lighting__system__control_1_1_projector_state.xhtml#a8c9dfcb5d34084385d2f907018a6d769", null ]
];