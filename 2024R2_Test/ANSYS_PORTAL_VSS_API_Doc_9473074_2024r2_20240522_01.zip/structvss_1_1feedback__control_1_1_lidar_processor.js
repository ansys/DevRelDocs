var structvss_1_1feedback__control_1_1_lidar_processor =
[
    [ "analog_to_digital_converter", "structvss_1_1feedback__control_1_1_lidar_processor.xhtml#aee5d8c98ddf7dcdd474096a790b8ad73", null ],
    [ "max_returns", "structvss_1_1feedback__control_1_1_lidar_processor.xhtml#a2a132654b2d59075b1eacb2caa2065ea", null ],
    [ "max_range", "structvss_1_1feedback__control_1_1_lidar_processor.xhtml#a2ef989d5575af5b4a9b494a2db13c8ab", null ]
];