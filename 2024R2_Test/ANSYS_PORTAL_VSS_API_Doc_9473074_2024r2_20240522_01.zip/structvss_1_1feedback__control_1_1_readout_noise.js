var structvss_1_1feedback__control_1_1_readout_noise =
[
    [ "readout_noise_average", "structvss_1_1feedback__control_1_1_readout_noise.xhtml#ad39ed7213fb956c2ac38fdb81656bb5d", null ],
    [ "readout_noise_standard", "structvss_1_1feedback__control_1_1_readout_noise.xhtml#a8f6f8757d4a93479dce80c6055c90a12", null ]
];