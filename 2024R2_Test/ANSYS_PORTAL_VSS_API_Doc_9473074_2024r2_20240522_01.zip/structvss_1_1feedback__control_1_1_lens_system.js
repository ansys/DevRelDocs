var structvss_1_1feedback__control_1_1_lens_system =
[
    [ "aperture_area", "structvss_1_1feedback__control_1_1_lens_system.xhtml#a990aff7de4fce3a0212f9c0db99c1b97", null ],
    [ "field_of_view", "structvss_1_1feedback__control_1_1_lens_system.xhtml#a8b08aa012dbf336877eb38ed68fe928f", null ],
    [ "lens_distortion", "structvss_1_1feedback__control_1_1_lens_system.xhtml#a7789e3b847a620cc2adfe2dd66e1c334", null ]
];