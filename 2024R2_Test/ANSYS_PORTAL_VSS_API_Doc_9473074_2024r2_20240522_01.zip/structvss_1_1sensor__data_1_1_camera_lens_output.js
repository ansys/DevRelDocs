var structvss_1_1sensor__data_1_1_camera_lens_output =
[
    [ "resolution", "structvss_1_1sensor__data_1_1_camera_lens_output.xhtml#a4ddb69568d2cb4dcf8fd8bbf933401ad", null ],
    [ "spectral_sampling", "structvss_1_1sensor__data_1_1_camera_lens_output.xhtml#ace7ea5433bb0784cd241236dc0cc2d01", null ],
    [ "camera_data", "structvss_1_1sensor__data_1_1_camera_lens_output.xhtml#a11e90704a24ec6960477c5cea0ac90ae", null ]
];