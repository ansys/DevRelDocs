var structvss_1_1simulation_1_1_deploy_host =
[
    [ "address", "structvss_1_1simulation_1_1_deploy_host.xhtml#aa20b742aa8a5fa9890e1b63a7e373273", null ],
    [ "deploy_nodes", "structvss_1_1simulation_1_1_deploy_host.xhtml#a69fcdb30fc547f53dcca2acfcf479096", null ],
    [ "resource_manager_port", "structvss_1_1simulation_1_1_deploy_host.xhtml#a4ba0630268d1749d72664d8f7cfca19f", null ],
    [ "gpu_identifiers", "structvss_1_1simulation_1_1_deploy_host.xhtml#ade569ae443f506dd6f109304b4251dd6", null ],
    [ "data_access_server_port", "structvss_1_1simulation_1_1_deploy_host.xhtml#a1520aff7ae1ad12eef539419e2322dad", null ]
];