var structvss_1_1simulation_1_1_lighting_system =
[
    [ "identifier", "structvss_1_1simulation_1_1_lighting_system.xhtml#a548339c4c83a6aedd2f0f489a9c05c06", null ],
    [ "lighting_system_data", "structvss_1_1simulation_1_1_lighting_system.xhtml#ac07896245844d4b6b53671eac8f7b293", null ],
    [ "resource", "structvss_1_1simulation_1_1_lighting_system.xhtml#af23e6732a274956aaec308cc1a666de4", null ]
];