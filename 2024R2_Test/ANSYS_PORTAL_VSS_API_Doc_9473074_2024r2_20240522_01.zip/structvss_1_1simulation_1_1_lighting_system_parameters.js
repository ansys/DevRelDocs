var structvss_1_1simulation_1_1_lighting_system_parameters =
[
    [ "sampling_rate", "structvss_1_1simulation_1_1_lighting_system_parameters.xhtml#ac098f62c7cf0a449309e2b5890cfeb38", null ]
];