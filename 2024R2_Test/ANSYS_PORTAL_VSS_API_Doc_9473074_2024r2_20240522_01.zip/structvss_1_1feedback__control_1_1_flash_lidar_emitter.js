var structvss_1_1feedback__control_1_1_flash_lidar_emitter =
[
    [ "frequency", "structvss_1_1feedback__control_1_1_flash_lidar_emitter.xhtml#ac811346d20da5d81b936eed4df004f43", null ],
    [ "laser_pulse", "structvss_1_1feedback__control_1_1_flash_lidar_emitter.xhtml#af411d13828f289861bc5ebe6e87a811a", null ],
    [ "gaussian_beam_shape", "structvss_1_1feedback__control_1_1_flash_lidar_emitter.xhtml#a049728afc6a21010f748b782501b510d", null ],
    [ "beam_shape_intensity_file", "structvss_1_1feedback__control_1_1_flash_lidar_emitter.xhtml#a5377fbbf0ce250f9361d2c75697735de", null ],
    [ "peak_power", "structvss_1_1feedback__control_1_1_flash_lidar_emitter.xhtml#a8f8277df75efd825c98c17f86ee93ce2", null ]
];