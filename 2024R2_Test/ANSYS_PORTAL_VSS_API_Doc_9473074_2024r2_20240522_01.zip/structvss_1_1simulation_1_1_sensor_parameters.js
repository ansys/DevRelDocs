var structvss_1_1simulation_1_1_sensor_parameters =
[
    [ "identifier", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#a0992e8610dd365cf41269f4e2b2d3f60", null ],
    [ "recording_format", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#a038071eea4353930683fcaa95c8a8056", null ],
    [ "display", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#a24378052ec7597a81fd5a5f218e3f69f", null ],
    [ "radar_simulation", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#a451f5bcf0184d29d997f461a99c09656", null ],
    [ "lidar_simulation", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#ae2641c8ac11ba1fb88b8eef2204e1bf1", null ],
    [ "pb_cam_simulation", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#a62887911f25b3b86dc9ee6ad40c35564", null ],
    [ "thermal_cam_simulation", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#a4427be3505c07682546cc7bba2b4f767", null ],
    [ "output_splitting", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#afb6970ba2c065b09ab2774fe0559a704", null ],
    [ "serialize_data", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#aaf5e1ebedbe438446020f280477cd4e9", null ],
    [ "deploy_node_id", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#a2b33511156f8590a64822cc74e17a1b9", null ],
    [ "data_access_settings", "structvss_1_1simulation_1_1_sensor_parameters.xhtml#ab6ec565337ce1e4fc61520528ef3dee5", null ]
];