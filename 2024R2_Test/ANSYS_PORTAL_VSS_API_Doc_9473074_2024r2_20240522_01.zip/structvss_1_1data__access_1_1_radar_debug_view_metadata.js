var structvss_1_1data__access_1_1_radar_debug_view_metadata =
[
    [ "image_width", "structvss_1_1data__access_1_1_radar_debug_view_metadata.xhtml#ad65de0aa84a0ad2841b1b5ab2015bc7a", null ],
    [ "image_height", "structvss_1_1data__access_1_1_radar_debug_view_metadata.xhtml#a82ffcb3d6c6dbdb55268527e3ffeb4eb", null ],
    [ "pixel_format", "structvss_1_1data__access_1_1_radar_debug_view_metadata.xhtml#a3079096520acc17bdf10e8fe6fefad6c", null ],
    [ "mode_identifier", "structvss_1_1data__access_1_1_radar_debug_view_metadata.xhtml#a84a44e7ce5b20986ade128c3cb610be7", null ]
];