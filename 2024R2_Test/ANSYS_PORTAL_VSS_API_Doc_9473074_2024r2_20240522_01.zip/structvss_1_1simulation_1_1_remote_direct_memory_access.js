var structvss_1_1simulation_1_1_remote_direct_memory_access =
[
    [ "buffer_size", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#ae61265b012a1a9e08a51d3c888ed0d72", null ],
    [ "sender_address", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#aa1cce85118ef2acb91624764d46fcaea", null ],
    [ "sender_port", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#ab6368d05a727c6f4c7f28d37b2c7d2f6", null ],
    [ "sender_backchannel_port", "structvss_1_1simulation_1_1_remote_direct_memory_access.xhtml#a1f756616509786eb224c2a067452f41e", null ]
];