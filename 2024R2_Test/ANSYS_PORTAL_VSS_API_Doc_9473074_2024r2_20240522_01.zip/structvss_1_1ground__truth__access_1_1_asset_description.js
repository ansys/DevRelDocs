var structvss_1_1ground__truth__access_1_1_asset_description =
[
    [ "instance_name", "structvss_1_1ground__truth__access_1_1_asset_description.xhtml#a7b99ca6d7d96d1d22cd46f4a03770329", null ],
    [ "asset_path", "structvss_1_1ground__truth__access_1_1_asset_description.xhtml#adccf72dc2450928b75e29867d26ed83c", null ]
];