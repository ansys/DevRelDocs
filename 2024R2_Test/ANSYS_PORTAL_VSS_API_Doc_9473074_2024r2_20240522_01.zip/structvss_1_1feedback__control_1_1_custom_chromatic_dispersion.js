var structvss_1_1feedback__control_1_1_custom_chromatic_dispersion =
[
    [ "focal_shift", "structvss_1_1feedback__control_1_1_custom_chromatic_dispersion.xhtml#abcdd9e91085d744773789375fe5d3a34", null ]
];