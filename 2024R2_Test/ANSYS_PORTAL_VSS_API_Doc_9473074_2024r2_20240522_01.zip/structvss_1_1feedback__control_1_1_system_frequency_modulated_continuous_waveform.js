var structvss_1_1feedback__control_1_1_system_frequency_modulated_continuous_waveform =
[
    [ "bandwidth", "structvss_1_1feedback__control_1_1_system_frequency_modulated_continuous_waveform.xhtml#abf335cf038fda465e7829b8fd7d90c77", null ],
    [ "sampling_rate", "structvss_1_1feedback__control_1_1_system_frequency_modulated_continuous_waveform.xhtml#a0a6710006b442c662e12445d25257edb", null ],
    [ "number_of_samples_per_chirp", "structvss_1_1feedback__control_1_1_system_frequency_modulated_continuous_waveform.xhtml#a289f2987040b0c161af312961569f6af", null ],
    [ "chirp_interval", "structvss_1_1feedback__control_1_1_system_frequency_modulated_continuous_waveform.xhtml#a2784a334efa21fcc334a0e00f767d1fc", null ],
    [ "number_of_chirps_in_coherent_processing_interval", "structvss_1_1feedback__control_1_1_system_frequency_modulated_continuous_waveform.xhtml#a8082fb142ce411fc025332c8223de6c6", null ],
    [ "rx_components", "structvss_1_1feedback__control_1_1_system_frequency_modulated_continuous_waveform.xhtml#a80da493360ecaf60c26bc2b82a48a47d", null ]
];