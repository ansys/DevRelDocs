var structvss_1_1simulation_1_1_world_update =
[
    [ "simulation_time", "structvss_1_1simulation_1_1_world_update.xhtml#a4166e9fe3d2230b2c58cdd4c3102899c", null ],
    [ "environment_updates", "structvss_1_1simulation_1_1_world_update.xhtml#a1ce99168f696131f9b2ad7271930c3f1", null ],
    [ "object_updates", "structvss_1_1simulation_1_1_world_update.xhtml#a367c41b943543b5cdd6fd427873fbbeb", null ]
];