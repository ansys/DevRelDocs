var structvss_1_1feedback__control_1_1_firing =
[
    [ "time", "structvss_1_1feedback__control_1_1_firing.xhtml#a86ae2e189968a4f26a1d5d2af037d524", null ],
    [ "azimuth", "structvss_1_1feedback__control_1_1_firing.xhtml#af21d385016cc574440f420a87ccdebdd", null ],
    [ "elevation", "structvss_1_1feedback__control_1_1_firing.xhtml#a37b5ef9efa5500172474da495eb7266c", null ],
    [ "peak_power", "structvss_1_1feedback__control_1_1_firing.xhtml#a9d1ee6934f58d7617c044f68bdd9c677", null ]
];