var structvss_1_1ground__truth__access_1_1_mesh_description =
[
    [ "mesh_part_name", "structvss_1_1ground__truth__access_1_1_mesh_description.xhtml#a33b485a1c16a89ed529e1041f2bcd804", null ],
    [ "material_path", "structvss_1_1ground__truth__access_1_1_mesh_description.xhtml#aaceb40631c9f8ebf46ec816d67aac87e", null ],
    [ "mesh_name", "structvss_1_1ground__truth__access_1_1_mesh_description.xhtml#a5d3659bb9ff92e18a27f0b2c8ec31e5c", null ]
];