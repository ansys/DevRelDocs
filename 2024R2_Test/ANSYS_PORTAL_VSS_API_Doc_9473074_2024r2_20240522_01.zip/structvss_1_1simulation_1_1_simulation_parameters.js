var structvss_1_1simulation_1_1_simulation_parameters =
[
    [ "sensor_simulation_parameters", "structvss_1_1simulation_1_1_simulation_parameters.xhtml#a31970d26ac4b480d8a1e381b63ff70dc", null ],
    [ "lighting_system_parameters", "structvss_1_1simulation_1_1_simulation_parameters.xhtml#a1fb9614b06557a139728dfa015be7fb9", null ],
    [ "pixel_segmentation_mapping", "structvss_1_1simulation_1_1_simulation_parameters.xhtml#a1cadf10a54028a12ef433455858a2438", null ]
];