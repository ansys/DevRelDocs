var structvss_1_1feedback__control_1_1_arbitrary_pulse =
[
    [ "center_frequency", "structvss_1_1feedback__control_1_1_arbitrary_pulse.xhtml#a7e7d8d59dcf300872c8057707ef5baa9", null ],
    [ "bandwidth", "structvss_1_1feedback__control_1_1_arbitrary_pulse.xhtml#ad1dddd94dd3723fe6e0e2545238c13a8", null ],
    [ "number_of_frequency_samples_per_pulse", "structvss_1_1feedback__control_1_1_arbitrary_pulse.xhtml#af6bf636cec3a5bfc0dbfb425c94deeb6", null ],
    [ "pulse_interval", "structvss_1_1feedback__control_1_1_arbitrary_pulse.xhtml#a204737194787b3ecbdb74bca4f383c90", null ]
];