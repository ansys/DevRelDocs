var structvss_1_1sensor__data_1_1_waveform_data =
[
    [ "waveform_length", "structvss_1_1sensor__data_1_1_waveform_data.xhtml#a996e4b3405c200f73d0761573fea1e62", null ],
    [ "data", "structvss_1_1sensor__data_1_1_waveform_data.xhtml#ace2e1c0e5eee75a3245447ed2e8f1948", null ]
];