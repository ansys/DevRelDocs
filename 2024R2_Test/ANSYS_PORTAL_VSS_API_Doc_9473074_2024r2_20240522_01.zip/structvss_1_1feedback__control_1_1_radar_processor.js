var structvss_1_1feedback__control_1_1_radar_processor =
[
    [ "range_pixels", "structvss_1_1feedback__control_1_1_radar_processor.xhtml#a9bd9e67f3c5c99a2c6b05502658c8d66", null ],
    [ "velocity_pixels", "structvss_1_1feedback__control_1_1_radar_processor.xhtml#a08a6e2a6812e2fd14734457a2bd90dc1", null ],
    [ "range_window", "structvss_1_1feedback__control_1_1_radar_processor.xhtml#a3d1d69f1075cf16c846dd5d7ddc134a7", null ],
    [ "velocity_window", "structvss_1_1feedback__control_1_1_radar_processor.xhtml#a062acef54a6300d3dcfeefb3f76c58fa", null ],
    [ "center_velocity", "structvss_1_1feedback__control_1_1_radar_processor.xhtml#a2f5374aae6fb9470c2f361d4caf1160a", null ]
];