var structvss_1_1lighting__system__control_1_1_time_stamped_lighting_system_state =
[
    [ "lighting_system_state", "structvss_1_1lighting__system__control_1_1_time_stamped_lighting_system_state.xhtml#ae0b150d0fb0b5a1bc5ee331fd5f9b07d", null ],
    [ "simulation_time", "structvss_1_1lighting__system__control_1_1_time_stamped_lighting_system_state.xhtml#a1496c37bb746ba39c02a65c9f7d3cc24", null ]
];