var structvss_1_1_color =
[
    [ "red", "structvss_1_1_color.xhtml#a76695eecc36bb9564d05b17279a02385", null ],
    [ "green", "structvss_1_1_color.xhtml#a31dabee08f7e01c88c3ff7b156bf4183", null ],
    [ "blue", "structvss_1_1_color.xhtml#ad984ffbc4817fa2ef9bcd5e1501675c6", null ]
];