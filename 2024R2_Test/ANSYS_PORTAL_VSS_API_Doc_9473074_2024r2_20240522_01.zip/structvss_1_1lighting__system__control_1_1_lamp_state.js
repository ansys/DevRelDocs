var structvss_1_1lighting__system__control_1_1_lamp_state =
[
    [ "lamp_name", "structvss_1_1lighting__system__control_1_1_lamp_state.xhtml#acb0a411d1549c7f6a29204dcbe77efd9", null ],
    [ "flux", "structvss_1_1lighting__system__control_1_1_lamp_state.xhtml#a436692a2101f1e83cf119bae9591faae", null ]
];