var structvss_1_1ground__truth__access_1_1_pixel_segmentation_tag_color_map =
[
    [ "tag_color_map", "structvss_1_1ground__truth__access_1_1_pixel_segmentation_tag_color_map.xhtml#acb8ca040922e13323d39a93e99420be8", null ],
    [ "status", "structvss_1_1ground__truth__access_1_1_pixel_segmentation_tag_color_map.xhtml#a25b66afd35f5c23920a73d856edbffcc", null ]
];