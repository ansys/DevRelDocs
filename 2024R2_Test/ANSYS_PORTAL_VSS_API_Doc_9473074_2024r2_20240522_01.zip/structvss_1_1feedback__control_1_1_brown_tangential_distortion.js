var structvss_1_1feedback__control_1_1_brown_tangential_distortion =
[
    [ "p1", "structvss_1_1feedback__control_1_1_brown_tangential_distortion.xhtml#ac41610ff67bf2451c179fcd9893496cf", null ],
    [ "p2", "structvss_1_1feedback__control_1_1_brown_tangential_distortion.xhtml#aa0ea422b258ad36e803b4e38e8155fc8", null ]
];