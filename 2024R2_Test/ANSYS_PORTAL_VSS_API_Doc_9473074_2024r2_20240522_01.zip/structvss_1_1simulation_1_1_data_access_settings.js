var structvss_1_1simulation_1_1_data_access_settings =
[
    [ "recording_format", "structvss_1_1simulation_1_1_data_access_settings.xhtml#a9b92d415ebee47d6d015886036ea7075", null ],
    [ "shared_memory_access", "structvss_1_1simulation_1_1_data_access_settings.xhtml#aede87e6857ba44c6891d61ebce05fc38", null ],
    [ "remote_direct_memory_access", "structvss_1_1simulation_1_1_data_access_settings.xhtml#a73aed2d37e6dafc80a287e188f6f8d7b", null ]
];