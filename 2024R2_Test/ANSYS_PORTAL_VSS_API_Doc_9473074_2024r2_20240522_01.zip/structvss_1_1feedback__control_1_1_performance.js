var structvss_1_1feedback__control_1_1_performance =
[
    [ "range_resolution", "structvss_1_1feedback__control_1_1_performance.xhtml#a3a5ed74da68d606d777412ead65f3c3f", null ],
    [ "velocity_resolution", "structvss_1_1feedback__control_1_1_performance.xhtml#a62d7f953fabe6817b218c9f50ddd68e6", null ],
    [ "range_ambiguity", "structvss_1_1feedback__control_1_1_performance.xhtml#acceab80292e9f6e2e4f7bf15459d786b", null ],
    [ "velocity_ambiguity", "structvss_1_1feedback__control_1_1_performance.xhtml#aa84edf163179103b71e5ac773083cccf", null ]
];