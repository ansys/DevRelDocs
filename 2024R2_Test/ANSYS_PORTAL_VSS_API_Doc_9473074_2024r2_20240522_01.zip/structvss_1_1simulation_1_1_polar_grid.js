var structvss_1_1simulation_1_1_polar_grid =
[
    [ "radial_grid_points", "structvss_1_1simulation_1_1_polar_grid.xhtml#a2e38a000cbd249c7a32d492557702130", null ],
    [ "angular_grid_points", "structvss_1_1simulation_1_1_polar_grid.xhtml#a15daf468dc9928c37dc144dedacc11e9", null ],
    [ "has_central_point", "structvss_1_1simulation_1_1_polar_grid.xhtml#a9f85a16d560934b25a31bf69684c1823", null ]
];