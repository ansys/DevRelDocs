var structvss_1_1data__access_1_1_sensor_data_description =
[
    [ "sensor_id", "structvss_1_1data__access_1_1_sensor_data_description.xhtml#a776ff5ae2d82d8edcf775dbaef51d583", null ],
    [ "data_id", "structvss_1_1data__access_1_1_sensor_data_description.xhtml#a3350569b3f81d18f7e611789e128ca04", null ],
    [ "simulation_time", "structvss_1_1data__access_1_1_sensor_data_description.xhtml#a6fc83bdd8d379676869cd169fe0e936d", null ],
    [ "metadata", "structvss_1_1data__access_1_1_sensor_data_description.xhtml#a73764c0350b3e9ea2b4ab54f2fe37d4d", null ],
    [ "data_by_identifiers", "structvss_1_1data__access_1_1_sensor_data_description.xhtml#ac5b8caedd8bf3c7c5284854f57f3513d", null ]
];