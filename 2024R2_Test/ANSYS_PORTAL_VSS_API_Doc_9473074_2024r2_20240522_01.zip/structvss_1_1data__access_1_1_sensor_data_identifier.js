var structvss_1_1data__access_1_1_sensor_data_identifier =
[
    [ "data_id", "structvss_1_1data__access_1_1_sensor_data_identifier.xhtml#a87a5690fa62e66a1a80f2d44e730e589", null ]
];