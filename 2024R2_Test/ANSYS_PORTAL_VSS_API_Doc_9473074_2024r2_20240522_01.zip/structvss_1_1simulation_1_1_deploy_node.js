var structvss_1_1simulation_1_1_deploy_node =
[
    [ "node_id", "structvss_1_1simulation_1_1_deploy_node.xhtml#aab7415ed288e0cb645b7ea777807fc69", null ],
    [ "port", "structvss_1_1simulation_1_1_deploy_node.xhtml#a1f0b0fe1a6e257d96edb11ec34300b25", null ]
];