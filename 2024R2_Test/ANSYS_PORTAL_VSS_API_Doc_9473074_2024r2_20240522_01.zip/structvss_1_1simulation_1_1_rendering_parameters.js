var structvss_1_1simulation_1_1_rendering_parameters =
[
    [ "RealTimeParameters", "structvss_1_1simulation_1_1_rendering_parameters_1_1_real_time_parameters.xhtml", "structvss_1_1simulation_1_1_rendering_parameters_1_1_real_time_parameters" ],
    [ "camera_near_plane", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#ab1079b5e0ac8426c4f23a62cba776b2d", null ],
    [ "camera_far_plane", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#a8656ad82a8121af563da4df1d395c97c", null ],
    [ "shadow_quality", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#a8a6e06da7ce13460d212701c8f21d7ab", null ],
    [ "texture_quality", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#a1dcea248e7b738f9e72248414a7441fe", null ],
    [ "borderless", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#a2417bdf1f7d38eb12e8ca30f6f9fa81b", null ],
    [ "antialiasing_factor", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#a605b9f16152b40e3b2f96bbd4fe7245d", null ],
    [ "vertical_sync", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#a538847812285ed697366fe55fc87fc54", null ],
    [ "enable_alpha_channel", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#abdf78d46e29058ebf631ae16756ddd65", null ],
    [ "enable_asynchronous_readback", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#ae141dfc7416640a294095e6bc9f0936e", null ],
    [ "real_time_parameters", "structvss_1_1simulation_1_1_rendering_parameters.xhtml#a23ac17870fccac097d3778e9d6c39ca0", null ]
];