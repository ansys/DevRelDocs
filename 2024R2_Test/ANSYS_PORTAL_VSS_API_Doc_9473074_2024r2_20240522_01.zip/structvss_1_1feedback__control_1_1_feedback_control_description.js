var structvss_1_1feedback__control_1_1_feedback_control_description =
[
    [ "sensor_id", "structvss_1_1feedback__control_1_1_feedback_control_description.xhtml#aa4d921462e30e4d260c3daba6483db70", null ],
    [ "feedback_control_camera_parameters", "structvss_1_1feedback__control_1_1_feedback_control_description.xhtml#ab5007d80d0512360d9cee713f30843cf", null ],
    [ "feedback_control_radar_parameters", "structvss_1_1feedback__control_1_1_feedback_control_description.xhtml#a66162939f0aa5a7ee4f0b3c6b544c794", null ],
    [ "feedback_control_lidar_parameters", "structvss_1_1feedback__control_1_1_feedback_control_description.xhtml#a699fc07d4f10c51437143379eee788ab", null ],
    [ "enable_sensor_protection", "structvss_1_1feedback__control_1_1_feedback_control_description.xhtml#a657072e71c8bd8542719cc7e35e4cced", null ]
];