var structvss_1_1feedback__control_1_1_gaussian_beam_shape =
[
    [ "divergence", "structvss_1_1feedback__control_1_1_gaussian_beam_shape.xhtml#a9e4c097623a580451e79881ef32958e1", null ]
];