var structvss_1_1ground__truth__access_1_1_contribution_dictionary =
[
    [ "items", "structvss_1_1ground__truth__access_1_1_contribution_dictionary.xhtml#ac8caf61705b0f998688f5ace29e3a594", null ],
    [ "status", "structvss_1_1ground__truth__access_1_1_contribution_dictionary.xhtml#aac8105451626f3f5922e567b5940391e", null ]
];