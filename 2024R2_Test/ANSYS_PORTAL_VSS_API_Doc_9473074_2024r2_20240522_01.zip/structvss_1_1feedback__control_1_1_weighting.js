var structvss_1_1feedback__control_1_1_weighting =
[
    [ "real_part", "structvss_1_1feedback__control_1_1_weighting.xhtml#a41053839b3886eebf476f0787220dd87", null ],
    [ "imaginary_part", "structvss_1_1feedback__control_1_1_weighting.xhtml#a164dbdfb32d52e3f149efe4b8c114444", null ]
];