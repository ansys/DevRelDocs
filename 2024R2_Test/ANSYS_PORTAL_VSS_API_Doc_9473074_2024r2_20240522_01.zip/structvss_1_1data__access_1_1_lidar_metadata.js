var structvss_1_1data__access_1_1_lidar_metadata =
[
    [ "formats", "structvss_1_1data__access_1_1_lidar_metadata.xhtml#af9e966b36073e1f8409e60599ec5c6b3", null ],
    [ "resolution", "structvss_1_1data__access_1_1_lidar_metadata.xhtml#a0b83adf75865305ce39ac56c74d94886", null ]
];