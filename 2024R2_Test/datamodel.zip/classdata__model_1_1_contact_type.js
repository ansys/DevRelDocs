var classdata__model_1_1_contact_type =
[
    [ "ContactType", "classdata__model_1_1_contact_type.xhtml#a649d693870c6e4ea50c4c3849cb0e4f8", null ]
];