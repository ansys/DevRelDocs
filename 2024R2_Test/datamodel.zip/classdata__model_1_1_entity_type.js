var classdata__model_1_1_entity_type =
[
    [ "EntityType", "classdata__model_1_1_entity_type.xhtml#a8081efa7982097a3b0625b7b93a2adc9", null ]
];