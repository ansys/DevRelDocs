var classdata__model_1_1_accessor_user_settings =
[
    [ "DataModelConnection", "classdata__model_1_1_accessor_user_settings.xhtml#a564dff409d0d104b4782b391271fe62e", null ]
];