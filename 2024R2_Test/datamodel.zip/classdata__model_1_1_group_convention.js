var classdata__model_1_1_group_convention =
[
    [ "GroupConvention", "classdata__model_1_1_group_convention.xhtml#ad2d030204f141fb68c4a8db432dc6c4f", null ]
];