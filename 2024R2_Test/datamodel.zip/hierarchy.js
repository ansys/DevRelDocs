var hierarchy =
[
    [ "data_model::AccessBase< DataModelHandleT, ObjectT >", "classdata__model_1_1_access_base.xhtml", [
      [ "data_model::TopologyAccessBase< StreamT >", "classdata__model_1_1_topology_access_base.xhtml", [
        [ "data_model::TopologyAccessBaseT< CustomClassT, StreamT >", "classdata__model_1_1_topology_access_base_t.xhtml", null ]
      ] ]
    ] ],
    [ "data_model::AccessBase< DataModelHandleT, BoundaryConditions >", "classdata__model_1_1_access_base.xhtml", [
      [ "data_model::BoundaryConditionsAccessBase< DataModelHandleT >", "classdata__model_1_1_boundary_conditions_access_base.xhtml", null ]
    ] ],
    [ "data_model::AccessBase< DataModelHandleT, MeshAssembly >", "classdata__model_1_1_access_base.xhtml", [
      [ "data_model::MeshAssemblyAccessBase< DataModelHandleT >", "classdata__model_1_1_mesh_assembly_access_base.xhtml", [
        [ "data_model::MeshAssemblyAccessBaseT< CustomClassT, DataModelHandleT >", "classdata__model_1_1_mesh_assembly_access_base_t.xhtml", null ]
      ] ]
    ] ],
    [ "data_model::AccessBase< DataModelHandleT, MeshPart >", "classdata__model_1_1_access_base.xhtml", [
      [ "data_model::MeshPartAccessBase< DataModelHandleT >", "classdata__model_1_1_mesh_part_access_base.xhtml", [
        [ "data_model::MeshPartAccessBaseT< CustomClassT, DataModelHandleT >", "classdata__model_1_1_mesh_part_access_base_t.xhtml", null ]
      ] ]
    ] ],
    [ "data_model::AccessBase< DataModelHandleT, MeshRegion >", "classdata__model_1_1_access_base.xhtml", [
      [ "data_model::MeshRegionAccessBase< DataModelHandleT >", "classdata__model_1_1_mesh_region_access_base.xhtml", [
        [ "data_model::MeshRegionAccessT< CustomClassT, DataModelHandleT >", "classdata__model_1_1_mesh_region_access_t.xhtml", null ]
      ] ]
    ] ],
    [ "data_model::AccessBase< DataModelHandleT, NamedReference >", "classdata__model_1_1_access_base.xhtml", [
      [ "data_model::NamedReferenceAccessBase< DataModelHandleT >", "classdata__model_1_1_named_reference_access_base.xhtml", [
        [ "data_model::NamedReferenceAccessBaseT< CustomClassT, DataModelHandleT >", "classdata__model_1_1_named_reference_access_base_t.xhtml", null ]
      ] ]
    ] ],
    [ "data_model::AccessBase< DataModelHandleT, SimulationSpace >", "classdata__model_1_1_access_base.xhtml", [
      [ "data_model::SimulationSpaceAccessBase< DataModelHandleT >", "classdata__model_1_1_simulation_space_access_base.xhtml", null ]
    ] ],
    [ "data_model::AccessBase< DataModelHandleT, Topology >", "classdata__model_1_1_access_base.xhtml", [
      [ "data_model::TopologyAccessBase< DataModelHandleT >", "classdata__model_1_1_topology_access_base.xhtml", null ]
    ] ],
    [ "data_model::AccessBase< StreamT, Topology >", "classdata__model_1_1_access_base.xhtml", null ],
    [ "data_model::AccessConfig", "classdata__model_1_1_access_config.xhtml", [
      [ "data_model::MeshPartAccessConfig", "classdata__model_1_1_mesh_part_access_config.xhtml", null ],
      [ "data_model::MeshRegionAccessConfig", "classdata__model_1_1_mesh_region_access_config.xhtml", null ],
      [ "data_model::TopologyAccessConfig", "classdata__model_1_1_topology_access_config.xhtml", null ]
    ] ],
    [ "data_model::AccessDefinition", "classdata__model_1_1_access_definition.xhtml", null ],
    [ "data_model::AccessorSettings", "classdata__model_1_1_accessor_settings.xhtml", null ],
    [ "datamodel.accessor_settings.AccessorSettings", "classdatamodel_1_1accessor__settings_1_1_accessor_settings.xhtml", null ],
    [ "data_model::AccessorSettingsSpec", "classdata__model_1_1_accessor_settings_spec.xhtml", null ],
    [ "data_model::AccessorUserSetting", "classdata__model_1_1_accessor_user_setting.xhtml", null ],
    [ "datamodel.accessor_settings.AccessorUserSetting", "classdatamodel_1_1accessor__settings_1_1_accessor_user_setting.xhtml", null ],
    [ "data_model::AccessorUserSettings", "classdata__model_1_1_accessor_user_settings.xhtml", null ],
    [ "datamodel.accessor_settings.AccessorUserSettings", "classdatamodel_1_1accessor__settings_1_1_accessor_user_settings.xhtml", null ],
    [ "data_model::AccessorUserSettingSpec", "classdata__model_1_1_accessor_user_setting_spec.xhtml", null ],
    [ "data_model::AccessorUserSettingsSpec", "classdata__model_1_1_accessor_user_settings_spec.xhtml", null ],
    [ "data_model::internal::ReflectionData::Actions", "structdata__model_1_1internal_1_1_reflection_data_1_1_actions.xhtml", null ],
    [ "data_model::AttributeRecorderT< CustomClassT >", "classdata__model_1_1_attribute_recorder_t.xhtml", null ],
    [ "data_model::bc_types", "structdata__model_1_1bc__types.xhtml", null ],
    [ "data_model::BCData", "classdata__model_1_1_b_c_data.xhtml", [
      [ "data_model::BCTable", "classdata__model_1_1_b_c_table.xhtml", null ]
    ] ],
    [ "data_model::BCReferences", "classdata__model_1_1_b_c_references.xhtml", null ],
    [ "data_model::beam_types", "structdata__model_1_1beam__types.xhtml", null ],
    [ "data_model::BoundaryCondition", "classdata__model_1_1_boundary_condition.xhtml", null ],
    [ "datamodel.boundary_conditions.BoundaryCondition", "classdatamodel_1_1boundary__conditions_1_1_boundary_condition.xhtml", null ],
    [ "datamodel.boundary_conditions.BoundaryConditions", "classdatamodel_1_1boundary__conditions_1_1_boundary_conditions.xhtml", null ],
    [ "data_model::BoundaryConditionsOperators< BCAccessT >", "structdata__model_1_1_boundary_conditions_operators.xhtml", null ],
    [ "data_model::common", "structdata__model_1_1common.xhtml", null ],
    [ "data_model::connection_types", "structdata__model_1_1connection__types.xhtml", null ],
    [ "data_model::construct_trait< DataT, IsGDC >", "structdata__model_1_1construct__trait.xhtml", null ],
    [ "data_model::construct_trait< DataT, std::false_type >", "structdata__model_1_1construct__trait_3_01_data_t_00_01std_1_1false__type_01_4.xhtml", null ],
    [ "data_model::construct_trait< DataT, std::true_type >", "structdata__model_1_1construct__trait_3_01_data_t_00_01std_1_1true__type_01_4.xhtml", null ],
    [ "data_model::internal::traits::constructor_iterators_helper< ArgsT >", "structdata__model_1_1internal_1_1traits_1_1constructor__iterators__helper.xhtml", null ],
    [ "data_model::internal::traits::constructor_iterators_helper< FirstDataT >", "structdata__model_1_1internal_1_1traits_1_1constructor__iterators__helper_3_01_first_data_t_01_4.xhtml", null ],
    [ "data_model::internal::traits::constructor_iterators_helper< FirstDataT, ArgsT... >", "structdata__model_1_1internal_1_1traits_1_1constructor__iterators__helper_3_01_first_data_t_00_01_args_t_8_8_8_01_4.xhtml", null ],
    [ "data_model::contact_types", "structdata__model_1_1contact__types.xhtml", null ],
    [ "data_model::ContextPath", "classdata__model_1_1_context_path.xhtml", null ],
    [ "ansys::dpf::CustomContainerBase", null, [
      [ "data_model::BoundaryConditions", "classdata__model_1_1_boundary_conditions.xhtml", null ],
      [ "data_model::ElementsProperties", "classdata__model_1_1_elements_properties.xhtml", null ],
      [ "data_model::Group", "classdata__model_1_1_group.xhtml", null ],
      [ "data_model::MeshEntity", "classdata__model_1_1_mesh_entity.xhtml", [
        [ "data_model::MeshAssembly", "classdata__model_1_1_mesh_assembly.xhtml", null ],
        [ "data_model::MeshPart", "classdata__model_1_1_mesh_part.xhtml", null ],
        [ "data_model::MeshRegion", "classdata__model_1_1_mesh_region.xhtml", null ]
      ] ],
      [ "data_model::MetadataBase", "classdata__model_1_1_metadata_base.xhtml", [
        [ "data_model::MeshRegionMetadata", "classdata__model_1_1_mesh_region_metadata.xhtml", null ]
      ] ],
      [ "data_model::NamedReference", "classdata__model_1_1_named_reference.xhtml", null ],
      [ "data_model::ObjectTypeInfo", "classdata__model_1_1_object_type_info.xhtml", null ],
      [ "data_model::ObjectsManager", "classdata__model_1_1_objects_manager.xhtml", null ],
      [ "data_model::Reference", "classdata__model_1_1_reference.xhtml", null ],
      [ "data_model::ReferenceOperationTypes::ReferenceOperationSpecification", "classdata__model_1_1_reference_operation_types_1_1_reference_operation_specification.xhtml", null ],
      [ "data_model::ReferenceOperationsManager", "classdata__model_1_1_reference_operations_manager.xhtml", null ],
      [ "data_model::SimulationSpace", "classdata__model_1_1_simulation_space.xhtml", null ],
      [ "data_model::SolverElementDefinitions", "classdata__model_1_1_solver_element_definitions.xhtml", null ],
      [ "data_model::TopoEntities", "classdata__model_1_1_topo_entities.xhtml", null ],
      [ "data_model::TopoEntity", "classdata__model_1_1_topo_entity.xhtml", null ],
      [ "data_model::Topology", "classdata__model_1_1_topology.xhtml", null ]
    ] ],
    [ "data_model::internal::data_model_types_actions", "structdata__model_1_1internal_1_1data__model__types__actions.xhtml", null ],
    [ "data_model::DataModelConnection", "classdata__model_1_1_data_model_connection.xhtml", null ],
    [ "datamodel.data_model_connection.DataModelConnection", "classdatamodel_1_1data__model__connection_1_1_data_model_connection.xhtml", null ],
    [ "data_model::DataModelHandleInputData", "classdata__model_1_1_data_model_handle_input_data.xhtml", null ],
    [ "data_model::DataModelHandleOperators< DataModelHandleT >", "structdata__model_1_1_data_model_handle_operators.xhtml", null ],
    [ "data_model::internal::dpf_object_client_construct< InternalDataT >", "structdata__model_1_1internal_1_1dpf__object__client__construct.xhtml", null ],
    [ "data_model::internal::dpf_object_client_construct< ansys::dpf::Collection< DataT > >", "structdata__model_1_1internal_1_1dpf__object__client__construct_3_01ansys_1_1dpf_1_1_collection_3_01_data_t_01_4_01_4.xhtml", null ],
    [ "data_model::internal::dpf_object_client_construct< DoubleField >", "structdata__model_1_1internal_1_1dpf__object__client__construct_3_01_double_field_01_4.xhtml", null ],
    [ "data_model::internal::dpf_object_construct< DataT >", "structdata__model_1_1internal_1_1dpf__object__construct.xhtml", null ],
    [ "data_model::internal::dpf_object_empty_construct< InternalDataT, IsGDC >", "structdata__model_1_1internal_1_1dpf__object__empty__construct.xhtml", null ],
    [ "data_model::internal::dpf_object_empty_construct< ansys::dpf::Collection< DataT > >", "structdata__model_1_1internal_1_1dpf__object__empty__construct_3_01ansys_1_1dpf_1_1_collection_3_01_data_t_01_4_01_4.xhtml", null ],
    [ "data_model::internal::dpf_object_empty_construct< ansys::dpf::Operator >", "structdata__model_1_1internal_1_1dpf__object__empty__construct_3_01ansys_1_1dpf_1_1_operator_01_4.xhtml", null ],
    [ "data_model::internal::dpf_object_empty_construct< DoubleField >", "structdata__model_1_1internal_1_1dpf__object__empty__construct_3_01_double_field_01_4.xhtml", null ],
    [ "data_model::internal::dpf_object_empty_construct< Int32Field >", "structdata__model_1_1internal_1_1dpf__object__empty__construct_3_01_int32_field_01_4.xhtml", null ],
    [ "data_model::internal::dpf_object_empty_construct< InternalDataT, std::true_type >", "structdata__model_1_1internal_1_1dpf__object__empty__construct_3_01_internal_data_t_00_01std_1_1true__type_01_4.xhtml", null ],
    [ "ansys::dpf::DpfException", null, [
      [ "data_model::DeprecationException", "classdata__model_1_1_deprecation_exception.xhtml", null ],
      [ "data_model::RuntimeError", "classdata__model_1_1_runtime_error.xhtml", null ],
      [ "data_model::TypeException", "classdata__model_1_1_type_exception.xhtml", null ],
      [ "data_model::UnimplementedException", "classdata__model_1_1_unimplemented_exception.xhtml", null ],
      [ "data_model::VoidEntityException", "classdata__model_1_1_void_entity_exception.xhtml", null ]
    ] ],
    [ "data_model::internal::Element", "structdata__model_1_1internal_1_1_element.xhtml", null ],
    [ "data_model::ElementProperties", "classdata__model_1_1_element_properties.xhtml", null ],
    [ "datamodel.elements_properties.ElementsProperties", "classdatamodel_1_1elements__properties_1_1_elements_properties.xhtml", null ],
    [ "data_model::ElementsPropertiesAccessBase< DataModelHandleT >", "classdata__model_1_1_elements_properties_access_base.xhtml", null ],
    [ "data_model::ElementsPropertiesOperators< ElementsPropertiesAccessT >", "structdata__model_1_1_elements_properties_operators.xhtml", null ],
    [ "data_model::EntitiesCopier", "classdata__model_1_1_entities_copier.xhtml", null ],
    [ "data_model::internal::entity_type_reflect< DataT >", "structdata__model_1_1internal_1_1entity__type__reflect.xhtml", null ],
    [ "data_model::entity_types", "structdata__model_1_1entity__types.xhtml", null ],
    [ "data_model::internal::entity_types", "structdata__model_1_1internal_1_1entity__types.xhtml", null ],
    [ "datamodel.entity_generator.EntityProperty", "classdatamodel_1_1entity__generator_1_1_entity_property.xhtml", null ],
    [ "data_model::ReferenceEntries::EntryIndex", "structdata__model_1_1_reference_entries_1_1_entry_index.xhtml", null ],
    [ "ansys::dpf::ExternalStream", null, [
      [ "data_model::DataModelHandleBase< DataModelHandleT >", "classdata__model_1_1_data_model_handle_base.xhtml", null ]
    ] ],
    [ "data_model::internal::FieldAccessHelper< FieldT, DataT >", "classdata__model_1_1internal_1_1_field_access_helper.xhtml", null ],
    [ "data_model::internal::FieldsAccessHelper", "classdata__model_1_1internal_1_1_fields_access_helper.xhtml", null ],
    [ "data_model::formulations", "structdata__model_1_1formulations.xhtml", null ],
    [ "data_model::internal::getCreateFromIfPossible< DataT, hasCreateFrom >", "structdata__model_1_1internal_1_1get_create_from_if_possible.xhtml", null ],
    [ "data_model::internal::getCreateFromIfPossible< DataT, std::true_type >", "structdata__model_1_1internal_1_1get_create_from_if_possible_3_01_data_t_00_01std_1_1true__type_01_4.xhtml", null ],
    [ "datamodel.group.Group", "classdatamodel_1_1group_1_1_group.xhtml", null ],
    [ "data_model::group_conventions", "structdata__model_1_1group__conventions.xhtml", null ],
    [ "data_model::GroupGenerator", "classdata__model_1_1_group_generator.xhtml", null ],
    [ "data_model::internal::grouping_entity_types", "structdata__model_1_1internal_1_1grouping__entity__types.xhtml", null ],
    [ "data_model::GroupIterator", "classdata__model_1_1_group_iterator.xhtml", null ],
    [ "datamodel.group.GroupIterator", "classdatamodel_1_1group_1_1_group_iterator.xhtml", null ],
    [ "data_model::internal::traits::hasCreateFrom< DataT >", "structdata__model_1_1internal_1_1traits_1_1has_create_from.xhtml", null ],
    [ "std::hash< data_model::EntityType >", "structstd_1_1hash_3_01data__model_1_1_entity_type_01_4.xhtml", null ],
    [ "std::hash< data_model::UUID >", "structstd_1_1hash_3_01data__model_1_1_u_u_i_d_01_4.xhtml", null ],
    [ "data_model::internal::IdGenerator", "classdata__model_1_1internal_1_1_id_generator.xhtml", [
      [ "data_model::internal::ElementsPropertiesRepository", "classdata__model_1_1internal_1_1_elements_properties_repository.xhtml", null ]
    ] ],
    [ "data_model::integration_types", "structdata__model_1_1integration__types.xhtml", null ],
    [ "data_model::interpolation_methods", "classdata__model_1_1interpolation__methods.xhtml", null ],
    [ "data_model::IReferenceOperation", "classdata__model_1_1_i_reference_operation.xhtml", [
      [ "data_model::ReferenceOperationContainer", "classdata__model_1_1_reference_operation_container.xhtml", null ],
      [ "data_model::ReferenceOperationItem", "classdata__model_1_1_reference_operation_item.xhtml", null ]
    ] ],
    [ "datamodel.group.GroupIterator.Item", "classdatamodel_1_1group_1_1_group_iterator_1_1_item.xhtml", null ],
    [ "datamodel.reference_iterator.ReferenceIterator.Item", "classdatamodel_1_1reference__iterator_1_1_reference_iterator_1_1_item.xhtml", null ],
    [ "data_model::GroupIterator::ItemBase", "classdata__model_1_1_group_iterator_1_1_item_base.xhtml", [
      [ "data_model::GroupIterator::Item", "classdata__model_1_1_group_iterator_1_1_item.xhtml", null ],
      [ "data_model::GroupIterator::TypedItem< DataT >", "classdata__model_1_1_group_iterator_1_1_typed_item.xhtml", null ]
    ] ],
    [ "data_model::internal::traits::iterators_get_helper< ArgsT >", "structdata__model_1_1internal_1_1traits_1_1iterators__get__helper.xhtml", null ],
    [ "data_model::internal::traits::iterators_get_helper< FirstDataT >", "structdata__model_1_1internal_1_1traits_1_1iterators__get__helper_3_01_first_data_t_01_4.xhtml", null ],
    [ "data_model::internal::traits::iterators_get_helper< FirstDataT, ArgsT... >", "structdata__model_1_1internal_1_1traits_1_1iterators__get__helper_3_01_first_data_t_00_01_args_t_8_8_8_01_4.xhtml", null ],
    [ "data_model::internal::traits::iterators_push_back_helper< ArgsT >", "structdata__model_1_1internal_1_1traits_1_1iterators__push__back__helper.xhtml", null ],
    [ "data_model::internal::traits::iterators_push_back_helper< FirstDataT, indexTy >", "structdata__model_1_1internal_1_1traits_1_1iterators__push__back__helper_3_01_first_data_t_00_01index_ty_01_4.xhtml", null ],
    [ "data_model::internal::traits::iterators_push_back_helper< FirstDataT, indexTy, ArgsT... >", "structdata__model_1_1internal_1_1traits_1_1iterators__push__back__helper_3_01_first_data_t_00_017e1a60fe9546ffe82a96db99f73ae95d.xhtml", null ],
    [ "data_model::GroupIterator::iteratorT< ItemT >", "structdata__model_1_1_group_iterator_1_1iterator_t.xhtml", null ],
    [ "data_model::joint_types", "structdata__model_1_1joint__types.xhtml", null ],
    [ "data_model::load_bc_types", "structdata__model_1_1load__bc__types.xhtml", null ],
    [ "data_model::MeshAssemblyOperators< MeshAssemblyAccessT >", "structdata__model_1_1_mesh_assembly_operators.xhtml", null ],
    [ "data_model::MeshEntityGenerator", "classdata__model_1_1_mesh_entity_generator.xhtml", [
      [ "data_model::MeshAssemblyGenerator", "classdata__model_1_1_mesh_assembly_generator.xhtml", null ],
      [ "data_model::MeshPartGenerator", "classdata__model_1_1_mesh_part_generator.xhtml", null ],
      [ "data_model::MeshRegionGenerator", "classdata__model_1_1_mesh_region_generator.xhtml", null ]
    ] ],
    [ "data_model::MeshInfo", "classdata__model_1_1_mesh_info.xhtml", null ],
    [ "data_model::MeshOperators< MeshRegionAccessT >", "structdata__model_1_1_mesh_operators.xhtml", null ],
    [ "data_model::MeshPartOperators< MeshPartAccessT >", "structdata__model_1_1_mesh_part_operators.xhtml", null ],
    [ "datamodel.mesh_region_metadata.MeshRegionMetadata", "classdatamodel_1_1mesh__region__metadata_1_1_mesh_region_metadata.xhtml", null ],
    [ "data_model::MetadataBaseGenerator", "classdata__model_1_1_metadata_base_generator.xhtml", [
      [ "data_model::MeshRegionMetadataGenerator", "classdata__model_1_1_mesh_region_metadata_generator.xhtml", null ]
    ] ],
    [ "data_model::MultiLevelContext", "structdata__model_1_1_multi_level_context.xhtml", null ],
    [ "data_model::internal::MultiLevelContextEntriesData", "structdata__model_1_1internal_1_1_multi_level_context_entries_data.xhtml", null ],
    [ "datamodel.named_reference.NamedReference", "classdatamodel_1_1named__reference_1_1_named_reference.xhtml", null ],
    [ "data_model::NamedReferenceGenerator", "classdata__model_1_1_named_reference_generator.xhtml", null ],
    [ "data_model::NamedReferenceOperators< NamedReferenceAccessT >", "structdata__model_1_1_named_reference_operators.xhtml", null ],
    [ "data_model::AccessDefinition::NamespaceKey", "structdata__model_1_1_access_definition_1_1_namespace_key.xhtml", null ],
    [ "data_model::internal::Node", "structdata__model_1_1internal_1_1_node.xhtml", null ],
    [ "object", null, [
      [ "datamodel.reference.ReferenceEntries", "classdatamodel_1_1reference_1_1_reference_entries.xhtml", [
        [ "datamodel.reference.MultiLevelContextEntries", "classdatamodel_1_1reference_1_1_multi_level_context_entries.xhtml", null ],
        [ "datamodel.reference.SingleEntry", "classdatamodel_1_1reference_1_1_single_entry.xhtml", null ],
        [ "datamodel.reference.SingleLevelContextEntries", "classdatamodel_1_1reference_1_1_single_level_context_entries.xhtml", null ],
        [ "datamodel.reference.VoidEntries", "classdatamodel_1_1reference_1_1_void_entries.xhtml", null ]
      ] ],
      [ "datamodel.reference.ReferenceEntriesIterator", "classdatamodel_1_1reference_1_1_reference_entries_iterator.xhtml", null ],
      [ "datamodel.reference.ReferenceEntry", "classdatamodel_1_1reference_1_1_reference_entry.xhtml", null ]
    ] ],
    [ "data_model::internal::object_construct_trait< DataT, hasRef >", "structdata__model_1_1internal_1_1object__construct__trait.xhtml", null ],
    [ "data_model::internal::object_construct_trait< DataT, std::false_type >", "structdata__model_1_1internal_1_1object__construct__trait_3_01_data_t_00_01std_1_1false__type_01_4.xhtml", null ],
    [ "data_model::internal::object_construct_trait< DataT, std::true_type >", "structdata__model_1_1internal_1_1object__construct__trait_3_01_data_t_00_01std_1_1true__type_01_4.xhtml", null ],
    [ "datamodel.object_type_info.ObjectTypeInfo", "classdatamodel_1_1object__type__info_1_1_object_type_info.xhtml", null ],
    [ "data_model::ObjectTypeInfoGenerator", "classdata__model_1_1_object_type_info_generator.xhtml", null ],
    [ "data_model::other_bc_types", "structdata__model_1_1other__bc__types.xhtml", null ],
    [ "data_model::physics_type", "structdata__model_1_1physics__type.xhtml", null ],
    [ "data_model::PhysicsTypes", "classdata__model_1_1_physics_types.xhtml", null ],
    [ "datamodel.internal.Properties", "classdatamodel_1_1internal_1_1_properties.xhtml", null ],
    [ "datamodel.reference.Reference", "classdatamodel_1_1reference_1_1_reference.xhtml", null ],
    [ "data_model::ReferenceEntries", "classdata__model_1_1_reference_entries.xhtml", [
      [ "data_model::internal::MultiLevelContextEntries", "classdata__model_1_1internal_1_1_multi_level_context_entries.xhtml", null ],
      [ "data_model::internal::SingleEntry", "classdata__model_1_1internal_1_1_single_entry.xhtml", null ],
      [ "data_model::internal::SingleLevelContextEntries", "classdata__model_1_1internal_1_1_single_level_context_entries.xhtml", null ],
      [ "data_model::internal::VoidEntries", "classdata__model_1_1internal_1_1_void_entries.xhtml", null ]
    ] ],
    [ "data_model::ReferenceEntriesIterator", "classdata__model_1_1_reference_entries_iterator.xhtml", null ],
    [ "data_model::ReferenceEntry", "classdata__model_1_1_reference_entry.xhtml", null ],
    [ "data_model::ReferenceGeneratorBase< T >", "classdata__model_1_1_reference_generator_base.xhtml", null ],
    [ "data_model::ReferenceGeneratorBase< ContextualReferenceGenerator< ContextT > >", "classdata__model_1_1_reference_generator_base.xhtml", [
      [ "data_model::ContextualReferenceGenerator< ContextT >", "classdata__model_1_1_contextual_reference_generator.xhtml", null ]
    ] ],
    [ "data_model::ReferenceGeneratorBase< IdReferenceGenerator >", "classdata__model_1_1_reference_generator_base.xhtml", [
      [ "data_model::IdReferenceGenerator", "classdata__model_1_1_id_reference_generator.xhtml", null ]
    ] ],
    [ "data_model::ReferenceGeneratorBase< SimpleReferenceGenerator >", "classdata__model_1_1_reference_generator_base.xhtml", [
      [ "data_model::SimpleReferenceGenerator", "classdata__model_1_1_simple_reference_generator.xhtml", null ]
    ] ],
    [ "datamodel.reference_iterator.ReferenceIterator", "classdatamodel_1_1reference__iterator_1_1_reference_iterator.xhtml", null ],
    [ "data_model::ReferenceOperationGenerator", "classdata__model_1_1_reference_operation_generator.xhtml", null ],
    [ "data_model::ReferenceOperationTypes", "classdata__model_1_1_reference_operation_types.xhtml", null ],
    [ "data_model::ReferenceRelationTypes", "classdata__model_1_1_reference_relation_types.xhtml", null ],
    [ "datamodel.transfer_helpers.ReferenceTranslator", "classdatamodel_1_1transfer__helpers_1_1_reference_translator.xhtml", null ],
    [ "data_model::ReferenceUUID", "structdata__model_1_1_reference_u_u_i_d.xhtml", null ],
    [ "ansys::dpf::reflect< data_model::MeshAssembly >", "structansys_1_1dpf_1_1reflect_3_01data__model_1_1_mesh_assembly_01_4.xhtml", null ],
    [ "ansys::dpf::reflect< data_model::MeshPart >", "structansys_1_1dpf_1_1reflect_3_01data__model_1_1_mesh_part_01_4.xhtml", null ],
    [ "ansys::dpf::reflect< data_model::Topology >", "structansys_1_1dpf_1_1reflect_3_01data__model_1_1_topology_01_4.xhtml", null ],
    [ "data_model::internal::Reflection", "structdata__model_1_1internal_1_1_reflection.xhtml", null ],
    [ "data_model::internal::ReflectionData", "structdata__model_1_1internal_1_1_reflection_data.xhtml", null ],
    [ "data_model::internal::ReflectionRecorder< DataT >", "structdata__model_1_1internal_1_1_reflection_recorder.xhtml", null ],
    [ "datamodel.simulation_space.SimulationSpace", "classdatamodel_1_1simulation__space_1_1_simulation_space.xhtml", null ],
    [ "data_model::SimulationSpaceOperators< SimulationSpaceAccessT >", "structdata__model_1_1_simulation_space_operators.xhtml", null ],
    [ "data_model::SingleLevelContext", "structdata__model_1_1_single_level_context.xhtml", null ],
    [ "data_model::internal::SingleLevelContextEntriesData", "structdata__model_1_1internal_1_1_single_level_context_entries_data.xhtml", null ],
    [ "data_model::SolverElementDefinition", "classdata__model_1_1_solver_element_definition.xhtml", null ],
    [ "data_model::spring_types", "structdata__model_1_1spring__types.xhtml", null ],
    [ "str", null, [
      [ "datamodel.entity_types.EntityType", "classdatamodel_1_1entity__types_1_1_entity_type.xhtml", null ],
      [ "datamodel.topo_types.TopoType", "classdatamodel_1_1topo__types_1_1_topo_type.xhtml", null ]
    ] ],
    [ "data_model::StringWrapper", "classdata__model_1_1_string_wrapper.xhtml", [
      [ "data_model::BCType", "classdata__model_1_1_b_c_type.xhtml", null ],
      [ "data_model::BeamType", "classdata__model_1_1_beam_type.xhtml", null ],
      [ "data_model::ConnectionType", "classdata__model_1_1_connection_type.xhtml", null ],
      [ "data_model::ContactType", "classdata__model_1_1_contact_type.xhtml", null ],
      [ "data_model::EntityType", "classdata__model_1_1_entity_type.xhtml", null ],
      [ "data_model::Formulation", "classdata__model_1_1_formulation.xhtml", null ],
      [ "data_model::GroupConvention", "classdata__model_1_1_group_convention.xhtml", null ],
      [ "data_model::IntegrationType", "classdata__model_1_1_integration_type.xhtml", null ],
      [ "data_model::InterpolationMethod", "classdata__model_1_1_interpolation_method.xhtml", null ],
      [ "data_model::JointType", "classdata__model_1_1_joint_type.xhtml", null ],
      [ "data_model::LoadBCType", "classdata__model_1_1_load_b_c_type.xhtml", null ],
      [ "data_model::OtherBCType", "classdata__model_1_1_other_b_c_type.xhtml", null ],
      [ "data_model::PhysicsType", "classdata__model_1_1_physics_type.xhtml", null ],
      [ "data_model::SpringType", "classdata__model_1_1_spring_type.xhtml", null ],
      [ "data_model::TopoType", "classdata__model_1_1_topo_type.xhtml", null ]
    ] ],
    [ "data_model::internal::traits::hasCreateFrom< DataT >::TestStructure< U, >", "structdata__model_1_1internal_1_1traits_1_1has_create_from_1_1_test_structure.xhtml", null ],
    [ "data_model::topo_types", "structdata__model_1_1topo__types.xhtml", null ],
    [ "datamodel.topology.TopoEntities", "classdatamodel_1_1topology_1_1_topo_entities.xhtml", null ],
    [ "data_model::TopoEntitiesGenerator", "classdata__model_1_1_topo_entities_generator.xhtml", null ],
    [ "datamodel.topology.TopoEntity", "classdatamodel_1_1topology_1_1_topo_entity.xhtml", null ],
    [ "data_model::TopoEntityGenerator", "classdata__model_1_1_topo_entity_generator.xhtml", null ],
    [ "datamodel.topology.Topology", "classdatamodel_1_1topology_1_1_topology.xhtml", null ],
    [ "data_model::TopologyGenerator", "classdata__model_1_1_topology_generator.xhtml", null ],
    [ "data_model::TopologyOperators< TopologyAccessT >", "structdata__model_1_1_topology_operators.xhtml", null ],
    [ "data_model::Translator< DataT >", "classdata__model_1_1_translator.xhtml", null ],
    [ "data_model::types", "structdata__model_1_1types.xhtml", null ],
    [ "data_model::UUID", "structdata__model_1_1_u_u_i_d.xhtml", null ],
    [ "ABC", null, [
      [ "datamodel.entity_generator.EntityGenerator", "classdatamodel_1_1entity__generator_1_1_entity_generator.xhtml", null ],
      [ "datamodel.mesh_entity.MeshEntity", "classdatamodel_1_1mesh__entity_1_1_mesh_entity.xhtml", null ]
    ] ],
    [ "ConanFile", null, [
      [ "conanfile.AnsysDataModelAccessorExampleConan", "classconanfile_1_1_ansys_data_model_accessor_example_conan.xhtml", null ]
    ] ],
    [ "EntityGenerator", null, [
      [ "datamodel.group.GroupGenerator", "classdatamodel_1_1group_1_1_group_generator.xhtml", null ],
      [ "datamodel.mesh_assembly.MeshAssemblyGenerator", "classdatamodel_1_1mesh__assembly_1_1_mesh_assembly_generator.xhtml", null ],
      [ "datamodel.mesh_part.MeshPartGenerator", "classdatamodel_1_1mesh__part_1_1_mesh_part_generator.xhtml", null ],
      [ "datamodel.mesh_region.MeshRegionGenerator", "classdatamodel_1_1mesh__region_1_1_mesh_region_generator.xhtml", null ],
      [ "datamodel.named_reference.NamedReferenceGenerator", "classdatamodel_1_1named__reference_1_1_named_reference_generator.xhtml", null ],
      [ "datamodel.object_type_info.ObjectTypeInfoGenerator", "classdatamodel_1_1object__type__info_1_1_object_type_info_generator.xhtml", null ],
      [ "datamodel.topology.TopologyGenerator", "classdatamodel_1_1topology_1_1_topology_generator.xhtml", null ]
    ] ],
    [ "Enum", null, [
      [ "datamodel.mesh_region_metadata.MeshRegionDimension", "classdatamodel_1_1mesh__region__metadata_1_1_mesh_region_dimension.xhtml", null ],
      [ "datamodel.reference.ReferenceEntriesType", "classdatamodel_1_1reference_1_1_reference_entries_type.xhtml", null ]
    ] ],
    [ "MeshEntity", null, [
      [ "datamodel.mesh_assembly.MeshAssembly", "classdatamodel_1_1mesh__assembly_1_1_mesh_assembly.xhtml", null ],
      [ "datamodel.mesh_part.MeshPart", "classdatamodel_1_1mesh__part_1_1_mesh_part.xhtml", null ],
      [ "datamodel.mesh_region.MeshRegion", "classdatamodel_1_1mesh__region_1_1_mesh_region.xhtml", null ]
    ] ],
    [ "UserDict", null, [
      [ "datamodel.entity_generator.EntityProperties", "classdatamodel_1_1entity__generator_1_1_entity_properties.xhtml", null ]
    ] ]
];