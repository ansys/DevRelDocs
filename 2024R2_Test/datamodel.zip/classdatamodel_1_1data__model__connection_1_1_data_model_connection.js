var classdatamodel_1_1data__model__connection_1_1_data_model_connection =
[
    [ "current_user_settings", "classdatamodel_1_1data__model__connection_1_1_data_model_connection.xhtml#a6bc52c1c9430ffd40467296766e11c73", null ],
    [ "current_user_settings", "classdatamodel_1_1data__model__connection_1_1_data_model_connection.xhtml#a7b8f5bbaeaadfdc3e6abf52788ca022f", null ]
];