var classdata__model_1_1_object_type_info =
[
    [ "addReference", "classdata__model_1_1_object_type_info.xhtml#a67e5da84a580098271e8dcc8aa8daeba", null ],
    [ "entityType", "classdata__model_1_1_object_type_info.xhtml#a9bc09a89d77c282f413d90bd53057a99", null ],
    [ "parentReference", "classdata__model_1_1_object_type_info.xhtml#a5827d9e014ea6f2ea41c6ed404edc925", null ],
    [ "referenceByAppId", "classdata__model_1_1_object_type_info.xhtml#aac3700f6d516ef58cc8830a8ab895cea", null ],
    [ "referenceForInternalId", "classdata__model_1_1_object_type_info.xhtml#aad4b9335edf83ada23953632fb1471fa", null ],
    [ "references", "classdata__model_1_1_object_type_info.xhtml#a0b36d9f4272938584d2a0ec0fb792dcf", null ],
    [ "referencesAsGroup", "classdata__model_1_1_object_type_info.xhtml#a0e97b2c7b40c6d22b96489c4565338c6", null ],
    [ "registerReference", "classdata__model_1_1_object_type_info.xhtml#a1175f9817b736488e618b1c1963e175b", null ]
];