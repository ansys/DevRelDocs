var classdata__model_1_1_beam_type =
[
    [ "BeamType", "classdata__model_1_1_beam_type.xhtml#afa8cd579f63a0f12a0efc6e28ed0afac", null ]
];