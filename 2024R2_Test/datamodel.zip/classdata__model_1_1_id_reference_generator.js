var classdata__model_1_1_id_reference_generator =
[
    [ "create", "classdata__model_1_1_id_reference_generator.xhtml#a4da4698bfdeff3ef1479dcfa10e36efb", null ],
    [ "create", "classdata__model_1_1_id_reference_generator.xhtml#ace9f20ecaf6468c1251a311d26c51fec", null ]
];