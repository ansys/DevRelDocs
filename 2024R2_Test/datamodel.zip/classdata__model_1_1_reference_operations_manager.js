var classdata__model_1_1_reference_operations_manager =
[
    [ "addOperation", "classdata__model_1_1_reference_operations_manager.xhtml#a7a0537929faad1d40c9190a5b7001cf5", null ],
    [ "getOperationById", "classdata__model_1_1_reference_operations_manager.xhtml#ad26ba7d27228e242a168ad7129245ab1", null ],
    [ "getOperationByIndex", "classdata__model_1_1_reference_operations_manager.xhtml#aa5926560f4a79911a4e426a4a9679f65", null ]
];