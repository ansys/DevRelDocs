var classdatamodel_1_1reference__iterator_1_1_reference_iterator =
[
    [ "Item", "classdatamodel_1_1reference__iterator_1_1_reference_iterator_1_1_item.xhtml", null ]
];