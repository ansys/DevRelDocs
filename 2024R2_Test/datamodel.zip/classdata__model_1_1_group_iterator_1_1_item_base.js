var classdata__model_1_1_group_iterator_1_1_item_base =
[
    [ "reference", "classdata__model_1_1_group_iterator_1_1_item_base.xhtml#ab0b774b477004a4e43e1f6412b0d18ac", null ]
];