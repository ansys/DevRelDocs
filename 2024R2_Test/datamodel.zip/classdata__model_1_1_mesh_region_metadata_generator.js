var classdata__model_1_1_mesh_region_metadata_generator =
[
    [ "withDimension", "classdata__model_1_1_mesh_region_metadata_generator.xhtml#ab06bf94c5fa76cf50d0c3b9c54521e64", null ],
    [ "withIsPhysicalRegion", "classdata__model_1_1_mesh_region_metadata_generator.xhtml#a567d83b79edfb8c5df7210a978502d86", null ],
    [ "withNumberOfElements", "classdata__model_1_1_mesh_region_metadata_generator.xhtml#acd88a549c401f9c5f1a4bb3ae0f71492", null ]
];