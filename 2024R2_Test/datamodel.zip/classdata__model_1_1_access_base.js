var classdata__model_1_1_access_base =
[
    [ "assertGetDataModelHandle", "classdata__model_1_1_access_base.xhtml#a28ad2ca462bd2839ae587b2afd44edff", null ],
    [ "assertGetStream", "classdata__model_1_1_access_base.xhtml#a5d6fb3fcaa3158d584081f1364817abe", null ],
    [ "getDataModelHandle", "classdata__model_1_1_access_base.xhtml#a727451e0dfcc9f6926d762e46c510d43", null ],
    [ "getOrCreateFromObjectsManager", "classdata__model_1_1_access_base.xhtml#a0032119bc83d8be5b644c8bdd6d8ce12", null ],
    [ "getOrCreateFromObjectsManager", "classdata__model_1_1_access_base.xhtml#af4c3686bb35c71c7370e9477b97f2664", null ],
    [ "getOrCreateFromObjectsManager", "classdata__model_1_1_access_base.xhtml#a61189bb15d25178c8dbd3286f2896ba1", null ],
    [ "getOrCreateFromObjectsManager", "classdata__model_1_1_access_base.xhtml#acab924f79313e7e3d43ef74f91d1e44b", null ],
    [ "getStream", "classdata__model_1_1_access_base.xhtml#addaae58140076435c6cc1c0959f506b1", null ],
    [ "getStreams", "classdata__model_1_1_access_base.xhtml#ad3ce7fcef538441db2b76b35a7a33dbc", null ],
    [ "isAccessSimulationSpaceDefinedInStreams", "classdata__model_1_1_access_base.xhtml#aff87e11571bfeac016ee44092ebdf756", null ],
    [ "referenceByAppId", "classdata__model_1_1_access_base.xhtml#ad6aa55811b2ad90748ba5e406533ed96", null ],
    [ "requestedEntityAppId", "classdata__model_1_1_access_base.xhtml#ad882f0c8a870bea072bbd6219e76754f", null ],
    [ "requestedObjectInternalId", "classdata__model_1_1_access_base.xhtml#ab32b7ef7c86a2ce2f7b22a7d05899019", null ],
    [ "requestedObjectReference", "classdata__model_1_1_access_base.xhtml#afa987a2e2e7f13d2ed36d9c33e10c994", null ],
    [ "simulationSpaceReference", "classdata__model_1_1_access_base.xhtml#a976991d778a9ed5b936ef801ee6e8dfc", null ]
];