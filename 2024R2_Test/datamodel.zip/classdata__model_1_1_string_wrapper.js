var classdata__model_1_1_string_wrapper =
[
    [ "StringWrapper", "classdata__model_1_1_string_wrapper.xhtml#a2a0eb010aae30e59996352bdede6e741", null ],
    [ "c_str", "classdata__model_1_1_string_wrapper.xhtml#a21c81078dbea2b55e50d74ff3c168da5", null ],
    [ "operator std::string", "classdata__model_1_1_string_wrapper.xhtml#ad93c12fbf3f23a786dc4f9f4fdbf1b15", null ]
];