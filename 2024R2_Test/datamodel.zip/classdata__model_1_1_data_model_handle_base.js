var classdata__model_1_1_data_model_handle_base =
[
    [ "DataModelHandleBase", "classdata__model_1_1_data_model_handle_base.xhtml#a494f91bf22634cefde9758c9f7f747bd", null ],
    [ "accessSimulationSpace", "classdata__model_1_1_data_model_handle_base.xhtml#a52757a5344a40a7b31581363681164f2", null ],
    [ "accessSimulationSpace", "classdata__model_1_1_data_model_handle_base.xhtml#ad38012034cbf35903c847e2895a209b4", null ],
    [ "fileName", "classdata__model_1_1_data_model_handle_base.xhtml#a3e14f87b032b3fbcdc046942647da0a9", null ],
    [ "isAccessSimulationSpaceDefined", "classdata__model_1_1_data_model_handle_base.xhtml#a74361ec659d11f485d5912f556541295", null ],
    [ "release", "classdata__model_1_1_data_model_handle_base.xhtml#a15bfcec1bcc9dc256aa8ca49c951aed3", null ],
    [ "setSimulationSpace", "classdata__model_1_1_data_model_handle_base.xhtml#a463e4b5264d3b6363a70bc609382a24a", null ],
    [ "streamTypeName", "classdata__model_1_1_data_model_handle_base.xhtml#ac4f6d21a27267622d28f55c2d6ada1f9", null ]
];