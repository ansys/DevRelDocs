var classdata__model_1_1_metadata_base =
[
    [ "attribute", "classdata__model_1_1_metadata_base.xhtml#a655024e58e2707f16de0f28b829fd6dd", null ],
    [ "attributes", "classdata__model_1_1_metadata_base.xhtml#ae289113f2d0cde637cbc9bc65dd5b5e5", null ]
];