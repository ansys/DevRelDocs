var classdata__model_1_1_reference_generator_base =
[
    [ "ReferenceGeneratorBase", "classdata__model_1_1_reference_generator_base.xhtml#aceaa73cd247ba36a6302fc6bc54f9d19", null ],
    [ "create", "classdata__model_1_1_reference_generator_base.xhtml#a1ae0595f8c1b048c36a20bb182372c0a", null ],
    [ "forAttributeCreation", "classdata__model_1_1_reference_generator_base.xhtml#a79e742c5942acfb8103cf3ef41462739", null ],
    [ "forEntityCreation", "classdata__model_1_1_reference_generator_base.xhtml#af8024666d9dcf2a9a19a2c8ea045e00d", null ],
    [ "forReferenceTranslation", "classdata__model_1_1_reference_generator_base.xhtml#ac1a795222902267026fdf9d203e2b101", null ],
    [ "type", "classdata__model_1_1_reference_generator_base.xhtml#a9e2f4f47f46e9c06a81965eb7207a90a", null ],
    [ "withAppId", "classdata__model_1_1_reference_generator_base.xhtml#a1fe6828eba29e91a5bb2b5e8791f0b30", null ],
    [ "withEntityChildCreationOperation", "classdata__model_1_1_reference_generator_base.xhtml#a764b88bf5c72f2b9a8d29402f80d6b4a", null ],
    [ "withInstancing", "classdata__model_1_1_reference_generator_base.xhtml#a883236ead655c038aa1ba5494c2d1282", null ],
    [ "withInternalId", "classdata__model_1_1_reference_generator_base.xhtml#a66057e5918a1ea9a11c6148235541d2d", null ],
    [ "withMetadata", "classdata__model_1_1_reference_generator_base.xhtml#a6ecccd239ddbee93f004393a5703ea9a", null ]
];