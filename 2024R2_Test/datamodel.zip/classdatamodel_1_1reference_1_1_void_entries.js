var classdatamodel_1_1reference_1_1_void_entries =
[
    [ "__getitem__", "classdatamodel_1_1reference_1_1_void_entries.xhtml#a317bb4d8505a6d9c55241ded920a29ef", null ],
    [ "context_path", "classdatamodel_1_1reference_1_1_void_entries.xhtml#aa184a04e91eb9e2b910af737f976ea4d", null ]
];