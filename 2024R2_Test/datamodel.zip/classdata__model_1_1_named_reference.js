var classdata__model_1_1_named_reference =
[
    [ "setData", "classdata__model_1_1_named_reference.xhtml#ac3a57d85612c053a0f18d33a3ce92d7d", null ],
    [ "setName", "classdata__model_1_1_named_reference.xhtml#a2d3fa1d2a7f2ac24068778e651a3c99f", null ],
    [ "setReference", "classdata__model_1_1_named_reference.xhtml#ac333038ed072a12a682d139278fe654e", null ]
];