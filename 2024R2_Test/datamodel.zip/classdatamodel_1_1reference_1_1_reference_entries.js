var classdatamodel_1_1reference_1_1_reference_entries =
[
    [ "__getitem__", "classdatamodel_1_1reference_1_1_reference_entries.xhtml#af449616848d830144aae9088c35c1ccd", null ],
    [ "context_path", "classdatamodel_1_1reference_1_1_reference_entries.xhtml#aa45be7264422ffc4db5094f5443003f7", null ]
];