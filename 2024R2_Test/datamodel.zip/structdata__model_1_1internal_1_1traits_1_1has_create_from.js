var structdata__model_1_1internal_1_1traits_1_1has_create_from =
[
    [ "TestStructure", "structdata__model_1_1internal_1_1traits_1_1has_create_from_1_1_test_structure.xhtml", null ]
];