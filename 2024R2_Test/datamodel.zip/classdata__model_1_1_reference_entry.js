var classdata__model_1_1_reference_entry =
[
    [ "contextIds", "classdata__model_1_1_reference_entry.xhtml#a4dcf1873c1813aaef695b906d5934cdc", null ],
    [ "entityIds", "classdata__model_1_1_reference_entry.xhtml#a51874c53181d6551e12e4d592f074046", null ],
    [ "ids", "classdata__model_1_1_reference_entry.xhtml#af8b6f624b4c9d68b7c025bbff2182191", null ],
    [ "isAll", "classdata__model_1_1_reference_entry.xhtml#abafebbe0553f3821b3d197d21956b7d8", null ],
    [ "size", "classdata__model_1_1_reference_entry.xhtml#a70ef31778ff12dbe048469cbec4a7020", null ]
];