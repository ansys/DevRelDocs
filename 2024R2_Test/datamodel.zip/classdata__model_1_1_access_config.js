var classdata__model_1_1_access_config =
[
    [ "AccessConfig", "classdata__model_1_1_access_config.xhtml#ab2f0d88eabeb923b1ca50a4f0976946f", null ],
    [ "connectConfigToOperator", "classdata__model_1_1_access_config.xhtml#a625a5b480341c434436db6ae72ff5b03", null ],
    [ "setAsLazy", "classdata__model_1_1_access_config.xhtml#a7da9a3c1a6aaa30f0f5756ed196319dc", null ]
];