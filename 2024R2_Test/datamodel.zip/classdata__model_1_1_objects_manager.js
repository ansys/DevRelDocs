var classdata__model_1_1_objects_manager =
[
    [ "add", "classdata__model_1_1_objects_manager.xhtml#a447ca04c7469faae6b0c9108fb7595d1", null ],
    [ "create", "classdata__model_1_1_objects_manager.xhtml#a6ea798a1ab51cc17a29c5974d5d3e6ee", null ],
    [ "create", "classdata__model_1_1_objects_manager.xhtml#afa4408d414310edfdb296fe94031f031", null ],
    [ "get", "classdata__model_1_1_objects_manager.xhtml#a2cae229decf6d6634d55519e2f92fdf8", null ],
    [ "getAsAny", "classdata__model_1_1_objects_manager.xhtml#a97c5e52ad88e315791c1af4c0ddb9a7d", null ],
    [ "getOrCreate", "classdata__model_1_1_objects_manager.xhtml#a1850a371bc93f7caaba78cec7cbc0a6d", null ],
    [ "getOrCreate", "classdata__model_1_1_objects_manager.xhtml#a86f3a81ad745d5c2ef0c24d559d7aae6", null ],
    [ "has", "classdata__model_1_1_objects_manager.xhtml#a790a5e21300512d327e05b8d59a2ceb4", null ],
    [ "_mutex", "classdata__model_1_1_objects_manager.xhtml#a7aff09d35780c0fbd5e5b56dd9666787", null ]
];