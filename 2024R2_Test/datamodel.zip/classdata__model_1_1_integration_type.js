var classdata__model_1_1_integration_type =
[
    [ "IntegrationType", "classdata__model_1_1_integration_type.xhtml#a9b781e39ebfe95e366d992da5936f278", null ]
];