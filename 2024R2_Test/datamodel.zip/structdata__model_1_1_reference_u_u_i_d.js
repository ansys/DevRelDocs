var structdata__model_1_1_reference_u_u_i_d =
[
    [ "ReferenceUUID", "structdata__model_1_1_reference_u_u_i_d.xhtml#a705926e72ae4f95a51dc8083476682b6", null ],
    [ "id", "structdata__model_1_1_reference_u_u_i_d.xhtml#a0faa6088d94e6a963c9449e6642f7daa", null ],
    [ "objectsManagerUUID", "structdata__model_1_1_reference_u_u_i_d.xhtml#a16285895f1efaf793f1f224fb6af472b", null ]
];