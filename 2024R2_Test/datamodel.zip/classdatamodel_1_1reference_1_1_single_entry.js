var classdatamodel_1_1reference_1_1_single_entry =
[
    [ "__getitem__", "classdatamodel_1_1reference_1_1_single_entry.xhtml#a501b42ebfb05c11f4d0e3c4cc8d9b5f5", null ],
    [ "context_path", "classdatamodel_1_1reference_1_1_single_entry.xhtml#a856fe5438ddfb066c780d8918996f6a9", null ]
];