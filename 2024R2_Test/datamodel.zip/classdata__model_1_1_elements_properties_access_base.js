var classdata__model_1_1_elements_properties_access_base =
[
    [ "assertGetDataModelHandle", "classdata__model_1_1_elements_properties_access_base.xhtml#a84d960ecb291eb9bb7124647e4ab8718", null ],
    [ "getDataModelHandle", "classdata__model_1_1_elements_properties_access_base.xhtml#a1efec8c5e93cd5c25c533b30954fdcc4", null ]
];