var classdata__model_1_1_reference_operation_types =
[
    [ "ReferenceOperationSpecification", "classdata__model_1_1_reference_operation_types_1_1_reference_operation_specification.xhtml", null ]
];