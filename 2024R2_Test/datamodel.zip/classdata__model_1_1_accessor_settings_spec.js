var classdata__model_1_1_accessor_settings_spec =
[
    [ "generateDefaultSettings", "classdata__model_1_1_accessor_settings_spec.xhtml#ad1c7a6e8019f6c05b47357839de925cc", null ],
    [ "userSettings", "classdata__model_1_1_accessor_settings_spec.xhtml#a9439231bdc3a08f507b557cb4c02f90b", null ]
];