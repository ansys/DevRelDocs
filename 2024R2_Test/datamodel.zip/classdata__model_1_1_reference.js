var classdata__model_1_1_reference =
[
    [ "appId", "classdata__model_1_1_reference.xhtml#af8cab68ca3324183878ce3e08527fcc7", null ],
    [ "contextLabel", "classdata__model_1_1_reference.xhtml#ad0bd80ad88e265268dbb450a35c57812", null ],
    [ "DEPRECATED_WITH_ALTERNATIVE", "classdata__model_1_1_reference.xhtml#aac4c6ea40aa00651816bedd0ccd26179", null ],
    [ "empty", "classdata__model_1_1_reference.xhtml#a4449f511c7cfefef1d190fa988450d7d", null ],
    [ "entries", "classdata__model_1_1_reference.xhtml#a37de2d20ef22e1f85da80ab2cb15be97", null ],
    [ "internalId", "classdata__model_1_1_reference.xhtml#aca721efb71bff54bb40d1640dcc361c3", null ],
    [ "numEntries", "classdata__model_1_1_reference.xhtml#ab6d15f4ff2fdacdfa71a8725866e954e", null ],
    [ "type", "classdata__model_1_1_reference.xhtml#a4e80b93e61248cfdce6b10fb0f5de02e", null ],
    [ "UUID", "classdata__model_1_1_reference.xhtml#abb619ee0de22af43004555edb4692cb3", null ]
];