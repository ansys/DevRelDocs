var classdata__model_1_1_named_reference_access_base =
[
    [ "getReference", "classdata__model_1_1_named_reference_access_base.xhtml#ad965d6af5ce0bceddb9d458bd47ead94", null ],
    [ "setData", "classdata__model_1_1_named_reference_access_base.xhtml#a26d28af5519eb842b8469a5ec84b7fc3", null ],
    [ "setName", "classdata__model_1_1_named_reference_access_base.xhtml#acff5198fc70c4e4f51c424af0c2a954d", null ],
    [ "setReference", "classdata__model_1_1_named_reference_access_base.xhtml#a37f2b8ebdd45393286bed0d67bfd57fd", null ]
];