var classdata__model_1_1_attribute_recorder_t =
[
    [ "attributesAsDoubleFields", "classdata__model_1_1_attribute_recorder_t.xhtml#a1b63e0cf6b2cd859426f5d2117d2c9bf", null ],
    [ "attributesAsInt32Fields", "classdata__model_1_1_attribute_recorder_t.xhtml#a8e177f9f8dbe0623d4a2500f6e076b0d", null ],
    [ "getDoubleFieldAttribute", "classdata__model_1_1_attribute_recorder_t.xhtml#a6c5ce1d4dc878bbe8cd5bac2ea65c236", null ],
    [ "getInt32FieldAttribute", "classdata__model_1_1_attribute_recorder_t.xhtml#a5309b624f14514d83054624fe1be34cf", null ],
    [ "hasAttributeAsDoubleField", "classdata__model_1_1_attribute_recorder_t.xhtml#a26a172bbda6fc384d1dfddff3019705c", null ],
    [ "hasAttributeAsInt32Field", "classdata__model_1_1_attribute_recorder_t.xhtml#a2e8c596418c3ed4f559c3797f9888b28", null ],
    [ "recordAttributeAccess", "classdata__model_1_1_attribute_recorder_t.xhtml#ae38cb6075c181fab4f8d41520aec7c65", null ],
    [ "recordAttributeAccess", "classdata__model_1_1_attribute_recorder_t.xhtml#a42d6d2ba43a2795ba1a467001c12491f", null ]
];