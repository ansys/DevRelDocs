var classdata__model_1_1_mesh_part =
[
    [ "setData", "classdata__model_1_1_mesh_part.xhtml#a9a9d2fc92c23d77ac08aee29b88b903e", null ],
    [ "setMeshRegions", "classdata__model_1_1_mesh_part.xhtml#a12285f95212d9bb4ca56c34aa6581234", null ],
    [ "setNodeCoordinates", "classdata__model_1_1_mesh_part.xhtml#a5240970c282a9ed6e5eebd5a29acd636", null ]
];