var classdata__model_1_1_connection_type =
[
    [ "ConnectionType", "classdata__model_1_1_connection_type.xhtml#ab68f4e5e65fb9fbc1bbf0da0cec18f88", null ]
];