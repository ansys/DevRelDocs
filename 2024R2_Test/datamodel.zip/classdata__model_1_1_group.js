var classdata__model_1_1_group =
[
    [ "Group", "classdata__model_1_1_group.xhtml#a873ab6572b97944ab1dffcb0d4626bdb", null ],
    [ "empty", "classdata__model_1_1_group.xhtml#a7608921c76c388cc82c664938f5dcad8", null ],
    [ "size", "classdata__model_1_1_group.xhtml#a83a0c57be20342ec8296738c940e3961", null ]
];