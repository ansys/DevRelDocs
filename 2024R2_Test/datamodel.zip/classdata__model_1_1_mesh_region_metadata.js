var classdata__model_1_1_mesh_region_metadata =
[
    [ "dimension", "classdata__model_1_1_mesh_region_metadata.xhtml#a4fce34b00f3054d4b7903a5bc6611ab0", null ],
    [ "isPhysicalRegion", "classdata__model_1_1_mesh_region_metadata.xhtml#ada41143bad67ba5b69f6c0df9ef65668", null ],
    [ "numberOfElements", "classdata__model_1_1_mesh_region_metadata.xhtml#ae80bfdf4ce5c15266fd8e16fc130639a", null ]
];