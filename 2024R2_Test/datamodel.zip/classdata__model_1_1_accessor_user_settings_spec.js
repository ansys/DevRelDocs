var classdata__model_1_1_accessor_user_settings_spec =
[
    [ "addUserSetting", "classdata__model_1_1_accessor_user_settings_spec.xhtml#a9a369aca60aab37956b8f36ab3a182c9", null ],
    [ "addUserSettingsCategory", "classdata__model_1_1_accessor_user_settings_spec.xhtml#a15bc22f1352181a284f0b042568b8824", null ]
];