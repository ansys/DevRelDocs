var classdata__model_1_1_object_type_info_generator =
[
    [ "create", "classdata__model_1_1_object_type_info_generator.xhtml#a73adb5dbad94d3cfc7e8c790fa35c0f3", null ]
];