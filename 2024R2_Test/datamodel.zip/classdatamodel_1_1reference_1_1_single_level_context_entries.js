var classdatamodel_1_1reference_1_1_single_level_context_entries =
[
    [ "__getitem__", "classdatamodel_1_1reference_1_1_single_level_context_entries.xhtml#ab8e2cfa96d059629623d493f602eb3d5", null ],
    [ "context_path", "classdatamodel_1_1reference_1_1_single_level_context_entries.xhtml#a46efd311c89c5b876baa560b9adf9802", null ]
];