var classdata__model_1_1_simple_reference_generator =
[
    [ "create", "classdata__model_1_1_simple_reference_generator.xhtml#ad406ccd131255bd972cab8aecdc4f8dd", null ],
    [ "create", "classdata__model_1_1_simple_reference_generator.xhtml#a4b3774ee91378d587fbbe47c735bea49", null ]
];