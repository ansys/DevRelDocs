var classdata__model_1_1_access_definition =
[
    [ "NamespaceKey", "structdata__model_1_1_access_definition_1_1_namespace_key.xhtml", null ],
    [ "AccessDefinition", "classdata__model_1_1_access_definition.xhtml#ab1740be5a3256822a6831f82203c6dbb", null ],
    [ "addSecondaryAccess", "classdata__model_1_1_access_definition.xhtml#ae42e033758bee1b60154054b48687928", null ],
    [ "appKey", "classdata__model_1_1_access_definition.xhtml#a5a6ea8e1024f03a5d575089079226e07", null ],
    [ "appNamespace", "classdata__model_1_1_access_definition.xhtml#af91cf993e4acf90d6cee75b83b833a40", null ],
    [ "hasSingletonData", "classdata__model_1_1_access_definition.xhtml#a6cac0ae00ad5fd60ca5df9710de1f06a", null ],
    [ "prefix", "classdata__model_1_1_access_definition.xhtml#afaa25fa70dacdc316206b0e5b198f2b1", null ]
];