var classdata__model_1_1_data_model_connection =
[
    [ "getCurrentUserSettings", "classdata__model_1_1_data_model_connection.xhtml#a4f3547a777c51050cd1ee3b5a37dff95", null ],
    [ "releaseHandle", "classdata__model_1_1_data_model_connection.xhtml#a2552cd6fe28dfa51fad822d0f80a4fa7", null ],
    [ "setUserSettings", "classdata__model_1_1_data_model_connection.xhtml#a920b2eafbf6b9474400842e59154272f", null ]
];