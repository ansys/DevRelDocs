var class_speos_n_x_1_1_optical_properties_geometry =
[
    [ "Add", "class_speos_n_x_1_1_optical_properties_geometry.xhtml#a14f0db74968e569a7aa8d98824a419d6", null ],
    [ "Clear", "class_speos_n_x_1_1_optical_properties_geometry.xhtml#af90114b2280410b0c68aebc6241b3f0f", null ],
    [ "Remove", "class_speos_n_x_1_1_optical_properties_geometry.xhtml#aebc567ea018fac3ced7dd05e9a95fcd4", null ],
    [ "RevertGeometry", "class_speos_n_x_1_1_optical_properties_geometry.xhtml#a4bbae52c17203c13e6ed92f56a484af7", null ],
    [ "SetDirection", "class_speos_n_x_1_1_optical_properties_geometry.xhtml#af6258b2bbe185d87eff5cb6b8a34383d", null ]
];