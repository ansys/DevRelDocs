var class_speos_n_x_1_1_simulation_settings =
[
    [ "SaveAsPreset", "class_speos_n_x_1_1_simulation_settings.xhtml#a0d401fdf1f641ea5c1f2fa54df7f4ad8", null ]
];