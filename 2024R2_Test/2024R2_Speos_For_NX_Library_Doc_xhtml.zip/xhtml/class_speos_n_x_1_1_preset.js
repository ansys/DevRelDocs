var class_speos_n_x_1_1_preset =
[
    [ "Delete", "class_speos_n_x_1_1_preset.xhtml#a1334cd37d91f7a0902592f9b10ca1673", null ],
    [ "Rename", "class_speos_n_x_1_1_preset.xhtml#a6364b1b618468467bbc715c556268528", null ]
];