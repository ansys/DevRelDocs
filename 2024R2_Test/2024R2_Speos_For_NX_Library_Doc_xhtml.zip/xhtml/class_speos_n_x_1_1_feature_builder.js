var class_speos_n_x_1_1_feature_builder =
[
    [ "Commit", "class_speos_n_x_1_1_feature_builder.xhtml#a2b74e1b440341a82332053432b52b42c", null ],
    [ "ShowResult", "class_speos_n_x_1_1_feature_builder.xhtml#af46ee7a28cb7c93fbc6b6c4c4a7c7a53", null ]
];