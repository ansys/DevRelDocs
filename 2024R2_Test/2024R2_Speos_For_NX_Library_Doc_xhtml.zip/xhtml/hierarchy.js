var hierarchy =
[
    [ "_object", "class_speos_n_x_1_1__object.xhtml", [
      [ "AxisSystem", "class_speos_n_x_1_1_axis_system.xhtml", null ],
      [ "Feature", "class_speos_n_x_1_1_feature.xhtml", [
        [ "FeatureSimulation", "class_speos_n_x_1_1_feature_simulation.xhtml", null ]
      ] ],
      [ "FeatureBuilder", "class_speos_n_x_1_1_feature_builder.xhtml", [
        [ "FolderBuilder", "class_speos_n_x_1_1_folder_builder.xhtml", null ],
        [ "OpticalPropertiesBuilder", "class_speos_n_x_1_1_optical_properties_builder.xhtml", null ],
        [ "Sensor3DEnergyDensityBuilder", "class_speos_n_x_1_1_sensor3_d_energy_density_builder.xhtml", null ],
        [ "Sensor3DIrradianceBuilder", "class_speos_n_x_1_1_sensor3_d_irradiance_builder.xhtml", null ],
        [ "SensorCommonBuilder", "class_speos_n_x_1_1_sensor_common_builder.xhtml", [
          [ "SensorIntensityBuilder", "class_speos_n_x_1_1_sensor_intensity_builder.xhtml", null ],
          [ "SensorIrradianceBuilder", "class_speos_n_x_1_1_sensor_irradiance_builder.xhtml", null ],
          [ "SensorRadianceBuilder", "class_speos_n_x_1_1_sensor_radiance_builder.xhtml", null ]
        ] ],
        [ "SensorObserverBuilder", "class_speos_n_x_1_1_sensor_observer_builder.xhtml", null ],
        [ "SensorVRImmersiveBuilder", "class_speos_n_x_1_1_sensor_v_r_immersive_builder.xhtml", null ],
        [ "SimulationCommonBuilder", "class_speos_n_x_1_1_simulation_common_builder.xhtml", [
          [ "SimulationDirectBuilder", "class_speos_n_x_1_1_simulation_direct_builder.xhtml", null ],
          [ "SimulationInteractiveBuilder", "class_speos_n_x_1_1_simulation_interactive_builder.xhtml", null ],
          [ "SimulationInverseBuilder", "class_speos_n_x_1_1_simulation_inverse_builder.xhtml", null ]
        ] ],
        [ "SourceAmbientCommonBuilder", "class_speos_n_x_1_1_source_ambient_common_builder.xhtml", [
          [ "SourceAmbientGeneralSkyBuilder", "class_speos_n_x_1_1_source_ambient_general_sky_builder.xhtml", null ],
          [ "SourceAmbientNaturalLightBuilder", "class_speos_n_x_1_1_source_ambient_natural_light_builder.xhtml", null ],
          [ "SourceAmbientOvercastSkyBuilder", "class_speos_n_x_1_1_source_ambient_overcast_sky_builder.xhtml", null ],
          [ "SourceAmbientUS1976Builder", "class_speos_n_x_1_1_source_ambient_u_s1976_builder.xhtml", null ],
          [ "SourceAmbientUniformBuilder", "class_speos_n_x_1_1_source_ambient_uniform_builder.xhtml", null ]
        ] ],
        [ "SourceAmbientEnvironmentBuilder", "class_speos_n_x_1_1_source_ambient_environment_builder.xhtml", null ],
        [ "SourceDisplayBuilder", "class_speos_n_x_1_1_source_display_builder.xhtml", null ],
        [ "SourceLuminaireBuilder", "class_speos_n_x_1_1_source_luminaire_builder.xhtml", null ],
        [ "SourceRayFileBuilder", "class_speos_n_x_1_1_source_ray_file_builder.xhtml", null ],
        [ "SourceSurfaceBuilder", "class_speos_n_x_1_1_source_surface_builder.xhtml", null ],
        [ "SpeosPatternBuilder", "class_speos_n_x_1_1_speos_pattern_builder.xhtml", null ]
      ] ],
      [ "FeatureCollection", "class_speos_n_x_1_1_feature_collection.xhtml", null ],
      [ "OpticalPropertiesGeometry", "class_speos_n_x_1_1_optical_properties_geometry.xhtml", null ],
      [ "Part", "class_speos_n_x_1_1_part.xhtml", null ],
      [ "PartCollection", "class_speos_n_x_1_1_part_collection.xhtml", null ],
      [ "Preset", "class_speos_n_x_1_1_preset.xhtml", null ],
      [ "RayFileData", "class_speos_n_x_1_1_ray_file_data.xhtml", null ],
      [ "SensorFilter", "class_speos_n_x_1_1_sensor_filter.xhtml", null ],
      [ "Session", "class_speos_n_x_1_1_session.xhtml", null ],
      [ "SimulationSettings", "class_speos_n_x_1_1_simulation_settings.xhtml", null ],
      [ "SourceSurfaceEmissiveFaces", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml", null ],
      [ "Timezone", "class_speos_n_x_1_1_timezone.xhtml", null ],
      [ "ZenithNorthSystem", "class_speos_n_x_1_1_zenith_north_system.xhtml", null ]
    ] ]
];