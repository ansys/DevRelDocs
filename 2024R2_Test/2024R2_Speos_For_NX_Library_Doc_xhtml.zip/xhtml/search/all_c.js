var searchData=
[
  ['name_0',['Name',['../class_speos_n_x_1_1_feature_builder.xhtml#aa5998168cabfb2b2e41151349077812c',1,'SpeosNX.FeatureBuilder.Name'],['../class_speos_n_x_1_1_preset.xhtml#aa5998168cabfb2b2e41151349077812c',1,'SpeosNX.Preset.Name'],['../class_speos_n_x_1_1_feature.xhtml#aa5998168cabfb2b2e41151349077812c',1,'SpeosNX.Feature.Name']]],
  ['namewithcontext_1',['NameWithContext',['../class_speos_n_x_1_1_feature_builder.xhtml#a99e8764720550e4ed0eba629a625b2e3',1,'SpeosNX::FeatureBuilder']]],
  ['nearfield_2',['NearField',['../class_speos_n_x_1_1_sensor_intensity_builder.xhtml#a8121077a0dfadda5b619778fbdbbae2e',1,'SpeosNX::SensorIntensityBuilder']]],
  ['northdirection_3',['NorthDirection',['../class_speos_n_x_1_1_zenith_north_system.xhtml#a9238d12181c722155963a7e084d491a4',1,'SpeosNX::ZenithNorthSystem']]],
  ['northdirectionreversed_4',['NorthDirectionReversed',['../class_speos_n_x_1_1_zenith_north_system.xhtml#a9c36788c7756338c824fa5c8f1e27947',1,'SpeosNX::ZenithNorthSystem']]],
  ['numberofray_5',['NumberOfRay',['../class_speos_n_x_1_1_speos_pattern_builder.xhtml#a451c243568b9c7aa0d2ec3b91b6e6681',1,'SpeosNX::SpeosPatternBuilder']]],
  ['numberofrays_6',['NumberOfRays',['../class_speos_n_x_1_1_source_display_builder.xhtml#a622dc1d3ba1038d63b443881726aac17',1,'SpeosNX.SourceDisplayBuilder.NumberOfRays'],['../class_speos_n_x_1_1_source_luminaire_builder.xhtml#a622dc1d3ba1038d63b443881726aac17',1,'SpeosNX.SourceLuminaireBuilder.NumberOfRays'],['../class_speos_n_x_1_1_source_ray_file_builder.xhtml#a622dc1d3ba1038d63b443881726aac17',1,'SpeosNX.SourceRayFileBuilder.NumberOfRays'],['../class_speos_n_x_1_1_source_surface_builder.xhtml#a622dc1d3ba1038d63b443881726aac17',1,'SpeosNX.SourceSurfaceBuilder.NumberOfRays']]],
  ['numberstandardpasses_7',['NumberStandardPasses',['../class_speos_n_x_1_1_simulation_settings.xhtml#ad753e9714c570b8d2e70a83fec5b1ee6',1,'SpeosNX::SimulationSettings']]],
  ['nx_20library_8',['Speos for NX library',['../index.xhtml',1,'']]],
  ['nxsessiontag_9',['NXSessionTag',['../class_speos_n_x_1_1_session.xhtml#acd222d0756d43c811cc84b2abc9bc481',1,'SpeosNX::Session']]]
];
