var searchData=
[
  ['gatheringsourcenumber_0',['GatheringSourceNumber',['../class_speos_n_x_1_1_simulation_settings.xhtml#ac9808f0dd5e21fa21cf6b7fe230f6127',1,'SpeosNX::SimulationSettings']]],
  ['gaussianfwhmangle_1',['GaussianFWHMAngle',['../class_speos_n_x_1_1_source_display_builder.xhtml#aef43808a7f9844489cdeaf7a6c7db0d2',1,'SpeosNX::SourceDisplayBuilder']]],
  ['gaussianfwhmanglex_2',['GaussianFWHMAngleX',['../class_speos_n_x_1_1_source_display_builder.xhtml#a4855863207ac5302b593e6b769ec82a9',1,'SpeosNX::SourceDisplayBuilder']]],
  ['gaussianfwhmangley_3',['GaussianFWHMAngleY',['../class_speos_n_x_1_1_source_display_builder.xhtml#ab60d4d5c051a1779188872181db64fd7',1,'SpeosNX::SourceDisplayBuilder']]],
  ['geometricaldistancetolerance_4',['GeometricalDistanceTolerance',['../class_speos_n_x_1_1_simulation_settings.xhtml#acdb4d57d144ce070f4288cc0e33e6fb3',1,'SpeosNX::SimulationSettings']]],
  ['geometries_5',['Geometries',['../class_speos_n_x_1_1_simulation_common_builder.xhtml#a98788fbe263fc2e12068ecc7ddbadbc7',1,'SpeosNX::SimulationCommonBuilder']]],
  ['geometrylist_6',['GeometryList',['../class_speos_n_x_1_1_optical_properties_geometry.xhtml#a7a6aab2002227c688953646ab89e7d12',1,'SpeosNX::OpticalPropertiesGeometry']]],
  ['gpusimulationmode_7',['GPUSimulationMode',['../class_speos_n_x_1_1_feature_simulation.xhtml#a21f68ec2beda4bb03b75580244fbcaae',1,'SpeosNX::FeatureSimulation']]],
  ['greenspectrumfile_8',['GreenSpectrumFile',['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#ac58f22766bd30a897a5d5a1a365d07b7',1,'SpeosNX::SourceAmbientEnvironmentBuilder']]],
  ['greenspectrumfilepath_9',['GreenSpectrumFilePath',['../class_speos_n_x_1_1_source_display_builder.xhtml#ae08250ad2f5b04fa360eb22c7769c080',1,'SpeosNX::SourceDisplayBuilder']]],
  ['gridoriginx_10',['GridOriginX',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a5c64608c9fc8d2352e5deb9c2b74b3a4',1,'SpeosNX::SensorCommonBuilder']]],
  ['gridoriginy_11',['GridOriginY',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#aea68e71b420f605044061b8570cb2ca5',1,'SpeosNX::SensorCommonBuilder']]],
  ['gridstepx_12',['GridStepX',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#ada9eb3eb967aa429dc2e928c8b2db09a',1,'SpeosNX::SensorCommonBuilder']]],
  ['gridstepy_13',['GridStepY',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a1ad5c904b94df862b400a77756ffc7b0',1,'SpeosNX::SensorCommonBuilder']]],
  ['groundorigin_14',['GroundOrigin',['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#a1a6f83cd4e831a9eaef9dee84d5110a7',1,'SpeosNX::SourceAmbientEnvironmentBuilder']]]
];
