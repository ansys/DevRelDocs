var searchData=
[
  ['hasfluxinlumen_0',['HasFluxInLumen',['../class_speos_n_x_1_1_ray_file_data.xhtml#a922d332f6119354b2077a99a51842a5b',1,'SpeosNX::RayFileData']]],
  ['hasfluxinwatt_1',['HasFluxInWatt',['../class_speos_n_x_1_1_ray_file_data.xhtml#a336ebe30c695fab8d74c1e0f7d80fa18',1,'SpeosNX::RayFileData']]],
  ['haspower_2',['HasPower',['../class_speos_n_x_1_1_ray_file_data.xhtml#a59d42b5f59e514cac1351f62f95a46f2',1,'SpeosNX::RayFileData']]],
  ['hasspectrum_3',['HasSpectrum',['../class_speos_n_x_1_1_ray_file_data.xhtml#a0f6afdf1d622d54541ba81e7833ba659',1,'SpeosNX::RayFileData']]],
  ['height_4',['Height',['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#a27ba8679f9fd5b9572ecbf433894952c',1,'SpeosNX::SourceAmbientEnvironmentBuilder']]],
  ['hour_5',['Hour',['../class_speos_n_x_1_1_timezone.xhtml#a1b6150b6363edbcb51f9a559594ca426',1,'SpeosNX::Timezone']]],
  ['hvratio_6',['HVRatio',['../class_speos_n_x_1_1_sensor_radiance_builder.xhtml#a3bfb1c8912abb970b355e66a59b9e36b',1,'SpeosNX::SensorRadianceBuilder']]]
];
