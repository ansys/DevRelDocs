var searchData=
[
  ['delete_0',['Delete',['../class_speos_n_x_1_1_preset.xhtml#a1334cd37d91f7a0902592f9b10ca1673',1,'SpeosNX.Preset.Delete()'],['../class_speos_n_x_1_1_feature.xhtml#a1334cd37d91f7a0902592f9b10ca1673',1,'SpeosNX.Feature.Delete()']]],
  ['deletesourcefacefilteringreferences_1',['DeleteSourceFaceFilteringReferences',['../class_speos_n_x_1_1_simulation_inverse_builder.xhtml#a15bf9da521ec1b18da49f156d3971ae8',1,'SpeosNX::SimulationInverseBuilder']]]
];
