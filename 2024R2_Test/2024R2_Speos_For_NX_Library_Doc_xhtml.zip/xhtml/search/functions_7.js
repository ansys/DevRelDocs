var searchData=
[
  ['linkedexport_0',['LinkedExport',['../class_speos_n_x_1_1_feature_simulation.xhtml#a23529de1cab39154aa23c7133327ca82',1,'SpeosNX::FeatureSimulation']]],
  ['load_1',['Load',['../class_speos_n_x_1_1_part_collection.xhtml#a61d55b3161bc825e1df799cdb110d7ff',1,'SpeosNX::PartCollection']]]
];
