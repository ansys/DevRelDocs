var searchData=
[
  ['update_0',['Update',['../class_speos_n_x_1_1_feature.xhtml#ac738e9873f2235b40ac293b55192aff1',1,'SpeosNX::Feature']]]
];
