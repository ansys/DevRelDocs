var searchData=
[
  ['getsession_0',['GetSession',['../class_speos_n_x_1_1_session.xhtml#a0f0f57981687c74a3da64f469c97e70d',1,'SpeosNX::Session']]]
];
