var searchData=
[
  ['saveaspreset_0',['SaveAsPreset',['../class_speos_n_x_1_1_simulation_settings.xhtml#a0d401fdf1f641ea5c1f2fa54df7f4ad8',1,'SpeosNX::SimulationSettings']]],
  ['setdirection_1',['SetDirection',['../class_speos_n_x_1_1_optical_properties_geometry.xhtml#af6258b2bbe185d87eff5cb6b8a34383d',1,'SpeosNX.OpticalPropertiesGeometry.SetDirection()'],['../class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#af6258b2bbe185d87eff5cb6b8a34383d',1,'SpeosNX.SourceSurfaceEmissiveFaces.SetDirection()']]],
  ['showresult_2',['ShowResult',['../class_speos_n_x_1_1_feature_builder.xhtml#af46ee7a28cb7c93fbc6b6c4c4a7c7a53',1,'SpeosNX::FeatureBuilder']]]
];
