var searchData=
[
  ['add_0',['Add',['../class_speos_n_x_1_1_optical_properties_geometry.xhtml#a14f0db74968e569a7aa8d98824a419d6',1,'SpeosNX.OpticalPropertiesGeometry.Add()'],['../class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#a14f0db74968e569a7aa8d98824a419d6',1,'SpeosNX.SourceSurfaceEmissiveFaces.Add()'],['../class_speos_n_x_1_1_folder_builder.xhtml#a003dfaa76943aab1ef84be58d6dd359d',1,'SpeosNX.FolderBuilder.Add()']]],
  ['addgeometries_1',['AddGeometries',['../class_speos_n_x_1_1_simulation_common_builder.xhtml#a0ec813b00b8afd7a9702b5cf2f1525b2',1,'SpeosNX::SimulationCommonBuilder']]],
  ['addsensors_2',['AddSensors',['../class_speos_n_x_1_1_simulation_common_builder.xhtml#a2823ee2dcd595a45c1870bcaf47205e2',1,'SpeosNX::SimulationCommonBuilder']]],
  ['addsourcefacefilteringreferences_3',['AddSourceFaceFilteringReferences',['../class_speos_n_x_1_1_simulation_inverse_builder.xhtml#a7598bf83dc06bc58ec855cf4a061ebf0',1,'SpeosNX::SimulationInverseBuilder']]],
  ['addsources_4',['AddSources',['../class_speos_n_x_1_1_simulation_common_builder.xhtml#a99f17a25fe9e579fc3504b17728ca2da',1,'SpeosNX::SimulationCommonBuilder']]]
];
