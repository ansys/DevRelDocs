var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwxyz",
  1: "_afopstz",
  2: "acdefgilrsu",
  3: "abcdefghilmnoprstuvwxyz",
  4: "cefgilmnopsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "properties",
  4: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Properties",
  4: "Pages"
};

