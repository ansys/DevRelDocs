var searchData=
[
  ['overview_0',['Platform overview',['../_platform_overview.xhtml',1,'']]]
];
