var searchData=
[
  ['radius_0',['Radius',['../class_speos_n_x_1_1_sensor_intensity_builder.xhtml#a07a58ed1a86bc8ee747d6e5d067ef6e2',1,'SpeosNX::SensorIntensityBuilder']]],
  ['rayfileformat_1',['RayFileFormat',['../class_speos_n_x_1_1_sensor3_d_irradiance_builder.xhtml#a35e6f0c1b96490c0a04782ee3726a39a',1,'SpeosNX.Sensor3DIrradianceBuilder.RayFileFormat'],['../class_speos_n_x_1_1_sensor_irradiance_builder.xhtml#a35e6f0c1b96490c0a04782ee3726a39a',1,'SpeosNX.SensorIrradianceBuilder.RayFileFormat'],['../class_speos_n_x_1_1_simulation_direct_builder.xhtml#a35e6f0c1b96490c0a04782ee3726a39a',1,'SpeosNX.SimulationDirectBuilder.RayFileFormat']]],
  ['rayfilepath_2',['RayFilePath',['../class_speos_n_x_1_1_source_ray_file_builder.xhtml#a6488c5ef274cb7790579b544be0fc80d',1,'SpeosNX::SourceRayFileBuilder']]],
  ['raylength_3',['RayLength',['../class_speos_n_x_1_1_source_display_builder.xhtml#ac34ed0a90a26560cbc5671f5f0243421',1,'SpeosNX.SourceDisplayBuilder.RayLength'],['../class_speos_n_x_1_1_source_luminaire_builder.xhtml#ac34ed0a90a26560cbc5671f5f0243421',1,'SpeosNX.SourceLuminaireBuilder.RayLength'],['../class_speos_n_x_1_1_source_ray_file_builder.xhtml#ac34ed0a90a26560cbc5671f5f0243421',1,'SpeosNX.SourceRayFileBuilder.RayLength'],['../class_speos_n_x_1_1_source_surface_builder.xhtml#ac34ed0a90a26560cbc5671f5f0243421',1,'SpeosNX.SourceSurfaceBuilder.RayLength']]],
  ['raynumbermultiplier_4',['RayNumberMultiplier',['../class_speos_n_x_1_1_simulation_direct_builder.xhtml#a8c7f1fe2d578358867274eb0f466ad78',1,'SpeosNX::SimulationDirectBuilder']]],
  ['raysnumber_5',['RaysNumber',['../class_speos_n_x_1_1_simulation_direct_builder.xhtml#a5c9320b7b58cbf28d950fc145af414c5',1,'SpeosNX::SimulationDirectBuilder']]],
  ['raytracerprecisionmode_6',['RayTracerPrecisionMode',['../class_speos_n_x_1_1_simulation_settings.xhtml#ac34015a7669bda11023a46df84674489',1,'SpeosNX::SimulationSettings']]],
  ['redspectrumfile_7',['RedSpectrumFile',['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#ab3ec7aadd8cf0680d13f550136dd24d4',1,'SpeosNX::SourceAmbientEnvironmentBuilder']]],
  ['redspectrumfilepath_8',['RedSpectrumFilePath',['../class_speos_n_x_1_1_source_display_builder.xhtml#afc42d0cd925127b856144656d9f9d114',1,'SpeosNX::SourceDisplayBuilder']]],
  ['reflection_9',['Reflection',['../class_speos_n_x_1_1_sensor3_d_irradiance_builder.xhtml#a3703d6573392d7883981d3f831eadae4',1,'SpeosNX::Sensor3DIrradianceBuilder']]],
  ['renderingasoptical_10',['RenderingAsOptical',['../class_speos_n_x_1_1_simulation_settings.xhtml#a0d56a766554d2456b80222c74f6781df',1,'SpeosNX::SimulationSettings']]],
  ['resolution_11',['Resolution',['../class_speos_n_x_1_1_sensor_v_r_immersive_builder.xhtml#a3c1fc1369ee351f25804c8cde5e85ac3',1,'SpeosNX::SensorVRImmersiveBuilder']]],
  ['right_12',['Right',['../class_speos_n_x_1_1_sensor_v_r_immersive_builder.xhtml#a338f1941aaeb45ceefaa84416d2aaddb',1,'SpeosNX::SensorVRImmersiveBuilder']]]
];
