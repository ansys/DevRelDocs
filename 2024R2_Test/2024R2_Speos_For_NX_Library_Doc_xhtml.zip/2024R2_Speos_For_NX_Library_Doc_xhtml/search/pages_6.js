var searchData=
[
  ['main_20concepts_0',['Main concepts',['../_getting_started_main_concepts.xhtml',1,'']]]
];
