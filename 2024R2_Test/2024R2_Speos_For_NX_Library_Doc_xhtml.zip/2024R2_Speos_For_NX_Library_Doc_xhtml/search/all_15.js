var searchData=
[
  ['xdirection_0',['XDirection',['../class_speos_n_x_1_1_source_display_builder.xhtml#ac32c0a2dded19b16f8b3c6f95a350212',1,'SpeosNX::SourceDisplayBuilder']]],
  ['xdirectionreversed_1',['XDirectionReversed',['../class_speos_n_x_1_1_source_display_builder.xhtml#aeec30b2aaa4a69736255d2f2a67848c7',1,'SpeosNX::SourceDisplayBuilder']]],
  ['xend_2',['XEnd',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a799203cf9eff20a5ef568bbc1b9d1a47',1,'SpeosNX.SensorCommonBuilder.XEnd'],['../class_speos_n_x_1_1_source_display_builder.xhtml#a799203cf9eff20a5ef568bbc1b9d1a47',1,'SpeosNX.SourceDisplayBuilder.XEnd']]],
  ['xmirroredextent_3',['XMirroredExtent',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a78fc5a48a0a4a6282855a28240b3f94a',1,'SpeosNX.SensorCommonBuilder.XMirroredExtent'],['../class_speos_n_x_1_1_source_display_builder.xhtml#a78fc5a48a0a4a6282855a28240b3f94a',1,'SpeosNX.SourceDisplayBuilder.XMirroredExtent']]],
  ['xresolution_4',['XResolution',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a96287c228b691e8c81135fbb396e7478',1,'SpeosNX::SensorCommonBuilder']]],
  ['xsampling_5',['XSampling',['../class_speos_n_x_1_1_sensor3_d_energy_density_builder.xhtml#a540f4cef446490f932858988d28b9b8b',1,'SpeosNX.Sensor3DEnergyDensityBuilder.XSampling'],['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a540f4cef446490f932858988d28b9b8b',1,'SpeosNX.SensorCommonBuilder.XSampling']]],
  ['xsize_6',['XSize',['../class_speos_n_x_1_1_sensor3_d_energy_density_builder.xhtml#a8a07a0539e90243af02f23e81528ce2d',1,'SpeosNX::Sensor3DEnergyDensityBuilder']]],
  ['xstart_7',['XStart',['../class_speos_n_x_1_1_sensor_common_builder.xhtml#a7963a0ff7bd1a05f42907b2e4a8912fb',1,'SpeosNX.SensorCommonBuilder.XStart'],['../class_speos_n_x_1_1_source_display_builder.xhtml#a7963a0ff7bd1a05f42907b2e4a8912fb',1,'SpeosNX.SourceDisplayBuilder.XStart']]]
];
