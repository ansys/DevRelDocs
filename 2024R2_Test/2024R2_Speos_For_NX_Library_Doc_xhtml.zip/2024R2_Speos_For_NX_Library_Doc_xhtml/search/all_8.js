var searchData=
[
  ['height_0',['Height',['../class_speos_n_x_1_1_source_ambient_environment_builder.xhtml#a27ba8679f9fd5b9572ecbf433894952c',1,'SpeosNX::SourceAmbientEnvironmentBuilder']]],
  ['hour_1',['Hour',['../class_speos_n_x_1_1_timezone.xhtml#a1b6150b6363edbcb51f9a559594ca426',1,'SpeosNX::Timezone']]],
  ['hvratio_2',['HVRatio',['../class_speos_n_x_1_1_sensor_radiance_builder.xhtml#a3bfb1c8912abb970b355e66a59b9e36b',1,'SpeosNX::SensorRadianceBuilder']]]
];
