var searchData=
[
  ['changelog_0',['Changelog',['../_changelog.xhtml',1,'']]],
  ['concepts_1',['Main concepts',['../_getting_started_main_concepts.xhtml',1,'']]]
];
