var searchData=
[
  ['opticalpropertiesbuilder_0',['OpticalPropertiesBuilder',['../class_speos_n_x_1_1_optical_properties_builder.xhtml',1,'SpeosNX']]],
  ['opticalpropertiesgeometry_1',['OpticalPropertiesGeometry',['../class_speos_n_x_1_1_optical_properties_geometry.xhtml',1,'SpeosNX']]]
];
