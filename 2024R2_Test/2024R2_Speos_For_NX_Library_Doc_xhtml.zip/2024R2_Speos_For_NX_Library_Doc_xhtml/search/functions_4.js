var searchData=
[
  ['findfromname_0',['FindFromName',['../class_speos_n_x_1_1_feature_collection.xhtml#a90bc7a74a7ab1d63cb1b87a781d8ae6f',1,'SpeosNX.FeatureCollection.FindFromName()'],['../class_speos_n_x_1_1_part_collection.xhtml#a90bc7a74a7ab1d63cb1b87a781d8ae6f',1,'SpeosNX.PartCollection.FindFromName()']]],
  ['findfromtag_1',['FindFromTag',['../class_speos_n_x_1_1_feature_collection.xhtml#a081b01090a58981bf1a844f173c8d054',1,'SpeosNX.FeatureCollection.FindFromTag()'],['../class_speos_n_x_1_1_part_collection.xhtml#a081b01090a58981bf1a844f173c8d054',1,'SpeosNX.PartCollection.FindFromTag()']]]
];
