var class_speos_n_x_1_1_source_surface_emissive_faces =
[
    [ "Add", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#a14f0db74968e569a7aa8d98824a419d6", null ],
    [ "Clear", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#af90114b2280410b0c68aebc6241b3f0f", null ],
    [ "Remove", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#aebc567ea018fac3ced7dd05e9a95fcd4", null ],
    [ "RevertFace", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#a045474742e7127b40bcc14df00af90af", null ],
    [ "SetDirection", "class_speos_n_x_1_1_source_surface_emissive_faces.xhtml#af6258b2bbe185d87eff5cb6b8a34383d", null ]
];