var class_speos_n_x_1_1_part_collection =
[
    [ "FindFromName", "class_speos_n_x_1_1_part_collection.xhtml#a90bc7a74a7ab1d63cb1b87a781d8ae6f", null ],
    [ "FindFromTag", "class_speos_n_x_1_1_part_collection.xhtml#a081b01090a58981bf1a844f173c8d054", null ],
    [ "Load", "class_speos_n_x_1_1_part_collection.xhtml#a61d55b3161bc825e1df799cdb110d7ff", null ]
];