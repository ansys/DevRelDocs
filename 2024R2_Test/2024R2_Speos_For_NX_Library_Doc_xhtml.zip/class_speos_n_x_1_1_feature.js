var class_speos_n_x_1_1_feature =
[
    [ "Delete", "class_speos_n_x_1_1_feature.xhtml#a1334cd37d91f7a0902592f9b10ca1673", null ],
    [ "Update", "class_speos_n_x_1_1_feature.xhtml#ac738e9873f2235b40ac293b55192aff1", null ]
];