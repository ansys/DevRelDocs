var class_speos_n_x_1_1_folder_builder =
[
    [ "Add", "class_speos_n_x_1_1_folder_builder.xhtml#a003dfaa76943aab1ef84be58d6dd359d", null ],
    [ "Insert", "class_speos_n_x_1_1_folder_builder.xhtml#ab0bf366cd670a72883d7b4b03ba0cdea", null ],
    [ "IsCompatible", "class_speos_n_x_1_1_folder_builder.xhtml#a8424826084c0cbd5029e4146c95ee874", null ],
    [ "Remove", "class_speos_n_x_1_1_folder_builder.xhtml#afa15b7fc4f81281d2aaad2b7566089b2", null ]
];