var class_speos_n_x_1_1_simulation_inverse_builder =
[
    [ "AddSourceFaceFilteringReferences", "class_speos_n_x_1_1_simulation_inverse_builder.xhtml#a7598bf83dc06bc58ec855cf4a061ebf0", null ],
    [ "DeleteSourceFaceFilteringReferences", "class_speos_n_x_1_1_simulation_inverse_builder.xhtml#a15bf9da521ec1b18da49f156d3971ae8", null ]
];