var class_speos_n_x_1_1_simulation_common_builder =
[
    [ "AddGeometries", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a0ec813b00b8afd7a9702b5cf2f1525b2", null ],
    [ "AddSensors", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a2823ee2dcd595a45c1870bcaf47205e2", null ],
    [ "AddSources", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a99f17a25fe9e579fc3504b17728ca2da", null ],
    [ "RemoveGeometries", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a30e21d1cd47e7d87d547daede1cb45e4", null ],
    [ "RemoveSensors", "class_speos_n_x_1_1_simulation_common_builder.xhtml#a2cdb6d650a57ad372cff24bcf8e6ad10", null ],
    [ "RemoveSources", "class_speos_n_x_1_1_simulation_common_builder.xhtml#ac10a0c4124712e65cb3a6c55fc1350f3", null ]
];