var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid =
[
    [ "ConvertToRGB", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#afde524e0829260c947a78121967e18e2", null ],
    [ "X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a07aaf77c88f95016c9675185fe6b40bd", null ],
    [ "XYZ", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#ab4faf51a47c96182ab0fafee2fe8822a", null ],
    [ "Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a0d2831fee322a7ba4e03eb58874e3255", null ],
    [ "Z", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a8d9341e12275b6c3782cdc8ac8916566", null ],
    [ "Description", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a4825569523da5942be468e6a45b18f1c", null ],
    [ "Dx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a3cc8eebcf19c05df3fb479d5b903776b", null ],
    [ "Dy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a5da86f30d836256047b765dc5ae8af4c", null ],
    [ "MinX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a5a4afc1e9500191e2f187ce7fd98d58a", null ],
    [ "MinY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a32d23725c51d7e3fe21999b4501d67d5", null ],
    [ "Nx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a85ad5cb8149d444e9a1e4665d5a2993d", null ],
    [ "Ny", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a8d6eab2ad716c15fb8d8c21fdf154ad7", null ],
    [ "ValueData", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#ae608ff5fa0910119ce2faf4867d60767", null ],
    [ "ValueLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a060eeb06f96cc4abd5a17db0106dd38d", null ],
    [ "Values", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#ae6517bfa9e916925419bc6d2ba796969", null ],
    [ "XLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a3afdb945e3598c6adb9408db44906d5b", null ],
    [ "YLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid.xhtml#a4049b9dcfd43be5de261e51563aca9d0", null ]
];