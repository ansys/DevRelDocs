var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume =
[
    [ "InnerR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#a760c8973c73fcb840dc68e826b57747a", null ],
    [ "InnerRCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#af060f4940a94b4cc82573a930122685b", null ],
    [ "OuterR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#a0a1864065e28ffc1284da5e47ea81f07", null ],
    [ "OuterRCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#afd31586a132504226023fa92bdd2b5bd", null ],
    [ "StartAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#a3b95cc9ab7be8fc4fd324596f88950c4", null ],
    [ "StartAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#ab0c92f84f0332c6363c5c9136cadebab", null ],
    [ "StopAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#aeb83982afba3595c5cfb8d692f1209b8", null ],
    [ "StopAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#a0f25de80ef44e0e1f64abd882ddac5a9", null ],
    [ "Thickness", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#a198fc9e9d4f41a25f37ed92c6f258f02", null ],
    [ "ThicknessCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_volume.xhtml#adbd8f055a102c38132d2bdf4c2eb9651", null ]
];