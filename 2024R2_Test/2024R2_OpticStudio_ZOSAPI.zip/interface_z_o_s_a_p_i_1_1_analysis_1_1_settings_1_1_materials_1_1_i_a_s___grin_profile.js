var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile =
[
    [ "MaximumIndex", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a68747fb672ce895f234945e109352497", null ],
    [ "MaximumX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#aed937bb8f7f0c9ffec737a2a696ee10f", null ],
    [ "MaximumY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a2eb2fc7dff35e168a60505017d58897b", null ],
    [ "MaximumZ", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a160de6860ecc9de6d40f3a3c8257a14e", null ],
    [ "MinimumIndex", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a9dc30c855a5d17704616961218f84051", null ],
    [ "MinimumX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a53a2f67e7ca48d7f8e803c5ddb6fbc1d", null ],
    [ "MinimumY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#aab75c836868482ed1a0fc38257824f93", null ],
    [ "MinimumZ", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a91040a4700f811be2e7890052d543158", null ],
    [ "ShowIndexVs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a034f886944ce512d17089777e8385d38", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#ae99eb7ca7d99778f7c86ec4c785beefc", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a11367d2f17e805513cb348faed92a8a1", null ],
    [ "X_Value", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a5bdf4b473a9ebfaa4b61158e4aa1551e", null ],
    [ "Y_Value", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#a3231eaba85804bb73972f307aef75fc5", null ],
    [ "Z_Value", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_materials_1_1_i_a_s___grin_profile.xhtml#af88674e721a7d575893ced33d606f686", null ]
];