var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag =
[
    [ "BestFitSphereOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#a7b0def4f0f799eb02fd180879679dd00", null ],
    [ "ConsiderOffAxisAperture", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#a3d5f2dfd778251592e102912ff81e0f7", null ],
    [ "ContourFormat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#a2068672f2e6e0f90ca79d49f2788c220", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#a883cde2f7f51ed4794c2d9e6603cc0f4", null ],
    [ "RemoveOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#ad0963ccde7ea0593913237f36801cfa7", null ],
    [ "ReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#a9f3ea8b42cdd285120c2fb79f2ec9652", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#a23069eb6cb55673cec4ea809cca9e264", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#a90fc000fa0191de7dba90bbd43c31b49", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_sag.xhtml#aacc4071912574f6cc7efc0d46b76bb65", null ]
];