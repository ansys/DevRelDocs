var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___surface =
[
    [ "GetSurfaceNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___surface.xhtml#a6db53859556a2055468fada14d907adf", null ],
    [ "SetSurfaceNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___surface.xhtml#a80bea455b19f17b1d27215530914be1b", null ],
    [ "UseImageSurface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___surface.xhtml#a291977ee1ff82e948147cf667ba78d59", null ],
    [ "UseObjectiveSurface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___surface.xhtml#a3ac6563aeffa5cd13064f3265079a5f1", null ]
];