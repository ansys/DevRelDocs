var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map =
[
    [ "ContourFormat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a12661481d381c2ed8a4b2cbf5aa14483", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a174caeeede0e071e1aab0a62dbccd21a", null ],
    [ "Polarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a0f8f08b327b60ee259c0106138ca69eb", null ],
    [ "ReferenceToPrimary", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a0bb440a684c36d578f0eeca885866fa9", null ],
    [ "RemoveTilt", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a5fc96a3c57e2b66ee6783f7f7ce1a090", null ],
    [ "Rotation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a2170650fbfdc8d6b41a2be9d6345ed4f", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#acede87154dd8ce95152a3903eee932aa", null ],
    [ "Scale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a9172513f405242b575b6f3a77b20be68", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a41feb8f75da1a41271a7c7bf2c6baf39", null ],
    [ "STAREffects", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a6dc3652869608a67801df17171a99810", null ],
    [ "Subaperture_R", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#adfe3802a1f85e9372c28fed2b467d56e", null ],
    [ "Subaperture_X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a13c95c268aef032b00943a2b6153e226", null ],
    [ "Subaperture_Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a6af019508b80c665f7dfac472ea7d4dd", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a11a667702602aa746b6c2430e212c149", null ],
    [ "UseExitPupil", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#a4d016922efcbe3d636ac66fdb931ebf5", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavefront_map.xhtml#ab9c51b89c306988c823280b86e116380", null ]
];