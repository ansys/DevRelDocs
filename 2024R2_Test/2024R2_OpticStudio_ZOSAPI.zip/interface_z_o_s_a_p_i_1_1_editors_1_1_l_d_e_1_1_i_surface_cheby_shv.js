var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv =
[
    [ "CxyCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#affb7b345d39f30750e7cf44b8d3a3dcf", null ],
    [ "GetCxy", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#a684710e5556faae48a33d80e28e71efa", null ],
    [ "SetCxy", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#ab0a6c3576a5194994e6cc93abab74ef8", null ],
    [ "Norm_X_Length", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#a554f635fd0d0feed095afd069a454c92", null ],
    [ "Norm_X_LengthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#aae03c69ba603a97ce8b56790c997db70", null ],
    [ "Norm_Y_Length", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#a9cc74f0ebb56203b0f9cbbe3ecc4ef61", null ],
    [ "Norm_Y_LengthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#a50db6a0c362029872b69fd5dd589386d", null ],
    [ "NumberOf_X_Orders", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#a67376ec1cf8f5710b7fcc0861336a25e", null ],
    [ "NumberOf_X_OrdersCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#a65d8b5dede3d0bfe6283e87ac68a4d17", null ],
    [ "NumberOf_Y_Orders", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#af167e60db9da6172b6df74ae52ef93df", null ],
    [ "NumberOf_Y_OrdersCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cheby_shv.xhtml#a67b96a60643cf0159788007d64e07713", null ]
];