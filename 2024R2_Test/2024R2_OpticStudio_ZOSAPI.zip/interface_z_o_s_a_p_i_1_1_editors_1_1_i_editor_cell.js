var interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell =
[
    [ "CreateSolveType", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#aab9b45b0e5c224d1fb31bce66888d20d", null ],
    [ "FillAvailableSolveTypes", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#ad851036d1aea84f8a0de833deec57f22", null ],
    [ "GetAvailableSolveTypes", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#ac5dec896d11746368814951497684a41", null ],
    [ "GetNumberOfSolveTypes", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a91705d24b2fab8a87bbf2fafce9a27fc", null ],
    [ "GetSolveData", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#ae0c95f74b1e478f92ff2a97354b93af4", null ],
    [ "IsSolveTypeSupported", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#aa5bc0f35fa6a33a3e452d4ed164ebe5d", null ],
    [ "MakeSolveFixed", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#af38440e9a0652d4afce454efe7947e8d", null ],
    [ "MakeSolveVariable", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a74076350d7578c5d5eabb0a35095f9d1", null ],
    [ "SetSolveData", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a5c0cbba814207920589ee69ffcfc0d36", null ],
    [ "Col", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a5a446d0edbf4605c82ba3a2cb3347e19", null ],
    [ "DataType", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#ab67aa971d6a1b93ac816c9f1008975f2", null ],
    [ "DoubleValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a448d127a24d2dee490864d76b84f94ed", null ],
    [ "Header", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#af94827ad6009db175dd6eda2d4d19971", null ],
    [ "IntegerValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#ae449d1e2d9af965fc6cec60f2a9334ce", null ],
    [ "IsActive", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#ae74e564207afa919d59841c9808c5010", null ],
    [ "IsReadOnly", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a765abfa384159cc595b1db0b7302f225", null ],
    [ "Row", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a755a5358b106101db4a5fcb7140cfcca", null ],
    [ "Solve", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a37a16d3e7f8669bc707cb46416581f47", null ],
    [ "Value", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_editor_cell.xhtml#a5332feff66987beb351ea0117b4c1b89", null ]
];