var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface =
[
    [ "RX", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#aac112074f5394a50be4f09569f702c9e", null ],
    [ "RXCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#adc69871f2726a6f664db73396951ed49", null ],
    [ "RY", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#a8ac061522218d20bce18441aec6eed7c", null ],
    [ "RYCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#ac18745ef02a967be3833b4c45710e14f", null ],
    [ "TX", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#a619fdf10b3e386e221e8048edf4f5aeb", null ],
    [ "TXCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#a994ae9e89d9f9f03c9513c50f11e0891", null ],
    [ "TY", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#ae546f15be7ac85ddfcdf103cae2dfdd6", null ],
    [ "TYCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#a450eee2ffbbb0f18d548e7f33bb9efba", null ],
    [ "XHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#a2eaebe7648a02636979a448385091824", null ],
    [ "XHalfWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#a2c9ba40676710757fcc551e63eb93440", null ],
    [ "YHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#a7454566e6a7b23b52b2398aa76b2b7d1", null ],
    [ "YHalfWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_dual_b_e_f_surface.xhtml#ac2d5474a2a7daca3ead2c8ecaa9ee3c6", null ]
];