var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___detector =
[
    [ "GetDetectorNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___detector.xhtml#af163ef8793bc7f09873c456801282620", null ],
    [ "SetDetectorNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___detector.xhtml#ad1d58eebd22900f71622b83219456264", null ],
    [ "SummarizeAll", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___detector.xhtml#a94e30a2f249a73b43b46d6fa002ee22c", null ]
];