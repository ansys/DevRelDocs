var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_importance_sampling_settings =
[
    [ "Limit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_importance_sampling_settings.xhtml#a034e9291ce19bff59b1c5f9af421beec", null ],
    [ "Size", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_importance_sampling_settings.xhtml#a8c01082a2d79f096e65067189defb631", null ],
    [ "Towards", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_importance_sampling_settings.xhtml#ad72e8046eac4b4a4b35a24e04c5a604b", null ]
];