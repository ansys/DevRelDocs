var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data =
[
    [ "AutoResample", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#a5835865aa83e7e7cb74ec57d3689d81e", null ],
    [ "DoNotRescaleBeamSizeUsingRayData", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#aa2aa30128a7273e4c35497476a785c8c", null ],
    [ "DrawThisLensOnShadedModel", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#ae3d5e1b95af77c97b082ae18cc818707", null ],
    [ "OutputPilotRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#af74e3b2027a224a5b4d2588e1b3919e6", null ],
    [ "ReComputePilotBeamParameters", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#afc0349d0cadff58597f93a8d6ef90b4f", null ],
    [ "ResampleAfterRefraction", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#a5448bd5bbe513f00ac229d6245abf300", null ],
    [ "UseAngularSpectrumPropagator", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#ab204b601ebd4a2359379280a2652314b", null ],
    [ "UseRaysToPropagateToNextSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#a827354f0c92dc02102b15f2d8937aa82", null ],
    [ "UseXaxisReference", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#af8d705361f21d87a53c95c74838384c9", null ],
    [ "XRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#affa09787c66941defd72592925c2075f", null ],
    [ "XSampling", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#a7c2120e3c55509ad07631185ece0fb4e", null ],
    [ "XWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#a4afb2d12cf950b3ca53e9fcf04d5b6d9", null ],
    [ "YRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#a02aa465e14b61419405936f11a9cf527", null ],
    [ "YSampling", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#ae39b11eba1c235b2c712e99f85bb9091", null ],
    [ "YWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_physical_optics_data.xhtml#a94ac52c0499b8bf73fe9200868f66cdd", null ]
];