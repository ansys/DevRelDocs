var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_power =
[
    [ "Coeff_R_NthPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_power.xhtml#aa49f7493fca94aa5904332dc7f35802c", null ],
    [ "GetCoeff_R_NthPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_power.xhtml#ac4b0ea3a7a147dc6dfe349c09035c4ab", null ],
    [ "SetCoeff_R_NthPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___r___nth_power.xhtml#ac867eb069c2bc31d59292b660668f27e", null ]
];