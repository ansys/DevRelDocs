var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular =
[
    [ "AmbientObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a2903a9348fb7cd564e145e048192171e", null ],
    [ "DetectorObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a9ec46978f424840275e7470554b470e5", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a01d01748c27109284c269d7f2466d9a0", null ],
    [ "HologramObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a5b6389e536016926449fb2a9d97ff174", null ],
    [ "InsideOfObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a679aac47c3986be3446e95c8d9050247", null ],
    [ "MaxAngle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a1d0243d29512b6099442c26aef8bf1da", null ],
    [ "MinAngle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#abf880c519919dee2f4066d4792f9abcc", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a9c53d2eba8e6c9938d5192ea1e3bfcf4", null ],
    [ "srcPolJx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#ac120622b8c071bb07dd58a649504d38e", null ],
    [ "srcPolJy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a0f9eebcabff525332f7cd73a71d8caa9", null ],
    [ "srcPositionX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a801f77d330e31ef75878595353a4906c", null ],
    [ "srcPositionY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a253cb0a96a4a43fdb07144797ecb65be", null ],
    [ "srcPositionZ", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#afc0591762e821c0950ed8b3f8893b4c1", null ],
    [ "srcPrePropagation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#ac254cbac6106ca9e3e452602642f4c74", null ],
    [ "srcUnpolarized", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a605fcdc47fd0c2e7360f9be77b496f88", null ],
    [ "srcXTitled", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a6d74b5033762fe74476ebe7475a7d3f6", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a4c81943a0457868b9f6722d04b81638b", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_angular.xhtml#a0a3615c9bc7473abd42695162d37215e", null ]
];