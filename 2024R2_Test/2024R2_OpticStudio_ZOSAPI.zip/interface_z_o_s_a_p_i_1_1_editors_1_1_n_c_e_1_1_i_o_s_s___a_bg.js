var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___a_bg =
[
    [ "GetAvailableABgNames", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___a_bg.xhtml#aa3f899744284fb453288799abbcb9b2f", null ],
    [ "ReflectName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___a_bg.xhtml#a15a64091cdf40210fce8276cdd9db9f8", null ],
    [ "TransmitName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___a_bg.xhtml#a3ad61358c5f2cda242237d57012ff86c", null ]
];