var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector =
[
    [ "DeltaX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a0f4b3432df616d3d4f6275f2026899a6", null ],
    [ "DeltaY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a156f671cfda6d1755c27e0398d0c1e2e", null ],
    [ "X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a6799ad4faf12cab8f22d93834e699cb7", null ],
    [ "Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a0d275302ae69f75d7955b01d10a1cc6e", null ],
    [ "DeltaXValueData", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#af97b8c3acaf3da8f2a093844fa3e69f1", null ],
    [ "DeltaXValues", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a3e964e93be833d80d41415c834723501", null ],
    [ "DeltaYValueData", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#ac477cefd6db8e637138396142f4ece89", null ],
    [ "DeltaYValues", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a483a67fa0c7b3dfa5e096b0c66cb39f3", null ],
    [ "Description", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a6ca563ff8709776fec3c06ace0808554", null ],
    [ "Dx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#ad73c1909f0a5bff9df31ad265f976796", null ],
    [ "Dy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#af3f4aee9d681a4ebf12425cae524ae7e", null ],
    [ "MinX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#abea7c4d89185b77bba96bb9b65a465ef", null ],
    [ "MinY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#ae69f2b5c4b54436fc0a19edc93f1574c", null ],
    [ "Nx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#ac605d70de064671b0c472ff23200f499", null ],
    [ "Ny", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a1999eee226d46b68ade9b1889c3eefe3", null ],
    [ "ValueLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#a77f72bf76036dff65791238ef3d8075e", null ],
    [ "XLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#aebe96359d71c070eef5e8a67ea5d20ed", null ],
    [ "YLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_vector.xhtml#aa8204840b073558be529f4e9321aade0", null ]
];