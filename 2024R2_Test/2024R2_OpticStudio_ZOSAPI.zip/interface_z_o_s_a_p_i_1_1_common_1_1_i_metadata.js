var interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata =
[
    [ "ConvertFromBinary", "interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata.xhtml#a8e5bfb94239493967af4c7be65cc53a0", null ],
    [ "ConvertToBinary", "interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata.xhtml#aba4dfbe8b303bde26bee078a851f2bc7", null ],
    [ "CreateGuid", "interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata.xhtml#a2375480900846e8847e4aa5e711f73c0", null ],
    [ "GetData", "interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata.xhtml#a9af7c6589e6bdb6be447e58222780077", null ],
    [ "GetKeyName", "interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata.xhtml#aad12ddcc6951c2ba774e36e118be36c5", null ],
    [ "RemoveData", "interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata.xhtml#aff5188a0436eaaf0ebd8a5b6257bb2ea", null ],
    [ "SetData", "interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata.xhtml#a7f47c708fd816e2cab402d995b5e09bf", null ],
    [ "NumberOfKeys", "interface_z_o_s_a_p_i_1_1_common_1_1_i_metadata.xhtml#aface6bd1c89bc51c13fdc53f7db764f3", null ]
];