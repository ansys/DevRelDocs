var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data =
[
    [ "ChangeApertureTypeSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data.xhtml#a14089fd69c14646e13d066f718d084d1", null ],
    [ "CreateApertureTypeSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data.xhtml#a4dbb443475e2249c33d73b10c50c8ece", null ],
    [ "SetPickupNone", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data.xhtml#a167e5ae61e280f78013c68cddc4a8e97", null ],
    [ "CurrentType", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data.xhtml#a1a889b7ef609eb0c1b77f4e793c46786", null ],
    [ "CurrentTypeSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data.xhtml#a4a38e4c04d8d2ff12336f8dc8ffb22cc", null ],
    [ "DisableClearSemiDiameterMarginsForThisSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data.xhtml#a60271be9abb4a8e5941e48b2239e7747", null ],
    [ "IsPickedUp", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data.xhtml#ad7bc156d65107ee782e7c7b48bc8e534", null ],
    [ "PickupFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_aperture_data.xhtml#a95f7da62e392cf29eb8e5cbfae106adf", null ]
];