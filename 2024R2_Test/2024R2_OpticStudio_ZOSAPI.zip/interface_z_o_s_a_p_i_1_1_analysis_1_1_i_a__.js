var interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__ =
[
    [ "Apply", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#a594dbc69e6e0dc6abe0788e05c0625e1", null ],
    [ "ApplyAndWaitForCompletion", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#aff285af72f196b9c4915c531ff9873a4", null ],
    [ "Close", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#ac90e99f359e260ded477194f16465d77", null ],
    [ "GetResults", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#a4c6f286eaffe67e97984cf1f91cc5cef", null ],
    [ "GetSettings", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#af82c93423d06452642e5cb31203cc109", null ],
    [ "IsRunning", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#a3e7bf10bc3c834c9fd2b7df459fdf6f0", null ],
    [ "Release", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#a00105beb2487c03cbf6615a33071680a", null ],
    [ "Terminate", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#a764ca87cbb1df1a48d2c6353538094aa", null ],
    [ "ToFile", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#ab137ee351d3a097e9162fd588c53a72e", null ],
    [ "WaitForCompletion", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#a8ef153c1ce41e66e3352e717905bf543", null ],
    [ "AnalysisType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#aa5ccb96c9ccafd4d63974858eb150ec4", null ],
    [ "GetAnalysisName", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#a07afa6a01b14033c0c07c90f3cc582ae", null ],
    [ "HasAnalysisSpecificSettings", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#a96db558bda38b70d914811e7fd652c8f", null ],
    [ "StatusMessages", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#aaad3a530e0ff2f372ce583b50df87362", null ],
    [ "Title", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_a__.xhtml#ac171cfa0fe0ffe86771e2762ece3249e", null ]
];