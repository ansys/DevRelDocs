var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field =
[
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#a8d3e697e94a54132246c74164e439e21", null ],
    [ "FieldDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#ac73dfcccdee7f6ed0e04426266302f46", null ],
    [ "Method", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#a2f0c9c4655658b75c22056833379a258", null ],
    [ "Orientation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#a2b049f7f435298a829adf0ed1135e94f", null ],
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#aea9988812f786111c2f08a6514ab1e9b", null ],
    [ "RayDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#a46bfce6a99092f1368d8aeb3d59b323d", null ],
    [ "ReferTo", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#a411c5bdbb5c101a2c2127adb1a06b914", null ],
    [ "RemoveVignettingFactors", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#aa0d4c6dc39cc89605304f78be2639e7b", null ],
    [ "ShowDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#ad67a0107482470c74c7cf191c531967d", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#a57bf1e8d6a18526f4c4814dd66bd1e7a", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#a8f15fbdf3c3418c5db0b662be1736397", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_field.xhtml#a4360d93a336db7761df9c488e5ae4863", null ]
];