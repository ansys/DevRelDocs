var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog =
[
    [ "GetAvailableISFiles", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#a6571295b32ba2fede274240477795ab3", null ],
    [ "GetReflectFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#a37723541cde213cccf2e87379f96fe38", null ],
    [ "GetSampleSidesR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#af26ae2596c1dd81cd49aada7a6cb74e7", null ],
    [ "GetSampleSidesT", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#aef981f261cb60e2274751d377f2f4fc8", null ],
    [ "GetTransmitFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#a07e1535fe8ca7ac2af18822ab6001dc5", null ],
    [ "SetReflectFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#a185bb6917b5099429fa10925bf85760b", null ],
    [ "SetTransmitFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#ab90192fbfbe09730ef4e2dda4dbcdcab", null ],
    [ "Angle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#a58888aa7dd9550daa57e53d8758753d8", null ],
    [ "SampleSideR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#a5fcb388cb98718c5e1072139c31b66ed", null ],
    [ "SampleSideT", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#ad2bc545b299004e7659025c48787cdf3", null ],
    [ "SamplingR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#a079ed61a93bbd1c9e4cbce2912b9c130", null ],
    [ "SamplingT", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___i_s_scatter_catalog.xhtml#af6dfa98b1aa1c517187469e9024b2eb4", null ]
];