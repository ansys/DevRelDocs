var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular =
[
    [ "IsVolume", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a10edce126014820523ef973718ee1985", null ],
    [ "IsVolumeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#aac323bfb10c2f3ef90c93d040b923621", null ],
    [ "Length", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a65faba92ef9d5d4cb680d02b071f7dc5", null ],
    [ "LengthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a21bc76235c109603d793fd6d64ffb325", null ],
    [ "VolumeIndex", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a6fe116061889f354135541fed2accbfc", null ],
    [ "VolumeIndexCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a7d8fe5d4935a4696fe3d78b985476d72", null ],
    [ "XAngleDegrees", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a63a09fee14681ec41d4ec8496911d438", null ],
    [ "XAngleDegreesCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a6987c5a36d00659d7ab38541ae6de422", null ],
    [ "XAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#aa178acde408bf771a3dd7d60a550f089", null ],
    [ "XApertureCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#abb6d4b61c5dcfe5446e76f403d09d15f", null ],
    [ "YAngleDegrees", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#ac6f0221295d533159f84d88bc24ada79", null ],
    [ "YAngleDegreesCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a11b1cb8acfd6cec60cfe81e237c23834", null ],
    [ "YAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#a8949e0a0d145c81c2ab196b64ab0b355", null ],
    [ "YApertureCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_p_c_rectangular.xhtml#ad2ac3bb728cd3081bb20a4a48b657a25", null ]
];