var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotation_angles =
[
    [ "Alpha", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotation_angles.xhtml#ad58c15aa36c4d05e2a2007675fed8a47", null ],
    [ "Beta", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotation_angles.xhtml#a2aa8307d29ae0e70ee5b992d732bf956", null ],
    [ "Gamma", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotation_angles.xhtml#ae3966a427314e0f4aa5b965e2c17fe06", null ],
    [ "ThetaX", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotation_angles.xhtml#a07299eca1608c8b6433aa30b5fa20680", null ],
    [ "ThetaY", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotation_angles.xhtml#a6acbd81cb150674c232727e893fbca51", null ],
    [ "ThetaZ", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotation_angles.xhtml#af17384e16a0950be42739dcf5b626c87", null ]
];