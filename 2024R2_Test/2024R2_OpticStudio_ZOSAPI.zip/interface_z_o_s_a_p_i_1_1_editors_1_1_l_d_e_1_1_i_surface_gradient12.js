var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12 =
[
    [ "GetNthNx", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#a1ac7511e9f172c155e18719e5368b922", null ],
    [ "GetNthNy", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#aa089b20d9e29381e8d604444dc95c2f5", null ],
    [ "GetNthNz", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#a91fad16228d201d9f4fe121e8f35316c", null ],
    [ "NthNxCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#a8b9786bf8a77cfd7b75f1785bcc28313", null ],
    [ "NthNyCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#a53ec22c9a3dbf9896b39c43056754a37", null ],
    [ "NthNzCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#a5e3a1f70f46bf1910cfeef5aa3ec32d4", null ],
    [ "SetNthNx", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#a465006dcc4b3faad688a96966acdd2d9", null ],
    [ "SetNthNy", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#aa76a8eda18b95a005602528020abec2c", null ],
    [ "SetNthNz", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#ae4f8aee354a59f315eb52c2780fd1347", null ],
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#ab5bdd198050e827c34d7fa1cff4f150b", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#a41f0ac616164646a037f01234961f423", null ],
    [ "n0", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#ab997f197eb6fd4a1ca3a952ec25f9d5a", null ],
    [ "n0Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#afb68b5591d941996f15c550f0cca3ad2", null ],
    [ "Order", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#ab3cc0e87473195cc2dfbe5a1992919d8", null ],
    [ "OrderCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient12.xhtml#a45477932e7c98a6d5d6da798295220cd", null ]
];