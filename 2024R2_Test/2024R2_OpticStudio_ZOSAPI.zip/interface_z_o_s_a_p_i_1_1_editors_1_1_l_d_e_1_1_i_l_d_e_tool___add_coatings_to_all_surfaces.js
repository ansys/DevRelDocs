var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_tool___add_coatings_to_all_surfaces =
[
    [ "AvailableCoatings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_tool___add_coatings_to_all_surfaces.xhtml#a05f3ffe055daad7378067e04b96f8226", null ],
    [ "CoatingToAdd", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_tool___add_coatings_to_all_surfaces.xhtml#aa51180d0a0c6e7af0330e1569ce667fc", null ]
];