var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_lambertian =
[
    [ "ScatterFraction", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_lambertian.xhtml#aeb8faa0b638b8ad536f1dabe3306ecaa", null ]
];