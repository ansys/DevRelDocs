var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map =
[
    [ "Frequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#ada7c5927f8623e76aac96ea603db0e7b", null ],
    [ "MTF_DataType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#a7ef05927e8cc11fd4551226376332c9d", null ],
    [ "ReferenceField", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#ae03f2829f5a2f0381fdc7fc41bb48deb", null ],
    [ "RemoveVignetting", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#a844f706f1eac621999e6cc9d67f71a2a", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#a17199dfc3f03714e7b3af7dbb880ce12", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#abf64f3bf8e8424d2fedee43aa43216d5", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#a9d390629fff27d2bda4a390ef8a10dff", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#a806ed8008a46eda4c605b0bc66b1dddc", null ],
    [ "X_Field_Width", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#a8b7aa3e5e7a1017feb1a4fa72972e069", null ],
    [ "X_Pixels", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#a755c2a5de28f05b24bb8deb0f8a29c18", null ],
    [ "Y_Field_Width", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#a475730af86bfc191917fe1435d5571af", null ],
    [ "Y_Pixels", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_mtf_map.xhtml#ad4a61c541740779d7787afe282d7d263", null ]
];