var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform =
[
    [ "AmnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a20017a0e4f7e91ee087462af917a1d5e", null ],
    [ "BmnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a162f9d9bbb473d3b02013b13544664f7", null ],
    [ "GetAmn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a6fe44c4a0a3393eb7631d473339da4e3", null ],
    [ "GetBmn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a1abcefe1bff992195bcdd56bf3daa1c4", null ],
    [ "SetAmn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a7570ed6d4627f7261310e4f8952098ed", null ],
    [ "SetBmn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#af568de6d08ce8d238e8b0c196be6cb4c", null ],
    [ "DecenterX", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a059b6390d7e7f0bdc5a274d49c98d484", null ],
    [ "DecenterXCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#afd9c329ede8dbba458bc59760756fec4", null ],
    [ "DecenterY", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#aab57a7a47041712bd01d803f362327cc", null ],
    [ "DecenterYCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a29fc7f02b05a71c8550d34017a4c2f94", null ],
    [ "MaxPolynomialPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a70724cbaab17a1e214a09be6cb681afa", null ],
    [ "MaxPolynomialPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#a237e4acf313eab07e952321f660ccfb0", null ],
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#ad03eb23966fa54a243b7676f0821144a", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_q_type_freeform.xhtml#aee61a6667faff041514c474a8592275e", null ]
];