var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike =
[
    [ "GetCellXn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a550d191e6ef3f30f20a8729e37ea07b0", null ],
    [ "GetCellYn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#aab776e70db53c7f90ce75fa1bcc09f39", null ],
    [ "GetCellZn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a442cd545424c5f4c1fd0099b395f900c", null ],
    [ "GetXn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#af789feb7c1aa8cc48c81c178edc3f649", null ],
    [ "GetYn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a1b18ba89eee28ba6069b7d0f71c09079", null ],
    [ "GetZn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a1d153626ae7c612bf1cc7d070d678f67", null ],
    [ "SetXn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a09ad91c972fe4e8e18e65f9ef6e7649d", null ],
    [ "SetYn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#abeab9b81e28ecda51a3bcdeb55f514ba", null ],
    [ "SetZn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a279a27f32e2300d703d934290e1dc3ec", null ],
    [ "Extrapolate", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#aaefd7bc34a54ea2a74d62361481d89b7", null ],
    [ "ExtrapolateCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a8ac20e42e1225162f1a6145851c753ee", null ],
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a8962feda56f5db7d68016bb23dd252a5", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#abb18c6c4e3c637dcb4e80ca6c1553fb5", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#abcab8f890efb4d927e073fbc930d3a46", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#ab771398f91f1dc2499b776f5647dbc03", null ],
    [ "XConic", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a49cbf13b6a2b7d39279ee239743adb27", null ],
    [ "XConicCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a2ae293df946eaae0c4f6f84aa6515d37", null ],
    [ "XRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a41a4e89c44f1b64fe87b293c3807fc77", null ],
    [ "XRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_biconic_zernike.xhtml#a2f6148c1dbdddd114731decd1300fb05", null ]
];