var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data =
[
    [ "MakeAllObjectsDrawLikeThisOne", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#a471e3c729259ea2f6b3b1cb67ccf0569", null ],
    [ "DoNotDrawObject", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#a716b37cbe01b65b4b97c9dc22c29cdb6", null ],
    [ "DrawingResolution", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#ac4a573a288d78eed465c88e6da42ddd3", null ],
    [ "DrawLocalAxis", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#aa2bb575d8f888c880e60db5671af2361", null ],
    [ "ExportAsTriangles", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#af3e7fd5d09a87bdfabc1f3b9f780b3c1", null ],
    [ "IncreaseResolutionOnShadedModelLayouts", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#a02fa5219dbe03b19408f37503b789e73", null ],
    [ "NumSegments1", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#a74e21f587a5feb5e042fa44a3de26ac7", null ],
    [ "NumSegments2", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#a14f7825a4e9229f209d704333a5aacfa", null ],
    [ "ObjectColor", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#aedd01642239ba9a06d2828313b13ec6a", null ],
    [ "Opacity", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#a0faaf10a0cab05b6dc823b6078d9cee5", null ],
    [ "Segments1Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#ae08d64db712ac6e84a3e88249afc3d6a", null ],
    [ "Segments2Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#aaa99e5e5d091fea8a10c674547e9a8ed", null ],
    [ "SupportsDrawingResolution", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_draw_data.xhtml#abd4faaf2699c87ac0bd70644db3602c6", null ]
];