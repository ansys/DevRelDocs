var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_grid_gradient =
[
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_grid_gradient.xhtml#af27a137d66b5b9d1332ebc29b704002b", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_grid_gradient.xhtml#a6a117c5c99c23cb26b2fc399d39f78d7", null ]
];