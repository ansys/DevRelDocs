var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus =
[
    [ "MaxXHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus.xhtml#aec5a63e5f0687b58d917473359e96487", null ],
    [ "MaxXHalfWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus.xhtml#abae44310dcfb89808ea29a30ec99d418", null ],
    [ "MaxYHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus.xhtml#abda15880ab591a9290afddb8cc1c40d1", null ],
    [ "MaxYHalfWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus.xhtml#a0746c0eb0032d1cc780c667612a282ed", null ],
    [ "MinXHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus.xhtml#af0ab86d0fbf84e0bd8bca49367c287d8", null ],
    [ "MinXHalfWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus.xhtml#ab45cf91bf930b4dda6ed8473b8ef1523", null ],
    [ "MinYHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus.xhtml#a06161c7b1f5e6659407991d16e1bd559", null ],
    [ "MinYHalfWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_annulus.xhtml#aa28968ebdaab5757db47615488cb63e0", null ]
];