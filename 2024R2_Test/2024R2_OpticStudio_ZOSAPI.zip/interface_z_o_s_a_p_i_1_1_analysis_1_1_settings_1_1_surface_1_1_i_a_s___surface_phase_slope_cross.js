var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross =
[
    [ "Angle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross.xhtml#a8e18835b57282fdf1aed4c1198e59fea", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross.xhtml#a58e36ff9e126d507ac53ab7ada3b230e", null ],
    [ "RemovePiston", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross.xhtml#a9d53f79a5d3ac054a19c4c25d00fb715", null ],
    [ "RemovePower", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross.xhtml#ac3df4313340f71493e46cd9ca34b9d5d", null ],
    [ "RemoveTiltX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross.xhtml#a7c90a49974ad14cdfb5420d7bfa9f140", null ],
    [ "RemoveTiltY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross.xhtml#adbd3e41e4f3115b108d65d00f80d757b", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross.xhtml#a24be794e64ef5ee06ab6a94ff4df31e7", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope_cross.xhtml#adf08ff6c989da03cea9f6d9589e61278", null ]
];