var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope =
[
    [ "ContourFormat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#a8639aa6162a497e335e4cf5ffd971406", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#a2ce97de1acdf2a25837df3495e7b0f8e", null ],
    [ "RemovePiston", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#a421974260a6b61c5f999c1081996dd78", null ],
    [ "RemovePower", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#a7fd8eaa3adb7578e0d1e27b923ef67b4", null ],
    [ "RemoveTiltX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#adf85feddadb5cf9be54e5d246347f1eb", null ],
    [ "RemoveTiltY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#a9f7d50905850a78b7d3270185d3ff87d", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#a8daf86264ddd8b2231810f8635685b1f", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#afea3506edb6fc2c10dd3d3f1218b1c40", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase_slope.xhtml#a3d8d26a9fa4a88f83922e90b3076ee32", null ]
];