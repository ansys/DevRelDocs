var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic =
[
    [ "AmbientObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#abbd3c68bbbdd0d4cbaf5db5558e46f25", null ],
    [ "DetectorObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#af30f0fba696f44a73c95d8158f18886c", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a8fa5abb93d379d7c4fd9399392e693fb", null ],
    [ "HologramObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#afa1ad7e9371294b07c8e1e9a1ed4ff89", null ],
    [ "InsideOfObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a15f685bbc869dae33100a41c823dbbb9", null ],
    [ "MaxWavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a97d67bdf2168bc60a7e5338eac78a547", null ],
    [ "MinWavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#af34bab45fd6413f14d70d2fab42d4434", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#aea75d153c347e646954aa631c51cc6dd", null ],
    [ "srcPolJx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#ae42fcb07f0707d575a832cbbeb2f2f9d", null ],
    [ "srcPolJy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a1e9115985196e0bfa92c56e1b765a638", null ],
    [ "srcPositionX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#ac8f5dd5bd9128dc435fb23211e368e42", null ],
    [ "srcPositionY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a6c47e393b2454bab0cfa4819b2a161fb", null ],
    [ "srcPositionZ", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a316c190259fe08a36e087028e4a0c8a3", null ],
    [ "srcPrePropagation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#af1401fcc08890a20cbaf7427be5f7f25", null ],
    [ "srcUnpolarized", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#adde37dd1d307085e56c51b061004da2c", null ],
    [ "srcXTitled", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a425744a1e4c04c7c8cd6f5ae886923c9", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a475ecb89b51f342097a0b6180c0759c4", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency_chromatic.xhtml#a260fbfad87cbc3d320f637eefeef6aa4", null ]
];