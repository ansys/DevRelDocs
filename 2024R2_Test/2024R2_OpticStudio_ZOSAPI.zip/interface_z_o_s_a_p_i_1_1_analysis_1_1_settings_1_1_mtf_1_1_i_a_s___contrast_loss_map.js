var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___contrast_loss_map =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___contrast_loss_map.xhtml#a6412c89a2495761e186711129e1a2fdd", null ],
    [ "Frequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___contrast_loss_map.xhtml#a47bb63ee1fdc376e565d2d01f1279f8f", null ],
    [ "Normalize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___contrast_loss_map.xhtml#a34f51645326e044e9728c6810891d227", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___contrast_loss_map.xhtml#a4a830727113508e354a7efa2da33e15e", null ],
    [ "ShowOPD", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___contrast_loss_map.xhtml#a0eaa093454c15990e6c68e728c87b49a", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___contrast_loss_map.xhtml#a40a053411fae7cc62655b735d0dc9fd5", null ]
];