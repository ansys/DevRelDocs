var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_data =
[
    [ "GetNthExtraData", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_data.xhtml#a78951acadf63123e8c3819cb952c6c9f", null ],
    [ "NthExtraDataCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_data.xhtml#ad3b7f1c4d0ce169414e7b4ca8f6a2478", null ],
    [ "SetNthExtraData", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_data.xhtml#a97a20c94a95af3caaac24ae353ca0ac2", null ]
];