var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf.xhtml#ab9f77a116a9a0e27180fb60484047644", null ],
    [ "Rotation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf.xhtml#a6d2abd5546597faf1013286e2d63b75f", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf.xhtml#a5a55aac10cc1edd08cd2199779afca8d", null ],
    [ "ScaleFactor", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf.xhtml#a6b6394cdb089befd21934fad698ee3ca", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf.xhtml#ae18f049e3c5d544c4ff2e6244521c963", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf.xhtml#ab86481bb4d9304cf5697951271c56955", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf.xhtml#a650e9f914de9a403d1f85a6bc9cfe481", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_surface_mtf.xhtml#ae0635f16f311ff9b43fe14f077dc4a32", null ]
];