var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot =
[
    [ "ColorRaysBy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a4f7d11baced951242445b3013cfc91ff", null ],
    [ "Configuration", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#adf85f84cf046ba3810f8cede836c2c87", null ],
    [ "DeltaFocus", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#af859f9aecefe53751bcc17b6afe222f0", null ],
    [ "DirectionCosines", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#ae6261efeda3c3ef1de1ff5c9791f2ace", null ],
    [ "Exaggerate", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a01977c08d13a7d8720332f59744d6b84", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a48f3e03fca527bd2ef081f3e8fe5b185", null ],
    [ "IgnoreLateralColor", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a41ac085359c382bfd8fc0c4c774516c0", null ],
    [ "Pattern", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#add0386cf95ec0df54f73577d4b73cd5e", null ],
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a8fb327d1709acae2e68fbb6a8227e203", null ],
    [ "RayDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#afe69979aab626eeea9cb5ed8f2ed17e9", null ],
    [ "ReferTo", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a5d874053da75956c4a3bf0d0ad895613", null ],
    [ "ScatterRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a772e079e6f5e54a2f6cf63feaac4efa1", null ],
    [ "ShowAiryDisk", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a331964616d2ffdc353d0a133d8fc7dde", null ],
    [ "ShowScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#aec6e6c40a753cca712d3d4c917e74ccb", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#a3b9e49b701b1d6a3b0ce8428261bbc43", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#af4435330d1b0c60c5f546d84d02d9f8b", null ],
    [ "UseSymbols", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#ab184a912b248c533ba8d4a37fa2d941a", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_spot_1_1_i_a_s___spot.xhtml#af17353a5d59cf503f0f2d14109121979", null ]
];