var class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection =
[
    [ "ZOSAPI_Connection", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#ae6a7ccfa18e85b299e7b8deb53784412", null ],
    [ "AddInitializationProgress", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#a5a6dc9015021662dfdb8de813a946afe", null ],
    [ "ConnectAsExtension", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#acc229ae487281fc0aae93e470d9012e3", null ],
    [ "ConnectToApplication", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#aeb9010dade0f9685d455425d7eb7d8f5", null ],
    [ "CreateNewApplication", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#aadc54af7d7415a765592acf23d3a08ef", null ],
    [ "CreateZemaxServer", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#ac5a1a6e0cd4471e311063a93a7364478", null ],
    [ "CreateZemaxServerEx", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#a6e2f7726aad2dfb4dff4ce6b4e37905a", null ],
    [ "GetConfigSetting", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#adbd4b91b67032fdf22ec234c1504d034", null ],
    [ "RunCommand", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#a25ac733120b770870ae8b29ae5dedd3c", null ],
    [ "SetConfigSetting", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#abf86fb8f2afa7d151aac3edffba1112e", null ],
    [ "SetCreoInstallPath", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#a7fb82eee18d1effa877e14e91bcb7d67", null ],
    [ "ConnectionTimeoutSeconds", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#a78bccc848680a14183d566abef3db95c", null ],
    [ "FormattingCulture", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#af7b5adda339e520acc906448caafdf8d", null ],
    [ "InitializationSettings", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#a88c533ef108da80512b694850358dd57", null ],
    [ "IntializationProgress", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#a2fac04f5e9c7cb72085e1c95fd948416", null ],
    [ "IsAlive", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#ae1039e03d33469f50075ccdcd53384c1", null ],
    [ "PreferencesFile", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#a18dc1b1ef3fac28798acc2ecdedd3e08", null ],
    [ "SystemStatusChangedEvent", "class_z_o_s_a_p_i_1_1_z_o_s_a_p_i___connection.xhtml#ae82cd6a492d881b337d011af667dd877", null ]
];