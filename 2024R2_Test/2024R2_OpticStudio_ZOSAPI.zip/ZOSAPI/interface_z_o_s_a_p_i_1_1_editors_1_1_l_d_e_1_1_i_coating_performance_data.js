var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data =
[
    [ "GetCoatingPerformance", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data.xhtml#a84ab54adfade902146b9f34fb0d08559", null ],
    [ "Absorption", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data.xhtml#a66c569969ec12757fa9f7f6b56b7b178", null ],
    [ "Diattenuation", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data.xhtml#a890ef8a55c912526c95b0b57f7d2f778", null ],
    [ "Phase", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data.xhtml#a81359a48ccf26c73c0003477655b63a7", null ],
    [ "Reflection", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data.xhtml#a7481a6f1a299c4bae8307fe9a2d06be9", null ],
    [ "Retardation", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data.xhtml#a57da593e340e9ed5f92e9dcfaedb4d96", null ],
    [ "SurfaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data.xhtml#a2ad6e2a0661a49004e0c1b4c8ad9e43a", null ],
    [ "Transmission", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_coating_performance_data.xhtml#aff88cd3ccaf8da1821caf2eaaa91104d", null ]
];