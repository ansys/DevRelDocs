var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data =
[
    [ "Advanced", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#af00d328e42650319df240ce5501ef1ae", null ],
    [ "Aperture", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#a1b6e31d087dab2cd9778f73dbf604f1c", null ],
    [ "Environment", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#a0874eb4462f9f5eaef9590c39c5cad98", null ],
    [ "Fields", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#a86c457ff0635211b4c8ac1816f2b1d25", null ],
    [ "Files", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#aac14b796721590711d395dd361dbc1cb", null ],
    [ "MaterialCatalogs", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#a59915a1f5ea9ad13dd27aaf4e302c4d7", null ],
    [ "NamedFiltersData", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#a4c81de7e13463faadda51c55218af1c6", null ],
    [ "NonSequentialData", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#aee7658799ccdc775d1392861e40511c9", null ],
    [ "Polarization", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#ac6dfe3dfd4f79d7881959c5113da1991", null ],
    [ "RayAiming", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#a66b63f98aa33876bca31830f1912aebb", null ],
    [ "TitleNotes", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#a41e6e38599d823e88a5946fc85e1e574", null ],
    [ "Units", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#ae3b377657650d4b024fe9fc3f17f8f21", null ],
    [ "Wavelengths", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_system_data.xhtml#adc3ab867ef04c79e760a3726b9509fa7", null ]
];