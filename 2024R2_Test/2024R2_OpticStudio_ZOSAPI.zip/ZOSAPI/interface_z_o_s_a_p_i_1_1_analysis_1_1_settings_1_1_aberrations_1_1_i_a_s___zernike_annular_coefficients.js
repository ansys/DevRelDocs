var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#a808f18be2a4f33aac6f02ad671cd2ee1", null ],
    [ "MaximumNumberOfTerms", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#ac9cb2d97356db8bfd48a68cdb29dd4a8", null ],
    [ "Obscuration", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#adafa6552f22772c75bd0442f71ae20f8", null ],
    [ "ReferenceOBDToVertex", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#a37366e93b4d403cf1ce889a932eb2039", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#ad7902fffc7ccc466b4d5f6f170344c7c", null ],
    [ "Sr", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#ac7a972206d57e7823cbcf17639a5927a", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#a685a0c144730f17290a42f4487526246", null ],
    [ "Sx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#a84fe5d96da1258a897c6cacd20ca5501", null ],
    [ "Sy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#a015a3906068eba103557ffcd6ea418e3", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_annular_coefficients.xhtml#a42ef3d6050b4ca868b169fd83ec41f15", null ]
];