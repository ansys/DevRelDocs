var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_thickness =
[
    [ "GetNthThickness", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_thickness.xhtml#a239f441aba1a4d815bdc637bff0d92ea", null ],
    [ "NthThicknessCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_thickness.xhtml#a8fe50aa2ddd435e33dc2f50d243b49b6", null ],
    [ "SetNthThickness", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_thickness.xhtml#a893bfd68a2eaef975353872d16fc168a", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_thickness.xhtml#af6b809c478686b676940c88bb353bc1d", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_nth_thickness.xhtml#a097616b1bd94d08caefa3290ff7aaae5", null ]
];