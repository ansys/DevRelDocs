var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___critical_ray_data =
[
    [ "GetRay", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___critical_ray_data.xhtml#a34f7fbefd5531ead351f4a267e4c1581", null ],
    [ "HeaderLabels", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___critical_ray_data.xhtml#a7954aaacec9cce837e6f9fbc76ffff40", null ],
    [ "NumRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___critical_ray_data.xhtml#a270b3642b6492596b0e6fc85dd98402c", null ],
    [ "Rays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___critical_ray_data.xhtml#a80805911a7eb2fa9d15abb6ff8a019b6", null ]
];