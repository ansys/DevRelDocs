var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic =
[
    [ "GetUn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic.xhtml#ac0de85318944d2806890cc2d6c808166", null ],
    [ "GetVn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic.xhtml#a5368e9aa30da9941fb0892d84c3981c6", null ],
    [ "SetUn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic.xhtml#a61981205e760c9dbeb3e759da45400ae", null ],
    [ "SetVn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic.xhtml#ac7fa870623051174b481e124f551e919", null ],
    [ "UnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic.xhtml#afba4e3a11794fadf5a94c459a0b7b055", null ],
    [ "VnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic.xhtml#a744d34071011241cb0d726ff1a27c1ab", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic.xhtml#aca484688fd29be5046debb3a79caae3a", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_superconic.xhtml#ab7d25c0d93e62521f00d3391dcd71fbb", null ]
];