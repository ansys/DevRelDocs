var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___focal_shift_diagram =
[
    [ "MaximumShift", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___focal_shift_diagram.xhtml#a6b4179e3f992ea02cd3837f5a44dc51a", null ],
    [ "PupilZone", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___focal_shift_diagram.xhtml#af68dd14789d6f93fc645522adfde8514", null ]
];