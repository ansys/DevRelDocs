var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___lateral_color =
[
    [ "AllWavelengths", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___lateral_color.xhtml#aa53798b96760cb28fc8889f96fa2ffc1", null ],
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___lateral_color.xhtml#a05d96069dfd1debd78507c6c60bf9276", null ],
    [ "ShowAiryDisk", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___lateral_color.xhtml#a9bef358754172131c2d16ceeb4364a2c", null ],
    [ "UseRealRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___lateral_color.xhtml#ae619d2d49d39b81292abe4942ba27216", null ]
];