var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user =
[
    [ "GetAvailableDLLNames", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#ac8d43cf1b66d80c058e6975b64235d60", null ],
    [ "GetAvailableFileNames", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#a53c17fad2a5a32cc6a77280fbb889f01", null ],
    [ "GetParameterName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#a2891598e7fe0a498d9405d54d4b7d6e4", null ],
    [ "GetParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#a1b414619ac986b9e807462b13836d8c0", null ],
    [ "SetParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#a9389116f92cb0c2d92f4f3504dd3232b", null ],
    [ "DLLName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#a68d9fea70c9222132222c663392540c3", null ],
    [ "FileName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#a29810340f1f495cb2e5baef9326f6200", null ],
    [ "FileNameRequired", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#afc39a38e3fead1998aec0aa53e008b5f", null ],
    [ "NumberOfParameters", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#ac4e2f916a52bc1aa6b2fc4cba83a5526", null ],
    [ "ScatterFraction", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___user.xhtml#af3d1af7d1437b8776bb5bec230c9bd4a", null ]
];