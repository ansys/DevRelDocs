var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section =
[
    [ "Configuration", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#ae7734fc8b66c6203ffb0d32b2817e1f6", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#abf37fc17a809e37200ff80fd8a1eb1f9", null ],
    [ "ImageDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#a32e9ea0743ffe62959dc0e88f1d598b3", null ],
    [ "ImageSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#ae1625a0f0d20051dd9db28c00f4f9403", null ],
    [ "Normalize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#a29eb56bc7cdf62c20f70b42a20d00c71", null ],
    [ "PupilSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#a8b02eb3b8a780ff9ae07a364e8e50697", null ],
    [ "RowCol", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#a478951dd88f8a20e09dcc77c0b078691", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#a28f789979298a31be5404668ddf688aa", null ],
    [ "UseCentroid", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#ae2dee0d98a5fd8fbb70bddcafa413d2d", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#afd7f088cd61fcf5f4d49417f6d3dc1d9", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___huygens_psf_cross_section.xhtml#a6c43421805b6796fb06b7ffc958edf07", null ]
];