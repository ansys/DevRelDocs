var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s =
[
    [ "GetPixelAddressGroupN", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a432080b5046ca66cacbee1de3ce19ed2", null ],
    [ "PixelAddressGroupNCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a77a46e3f11b871f3e6e57e81dc564412", null ],
    [ "SetPixelAddressGroupN", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a8df4397f6658c8185423c77bbbcd99f6", null ],
    [ "Angle0", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#ad8848b41c9c26369742883973503bd74", null ],
    [ "Angle0Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a78c785eaac3c0ab5c37b33452c78d0a3", null ],
    [ "Angle1", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a32231a64778de3f5bce2421d03cc4808", null ],
    [ "Angle1Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a9e187c1bcff686378006f8b932d2a4c2", null ],
    [ "Angle2", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a602f65a04a17481a5c87a82f34f26c53", null ],
    [ "Angle2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#ae77e8e697086d61fb6816b958aeeef6b", null ],
    [ "NumberOfXPixels", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a7a64e71f4f289d68539cffac07ea3379", null ],
    [ "NumberOfXPixelsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a72e419d5b51faa4a0d965dace841272c", null ],
    [ "NumberOfYPixels", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a7f8650139efb555da0f93077a714adec", null ],
    [ "NumberOfYPixelsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a3f10a710f11cd34fe8db2a5511f82655", null ],
    [ "PFlag", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#ad66ec64321bfa690870f9b145883747d", null ],
    [ "PFlagCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#ad0c37f59048c117a653fe5d5bbf54f10", null ],
    [ "RotationAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a186a18eb75cf9dadc0cbc7ce07aad035", null ],
    [ "RotationAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a0c5961ae5c859dee091330bc5d097819", null ],
    [ "XMinusWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a30cc1645d67ddf78a3e0c6b3b640a04e", null ],
    [ "XMinusWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#ade08b6d9c3ed099af31351edc3109385", null ],
    [ "YMinusWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#aa58bc1c35acd66ef837938c28dc123ae", null ],
    [ "YMinusWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_m_e_m_s.xhtml#a94daceee848573df694ee203353d8732", null ]
];