var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_extended_scene_1_1_i_a_s___relative_illumination =
[
    [ "FieldDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_extended_scene_1_1_i_a_s___relative_illumination.xhtml#ac7039f5bfad6f886e9958c6c5e7645df", null ],
    [ "LogScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_extended_scene_1_1_i_a_s___relative_illumination.xhtml#a73f13a57a18ea8db2da1a84c386e572b", null ],
    [ "RayDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_extended_scene_1_1_i_a_s___relative_illumination.xhtml#a5f5faf411b08fdbe44767c40fc8327f7", null ],
    [ "RemoveVignettingFactors", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_extended_scene_1_1_i_a_s___relative_illumination.xhtml#a255917fd21ef8ceafba1daf028e8fba1", null ],
    [ "ScanType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_extended_scene_1_1_i_a_s___relative_illumination.xhtml#ac8a828a27021fb378b16f5e5f8eddada", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_extended_scene_1_1_i_a_s___relative_illumination.xhtml#a6a4a88e64c259a0b23213cc88d682bb5", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_extended_scene_1_1_i_a_s___relative_illumination.xhtml#a258831e8ee1a34c361e4485cbc747993", null ]
];