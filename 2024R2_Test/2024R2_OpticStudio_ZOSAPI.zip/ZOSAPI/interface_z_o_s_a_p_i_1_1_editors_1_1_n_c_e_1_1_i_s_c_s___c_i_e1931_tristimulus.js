var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_tristimulus =
[
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_tristimulus.xhtml#a33a77ece4c496b42764f1fd5920d5b1e", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_tristimulus.xhtml#a4e57cf8397a94be6f91f3cb9ad4fa53f", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_tristimulus.xhtml#ac8e64447d3a7e7874a15355b4c338c22", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_tristimulus.xhtml#a1aaca601247c8f3ab105651749857a70", null ],
    [ "X", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_tristimulus.xhtml#a748e6220d2c8c38f78b3aca0b718fc03", null ],
    [ "Y", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_tristimulus.xhtml#a90af892ce3b515abf12aeecd73a597c4", null ],
    [ "Z", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___c_i_e1931_tristimulus.xhtml#ab95402d3bd9c6bcd7a58ffa33fd092e5", null ]
];