var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix =
[
    [ "Get_L_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a06f02c650f93c01d22d27a892c5aa626", null ],
    [ "Get_M_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a503be120281c92a80d9f387ed6189360", null ],
    [ "Get_N_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a5378d3194dcfb1d8c5648d35f9f9cbdb", null ],
    [ "Get_X_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a53795bec468cba047de51102fef220a3", null ],
    [ "Get_Y_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a6987af3229e3660e0c05dbcc93307fb7", null ],
    [ "Get_Z_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a5df3a20b72eb26993d0c930b896d62b5", null ],
    [ "GetDetector_X_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a00e391168df46ae3a77b2fa5e6cb3344", null ],
    [ "GetDetector_Y_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#ac007c1b96bbc9404b977d2ab8bd7e0d1", null ],
    [ "GetDetector_Z_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a96ee006b470e8b3519f0232310b84ae0", null ],
    [ "GetGeoSpotSizeFor", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a8f205893bdd60f4ad12c126bbfd80a22", null ],
    [ "GetReferenceCoordinate_X_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a004786cf813690810a86888693d57a55", null ],
    [ "GetReferenceCoordinate_Y_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a482a8e632cea66e76c41838b7ea05ede", null ],
    [ "GetRMSSpot_X_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#ac96eadb3714eb91a03bbdc1f81ea1296", null ],
    [ "GetRMSSpot_Y_For", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a05f198465b35adc8283b100f32be2ebb", null ],
    [ "GetRMSSpotSizeFor", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a17359801dacfb1ac80570e2eca07a95a", null ],
    [ "HalfWidth_X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#aa966a5b20155f447a5d7b52c85c673dd", null ],
    [ "HalfWidth_Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a552087d90581efb1a96561abe21a5e64", null ],
    [ "MaxRadius", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a8900f0b8207156fd0789ae65bee14e65", null ],
    [ "MeanRadius", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#afda4c12fa95b434fe657b0826a51b914", null ],
    [ "NumberOfFields", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a67e3cdd799a7e2f6d11d324a9253b387", null ],
    [ "NumberOfWavelengths", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___spot_data_result_matrix.xhtml#a43c64a17b185a101c554cabb7455a11e", null ]
];