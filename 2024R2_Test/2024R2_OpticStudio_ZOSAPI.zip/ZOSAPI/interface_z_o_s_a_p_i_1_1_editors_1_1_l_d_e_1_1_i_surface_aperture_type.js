var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type =
[
    [ "_S_CircularAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a439f659dc8b447aa2364331272bab3f8", null ],
    [ "_S_CircularObscuration", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a72f7b1a973ffb930e44a0bb3f4c303d6", null ],
    [ "_S_EllipticalAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a8bf0bd56f4ef3bd17e93e5f75d31321a", null ],
    [ "_S_EllipticalObscuration", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a7cc88fc8d4813432e34ba60574ea45e0", null ],
    [ "_S_FloatingAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a7658d2c1d3184eba37ec2c48649cd22f", null ],
    [ "_S_None", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a8393381e491d65ad1f9417530dfe7fb2", null ],
    [ "_S_RectangularAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a1d1e419402700e0edec105a4ecd2f74b", null ],
    [ "_S_RectangularObscuration", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#aacca3dac48ca8b6158e930c337a76c01", null ],
    [ "_S_Spider", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a62a972d32de630a4614f41ed7a3c1e93", null ],
    [ "_S_UserAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#aa6deb3086d0296399f9f5a0b4d2bc25b", null ],
    [ "_S_UserObscuration", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a2d9f9e4546901ab0c695a5934f41c3da", null ],
    [ "IsReadOnly", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#ad179ddbace72e5ddbc188138f2793d61", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_type.xhtml#a2ba4db1052563f4ff2b27488ffedc0c2", null ]
];