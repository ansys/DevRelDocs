var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary1 =
[
    [ "DiffractOrder", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary1.xhtml#a83c6287067d261bf06f248eb5fafd2d4", null ],
    [ "DiffractOrderCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary1.xhtml#a32969103146e4dbe59046a45b08ceeb6", null ],
    [ "IsAbsolute", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary1.xhtml#a875a252e38273641f8769c78a15084c1", null ],
    [ "IsAbsoluteCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary1.xhtml#abd2d81c24e588c33ef28e94862fb60d7", null ],
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary1.xhtml#a97066596d88a3030e7f28d61448baca3", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary1.xhtml#a161ae29d784e353aeae8fa56fdbb0394", null ]
];