var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___ray_data =
[
    [ "GetRay", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___ray_data.xhtml#a62683454f69780173e92a8ec8197342d", null ],
    [ "Description", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___ray_data.xhtml#a6d773a105d1af186c47babd14f01a3c6", null ],
    [ "NumRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___ray_data.xhtml#a0e9ea0004cdaeb81dc74ffdc524a69fa", null ],
    [ "Rays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___ray_data.xhtml#ae470e9e42e867a4f37ccd034c115292e", null ]
];