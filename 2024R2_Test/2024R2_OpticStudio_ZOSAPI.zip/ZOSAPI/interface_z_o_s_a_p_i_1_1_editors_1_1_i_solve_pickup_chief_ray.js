var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_pickup_chief_ray =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_pickup_chief_ray.xhtml#a0c0f0c1e16432836193e34b1e1e4c37d", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_pickup_chief_ray.xhtml#a6de63a5da018ee4a3604fec4dfb20bf2", null ]
];