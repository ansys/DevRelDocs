var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___scatter_point_rgb =
[
    [ "Value", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___scatter_point_rgb.xhtml#a4ca2a0045e8bfc94aed4271286f3fbfa", null ],
    [ "X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___scatter_point_rgb.xhtml#a7842757d5f541927f54313ab68f8901e", null ],
    [ "Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___scatter_point_rgb.xhtml#aefabfef0a5e4f03bdead913f16b263c6", null ]
];