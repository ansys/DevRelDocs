var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___meta_data =
[
    [ "Date", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___meta_data.xhtml#a999dafe8ac1e31a5baac83a05020da58", null ],
    [ "FeatureDescription", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___meta_data.xhtml#a621e7db4b50588bf87bc2a08bb26a964", null ],
    [ "LensFile", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___meta_data.xhtml#a15c6050a02163923ecf0bf546c8fc0b6", null ],
    [ "LensTitle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___meta_data.xhtml#aa68846e4ce7b6449dadf425abb5345c2", null ]
];