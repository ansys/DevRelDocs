var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___birefringent =
[
    [ "Ax", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___birefringent.xhtml#a62d6cdbaa88c92a11df43b0b6e76cbb1", null ],
    [ "AxisLength", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___birefringent.xhtml#ac3787582b76d70aa0d3a5c2537387416", null ],
    [ "Ay", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___birefringent.xhtml#a85e9ef5f7aef40d82d80657c908c16a0", null ],
    [ "Az", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___birefringent.xhtml#a587892aafd96522fe79b4e8edf6836e9", null ],
    [ "Mode", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___birefringent.xhtml#a1febcc9f8104a077f168fa66722ddac9", null ],
    [ "Reflections", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___birefringent.xhtml#ab395defe6798b9f68726e248ab910cab", null ]
];