var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag =
[
    [ "BestFitSphereOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#aac3e9db1d217fdc323624720f2b24470", null ],
    [ "BFSReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a94f4a95003aa6afd37767a60c6d64634", null ],
    [ "ContourFormat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a1db2fb0b9932558b2b7a6440b8e645d4", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a86fae2ea3c7c38c2c40b4d9fe7f675e2", null ],
    [ "Decenter_X", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a369a8bb7617b1ac6dd1e3ed3b3285ea8", null ],
    [ "Decenter_Y", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#aba06d0d1c221d20d25d11ff6dd2274de", null ],
    [ "FaceNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a94d09fdc8ad89d7a7310d7ba1b2ff25b", null ],
    [ "KeepObjectTilts", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a82503b56f60cdf1e30e8df0c0d5105e8", null ],
    [ "KeepZRD", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a51b55c8bd53ee1325bc8ef1a2d4cfda4", null ],
    [ "ObjectNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a8ee0e3c6ecfbc8dd80c7a05ddb2a1955", null ],
    [ "Offset", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a0c67a43e02dc4bf784ecc35b41078e3b", null ],
    [ "ProbeRayOffset", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#ab00a14c40752648dcb9e8fb6d9bfc608", null ],
    [ "RemoveOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a04f3dcfcf5667f100a6e147d7b5e128c", null ],
    [ "Rotation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#ad2af818e0a6f4c7209f98e7f39822f2a", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a1877197a13e169e996ce77cfc507d4c1", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a34d7ee2a2eb22b91219ee3998a3b992c", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#a815c47835a92b183f88a6c0939f24530", null ],
    [ "Width", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#aa29ac08c2223182bb11029d2b4cbe58b", null ],
    [ "ZRDFilename", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_n_s_c_surface_1_1_i_a_s___n_s_c_surface_sag.xhtml#aec882f080fdfa379153a5ed1c358a6c3", null ]
];