var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle =
[
    [ "FaceNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#a2c138011ab0025424ddef3aab09ad5a4", null ],
    [ "MaxAngle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#a4d3207f9246762e5af62200e3e09e653", null ],
    [ "MaxY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#afbe03b060ff50cdaec00eae4011f125d", null ],
    [ "MinAngle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#a45c7ecb52a7e29c27b0134049db47805", null ],
    [ "MinY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#adcaec29e8d0f6d3cc0d10fa83dafdc7a", null ],
    [ "ObjectNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#a256b6e18d6ca98afb1aa43e57afb6d17", null ],
    [ "ReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#a75b2293e8a0a71d1f430fe492d50a776", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#af6c03d3fe0fa6d63ba92685e191ba6c8", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_coatings_1_1_i_a_s___r_t_a___angle.xhtml#a2795f84d6efb2dd42c8b8257431dcb77", null ]
];