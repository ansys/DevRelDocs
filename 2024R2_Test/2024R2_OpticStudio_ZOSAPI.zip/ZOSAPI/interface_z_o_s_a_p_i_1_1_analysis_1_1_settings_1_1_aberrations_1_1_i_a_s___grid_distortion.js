var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion =
[
    [ "Aspect", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#a4d51e548eedcf1df0f0f603c5233bf13", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#a8fbb5ca7d223c85b0957fe6736c06da2", null ],
    [ "FieldWidth", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#abdce79e9a485828fd1ae9175d50fc363", null ],
    [ "GridNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#ae854ed781c5e1c5cd69e6fe1c8a86398", null ],
    [ "Method", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#a58d2b05f4e47d4dfa4b06621c7547c44", null ],
    [ "RotateText", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#ad6927e011dc72a948868dded4900d3d7", null ],
    [ "ScaleFactor", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#a9741e2a1eafa4cf97f1bbc581f52ebb0", null ],
    [ "SymmetricMagnification", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#a0be1bc99cad26317e504e7483b565b5c", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___grid_distortion.xhtml#adac2bcdb86b6c47299b454579db2be61", null ]
];