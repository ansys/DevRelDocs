var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___d65_white =
[
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___d65_white.xhtml#a60fa8162832df3a054711dcbd695dccf", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___d65_white.xhtml#a72b2ee85a01edbff32e0d8eb4f8bca36", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___d65_white.xhtml#ab42f02e4cd206c9dece1dcaac8044796", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___d65_white.xhtml#a36cd09cf0c4004ba461b45fb33be4428", null ]
];