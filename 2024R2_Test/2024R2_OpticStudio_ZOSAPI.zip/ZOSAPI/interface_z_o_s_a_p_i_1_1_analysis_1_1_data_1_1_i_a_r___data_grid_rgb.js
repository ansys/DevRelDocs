var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb =
[
    [ "FillValues", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#ae605e5fa29f55398f4f25dc0aadb3768", null ],
    [ "GetValue", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#a91a64f63065da8ab71c663f5080729d6", null ],
    [ "Description", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#a81ec49828b34b9ba8fc6daab36000017", null ],
    [ "Dx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#afd6c73f978b29b4c0438cb26920210b8", null ],
    [ "Dy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#adeedd84407c5b907fc1da7359f620179", null ],
    [ "MinX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#a4e4d3e498f7a2a852f2c735d70455c03", null ],
    [ "MinY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#aa4a819999f0b2d498431d5e3eb24d5ef", null ],
    [ "Nx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#a1be627920860fe39f04f383e2013bdb5", null ],
    [ "Ny", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#af200e421e44406d459c2f363d283b5a5", null ],
    [ "ValueLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#aac2b8931aab6a4d346ec6e6f17841322", null ],
    [ "Values", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#a7209c8598b2cdc3cd97505a50a898af2", null ],
    [ "XLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#acc9b4337c83f8350ca7392c51fcd7f5e", null ],
    [ "YLabel", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___data_grid_rgb.xhtml#ad186a10478f59ba75dd7ef2745206389", null ]
];