var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface =
[
    [ "InnerR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#a2ce90ac7f3075efb6ccb9f95a295bb39", null ],
    [ "InnerRCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#a3b611ba7e1045e21ff55fdc4101f03f5", null ],
    [ "OuterR", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#afb53ff6e5c29f594aeca5ce0d3c7f026", null ],
    [ "OuterRCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#a9b491c5defc5c08aec8f045b624de416", null ],
    [ "StartAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#a2331e612d6b04ecb839ee583009df5dc", null ],
    [ "StartAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#a68f24793faf5ad297f2e126b8d7c3567", null ],
    [ "StopAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#aac0a394e858e397ed4337ea02051f92b", null ],
    [ "StopAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#aaec0b5c26656159b225eabfc892d8469", null ],
    [ "Thickness", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#a2772ff00a82cdd0a04979cfc062e7d0c", null ],
    [ "ThicknessCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_rectangular_torus_surface.xhtml#acb1c7675ae06dd673a35425ee414f5b1", null ]
];