var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#a9c4afd811ec96a1fe100fc0ba11c1502", null ],
    [ "MaximumNumberOfTerms", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#a97bfe5e7986dc852795d522aab58bfb8", null ],
    [ "ReferenceOBDToVertex", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#a9c8b14cd93ee7fe511d33f11dfaeeed5", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#ae0842e5b41ec4ac64ab82af3490bd8d7", null ],
    [ "Sr", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#a6afb730f475bbe48d567d2eb0817b6bc", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#a009fbf9e5ec275015158f313f16c8a9a", null ],
    [ "Sx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#a349a75181771d11cbdd3673a22295aea", null ],
    [ "Sy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#a575a68d850d3373af09778f21df80501", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_fringe_coefficients.xhtml#ac464da3e3bc317216fcdf46da8a03598", null ]
];