var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings =
[
    [ "SetAllValues", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#a28812bfd0d2e0c72bd4779d9c0249952", null ],
    [ "Grid1", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#a01a81f393d7f945ad2797e216fb7ebcd", null ],
    [ "Grid2", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#a56d857b01df769e328c16e6fd4ed5505", null ],
    [ "Grid3", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#acbf408ed4231ba7fd6de2ff729e595df", null ],
    [ "MBAMaxLevel", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#a6e70706498f96ae2c5521e1be07fd7ae", null ],
    [ "MBAMinFill", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#a450ac4a53c6aaad578d6971a26d7c4cd", null ],
    [ "MBATol", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#a459fc2a6b4a81d133a632fd95e1de8af", null ],
    [ "SurfaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#a4d674ea5a6b0f99021e250ee5b73c4a9", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___f_e_a_fit_settings.xhtml#a5ee0d93e60ea44d265bc5632bba07521", null ]
];