var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary2 =
[
    [ "DiffractOrder", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary2.xhtml#acc85eed25a13b8df8e1b20ee2124d022", null ],
    [ "DiffractOrderCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary2.xhtml#a521754e953d086caff3aaccd8a38a6bd", null ],
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary2.xhtml#ae6d7adaa8b22ea23bf53fbd216e8e51a", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_binary2.xhtml#a283a36cbe899a794584c1facbb5cf69a", null ]
];