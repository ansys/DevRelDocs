var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_sphere =
[
    [ "IsVolume", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_sphere.xhtml#ad6bc697d8eb6818a1df63c0e71ad5ad5", null ],
    [ "IsVolumeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_sphere.xhtml#a3e8acaf644febfa891d3468bcff9343c", null ],
    [ "Radius", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_sphere.xhtml#a657ca2d7d01e4b73790f71f5b5c826d1", null ],
    [ "RadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_sphere.xhtml#af06b169381ed03226d148396aa1bf46e", null ]
];