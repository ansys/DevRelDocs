var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_off_axis_conic_freeform =
[
    [ "NormRadius", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_off_axis_conic_freeform.xhtml#abe27da09380819da53569166209bf5f5", null ],
    [ "NormRadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_off_axis_conic_freeform.xhtml#a35eb453a8bfcde9ed8868b062402ac50", null ],
    [ "Offset", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_off_axis_conic_freeform.xhtml#a67c6c41f018ce9a03ef9553ad1c529c6", null ],
    [ "OffsetCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_off_axis_conic_freeform.xhtml#aae273dfb9ac5b8773ce058b844c0660a", null ]
];