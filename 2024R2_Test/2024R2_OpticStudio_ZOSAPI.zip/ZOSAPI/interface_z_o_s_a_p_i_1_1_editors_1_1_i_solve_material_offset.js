var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_material_offset =
[
    [ "NdOffset", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_material_offset.xhtml#a1c3294e2abff6e1f9d62047f4a9be5c2", null ],
    [ "VdOffset", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_material_offset.xhtml#abc1f0c781dbc150b2b9eba848aa3f5fe", null ]
];