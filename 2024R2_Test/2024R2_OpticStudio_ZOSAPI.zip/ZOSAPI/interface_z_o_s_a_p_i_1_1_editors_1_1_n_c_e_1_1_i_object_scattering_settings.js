var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings =
[
    [ "_S_ABg", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#ae74b8f293baa55d117ee8b1a327cdaa7", null ],
    [ "_S_ABgFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#a0f6aa9f934241dfd7803ac7b60ca0ff4", null ],
    [ "_S_BSDF", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#ad2c4c54dbda6059fa51d5f8129e77182", null ],
    [ "_S_Gaussian", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#a8ab29cc60a2dc8cb19538f3b6c6c44e9", null ],
    [ "_S_ISScatterCatalog", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#a4170c4526371a7cb29192fd7efa22db1", null ],
    [ "_S_Lambertian", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#a2b6f7320ee0a5de54240ba7101cb6848", null ],
    [ "_S_None", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#a169589d933ef9e0ba9de49aec046f504", null ],
    [ "_S_User", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#aaf8697c0ab31a9fc33599efc0d9bced9", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#a2d8f29d5bc47a522983be45df7dc684a", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_scattering_settings.xhtml#a79d447e9b68b4c9c6445545764859836", null ]
];