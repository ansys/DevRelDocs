var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotations =
[
    [ "Angles", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotations.xhtml#a8918100b2351ea93e2e3ccd52e58ddfd", null ],
    [ "Values", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___rotations.xhtml#ac389d26ab85ae94510d187496237852f", null ]
];