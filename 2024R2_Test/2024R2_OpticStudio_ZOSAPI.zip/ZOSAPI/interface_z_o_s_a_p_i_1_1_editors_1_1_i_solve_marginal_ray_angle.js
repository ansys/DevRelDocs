var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_marginal_ray_angle =
[
    [ "Angle", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_marginal_ray_angle.xhtml#a384a35eb33ca981b9ba2a9212f7d1e4d", null ]
];