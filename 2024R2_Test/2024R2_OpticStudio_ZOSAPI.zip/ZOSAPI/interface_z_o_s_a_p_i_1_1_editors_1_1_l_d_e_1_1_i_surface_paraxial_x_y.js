var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_paraxial_x_y =
[
    [ "X_Power", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_paraxial_x_y.xhtml#ad3044c16213638c6c84002e7c20706da", null ],
    [ "X_PowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_paraxial_x_y.xhtml#aa154ec7d5ab087343d137b38708e45db", null ],
    [ "Y_Power", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_paraxial_x_y.xhtml#a8c77c065bafe7b477c753840e5a044e9", null ],
    [ "Y_PowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_paraxial_x_y.xhtml#a00580685e6771b31fde6283734ace670", null ]
];