var interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data =
[
    [ "Make2DLinePlot", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#ae47500b70ceb79e2ff493915ae025b55", null ],
    [ "Make2DLinePlotSafe", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#a9e649ae0baddc08009923d56507e8de5", null ],
    [ "MakeGridPlot", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#aa48feb3384d32b370751ebfe2940f686", null ],
    [ "MakeGridRGBPlot", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#a29b5814146ad65bd2fa792901e9058f2", null ],
    [ "MakeText", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#a54d356d36dfb4b3c14609b81a55e0541", null ],
    [ "AnalysisNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#af4aab5e6ff243d9897b349272aa27b6d", null ],
    [ "FeatureDescription", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#a7d259a3242d3ab83fddc902ccd959225", null ],
    [ "HeaderData", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#a9e99af28b532b16118772f7670baec86", null ],
    [ "PlotType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#ab206a2a82d3caeda11848c0d39f45ab7", null ],
    [ "RunAnalysisOnSettingsClosed", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#a9a04c065e2f3ff7ec7c42cfc2712da5e", null ],
    [ "ShowLegend", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#a78ace628ebb50c2b10f63b7e7ab54b51", null ],
    [ "UserSettings", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#ad65598e3b904e128dfc92664e6450399", null ],
    [ "WindowTitle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_user_analysis_data.xhtml#a5efb32eb83b8cbe9c7fd8533b7b49c82", null ]
];