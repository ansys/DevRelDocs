var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___gaussian =
[
    [ "ScatterFraction", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___gaussian.xhtml#a6c83d8944254985f231b8eadef42aa63", null ],
    [ "Sigma", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___gaussian.xhtml#af037d023320755db3a2c643b9d8eae4f", null ]
];