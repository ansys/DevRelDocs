var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power__8 =
[
    [ "Coeff_Y_NthEvenPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power__8.xhtml#a965ada9dfb8e15e1175eee1aa41ede9e", null ],
    [ "GetCoeff_Y_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power__8.xhtml#af6318b7dfbf7be6733f8da77ecd2bf56", null ],
    [ "SetCoeff_Y_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___y___nth_even_power__8.xhtml#a2230421d9079afcc95080ac7af3ac1b9", null ]
];