var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal =
[
    [ "Extrapolate", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal.xhtml#a56a12f7cfb99e8217a3f3d2b57955e6d", null ],
    [ "ExtrapolateCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal.xhtml#a8e6098a832cf8686a783e07274d88f9f", null ],
    [ "RadiusOfRotation", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal.xhtml#ada15116a3be7838e7e98f42c5715b981", null ],
    [ "RadiusOfRotationCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal.xhtml#a49daca0df6373058ea64b11e2a030d53", null ]
];