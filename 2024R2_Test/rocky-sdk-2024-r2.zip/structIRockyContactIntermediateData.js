var structIRockyContactIntermediateData =
[
    [ "get_friction_coefficient", "structIRockyContactIntermediateData.xhtml#a3efba296a1d32e115acbb7071cdbf775", null ],
    [ "get_home_centroid_to_contact_point_vector", "structIRockyContactIntermediateData.xhtml#ae7271a8689305777b1f39beb47898553", null ],
    [ "get_near_centroid_to_contact_point_vector", "structIRockyContactIntermediateData.xhtml#a00c355cde831bad36cd029544a7bbb16", null ]
];