var structIRockyContactDataRecorder =
[
    [ "enable_contact_scalar", "structIRockyContactDataRecorder.xhtml#a36e9b7b9de7b99a0e4c6ca703fc7fb5d", null ],
    [ "get_contact_scalar_index", "structIRockyContactDataRecorder.xhtml#a5ebed1613189e54bf4c202b5ec9553b8", null ]
];