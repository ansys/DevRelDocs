var structIRockyGeometryTriangle =
[
    [ "get_area", "structIRockyGeometryTriangle.xhtml#a87f5f5f9d279e717777feb3a934bac82", null ],
    [ "get_centroid", "structIRockyGeometryTriangle.xhtml#a51271bd50959a8f2a353ac6673ee7fd7", null ],
    [ "get_geometry_index", "structIRockyGeometryTriangle.xhtml#a8498939de6ea592bbfff2a4ec075f6ee", null ],
    [ "get_geometry_rotation_center", "structIRockyGeometryTriangle.xhtml#ad41c1ad766c0a34a978c5c59add829e7", null ],
    [ "get_geometry_rotational_velocity", "structIRockyGeometryTriangle.xhtml#a67d418dcadcd12fa9314ec4891bae8e0", null ],
    [ "get_material", "structIRockyGeometryTriangle.xhtml#ad93dcca6decba182b3cc02e95bd09c38", null ],
    [ "get_material_index", "structIRockyGeometryTriangle.xhtml#a9bcc3c8846e93fd1e9876ba328e6a09d", null ],
    [ "get_normal_unit_vector", "structIRockyGeometryTriangle.xhtml#a3dffe992b4dc3278be110fd792142b80", null ],
    [ "get_poisson_ratio", "structIRockyGeometryTriangle.xhtml#a362d59bc94cc55f1cb37d6fe00764a4b", null ],
    [ "get_scalars", "structIRockyGeometryTriangle.xhtml#a525086257224ba19ec3bbfec2522bdba", null ],
    [ "get_temperature", "structIRockyGeometryTriangle.xhtml#a4ad4b4c3dbdb033213b9f68d4c497f68", null ],
    [ "get_thermal_conductivity", "structIRockyGeometryTriangle.xhtml#a6288e5b20aa8375b184529d1760d9a93", null ],
    [ "get_translational_velocity", "structIRockyGeometryTriangle.xhtml#a704cfc661bc09630a2d7345d7ea53309", null ],
    [ "is_adiabatic", "structIRockyGeometryTriangle.xhtml#acf3dd4c6616b36509791e2896595d16e", null ],
    [ "set_poisson_ratio", "structIRockyGeometryTriangle.xhtml#add105a1fd3ed0e38ad85c93d09ee4a27", null ],
    [ "set_temperature", "structIRockyGeometryTriangle.xhtml#a4286e7ea37b1863c8ea48d2fcd729b9c", null ],
    [ "set_thermal_conductivity", "structIRockyGeometryTriangle.xhtml#ab93ed9aba28273a9a329a212457b0158", null ]
];