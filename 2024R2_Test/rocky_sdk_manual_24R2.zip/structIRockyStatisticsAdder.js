var structIRockyStatisticsAdder =
[
    [ "add_value", "structIRockyStatisticsAdder.xhtml#a2d87767ca1065f1a48778cf3d1e0f8ce", null ],
    [ "get_kurtosis", "structIRockyStatisticsAdder.xhtml#a6f398ed07d36a7deccea3621e9780109", null ],
    [ "get_mean", "structIRockyStatisticsAdder.xhtml#a57d3816e4f01de3fdd781ef229c9f771", null ],
    [ "get_skewness", "structIRockyStatisticsAdder.xhtml#a4968d2f7ab3265b9aefafe064ae16ba0", null ],
    [ "get_std_deviation", "structIRockyStatisticsAdder.xhtml#ac1c33e3ab2e1afd1590aef6e2c40eb64", null ],
    [ "join", "structIRockyStatisticsAdder.xhtml#a56563b07a2763d52804e5180f3ae0b07", null ],
    [ "reset", "structIRockyStatisticsAdder.xhtml#ae4b238da655579b44c6293a573cd9449", null ]
];