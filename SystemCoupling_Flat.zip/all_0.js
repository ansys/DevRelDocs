var searchData=
[
  ['addcouplinginterface_0',['addCouplingInterface',['../classsysc_1_1_system_coupling.html#ae4c93f4502c9df950fddddab3aab5eec',1,'sysc::SystemCoupling::addCouplingInterface(const CouplingInterface &amp;couplingInterface)'],['../classsysc_1_1_system_coupling.html#ae1f7fe88e678c07cde61acff8742b608',1,'sysc::SystemCoupling::addCouplingInterface(const CouplingInterface &amp;couplingInterface, bool autoGenerateTransfers)']]],
  ['adddatatransfer_1',['addDataTransfer',['../classsysc_1_1_coupling_interface.html#ab1230f4b0c7dc52fff73d1ddcd67f03e',1,'sysc::CouplingInterface']]],
  ['addinputvariable_2',['addInputVariable',['../classsysc_1_1_region.html#a018cbfef9eee8c3d2cd3b20084783390',1,'sysc::Region']]],
  ['addintegerattribute_3',['addIntegerAttribute',['../classsysc_1_1_variable.html#ae6fed92c7d5f748b3e26898af932eb46',1,'sysc::Variable']]],
  ['addoutputvariable_4',['addOutputVariable',['../classsysc_1_1_region.html#a96143a5b4d943e47d335d74fa1f827be',1,'sysc::Region']]],
  ['addrealattribute_5',['addRealAttribute',['../classsysc_1_1_variable.html#ab296b04988b750113600bcc4e302ae3c',1,'sysc::Variable']]],
  ['addregion_6',['addRegion',['../classsysc_1_1_system_coupling.html#afd8d4beebb3a46d80c9f9fcddc385db2',1,'sysc::SystemCoupling']]],
  ['addsideoneregion_7',['addSideOneRegion',['../classsysc_1_1_coupling_interface.html#ab7a385065f0fde034baa88a88f274946',1,'sysc::CouplingInterface']]],
  ['addsidetworegion_8',['addSideTwoRegion',['../classsysc_1_1_coupling_interface.html#a5afdb8ffa5c06d66fe30e6f150230b67',1,'sysc::CouplingInterface']]],
  ['amountofsubstance_9',['amountOfSubstance',['../structsysc_1_1_dimensionality.html#aa0de60275ce09315d344f2a96f397cca',1,'sysc::Dimensionality::amountOfSubstance()'],['../struct_sysc_dimensionality.html#a7cb2bcc42a70ccbcbc067d2f8e3537f1',1,'SyscDimensionality::amountOfSubstance()']]],
  ['analysistype_10',['analysisType',['../structsysc_1_1_setup_info.html#a45906ec4c888b7d0fbd42066f318284b',1,'sysc::SetupInfo::analysisType()'],['../struct_sysc_setup_info.html#ac769cbb25b2b34dbb5bc44f281299780',1,'SyscSetupInfo::analysisType()']]],
  ['analysistype_11',['AnalysisType',['../group___system_coupling_participant_a_p_is.html#gaffd523474fbd708f481a712f1841a967',1,'sysc']]],
  ['angle_12',['angle',['../structsysc_1_1_dimensionality.html#a03f6d1e6e0ebb147b85242eb889572a7',1,'sysc::Dimensionality::angle()'],['../struct_sysc_dimensionality.html#a97ee853763b54b62bbd1ead7cbd1a761',1,'SyscDimensionality::angle()']]],
  ['attributename_13',['AttributeName',['../group___system_coupling_participant_a_p_is.html#gadb06eacf4ed0787d18e8ddbf0612c83c',1,'sysc']]]
];
