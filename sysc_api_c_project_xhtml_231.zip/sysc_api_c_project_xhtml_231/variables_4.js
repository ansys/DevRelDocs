var searchData=
[
  ['elementids_0',['elementIds',['../structSyscElementIdData.xhtml#a876ea4ad83f4555fe2bf825517c8131b',1,'SyscElementIdData']]],
  ['elementnodecounts_1',['elementNodeCounts',['../structSyscElementNodeCountData.xhtml#a7b8d330429782be5862b24638866be6b',1,'SyscElementNodeCountData']]],
  ['elementnodeids_2',['elementNodeIds',['../structSyscElementNodeConnectivityData.xhtml#a08dfd1139cb4d1b40de4480d91a87565',1,'SyscElementNodeConnectivityData']]],
  ['elementtypes_3',['elementTypes',['../structSyscElementTypeData.xhtml#a19c71338f6ede3812e004456d525c5dd',1,'SyscElementTypeData']]]
];
