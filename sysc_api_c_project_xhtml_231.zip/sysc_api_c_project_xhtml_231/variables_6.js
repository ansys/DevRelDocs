var searchData=
[
  ['isextensive_0',['isExtensive',['../structSyscVariable.xhtml#aed5ddca8dd956e1b4935aa69c323e011',1,'SyscVariable']]]
];
