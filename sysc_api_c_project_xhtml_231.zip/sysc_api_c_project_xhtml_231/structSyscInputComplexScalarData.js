var structSyscInputComplexScalarData =
[
    [ "data1", "structSyscInputComplexScalarData.xhtml#aee021b7ac05827ac6d4d8dffc97605f5", null ],
    [ "data2", "structSyscInputComplexScalarData.xhtml#a57b73d00a5b261093b572c2f02c8e6a0", null ],
    [ "primitiveType", "structSyscInputComplexScalarData.xhtml#a68e7a5dcd79c528810151c82f29affdb", null ],
    [ "size", "structSyscInputComplexScalarData.xhtml#a3f5223d8696f734edf5ed4efe2ec21f8", null ]
];