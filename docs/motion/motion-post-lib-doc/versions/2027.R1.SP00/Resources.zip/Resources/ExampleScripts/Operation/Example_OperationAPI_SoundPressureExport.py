# Example_OperationAPI_SoundPressureExport.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Set array about result file
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path
filepaths.Add(RESULT_FILE_PATH)

# Open the result file.
# When the result is first opened, a Page is created and an Animation View is created on that Page.
application_handler.AddDocument(filepaths)

# Get the Animation View that AddDocument created on the active page.
page = application_handler.GetActivePage()
animation_view = page.GetActiveView()

# Load the frames used for the sound pressure calculation.
document = application_handler.GetDocument(RESULT_FILE_PATH)
dynamic_analysis = document.GetAnalysisResultViewModel(AnalysisResultType.Dynamics)
frame_count = 251
dynamic_analysis.SetAnimationFrame(frame_count)

# Create the microphone coordinate system on Ground and move it 300 above the origin.
microphone_name = "Microphone_01"
parent_name = "Ground"
animation_view.CreateCoordinateSystem(microphone_name, parent_name)
microphone = animation_view.GetCoordinateSystem(microphone_name)
microphone.TransformationOffsetPosition = Vector(0, 300, 0)

# Prepare the body and microphone names used by the sound pressure calculation.
body_names = List[str]()
body_name = "FEBody_01"
body_names.Add(body_name)
coordinate_names = List[str]()
coordinate_names.Add(microphone.FullName)

# Sound pressure parameters
coarsening_rate = 10.0
max_area_factor = 100.0
max_aspect_ratio = 3.0
air_density = 1.21E-09
sound_velocity = 343000.0
frequency = 2000.0
start_frame = 1
end_frame = 251
is_decibel_scale = True

# Calculate the sound pressure. A chart view with the curve is created on the active page for each microphone.
sound_pressure_curves = animation_view.CreateSoundPressure(body_names, coordinate_names, coarsening_rate, max_area_factor, max_aspect_ratio, air_density, sound_velocity, frequency, start_frame, end_frame, is_decibel_scale)

# Rename the sound pressure curves.
for curve in sound_pressure_curves :
    curve.SeriesName = "SPA_" + curve.SeriesName

# Find the chart view that holds the sound pressure curves.
chart_views = [view for view in page.GetViews() if view.ViewType == ViewType.Chart]
chart_view = chart_views[0]

# Export all curves of the chart view.
# OUTPUT_DIR : path to the folder where exported files are written
# CURVE_EXPORT_FILENAME : output filename for the exported sound pressure curves
export_filepath = Path.Combine(OUTPUT_DIR, CURVE_EXPORT_FILENAME)
chart_view.ExportAllCurves(export_filepath)

# Close the Pages
for page in list(application_handler.GetPages()) :
    page.Close()

# Close the Document
application_handler.CloseDocument(RESULT_FILE_PATH)
