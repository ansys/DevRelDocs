# Example_OperationAPI_ExportAllCurves.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get Active Page
# This retrieves the currently active page in the application.
page = application_handler.GetActivePage()

# Creating a Chart
# Create a new Chart View on the page
# This will create a new chart view with the specified name.
# The name of the new chart view.
chart_name = "Chart"
# The chart view created on the page.
chart_view = page.CreateChart(chart_name)

# Specify the paths for the curves you want to retrieve.
# For example, Acceleration represents the Characteristic, and Y after the / represents the Component.
# In this case, we are retrieving the Y component of Acceleration for the Crank.
# You can check the available Characteristics and Components for the target by using Add Curve in the Postprocessor.
# The characteristic/component paths of the curves to add, in "Characteristic/Component" format.
curve_paths = List[str]()
# Characteristic/component path of the curve to add, in "Characteristic/Component" format.
characteristic_path_magnitude = r'Displacement/Magnitude'
curve_paths.Add(characteristic_path_magnitude)
# Characteristic/component path of the curve to add, in "Characteristic/Component" format.
characteristic_path_z = r'Displacement/Z'
curve_paths.Add(characteristic_path_z)

# Create a PlotParameters object to specify the parameters for the plot.
# Set the Entity to Plot.
# The Target is the name of the target for which you want to retrieve the curves.
# Set the paths for the curves you want to retrieve.
# This is where you specify the characteristics and components you want to plot.
parameters = PlotParameters()
parameters.Paths = curve_paths
# The name of the target entity.
entity_name = "Crank"
parameters.Target = entity_name

# Add Curves
# The curves added to the chart view.
curves = chart_view.AddCurves(RESULT_FILE_PATH, parameters)

# Change the name of the curves
# The counter used to build the new curve names.
index = 0
for curve in curves :
    curve.SeriesName = "NameChange_{0}".format(index)
    index = index + 1

# Exporting All Curves
# This function exports all curves in the chart view to a specified file.
# OUTPUT_DIR : path to the folder where exported files are written (e.g., D:\PostprocessorAPI\Output)
# CURVE_DATA_FILENAME : output filename for the exported curve data (e.g., curvedata.txt)
# The path of the exported curve data file.
export_filepath = Path.Combine(OUTPUT_DIR, CURVE_DATA_FILENAME)
chart_view.ExportAllCurves(export_filepath)
