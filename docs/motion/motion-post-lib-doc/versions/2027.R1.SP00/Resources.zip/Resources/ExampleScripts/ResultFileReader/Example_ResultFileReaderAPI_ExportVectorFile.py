# Example_ResultFileReaderAPI_ExportVectorFile.py
import sys

# BINARY_FOLDER_PATH : path to the folder containing the Postprocessor dll files (e.g., D:\Motion\bin)
# RESULT_FILE_READER_API_MODULE_PATH : path to the folder containing ResultFileReaderAPI.py
sys.path.append(BINARY_FOLDER_PATH)
sys.path.append(RESULT_FILE_READER_API_MODULE_PATH)

# Import necessary modules
from ResultFileReaderAPI import *
import os

# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
# The reader that opens the result file.
output_reader = OutputReader(RESULT_FILE_PATH)

# The IDs of the states in the result file.
state_ids = output_reader.GetStateIDArray()

# Specifies the name of the vector displayable entity.
entity_name = "TJ_01"
# Vector characteristic for the Base Force result.
characteristic_name = "Base Force"

# The vector displays to export.
targets = List[IVectorDisplay]()
# The name of the vector.
vector_name = "vector"
# The vector definition created for the entity and characteristic.
vector = output_reader.CreateVector(vector_name, entity_name, characteristic_name)
targets.Add(vector)
print ("===ExportVectorDisplayToFile===")

# OUTPUT_DIR : path to the folder where exported files are written (e.g., D:\PostprocessorAPI\Output)
# The path of the exported vector display file for the target list.
export_vector_targets_file_path = os.path.join(OUTPUT_DIR, RFR_VECTOR_TARGETS_OUTPUT_FILENAME)
output_reader.ExportVectorDisplayToFile(export_vector_targets_file_path, state_ids, targets, True, True, True, AnalysisResultType.Dynamics)

# The path of the exported vector display file for a single target.
export_vector_target_file_path = os.path.join(OUTPUT_DIR, RFR_VECTOR_TARGET_OUTPUT_FILENAME)
output_reader.ExportVectorDisplayToFile(export_vector_target_file_path, state_ids, entity_name, characteristic_name, True, True, True, AnalysisResultType.Dynamics)

# Close
output_reader.Close()
