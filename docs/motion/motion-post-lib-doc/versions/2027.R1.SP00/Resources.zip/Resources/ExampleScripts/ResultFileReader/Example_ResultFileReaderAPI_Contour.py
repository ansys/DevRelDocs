# Example_ResultFileReaderAPI_Contour.py
import sys

# BINARY_FOLDER_PATH : path to the folder containing the Postprocessor dll files (e.g., D:\Motion\bin)
# RESULT_FILE_READER_API_MODULE_PATH : path to the folder containing ResultFileReaderAPI.py
sys.path.append(BINARY_FOLDER_PATH)
sys.path.append(RESULT_FILE_READER_API_MODULE_PATH)

# Import necessary modules
from ResultFileReaderAPI import *
import os
import struct

# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
# The reader that opens the result file.
output_reader = OutputReader(RESULT_FILE_PATH)

# OUTPUT_DIR : path to the folder where exported files are written (e.g., D:\PostprocessorAPI\Output)
# The path of the exported contour result file.
export_result_file_path = os.path.join(OUTPUT_DIR, RFR_CONTOUR_OUTPUT_FILENAME)

# State ID Array
state_ids = output_reader.GetStateIDArray()
# Characteristic/component path for the Top Stress X contour result.
characteristic_name = "Top Stress/X"

# The name of the target finite-element body.
entity_name = "FEBody_01"

# Export the contour result of the entity to the file.
# FileMode.Create specifies how the operating system should open the file.
# ContourMappingType.FENode specifies the type of the target for displaying contour (None, FENode, FEElement, FEElementNode, FEMaterial, BeamGroup, Contact, ChainedSystem, Usersubroutine).
# analysisResultType specifies the type of analysis result type for displaying contour.
# formatType specifies a file format type.
output_reader.ExportContourResultToFile(export_result_file_path, FileMode.Create, state_ids, entity_name, ContourMappingType.FENode, characteristic_name, analysisResultType=AnalysisResultType.Dynamics, formatType=FileFormatType.BINARY)

# The number of states in the result file.
total_steps = len(list(state_ids))
# The geometry data of the body.
data_part = output_reader.GetGeometryInfo(entity_name)
# The number of nodes of the body.
node_count = data_part.NodesCount
# The reference time of each state.
time_array = output_reader.GetReferenceTimeArray()

print('===================== Top Stress X =======================:')
print('total steps :', total_steps)
print('total nodes :', node_count)
with open(export_result_file_path, 'rb') as file:
    for state_id in state_ids:
        print('===================== state id =======================:', state_id)
        print('===================== ref time =======================:', time_array[state_id - 1])
        # The contour values of the nodes in the state.
        double_values = struct.unpack('d' * node_count, file.read(struct.calcsize('d') * node_count))
        
        print(*double_values, sep=',')
        print(f"\n")

# Close
output_reader.Close()
