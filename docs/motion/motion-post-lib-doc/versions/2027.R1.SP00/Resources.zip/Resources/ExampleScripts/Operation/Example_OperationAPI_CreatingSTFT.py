# Example_OperationAPI_CreatingSTFT.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get Active Page
# This retrieves the currently active page in the application.
page = application_handler.GetActivePage()

# Creating a Chart
# Create a new Chart View on the page
# This will create a new chart view with the specified name.
# The name of the new chart view.
chart_name = "Chart"
# The chart view created on the page.
chart_view = page.CreateChart(chart_name)

# Specify the paths for the curves you want to retrieve.
# For example, Acceleration represents the Characteristic, and Y after the / represents the Component.
# In this case, we are retrieving the Y component of Acceleration for the Crank.
# You can check the available Characteristics and Components for the target by using Add Curve in the Postprocessor.
# The characteristic/component paths of the curves to add, in "Characteristic/Component" format.
curve_paths = List[str]()
# Characteristic/component path of the curve to add, in "Characteristic/Component" format.
characteristic_path_magnitude = r'Displacement/Magnitude'
curve_paths.Add(characteristic_path_magnitude)

# Create a PlotParameters object to specify the parameters for the plot.
# Set the Entity to Plot.
# The Target is the name of the target for which you want to retrieve the curves.
# Set the paths for the curves you want to retrieve.
# This is where you specify the characteristics and components you want to plot.
parameters = PlotParameters()
parameters.Paths = curve_paths
# The name of the target entity.
entity_name = "Crank"
parameters.Target = entity_name

# Add Curves
# The curves added to the chart view.
curves = chart_view.AddCurves(RESULT_FILE_PATH, parameters)

# The list of the curve names to perform the operation.
curve_names = List[str]()
for curve in curves :
    curve_names.Add(curve.SeriesName)

# The STFT parameters.
stft_parameters = STFTParameters()
# The number of the interval for dividing Y direction grids on color map.
stft_parameters.SamplingFrequency = 100
# The number of the interval for dividing X direction grids on color map.
stft_parameters.TimeSlice = 0.05
# The value of the percentage for setting overlapped intervals.
stft_parameters.Overlap = 50
# The number of data point for FFT.
stft_parameters.SelectedPoints = 16384
# The start time for using FFT on target data series.
stft_parameters.Start = 0
# The end time for using FFT on target data series.
stft_parameters.End = 1.000000000001
# The reference value on decibel as the type of the scale.
stft_parameters.ReferenceValue = 1E-05
# The scale factor to change from time domain to another domain.
stft_parameters.ScaleFactor = 1.0
# The scale type of STFT. STFT Scale Type has Original, Decibel.
stft_parameters.SelectedScaleType = STFTScaleType.Original
chart_view.CreateSTFT(stft_parameters, curve_names)
