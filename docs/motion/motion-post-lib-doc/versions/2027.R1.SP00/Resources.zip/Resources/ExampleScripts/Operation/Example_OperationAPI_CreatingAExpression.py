# Example_OperationAPI_CreatingAExpression.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()

# The animation views that show the dynamic analysis result of the result file.
find_views = list()
for page in pages :
    # The views of the page.
    views = page.GetViews()
    # The animation views of the page.
    animation_views = [view for view in views if view.ViewType == ViewType.Animation]
    for animation_view in animation_views :
        if animation_view.DocumentFilePath == RESULT_FILE_PATH and animation_view.AnalysisResultType == AnalysisResultType.Dynamics :
            find_views.append(animation_view)

# The number of animation views found.
view_count = len(find_views)
if view_count > 0 :
    # Get the document from the result file
    document = application_handler.GetDocument(RESULT_FILE_PATH)

    # This retrieves the analysis result from the document.
    # Types of Analysis Results
    # - Dynamics
    # - Eigenvalue
    # - Statics
    dynamic_analysis = document.GetAnalysisResultViewModel(AnalysisResultType.Dynamics)

    # Creating a Expression
    expression = dynamic_analysis.CreateExpression("expression")
    expression.Expression = 'DM("Crank/CM")'

    # Add the expression value as curve data.
    # The name of the new chart view.
    chart_name = "ExpressionChart"
    # The chart view created on the page.
    chart = page.CreateChart(chart_name)
    # The characteristic/component paths of the curves to add, in "Characteristic/Component" format.
    curve_paths = List[str]()
    # Characteristic/component path of the curve to add, in "Characteristic/Component" format.
    curve_path = "Expression/Value"
    curve_paths.Add(curve_path)
    # The parameters that specify the target and curve paths of the plot.
    parameters = PlotParameters()
    parameters.Target = expression.FullName
    parameters.Paths = curve_paths
    chart.AddCurves(RESULT_FILE_PATH, parameters)

    # Remove the expression from the dynamic analysis result.
    dynamic_analysis.RemoveExpression(expression.FullName)
