# Example_OperationAPI_SignalProcessing.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get Active Page
# This retrieves the currently active page in the application.
page = application_handler.GetActivePage()

# Creating a Chart
# Create a new Chart View on the page
# This will create a new chart view with the specified name.
# The name of the new chart view.
chart_name = "Chart"
# The chart view created on the page.
chart_view = page.CreateChart(chart_name)

# Specify the paths for the curves you want to retrieve.
# For example, Acceleration represents the Characteristic, and Y after the / represents the Component.
# In this case, we are retrieving the Y component of Acceleration for the Crank.
# You can check the available Characteristics and Components for the target by using Add Curve in the Postprocessor.
# The characteristic/component paths of the curves to add, in "Characteristic/Component" format.
curve_paths = List[str]()
# Characteristic/component path of the curve to add, in "Characteristic/Component" format.
characteristic_path_magnitude = r'Displacement/Magnitude'
curve_paths.Add(characteristic_path_magnitude)
# Characteristic/component path of the curve to add, in "Characteristic/Component" format.
characteristic_path_z = r'Displacement/Z'
curve_paths.Add(characteristic_path_z)

# Create a PlotParameters object to specify the parameters for the plot.
# Set the Entity to Plot.
# The Target is the name of the target for which you want to retrieve the curves.
# Set the paths for the curves you want to retrieve.
# This is where you specify the characteristics and components you want to plot.
parameters = PlotParameters()
parameters.Paths = curve_paths
# The name of the target entity.
entity_name = "Crank"
parameters.Target = entity_name

# Add Curves
# The curves added to the chart view.
curves = chart_view.AddCurves(RESULT_FILE_PATH, parameters)

# Signal Processing - Filtering
# The filtering type can be LowPass, HighPass, BandPass, or BandStop.
# As the value decreases, the output becomes smoother.
order = 2
# The value of the cut off frequency(Hz) (low cut off frequency(Hz)).
low_cutoff_frequency = 100
# The value of the high cut off frequency(Hz).
high_cutoff_frequency = 100
chart_view.CreateFiltering(curves, FilteringType.LowPass, order, low_cutoff_frequency, high_cutoff_frequency)

# Signal Processing - Smoothing
# The smoothing type can be MovingWindowAveraging or SavitzkyGloay.
# The number of points for the window.
points_of_window = 8
# The polynomial order.
poly_order = 2
chart_view.CreateSmoothing(curves, SmoothingType.MovingWindowAveraging, points_of_window, poly_order)

# Signal Processing - FrequencyWeighting
# The weighting type can be AWeighting, BWeighting, or CWeighting.
# The axis type can be X or Y.
chart_view.CreateFrequencyWeighting(curves, WeightingType.AWeighting, FrequencyAxisType.X)
