# Example_ResultFileReaderAPI_Vector.py
import sys

# BINARY_FOLDER_PATH : path to the folder containing the Postprocessor dll files (e.g., D:\Motion\bin)
# RESULT_FILE_READER_API_MODULE_PATH : path to the folder containing ResultFileReaderAPI.py
sys.path.append(BINARY_FOLDER_PATH)
sys.path.append(RESULT_FILE_READER_API_MODULE_PATH)

# Import necessary modules
from ResultFileReaderAPI import *

# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
# The reader that opens the result file.
output_reader = OutputReader(RESULT_FILE_PATH)

print ("===GetVector===")
# Specifies the name of the vector displayable entity.
entity_name = "TJ_01"
# Vector characteristic for the Action Force result.
characteristic_name = "Action Force"
# The vector animation data of the entity and characteristic.
vectors = output_reader.GetVector(entity_name, characteristic_name)
for vector in vectors:
    print(f"Vector : {vector.Key}")
    # The animation data of the vector.
    animation_data = vector.Value

    # The number of position groups in the animation data.
    position_count = len(list(animation_data.Positions))
    for i in range(position_count):
        # The number of position arrays in the group.
        first_position_count = len(list(animation_data.Positions[i]))
        for j in range(first_position_count):
            # The position values of the vector.
            second_positions = list(animation_data.Positions[i][j])
            print("Positions :", *second_positions, sep=',')

    # The number of vector groups in the animation data.
    vector_count = len(list(animation_data.Vectors))
    for i in range(vector_count):
        # The number of vector arrays in the group.
        first_vector_count = len(list(animation_data.Vectors[i]))
        for j in range(first_vector_count):
            # The vector component values.
            second_vectors = list(animation_data.Vectors[i][j])
            print("Vectors :", *second_vectors, sep=',')
# Close
output_reader.Close()
