# Example_OperationAPI_CreatingATransform.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Set array about result file
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path
filepaths.Add(RESULT_FILE_PATH)

# Open about result files
# This will open the result file in the application.
# When the result is first opened, a Page is created and an Animation View is created on that Page.
application_handler.AddDocument(filepaths)

# Get Active Page
# This retrieves the currently active page in the application.
page = application_handler.GetActivePage()

# Creating a Chart
# Create a new Chart View on the page
# This will create a new chart view with the specified name.
chart_name = "Chart"
chart_view = page.CreateChart(chart_name)

# Specify the paths for the curves you want to retrieve.
# For example, Acceleration represents the Characteristic, and Y after the / represents the Component.
# In this case, we are retrieving the Y component of Acceleration for the Crank.
# You can check the available Characteristics and Components for the target by using Add Curve in the Postprocessor.
curve_paths = List[str]()
# characteristic_path_magnitude : characteristic/component path of the curve to add, in "Characteristic/Component" format
characteristic_path_magnitude = r'Displacement/Magnitude'
curve_paths.Add(characteristic_path_magnitude)
# characteristic_path_z : characteristic/component path of the curve to add, in "Characteristic/Component" format
characteristic_path_z = r'Displacement/Z'
curve_paths.Add(characteristic_path_z)

# Create a PlotParameters object to specify the parameters for the plot.
# Set the Entity to Plot.
# The Target is the name of the target for which you want to retrieve the curves.
# Set the paths for the curves you want to retrieve.
# This is where you specify the characteristics and components you want to plot.
parameters = PlotParameters()
parameters.Paths = curve_paths
entity_name = "Crank"
parameters.Target = entity_name

# Add Curves (FilePath, Curve Parameter)
# FilePath : The path of the result to access.
# parameters : The class used as a parameter of the AddCurve function.
# The instance of the curve.
curves = chart_view.AddCurves(RESULT_FILE_PATH, parameters)

# Documentation Example
# Transform : Translate
# OffsetX : The value to translate for X- axis.
# OffsetY : The value to translate for Y- axis.
offset_x = 0
offset_y = 100
chart_view.CreateTranslate(curves, offset_x, offset_y)

# Transform : Scale
# ScaleX : The value to scale for X- axis.
# ScaleY : The value to scale for Y- axis.
scale_x = 2
scale_y = 2
chart_view.CreateScale(curves, scale_x, scale_y)

# Transform : Absolute
# SignType : The types of the absolute value are as follows.
chart_view.CreateAbsolute(curves, SignType.Positive)

# Transform : Align (Zero, Curve)
# AlignType : The types of the alignment are as follows.
chart_view.CreateAlign(curves, AlignType.Curve)

# Transform : Log Scale
# Coeficient : The value of the coefficient.
# BaseValue : The value of the base.
# Decibel : Taking the decibel scale for the list of the curve (20Log_10(Y)).
chart_view.CreateLogScale(curves, 10, 10, False)

# Close the Pages
page.Close()

# Close the Document
application_handler.CloseDocument(RESULT_FILE_PATH)
