# Example_OperationAPI_CreatingContour.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *
from System.Threading import Thread

# Start the headless application interface
application_handler = ApplicationHandler()

# Set array about result file
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path
filepaths.Add(RESULT_FILE_PATH)

# Open about result files
# This will open the result file in the application.
# When the result is first opened, a Page is created and an Animation View is created on that Page.
application_handler.AddDocument(filepaths)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()

find_views = list()
for page in pages :
    views = page.GetViews()
    animation_views = [view for view in views if view.ViewType == ViewType.Animation]
    for animation_view in animation_views :
        if animation_view.DocumentFilePath == RESULT_FILE_PATH and animation_view.AnalysisResultType == AnalysisResultType.Dynamics :
            find_views.append(animation_view)

# RESULT_FILE_PATH : Get the document from the result file path.
document = application_handler.GetDocument(RESULT_FILE_PATH)

# This retrieves the analysis result from the document.
# Types of Analysis Results
# - Dynamics
# - Eigenvalue
# - Statics
dynamic_analysis = document.GetAnalysisResultViewModel(AnalysisResultType.Dynamics)
frame_count = 10
dynamic_analysis.SetAnimationFrame(frame_count)

# It returns the objects available for contouring that correspond to the MappingType.
target_entities = dynamic_analysis.GetContourables(ContourMappingType.FENode)

# Create Contour
# target_entities : Set the entity as the target
# Set Contour Mapping Type
# ContourMappingType can be one of the following:
# - ContourMappingType.None : None
# - ContourMappingType.FENode : Node (Averaged across body)
# - ContourMappingType.FEElement : Element (Unaveraged)
# - ContourMappingType.FEElementNode : Node (Unaveraged)
# - ContourMappingType.FEMaterial : Node (Averaged within material)
# - ContourMappingType.BeamGroup : Beam Group
# - ContourMappingType.Contact : Contact
# - ContourMappingType.ChainedSystem : Chained System
# - ContourMappingType.Usersubroutine : Usersubroutine
# characteristic_path : The path to the characteristic for which the contour will be created.
# component_path : The path to the component for which the contour will be created.
characteristic_name = "Displacement"
component_name = "X"
contour = dynamic_analysis.CreateContour(target_entities, ContourMappingType.FENode, characteristic_name, component_name)

# Contour data is generated on a background task; let it finish before changing properties.
Thread.CurrentThread.Join(3000)

# Set properties for the contour
contour.LegendColorScheme = ColorSchemeType.BLACK_TO_WHITE
contour.AutoRange = False
if contour.AutoRange == False:
    contour.Max = 4
    contour.Min = 1

contour.LegendFontColor = Colors.Red
contour.LogScale = True
contour.LegendVisibility = False
contour.Continuous = True
new_component_name = "Z"
contour.Component = new_component_name
Thread.CurrentThread.Join(3000)
contour.FullName = "FEBody_01_Contour_Z"
contour.MinMaxTargetType = ExtremalValueType.Part
contour.IsEnabled = False
# Closing disposes the model, so let any background contour update finish first.
Thread.CurrentThread.Join(3000)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()
for page in pages :
    page.Close()

# Close the Document
application_handler.CloseDocument(RESULT_FILE_PATH)
