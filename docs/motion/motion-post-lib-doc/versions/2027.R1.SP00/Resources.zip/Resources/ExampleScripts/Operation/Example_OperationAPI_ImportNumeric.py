# Example_OperationAPI_ImportNumeric.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get Active Page
# This retrieves the currently active page in the application.
page = application_handler.GetActivePage()

# Creating a Chart
# Create a new Chart View on the page
# This will create a new chart view with the specified name.
# The name of the new chart view.
chart_name = "Chart"
# The chart view created on the page.
chart_view = page.CreateChart(chart_name)

# Importing Numeric Data
# The numeric parameters that define how to interpret the data in the file.
numeric_parameters = List[INumericParameter](2)

# To create a curve from a file, create a NumericParameter.
# In this example, a curve named 'OrderTrackingCurve' is created, and data corresponding to the X and Y headers is retrieved from the file.
parameter = NumericParameter()
# The name of the curve to be created.
parameter.Name = r'OrderTrackingCurve'
# The name of the X-axis data.
parameter.TargetX = r'Time(sec)'
# The name of the Y-axis data.
parameter.TargetY = r'Value'
numeric_parameters.Add(parameter)

# NUMERIC_INPUT_FILENAME : path to the numeric input file (e.g., D:\PostprocessorAPI\Input\numeric_data.csv)
chart_view.ImportNumeric(NUMERIC_INPUT_FILENAME, numeric_parameters)
