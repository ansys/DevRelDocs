# Example_OperationAPI_ImageCapture.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()

# The animation views that show the dynamic analysis result of the result file.
find_views = list()
for page in pages :
    # The views of the page.
    views = page.GetViews()
    # The animation views of the page.
    animation_views = [view for view in views if view.ViewType == ViewType.Animation]
    for animation_view in animation_views :
        if animation_view.DocumentFilePath == RESULT_FILE_PATH and animation_view.AnalysisResultType == AnalysisResultType.Dynamics :
            find_views.append(animation_view)

# The number of animation views found.
view_count = len(find_views)
if view_count > 0 :
    # Get the document from the result file
    document = application_handler.GetDocument(RESULT_FILE_PATH)

    # This retrieves the analysis result from the document.
    # Types of Analysis Results
    # - Dynamics
    # - Eigenvalue
    # - Statics
    dynamic_analysis = document.GetAnalysisResultViewModel(AnalysisResultType.Dynamics)

    animation_view = find_views[0]
    # The number of animation frames.
    frame_count = 10
    dynamic_analysis.SetAnimationFrame(frame_count)
    # The index of the animation frame to move to.
    frame_index = 5
    dynamic_analysis.MoveToAnimationFrame(frame_index) # MoveToAnimationFrame

    # OUTPUT_DIR : path to the folder where exported files are written (e.g., D:\PostprocessorAPI\Output)
    # IMAGE_OUTPUT_FILENAME : output filename for the exported view image (e.g., chart_image.png)
    # The path of the exported image file.
    export_filepath = Path.Combine(OUTPUT_DIR, IMAGE_OUTPUT_FILENAME)

    # The width of the exported image.
    image_width = 1920
    # The height of the exported image.
    image_height = 1080
    animation_view.ExportImage(export_filepath, ImageFormat.Png, image_width, image_height)
