# Example_OperationAPI_ImageCapture.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Set array about result file
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path
filepaths.Add(RESULT_FILE_PATH)

# Open about result files
# This will open the result file in the application.
# When the result is first opened, a Page is created and an Animation View is created on that Page.
application_handler.AddDocument(filepaths)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()

find_views = list()
for page in pages :
    views = page.GetViews()
    animation_views = [view for view in views if view.ViewType == ViewType.Animation]
    for animation_view in animation_views :
        if animation_view.DocumentFilePath == RESULT_FILE_PATH and animation_view.AnalysisResultType == AnalysisResultType.Dynamics :
            find_views.append(animation_view)

view_count = len(find_views)
if view_count > 0 :
    # RESULT_FILE_PATH : Get the document from the result file path.
    document = application_handler.GetDocument(RESULT_FILE_PATH)

    # This retrieves the analysis result from the document.
    # Types of Analysis Results
    # - Dynamics
    # - Eigenvalue
    # - Statics
    dynamic_analysis = document.GetAnalysisResultViewModel(AnalysisResultType.Dynamics)

    animation_view = find_views[0]
    frame_count = 10
    dynamic_analysis.SetAnimationFrame(frame_count)
    frame_index = 5
    dynamic_analysis.MoveToAnimationFrame(frame_index) # MoveToAnimationFrame

    # OUTPUT_DIR : path to the folder where exported files are written
    # IMAGE_OUTPUT_FILENAME : output filename for the exported view image
    export_filepath = Path.Combine(OUTPUT_DIR, IMAGE_OUTPUT_FILENAME)

    image_width = 1920
    image_height = 1080
    animation_view.ExportImage(export_filepath, ImageFormat.Png, image_width, image_height)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()
for page in pages :
    page.Close()

# Close the Document
application_handler.CloseDocument(RESULT_FILE_PATH)
