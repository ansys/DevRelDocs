# Example_OperationAPI_ExportContourResultToFile.py
# -*- coding: utf-8 -*-
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get Active Page
# This retrieves the currently active page in the application.
page = application_handler.GetActivePage()

# Get Active View
# This retrieves the currently active view in the page.
active_view = page.GetActiveView()

# Loading Animation - Use this only when the current Active View is an Animation View.
# This method is used to load the animation in the active view.
application_handler.LoadingAnimation()

# Get instance of entity
# The GetViewModelByName method retrieves the target by its name.
# The name of the target finite-element body.
entity_name = "FEBody_01"
# The finite-element body with the specified name.
febody = active_view.GetViewModelByName(entity_name)

# Check if the FEBody is found
if febody is None:
    sys.exit(1)

# OUTPUT_DIR : path to the folder where exported files are written (e.g., D:\PostprocessorAPI\Output)
# CONTOUR_OUTPUT_FILENAME : output filename for the exported contour result (e.g., Displacement.txt)
# The path of the exported contour result file.
output_path = Path.Combine(OUTPUT_DIR, CONTOUR_OUTPUT_FILENAME)

# A boolean indicating whether to export the full frame or not.
# If True, the full frame will be exported; if False, only the current frame will be exported.
# True to export all frames, or False to export only the current frame.
is_full_frame = True

# Set the febody fullname as the target for export
# The names of the targets to export.
target_names = List[str]()
target_names.Add(febody.FullName)

# Set Contour Mapping Type
# ContourMappingType can be one of the following:
# - ContourMappingType.None : None
# - ContourMappingType.FENode : Node (Averaged across body)
# - ContourMappingType.FEElement : Element (Unaveraged)
# - ContourMappingType.FEElementNode : Node (Unaveraged)
# - ContourMappingType.FEMaterial : Node (Averaged within material)
# - ContourMappingType.BeamGroup : Beam Group
# - ContourMappingType.Contact : Contact
# - ContourMappingType.ChainedSystem : Chained System
# - ContourMappingType.Usersubroutine : Usersubroutine
# The type of the contour mapping.
contour_mapping_type = ContourMappingType.FENode

# Set Characteristic Path
# The name of the characteristic.
characteristic_name = "Displacement"

# Set Component Path
# The name of the component.
component_name = "X"

# Combine Characteristic and Component Path
# The characteristic/component path of the result to export, in "Characteristic/Component" format.
combined_characteristic_component_path = characteristic_name + "/" + component_name

# Export Contour Result to File - When the Animation View is the Active View
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
# The analysis type argument is optional. The default value is AnalysisResultType.Dynamics.
# The file format type argument is optional. The default is FileFormatType.TXT. The format type can be set to TXT or BINARY.
Export.ExportContourResultToFile(RESULT_FILE_PATH, output_path, target_names, is_full_frame, contour_mapping_type, combined_characteristic_component_path)
