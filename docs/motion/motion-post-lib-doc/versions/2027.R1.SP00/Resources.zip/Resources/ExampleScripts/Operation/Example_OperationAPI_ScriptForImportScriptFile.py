# Example_OperationAPI_ScriptForImportScriptFile.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

from OperationAPI import *

# Initialize the Operation API application and suppress message boxes.
application_handler = ApplicationHandler()
application_handler.IsShowMessageBox = False

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Create a page to demonstrate an Operation API call
# The name of the page.
page_name = "FirstPage"
application_handler.AddPage(page_name)
