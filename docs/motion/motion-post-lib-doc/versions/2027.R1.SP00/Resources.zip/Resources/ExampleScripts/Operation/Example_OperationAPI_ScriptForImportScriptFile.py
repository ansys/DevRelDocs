# Example_OperationAPI_ScriptForImportScriptFile.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

from OperationAPI import *

# Initialize the Operation API application and suppress message boxes.
applicationHandler = ApplicationHandler()
applicationHandler.IsShowMessageBox = False

# Open the result file in the application.
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path
filepaths.Add(RESULT_FILE_PATH)
applicationHandler.AddDocument(filepaths)

# Create and close a page to demonstrate an Operation API call.
page_name = "FirstPage"
page = applicationHandler.AddPage(page_name)
page.Close()

# Close the result file and application.
applicationHandler.CloseDocument(RESULT_FILE_PATH)
applicationHandler.Close()
