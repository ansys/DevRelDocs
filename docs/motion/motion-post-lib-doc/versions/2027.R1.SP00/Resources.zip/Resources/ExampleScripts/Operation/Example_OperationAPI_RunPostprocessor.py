# Example_OperationAPI_RunPostprocessor.py
import sys
import clr

# BINARY_FOLDER_PATH : path to the folder containing Postprocessor.exe in the installed Motion (e.g., D:\Motion\bin)
sys.path.append(BINARY_FOLDER_PATH)

clr.AddReference("VM.Windows.Post.Remoting")

from System.Reflection import AssemblyName
from VM.Windows.Post import PostprocessorRemotingUtil

# POSTPROCESSOR_EXE_PATH : full path to the Postprocessor executable (e.g., D:\Motion\bin\Postprocessor.exe)
# The version of Postprocessor.exe.
version = AssemblyName.GetAssemblyName(POSTPROCESSOR_EXE_PATH).Version
# The remoting utility that starts Postprocessor and runs scripts in it.
postprocessor = PostprocessorRemotingUtil(version, False)
postprocessor.RunPostprocessor(POSTPROCESSOR_EXE_PATH).Wait()

# IMPORT_SCRIPT_FILE_PATH : full path to the Operation API script to run in the Postprocessor (e.g., D:\PostprocessorAPI\Example\Example_OperationAPI_ScriptForImportScriptFile.py)
postprocessor.ImportScriptFile(IMPORT_SCRIPT_FILE_PATH).Wait()
