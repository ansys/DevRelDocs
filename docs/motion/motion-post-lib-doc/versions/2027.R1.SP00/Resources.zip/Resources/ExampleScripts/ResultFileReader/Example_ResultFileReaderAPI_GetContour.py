# Example_ResultFileReaderAPI_GetContour.py
import sys

# BINARY_FOLDER_PATH : path to the folder containing the Postprocessor dll files (e.g., D:\Motion\bin)
# RESULT_FILE_READER_API_MODULE_PATH : path to the folder containing ResultFileReaderAPI.py
sys.path.append(BINARY_FOLDER_PATH)
sys.path.append(RESULT_FILE_READER_API_MODULE_PATH)

# Import necessary modules
from ResultFileReaderAPI import *

# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
# The reader that opens the result file.
output_reader = OutputReader(RESULT_FILE_PATH)

# State ID Array
state_ids = output_reader.GetStateIDArray()

# Select the entity and the characteristic/component path to read.
# The name of the target finite-element body.
entity_name = "FEBody_01"
# Characteristic/component path for the Top Stress X contour result.
characteristic_name = "Top Stress/X"

# Define the callback that receives contour values for each state.
def write_result(state_id, result_groups):
    print(f"State ID: {state_id}")
    print(f"Value groups: {len(result_groups)}")
# The callback that receives the contour values of each state.
action = Action[Int32, IList[Array[Double]]](write_result)

# Read contour values for the selected entity and each requested state.
output_reader.GetContourResult(
    state_ids,
    entity_name,
    ContourMappingType.FENode,
    characteristic_name,
    action,
    AnalysisResultType.Dynamics,
)

# Close
output_reader.Close()
