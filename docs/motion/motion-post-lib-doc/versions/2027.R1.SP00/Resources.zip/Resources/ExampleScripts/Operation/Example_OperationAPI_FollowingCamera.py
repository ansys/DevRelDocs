# Example_OperationAPI_FollowingCamera.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# ANIMATION_RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\LogtudinalX_VibrationZ.dfr)
filepaths.Add(ANIMATION_RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get the document from the result file
document = application_handler.GetDocument(ANIMATION_RESULT_FILE_PATH)

# This retrieves the analysis result from the document.
dynamic_analysis = document.GetAnalysisResultViewModel(AnalysisResultType.Dynamics)

# Create the animation view on the active page.
page = application_handler.GetActivePage()
# The first view of the page.
animation_view = page.GetViews()[0]

# Set the camera to a starting viewpoint before recording.
# The X coordinate of the camera position.
eye_x = 400
# The Y coordinate of the camera position.
eye_y = 85
# The Z coordinate of the camera position.
eye_z = 10
# The X coordinate of the point the camera looks at.
target_x = 0
# The Y coordinate of the point the camera looks at.
target_y = 85
# The Z coordinate of the point the camera looks at.
target_z = 10
# The X component of the camera up vector.
up_vector_x = 0
# The Y component of the camera up vector.
up_vector_y = 0
# The Z component of the camera up vector.
up_vector_z = 1
# The camera specification applied to the animation view.
view_spec = ViewSpec()
view_spec.Eye = Vector(eye_x, eye_y, eye_z)
view_spec.Target = Vector(target_x, target_y, target_z)
view_spec.UpVector = Vector(up_vector_x, up_vector_y, up_vector_z)
animation_view.SetViewSpec(view_spec)

# Select the entity that the camera follows.
# The target can be a body, a marker, a coordinate system, or a node.
# The full name of the entity that the camera follows.
target_full_name = "BD_02"
animation_view.SetFollowingCameraTarget(target_full_name)


# Turn camera tracking on so the camera follows the selected target.
animation_view.IsFollowingCameraActive = True

# Follow the target's translation along the enabled axes.
animation_view.TransformationType = TransformationType.Translation
animation_view.IsFollowingXAxis = True
animation_view.IsFollowingYAxis = True
animation_view.IsFollowingZAxis = False

# Sets a specified number of animation frames.
# This will set the animation frame to the specified number.
# The number of animation frames.
frame_count = 50
dynamic_analysis.SetAnimationFrame(frame_count)

# OUTPUT_DIR : path to the folder where exported files are written (e.g., D:\PostprocessorAPI\Output)
# FOLLOWING_CAMERA_OUTPUT_NAME : output filename for the recorded animation, without a file extension (e.g., following_camera_animation)
# The path of the recorded animation file, without an extension.
export_filepath = Path.Combine(OUTPUT_DIR, FOLLOWING_CAMERA_OUTPUT_NAME)
# Record the loaded frames. Passing no viewSpecs keeps the current camera position for every
# frame, which the active camera tracking set up above updates as the target moves.
animation_view.RecordingAnimation(export_filepath, RecordingType.MP4, RecordingRangeType.ActiveView, 10)
