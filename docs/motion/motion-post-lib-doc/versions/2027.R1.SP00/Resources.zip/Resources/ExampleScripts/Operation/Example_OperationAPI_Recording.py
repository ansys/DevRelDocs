# Example_OperationAPI_Recording.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Set array about result file
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path
filepaths.Add(RESULT_FILE_PATH)

# Open about result files
# This will open the result file in the application.
# When the result is first opened, a Page is created and an Animation View is created on that Page.
application_handler.AddDocument(filepaths)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()

find_views = list()
for page in pages :
    views = page.GetViews()
    animation_views = [view for view in views if view.ViewType == ViewType.Animation]
    for animation_view in animation_views :
        if animation_view.DocumentFilePath == RESULT_FILE_PATH and animation_view.AnalysisResultType == AnalysisResultType.Dynamics :
            find_views.append(animation_view)

view_count = len(find_views)
if view_count > 0 :
    # RESULT_FILE_PATH : Get the document from the result file path.
    document = application_handler.GetDocument(RESULT_FILE_PATH)

    # This retrieves the analysis result from the document.
    # Types of Analysis Results
    # - Dynamics
    # - Eigenvalue
    # - Statics
    dynamic_analysis = document.GetAnalysisResultViewModel(AnalysisResultType.Dynamics)

    animation_view = find_views[0]

    # Sets a specified number of animation frames.
    # This will set the animation frame to the specified number.
    frame_count = 100
    dynamic_analysis.SetAnimationFrame(frame_count)

    # OUTPUT_DIR : path to the folder where exported files are written
    # RECORDING_OUTPUT_NAME : output filename for the recorded animation, without a file extension
    export_filepath = Path.Combine(OUTPUT_DIR, RECORDING_OUTPUT_NAME)
    specs = animation_view.GetViewSpecs()
    start_eye_x = -300.0
    end_eye_x = 300.0
    for frame_index in range(frame_count):
        progress = float(frame_index) / (frame_count - 1)
        eye_x = start_eye_x + (end_eye_x - start_eye_x) * progress
        specs[frame_index].Eye = Vector(eye_x, 0, 700)
        specs[frame_index].Target = Vector(0, 50, 0)
        specs[frame_index].UpVector = Vector(0, 1, 0)

    # Recording Animation
    animation_view.RecordingAnimation(export_filepath, RecordingType.MP4, RecordingRangeType.ActiveView, 10, specs)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()
for page in pages :
    page.Close()

# Close the Document
application_handler.CloseDocument(RESULT_FILE_PATH)
