# Example_OperationAPI_Recording.py
import sys

# OPERATION_API_MODULE_PATH : path to the folder containing OperationAPI.py
sys.path.append(OPERATION_API_MODULE_PATH)

# Import necessary modules
from OperationAPI import *

# Start the headless application interface
application_handler = ApplicationHandler()

# Create a list of result file paths
filepaths = List[str]()
# RESULT_FILE_PATH : .dfr result file path (e.g., D:\PostprocessorAPI\Results\Tutorial_ModalFlex.dfr)
filepaths.Add(RESULT_FILE_PATH)

# Open the result file
# This opens the result file in the application.
# When a result file is opened for the first time, a page and an Animation View are created automatically.
application_handler.AddDocument(filepaths)

# Get all created pages.
# This retrieves all pages created in the application.
pages = application_handler.GetPages()

# The animation views that show the dynamic analysis result of the result file.
find_views = list()
for page in pages :
    # The views of the page.
    views = page.GetViews()
    # The animation views of the page.
    animation_views = [view for view in views if view.ViewType == ViewType.Animation]
    for animation_view in animation_views :
        if animation_view.DocumentFilePath == RESULT_FILE_PATH and animation_view.AnalysisResultType == AnalysisResultType.Dynamics :
            find_views.append(animation_view)

# The number of animation views found.
view_count = len(find_views)
if view_count > 0 :
    # Get the document from the result file
    document = application_handler.GetDocument(RESULT_FILE_PATH)

    # This retrieves the analysis result from the document.
    # Types of Analysis Results
    # - Dynamics
    # - Eigenvalue
    # - Statics
    dynamic_analysis = document.GetAnalysisResultViewModel(AnalysisResultType.Dynamics)

    animation_view = find_views[0]

    # Sets a specified number of animation frames.
    # This will set the animation frame to the specified number.
    # The number of animation frames.
    frame_count = 100
    dynamic_analysis.SetAnimationFrame(frame_count)

    # OUTPUT_DIR : path to the folder where exported files are written (e.g., D:\PostprocessorAPI\Output)
    # RECORDING_OUTPUT_NAME : output filename for the recorded animation, without a file extension (e.g., result_animation)
    # The path of the recorded animation file, without an extension.
    export_filepath = Path.Combine(OUTPUT_DIR, RECORDING_OUTPUT_NAME)
    # The camera specifications, one for each loaded animation frame.
    specs = animation_view.GetViewSpecs()
    # The X coordinate of the camera position at the first frame.
    start_eye_x = -300.0
    # The X coordinate of the camera position at the last frame.
    end_eye_x = 300.0
    for frame_index in range(frame_count):
        # The progress of the current frame within the recording range, from 0 to 1.
        progress = float(frame_index) / (frame_count - 1)
        # The X coordinate of the camera position at the current frame.
        eye_x = start_eye_x + (end_eye_x - start_eye_x) * progress
        specs[frame_index].Eye = Vector(eye_x, 0, 700)
        specs[frame_index].Target = Vector(0, 50, 0)
        specs[frame_index].UpVector = Vector(0, 1, 0)

    # Recording Animation
    animation_view.RecordingAnimation(export_filepath, RecordingType.MP4, RecordingRangeType.ActiveView, 10, specs)
