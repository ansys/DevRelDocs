# Classes

* [IRockyAdhesiveDistanceData](classIRockyAdhesiveDistanceData.md#classIRockyAdhesiveDistanceData)
* [IRockyInteractionCalculationsData](classIRockyInteractionCalculationsData.md#classIRockyInteractionCalculationsData)
* [IRockyPluginDataEntry](classIRockyPluginDataEntry.md#classIRockyPluginDataEntry)
* [IRockyTimestepData](classIRockyTimestepData.md#classIRockyTimestepData)
* [IRockyPluginData](classIRockyPluginData.md#classIRockyPluginData)