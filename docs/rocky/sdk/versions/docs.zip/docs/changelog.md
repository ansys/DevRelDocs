# Changelog

## Release notes for 2027 R1

### Added
- `IRockyDeviceModel::get_field_source` method.
- `IRockySPHDeviceModel::get_field_source` method.
- `IRockyModel::get_field_sources_data` method.
- `IRockyModel::find_field_source` method.
- `IRockyModel::get_field_source` method.
- `IRockyFieldSourcesData::enable_dem_field_source_mapping` method.
- `IRockyFieldSourcesData::enable_sph_field_source_mapping` method.
- `IRockyFieldSource::find_property` method.
- `IRockyFieldSource::set_property_dimension` method.
- `IRockyFieldSource::is_enabled` method.
- `IRockyFieldSourceElement::get_property` method.
- `IRockyFieldSourceElement::is_valid` method.
- `IRockyFieldSourceElement::is_enabled` method.
- `IRockyFieldSourceElement::get_position` method.