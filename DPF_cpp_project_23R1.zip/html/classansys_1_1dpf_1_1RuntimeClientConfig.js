var classansys_1_1dpf_1_1RuntimeClientConfig =
[
    [ "enableCache", "classansys_1_1dpf_1_1RuntimeClientConfig.html#ab83354eaf4d8646fd7d06e0f5dbdafaf", null ],
    [ "getStreamingBufferSize", "classansys_1_1dpf_1_1RuntimeClientConfig.html#a31e99b0bf8468a58ca3b5bcaa1412fe6", null ],
    [ "isCacheEnabled", "classansys_1_1dpf_1_1RuntimeClientConfig.html#aac0f20eaf4cb412d3ef03d787ac38f06", null ],
    [ "setStreamFloatsInsteadOfDoubles", "classansys_1_1dpf_1_1RuntimeClientConfig.html#a380e861289e9683a04ca84c250b0ecf7", null ],
    [ "setStreamingBufferSize", "classansys_1_1dpf_1_1RuntimeClientConfig.html#a286701384f2b37237c61f20d1c24eae6", null ],
    [ "streamingFloatsInsteadOfDouble", "classansys_1_1dpf_1_1RuntimeClientConfig.html#a38db32f9104c3c2884a734a7cf606ed7", null ]
];