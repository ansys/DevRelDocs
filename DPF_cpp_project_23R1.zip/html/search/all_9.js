var searchData=
[
  ['job_5fname_0',['job_name',['../classansys_1_1dpf_1_1ResultInfo.html#ae6ed610647bdabcc9baab02b19462f99',1,'ansys::dpf::ResultInfo']]]
];
