var classansys_1_1dpf_1_1Session =
[
    [ "Session", "classansys_1_1dpf_1_1Session.html#a35c8573a7a81b571b6856c75142921a5", null ],
    [ "add", "classansys_1_1dpf_1_1Session.html#a1ca0f541376f2606d6a1d38d73b42095", null ],
    [ "add", "classansys_1_1dpf_1_1Session.html#a44217e8e1b859b6bbc3cd902597a441b", null ],
    [ "addEventHandler", "classansys_1_1dpf_1_1Session.html#a9d2f09db50b3767c062100bfc0b67e2c", null ],
    [ "getWorkflow", "classansys_1_1dpf_1_1Session.html#a1eb04b4b9a1df351de2211ed4a9065f3", null ],
    [ "getWorkflowByIndex", "classansys_1_1dpf_1_1Session.html#a0c351a7e9deb14ef205168a8c2a14535", null ],
    [ "id", "classansys_1_1dpf_1_1Session.html#a4fdd43dbb146e6bef0e69fdc3f6b8ac8", null ],
    [ "numberOfWorkflow", "classansys_1_1dpf_1_1Session.html#ae6197db1ac01a01c67f4f87955c2b849", null ]
];