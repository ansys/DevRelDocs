var classansys_1_1dpf_1_1ExternalStream =
[
    [ "fileName", "classansys_1_1dpf_1_1ExternalStream.html#a80d1920a080fd91dc80850b6b465cc29", null ],
    [ "release", "classansys_1_1dpf_1_1ExternalStream.html#aa6f23cac0435e5324144ee0887e80ecf", null ],
    [ "streamTypeName", "classansys_1_1dpf_1_1ExternalStream.html#a0e85f7d70ad9c2a2b80c81bf6ac2ed20", null ]
];