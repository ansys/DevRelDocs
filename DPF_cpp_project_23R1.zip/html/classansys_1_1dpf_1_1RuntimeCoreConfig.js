var classansys_1_1dpf_1_1RuntimeCoreConfig =
[
    [ "getNumberOfThreadsToUse", "classansys_1_1dpf_1_1RuntimeCoreConfig.html#a4ae882d7ed1e89ad3d03a761f6f485c1", null ],
    [ "setNumberOfThreadsToUse", "classansys_1_1dpf_1_1RuntimeCoreConfig.html#af02bd1ff8d573d83cecefcdd647f0a0b", null ]
];