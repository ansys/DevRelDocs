var searchData=
[
  ['realattribute_0',['RealAttribute',['../classsysc_1_1_real_attribute.html',1,'sysc']]],
  ['region_1',['Region',['../classsysc_1_1_region.html',1,'sysc']]],
  ['resultsinfo_2',['ResultsInfo',['../structsysc_1_1_results_info.html',1,'sysc']]]
];
