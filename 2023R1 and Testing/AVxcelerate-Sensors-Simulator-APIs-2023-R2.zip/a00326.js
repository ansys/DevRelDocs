var a00326 =
[
    [ "analog_to_digital_converter", "a00326.xhtml#aee5d8c98ddf7dcdd474096a790b8ad73", null ],
    [ "max_range", "a00326.xhtml#a2ef989d5575af5b4a9b494a2db13c8ab", null ],
    [ "max_returns", "a00326.xhtml#a2a132654b2d59075b1eacb2caa2065ea", null ]
];