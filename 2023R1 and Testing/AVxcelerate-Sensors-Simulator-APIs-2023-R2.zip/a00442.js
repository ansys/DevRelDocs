var a00442 =
[
    [ "material_path", "a00442.xhtml#aaceb40631c9f8ebf46ec816d67aac87e", null ],
    [ "mesh_part_name", "a00442.xhtml#a33b485a1c16a89ed529e1041f2bcd804", null ]
];