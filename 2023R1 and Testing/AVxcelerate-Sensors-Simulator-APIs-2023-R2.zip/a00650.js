var a00650 =
[
    [ "lighting_system_parameters", "a00650.xhtml#a1fb9614b06557a139728dfa015be7fb9", null ],
    [ "pixel_segmentation_mapping", "a00650.xhtml#a1cadf10a54028a12ef433455858a2438", null ],
    [ "sensor_simulation_parameters", "a00650.xhtml#a31970d26ac4b480d8a1e381b63ff70dc", null ]
];