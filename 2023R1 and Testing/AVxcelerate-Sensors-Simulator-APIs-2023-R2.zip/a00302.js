var a00302 =
[
    [ "horizontal", "a00302.xhtml#a54b4f2181863ed5669a68c6183c464b1", null ],
    [ "vertical", "a00302.xhtml#a73efc1503c3577dce2526ae306c719b2", null ]
];