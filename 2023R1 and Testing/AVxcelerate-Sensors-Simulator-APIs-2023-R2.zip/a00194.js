var a00194 =
[
    [ "focal_shift", "a00194.xhtml#abcdd9e91085d744773789375fe5d3a34", null ]
];