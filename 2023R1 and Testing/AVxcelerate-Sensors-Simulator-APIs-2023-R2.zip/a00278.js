var a00278 =
[
    [ "azimuth", "a00278.xhtml#af21d385016cc574440f420a87ccdebdd", null ],
    [ "elevation", "a00278.xhtml#a37b5ef9efa5500172474da495eb7266c", null ],
    [ "peak_power", "a00278.xhtml#a9d1ee6934f58d7617c044f68bdd9c677", null ],
    [ "time", "a00278.xhtml#a86ae2e189968a4f26a1d5d2af037d524", null ]
];