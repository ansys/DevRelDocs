var a00762 =
[
    [ "tag", "a00762.xhtml#a393c6f8edab12c9bc01544d29db5ac0f", null ],
    [ "vss_identity", "a00762.xhtml#a17c44c2a2a48a05ba60363dabb23ac8d", null ]
];