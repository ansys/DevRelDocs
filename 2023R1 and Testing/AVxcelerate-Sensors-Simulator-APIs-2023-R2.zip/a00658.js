var a00658 =
[
    [ "display_only", "a00658.xhtml#a576696c35d01e305e0c22c2fb8d2e28b", null ],
    [ "top_left_corner_position", "a00658.xhtml#aa67bd52b710562d2d069ab23ba6561d6", null ]
];