var a00642 =
[
    [ "bus_id", "a00642.xhtml#aaf69089e9c89cff5401a52779937a5bc", null ],
    [ "index", "a00642.xhtml#a4d73f14555f456a4a579645371b74593", null ],
    [ "name", "a00642.xhtml#a2a5aeaedb916b63f402e3867e472d660", null ],
    [ "uuid", "a00642.xhtml#a68d397eeda4cf9f4b79539b378da8149", null ]
];