var a00542 =
[
    [ "data", "a00542.xhtml#a7928920bcb41f78da6f86f8d1d5583c9", null ],
    [ "waveform_length", "a00542.xhtml#a6d54d14d65e0f2700335d1decfd91a62", null ]
];