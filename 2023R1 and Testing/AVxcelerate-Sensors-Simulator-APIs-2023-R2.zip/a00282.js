var a00282 =
[
    [ "aperture_area", "a00282.xhtml#aabec54d9b2cbeca9dd3d7344bd9e7d26", null ],
    [ "photo_detector", "a00282.xhtml#af13cb46a9a38bf59ef6eef2110775bc1", null ],
    [ "processor", "a00282.xhtml#af834b53ad2333a4bf86bf9e6e609a3df", null ]
];