var a00454 =
[
    [ "lighting_system_state", "a00454.xhtml#ae0b150d0fb0b5a1bc5ee331fd5f9b07d", null ],
    [ "simulation_time", "a00454.xhtml#a1496c37bb746ba39c02a65c9f7d3cc24", null ]
];