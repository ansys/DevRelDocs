var a00262 =
[
    [ "emitter", "a00262.xhtml#aade093db53db24899b883410ae73b087", null ],
    [ "receiver", "a00262.xhtml#a740e46af48b460a8103e8490d79bd047", null ],
    [ "rotation_speed", "a00262.xhtml#a0d7e695db66cd06cdcbc076055bd9852", null ]
];