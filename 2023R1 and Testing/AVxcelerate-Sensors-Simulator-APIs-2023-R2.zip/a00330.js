var a00330 =
[
    [ "bit_resolution", "a00330.xhtml#a6e0f521da4a167ce578a8793f8276941", null ],
    [ "sampling_frequency", "a00330.xhtml#a76a0ffa54413fbba7b2c7449a6472134", null ]
];