var a00526 =
[
    [ "data", "a00526.xhtml#ace2e1c0e5eee75a3245447ed2e8f1948", null ],
    [ "waveform_length", "a00526.xhtml#a996e4b3405c200f73d0761573fea1e62", null ]
];