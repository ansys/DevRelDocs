var a00234 =
[
    [ "dark_current_average_value", "a00234.xhtml#ad57972e361cbcda79719bf16296211c6", null ]
];