var a00470 =
[
    [ "lamps_state", "a00470.xhtml#a0f4b1ae38eebc60cd1260c9e14be9d90", null ],
    [ "module_name", "a00470.xhtml#a565ad260189d51c0864dd4f2bbc98658", null ],
    [ "orientation", "a00470.xhtml#a1712e92d8a8a3a22d232e56b99ceb862", null ],
    [ "position", "a00470.xhtml#a491b5f0dd654556c3cf53ba972458448", null ]
];