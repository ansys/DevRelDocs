var a00446 =
[
    [ "GetContributionDictionary", "a00446.xhtml#a3c572ff6aa0ad1b8a7b0cddeaaeece95", null ],
    [ "GetPixelSegmentationTagColorMap", "a00446.xhtml#aa10263ce0770a3748c87d3055d7342d7", null ]
];