var a00322 =
[
    [ "max_current", "a00322.xhtml#a75e8d9b10d17ca9d225927bf97910ad8", null ],
    [ "noise_standard_deviation", "a00322.xhtml#a930d6441bc9601544a2263b50b25e5bc", null ],
    [ "responsivity", "a00322.xhtml#af768300aaac0474138c4e62bf482b6fb", null ]
];