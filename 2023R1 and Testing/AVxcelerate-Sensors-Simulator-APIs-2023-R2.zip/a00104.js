var a00104 =
[
    [ "data_access", "a00105.xhtml", "a00105" ],
    [ "feedback_control", "a00106.xhtml", "a00106" ],
    [ "ground_truth_access", "a00107.xhtml", "a00107" ],
    [ "lighting_system_control", "a00108.xhtml", "a00108" ],
    [ "sensor_data", "a00109.xhtml", "a00109" ],
    [ "simulation", "a00110.xhtml", "a00110" ],
    [ "Color", "a00782.xhtml", "a00782" ],
    [ "EulerAngles", "a00410.xhtml", "a00410" ],
    [ "ObjectIdentifier", "a00478.xhtml", "a00478" ],
    [ "PixelSegmentationMapping", "a00786.xhtml", "a00786" ],
    [ "ResourceIdentifier", "a00482.xhtml", "a00482" ],
    [ "Status", "a00778.xhtml", "a00778" ],
    [ "Vector3D", "a00406.xhtml", "a00406" ]
];