var a00754 =
[
    [ "date_time", "a00754.xhtml#aa1c4817b2557a886a6b1eb955ecc2331", null ],
    [ "streetLightsState", "a00754.xhtml#a55256ba6cb1cf035a9ad4e7780d8eef5", null ]
];