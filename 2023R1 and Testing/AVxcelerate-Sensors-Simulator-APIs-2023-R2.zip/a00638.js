var a00638 =
[
    [ "node_id", "a00638.xhtml#aab7415ed288e0cb645b7ea777807fc69", null ],
    [ "port", "a00638.xhtml#a1f0b0fe1a6e257d96edb11ec34300b25", null ]
];