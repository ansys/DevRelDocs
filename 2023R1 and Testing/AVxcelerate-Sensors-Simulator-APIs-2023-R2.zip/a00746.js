var a00746 =
[
    [ "resource_identifier", "a00746.xhtml#aef069f6bd46cea43ac09d1880b09577a", null ]
];