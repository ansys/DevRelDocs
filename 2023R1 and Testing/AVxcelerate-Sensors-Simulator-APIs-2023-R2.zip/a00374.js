var a00374 =
[
    [ "frequency_modulated_continuous_waveform", "a00374.xhtml#ab36d87024ca30ccb546aa2d26e448747", null ],
    [ "pulse_doppler_waveform", "a00374.xhtml#ae5075acb9d557c07671746ffa4da18e9", null ]
];