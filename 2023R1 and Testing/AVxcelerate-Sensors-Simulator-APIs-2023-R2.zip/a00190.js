var a00190 =
[
    [ "custom_chromatic_dispersion", "a00190.xhtml#a9cd10c825b9f9cd4723971649d949a66", null ],
    [ "focal_length", "a00190.xhtml#a623fb6fa3b48befce461398200ebef82", null ],
    [ "preset_chromatic_dispersion", "a00190.xhtml#ae6bb0c875d174779a96a36b8650b3f5e", null ],
    [ "wavelength_of_focal_length", "a00190.xhtml#ac549aaa5a98ea07b86087ff104fd31c1", null ]
];