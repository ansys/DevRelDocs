var a00402 =
[
    [ "performance", "a00402.xhtml#a05af6d72d67ba21c0d4ad5b4828c26ed", null ],
    [ "rx_components", "a00402.xhtml#a14f91bf84e3d8f095f1a459d4169f194", null ],
    [ "sampling_rate", "a00402.xhtml#a44cf22bdf8f420fa33c5b4f66592196d", null ]
];