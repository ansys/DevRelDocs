var a00134 =
[
    [ "formats", "a00134.xhtml#af9e966b36073e1f8409e60599ec5c6b3", null ],
    [ "resolution", "a00134.xhtml#a0b83adf75865305ce39ac56c74d94886", null ]
];