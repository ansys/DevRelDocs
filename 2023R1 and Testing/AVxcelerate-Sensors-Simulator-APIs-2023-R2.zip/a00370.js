var a00370 =
[
    [ "side_lobe_level", "a00370.xhtml#add310bfcc457aa85ce5fc742791ec420", null ]
];