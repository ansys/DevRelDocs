/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "Getting started", "getting_started.html", null ],
    [ "User guide", "modules.xhtml", "modules" ],
    [ "Operators", "^https://dpf.docs.pyansys.com/version/0.8/operator_reference_load_apis.html", null ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Typedefs", "namespacemembers_type.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Examples", "examples.xhtml", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"AveragingTest_8cpp-example.xhtml",
"classansys_1_1dpf_1_1DataTree.xhtml#a35917cb2bc740594ed3dbfb6d6f4b20a",
"classansys_1_1dpf_1_1Field.xhtml#aa16920741c1432c16e46ec6da26b3f04",
"classansys_1_1dpf_1_1MeshQuery.xhtml#a0eaa2cac7c87dbc1b8b5f2b276df2509",
"classansys_1_1dpf_1_1Operator.xhtml#a2fc8d610df3ce984f84e75a7297d52c1",
"classansys_1_1dpf_1_1OperatorMain.xhtml#a13cd3ab170883dae7943255b33078cba",
"classansys_1_1dpf_1_1ResultInfo.xhtml#a09bb53667b42b70d13356395437cfe77",
"classansys_1_1dpf_1_1Session.xhtml#a1ca0f541376f2606d6a1d38d73b42095",
"classansys_1_1dpf_1_1Workflow.xhtml#a545556717c00fa45e69d5ef73db01a56",
"classansys_1_1dpf_1_1core.xhtml#ae9c538db9a8802e9ec28e9e7b40267b5",
"structansys_1_1dpf_1_1QuantityType.xhtml#aad0ded6e541fc561a3c3d1c28cdcaf3f",
"structansys_1_1dpf_1_1property__types.xhtml#a045cec6548d902ddedea643c669ab466"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';