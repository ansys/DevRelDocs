var namespaces_dup =
[
    [ "ansys", null, [
      [ "dpf", "namespaceansys_1_1dpf.xhtml", "namespaceansys_1_1dpf" ]
    ] ]
];