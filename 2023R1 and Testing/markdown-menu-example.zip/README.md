# Generic MarkDown Example Dataset with Separate Files for Navigation Links

This is a very simple Github-flavored MarkDown dataset that encapsulates what the generic importer on the Ansys developer portal is looking for and will process. Note that your MarkDown output should be flattened into one directory, with subdirectories (one level) for images and other assets.

This particular importer reconstructs sidebar navigation and information hierarchy, including breadcrumbs, from the included menu MarkDown file.

## Navigation from Menu file

Navigation is specified in a separate MarkDown file with an arbitrary name. You will be able to specify which file contains the navigation when configuring the importer. This navigation file is mandatory.

The menu list is assumed to be ordered and imply the information hierarchy. For example, if we have this menu.md file:
```
1. [Item1]item1
  - [Item1.1]item1-1
  - [Item1.2]item1-2
2. [Item2]item2
3. [Item3]item3
```
then items 1-3 are assumed to be siblingss, while items 1.1 and 1.2 are children of item1.  The resulting menu will look like this:
```
Item1
  Item1.1
  Item1.2
Item2
Item3
```
and URIs and breadcrumbs will reflect this hierarchy too. 

The importer will extract a complete sidebar menu from this file, as well as information hierarchy and breadcrumbs. Please be sure that your MarkDown export also specifies main navigation (top menu) items, as all navigation within your product documentation will move into the sidebar on the developer portal.

## Content files

### Metadata

```
---
last_updated: "2023-01-04"
version: "0.6.42"
summary: "This is my summary"
tags: ["MyProduct", "some other tag"]
---
```
You can include metadata at the top of each MarkDown content file in YAML format, preceeded and followed by triple dashes. Only YAML metadata at the very top of a content Markdown file will be parsed and used. Meta information is optional, but extremely useful to provide proper tagging on import. If last_updated is omitted, the importer will use the import date. If version is omitted, no version information will be displayed on the portal. Summary will be used for <meta name="description" entry in the HTML head section for SEO purposes, instead of the portal auto-extracting the title and first paragraph from the content.

### Content

```
# Item1

Body text example.
```

A heading 1 tag near the top of the content MarkDown and after the metadata YAML (if supplied) is mandatory, and it will be used as the page title.

At least one more line of valid Github-flavored MarkDown is mandatory and will be used to populate the page content field. Since Github-flavored MarkDown is a superset of CommonMark, the entire CommonMark specification is supported. The example files contain all supported markup for your reference.

Please make sure that internal links and image references are relative and conform to the implied menu hierarchy. Note that all inline HTML style specifications will be disregarded and supplanted by the developer portal styles. Inlined HTML classes will be retained, and if classes in your source match classes and styling used in the portal, they will be honored. In particular, valid ```<code class="language-python">``` markup (substitute any other common language here) will result in appropriate code highlighting.

### Images

Images in WebP format are preferred - the developer portal team may at a future time enforce this. The developer portal also supports PNG, Jpeg, and GIF formats. Please make sure any images are optimized to the smallest possible file size while retaining legibility and clarity.

