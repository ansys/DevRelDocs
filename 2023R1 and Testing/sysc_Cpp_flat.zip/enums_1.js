var searchData=
[
  ['convergencestatus_0',['ConvergenceStatus',['../group__SystemCouplingParticipantAPIs.xhtml#ga0b8801743579159eb41cf07d8372a734',1,'sysc']]]
];
