var searchData=
[
  ['facecellconnectivity_0',['faceCellConnectivity',['../structsysc_1_1FaceData.xhtml#af34fb6e2c2337068f19700e6da494275',1,'sysc::FaceData']]],
  ['faceids_1',['faceIds',['../structsysc_1_1FaceData.xhtml#a054bb75bbf88c08c5065b5f2f20dbf12',1,'sysc::FaceData']]],
  ['facenodeconnectivity_2',['faceNodeConnectivity',['../structsysc_1_1FaceData.xhtml#a4758c21d1ccd7b1ac07f231eb91e7540',1,'sysc::FaceData']]],
  ['facenodecounts_3',['faceNodeCounts',['../structsysc_1_1FaceData.xhtml#a8b63b98b757af684ee7d111a7e11a586',1,'sysc::FaceData']]],
  ['facetypes_4',['faceTypes',['../structsysc_1_1FaceData.xhtml#a791906023249db75a1b7437d7b5ca998',1,'sysc::FaceData']]]
];
