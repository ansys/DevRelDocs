var structsysc_1_1SolutionControl =
[
    [ "maximumIterations", "structsysc_1_1SolutionControl.xhtml#a0c973b27756ebeaf6fbe6d456c13b697", null ],
    [ "minimumIterations", "structsysc_1_1SolutionControl.xhtml#a6c84cc77b261df44b0f7f339f77a526b", null ]
];