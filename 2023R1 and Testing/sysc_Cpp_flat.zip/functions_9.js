var searchData=
[
  ['nodedata_0',['NodeData',['../structsysc_1_1NodeData.xhtml#a7ed7002dbee2dc944811525ea916815c',1,'sysc::NodeData::NodeData(OutputIntegerData nodeIds, OutputVectorData nodeCoords)'],['../structsysc_1_1NodeData.xhtml#a31950cfc2da55dd8da96b7f33f90fef0',1,'sysc::NodeData::NodeData(OutputVectorData nodeCoords)'],['../structsysc_1_1NodeData.xhtml#a69294cbb76cbfb7736b77c3b15518407',1,'sysc::NodeData::NodeData()=default'],['../structsysc_1_1NodeData.xhtml#ae5b86f2e6b88d7354620bc6013e7301c',1,'sysc::NodeData::NodeData(const NodeData &amp;)=default'],['../structsysc_1_1NodeData.xhtml#acc9254f0f146c5bffc87b4f23aa74507',1,'sysc::NodeData::NodeData(NodeData &amp;&amp;)=default']]]
];
