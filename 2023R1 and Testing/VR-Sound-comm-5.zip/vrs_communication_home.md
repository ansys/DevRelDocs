---
last_updated: '2023-11-09 11:00:00'
version: '2024 R1'
summary: 'VR Sound Communication API documentation'
current_page_name: 'vrs_communication_home'
tags: ['VR Sound', 'Acoustics Simulation']
---

# Ansys VR Sound Communication documentation

This document provides a description of the communication of Ansys VR Sound, a real-time 3D audio application for virtual reality through the following sections:

- [OSC Protocol](./vrs_communication_osc)  

- [Sound Playback Process](./vrs_communication_sound)  

- [Messages Format](./vrs_communication_messages)  

- [Messages List](./vrs_communication_messages_list)  

- [State of the Sound Generator](./vrs_communication_state)  