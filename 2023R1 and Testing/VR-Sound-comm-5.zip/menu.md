# Communication {#jpkgae}



- [VR Sound Communication](./vrs_communication_home) 
  - [OSC Protocol](./vrs_communication_home/vrs_communication_osc)  

  - [Sound Playback Process](./vrs_communication_home/vrs_communication_sound)  

  - [Messages Format](./vrs_communication_home/vrs_communication_messages)  

  - [Messages List](./vrs_communication_home/vrs_communication_messages_list)  

  - [State of the Sound Generator](./vrs_communication_home/vrs_communication_state)  


