var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3 =
[
    [ "DeltaT", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#aa96e84f1be7474e219b393da03ee052e", null ],
    [ "DeltaTCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#af596fc9042ce2823c4bac25025f506c1", null ],
    [ "n0", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#aab46174c7c6c0695900dc99e8256375d", null ],
    [ "n0Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#a3b4e979726d16ab24f31a0ae267dbcd8", null ],
    [ "Nr2", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#af5b1b2f61517dbfa03599dcbefb2041e", null ],
    [ "Nr2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#ac25e0e9a5abce2112c88e878c13ee6f2", null ],
    [ "Nr4", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#aa737c89d6b2aeab1756dd25114ccda4a", null ],
    [ "Nr4Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#a846713fa70de45ae16e10f57222597ea", null ],
    [ "Nr6", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#a34b66ea9fa2e81ef7a65a56c3d054cc8", null ],
    [ "Nr6Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#a7f2d182beafd6694f43dafc150c1cbe0", null ],
    [ "Nz1", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#ad388b319c8df582033e7abe2daee3680", null ],
    [ "Nz1Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#ad0c9211bdecccc4c4039cb30465fabda", null ],
    [ "Nz2", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#a657dcd3f1e190d0d0eb217fe45953f47", null ],
    [ "Nz2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#a3719589d0dd824ccafa7c2ad2ac1ea7d", null ],
    [ "Nz3", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#a6ee7ee73bf2f5ee45111a06b5f0dbbcf", null ],
    [ "Nz3Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_gradient3.xhtml#aac4ec64de1329c4d413eba1d5e34e010", null ]
];