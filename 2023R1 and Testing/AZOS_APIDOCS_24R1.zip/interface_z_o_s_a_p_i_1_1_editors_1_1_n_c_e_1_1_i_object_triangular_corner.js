var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_triangular_corner =
[
    [ "Width", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_triangular_corner.xhtml#a7cd7bb44343f537ed00f537cefa2bc0e", null ],
    [ "WidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_triangular_corner.xhtml#af2302c62e080b7bed20de3c951b5c355", null ]
];