var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_temperature_and_index =
[
    [ "Index", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_temperature_and_index.xhtml#a978ce1294e664d1a2cf3882e1b9cda3a", null ],
    [ "T", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_temperature_and_index.xhtml#a9ddfa812540ea59c0489ef8a9fbf95d2", null ],
    [ "X", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_temperature_and_index.xhtml#a43f9ca69ec30257d27e5c6322da6be8e", null ],
    [ "Y", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_temperature_and_index.xhtml#a243d1a68cd06f1848e58f46bddb26491", null ],
    [ "Z", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___point_with_temperature_and_index.xhtml#a6c4272554110c0cf7940184efce89e8d", null ]
];