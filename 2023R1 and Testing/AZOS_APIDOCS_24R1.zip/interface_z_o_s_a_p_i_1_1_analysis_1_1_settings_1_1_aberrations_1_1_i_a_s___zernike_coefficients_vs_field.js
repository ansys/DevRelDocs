var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field =
[
    [ "Coefficients", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#a6b10e64f8cd172cf7e2a59f8aa4ebbf6", null ],
    [ "FieldDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#afb6831e2ef6016a47cdc66af8b859d29", null ],
    [ "FieldScanDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#aae6ae0110422d4e112f8daea2cccc7ee", null ],
    [ "ObscurationFactor", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#a4869c37e96c4bce4ecafd34055a55346", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#a5325100d9db60c457e4daf88cd3276c0", null ],
    [ "ScaleMaximum", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#a2e9e2f2684e51323a9a6c0cafc422caf", null ],
    [ "ScaleMinimum", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#a8312cbce67c12b3974d671d942220c0a", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#a95b0b5dbacb38f460aeb0fabb2c99969", null ],
    [ "ZernikeCoefficientType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_aberrations_1_1_i_a_s___zernike_coefficients_vs_field.xhtml#a8fb1e95e9bebfd59141344e07eca2c0c", null ]
];