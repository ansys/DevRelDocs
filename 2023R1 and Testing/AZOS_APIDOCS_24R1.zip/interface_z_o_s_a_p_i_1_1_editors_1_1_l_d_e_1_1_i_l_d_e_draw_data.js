var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data =
[
    [ "DoNotDrawEdgesFromThisSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#aa325a26d190033d644154e612a588c0b", null ],
    [ "DoNotDrawThisSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#a65e70284ea69201263de71fa2dbcc162", null ],
    [ "DrawEdgesAs", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#a6e9d24db944e16225ce36e41d960a750", null ],
    [ "DrawLocalAxis", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#a026081886234b8fbe96c61c879493d9e", null ],
    [ "HasMirrorSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#a20676abdcd38ae0db2f0a8e7aaf04f06", null ],
    [ "HideRaysToThisSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#aa9931b7ca4e5fb9b4b4de33a85702ce1", null ],
    [ "MirrorSubstrate", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#a5491506b457439418628cbeaba362717", null ],
    [ "MirrorThickness", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#ae3755ad79bd1a2558c47b1904e747ecc", null ],
    [ "SkipRaysToThisSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_draw_data.xhtml#a63dd55e3a71f62509c5863fc3d161f99", null ]
];