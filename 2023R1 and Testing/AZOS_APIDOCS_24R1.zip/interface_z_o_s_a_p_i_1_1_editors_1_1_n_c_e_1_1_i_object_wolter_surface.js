var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface =
[
    [ "Angle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#a38d334e329b4369ab37ca137e940c2ff", null ],
    [ "AngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#af592d8d6b904f6c9e2902f3fe51656b6", null ],
    [ "CoeffZPower2", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#ada3e486da2b1e9cd19dd9dc1ff9b25d9", null ],
    [ "CoeffZPower2Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#acdf3c1dc588eca6aa7be04f779d83725", null ],
    [ "CoeffZPower3", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#abd964c19ffd6f5dfad85fb7bbe367792", null ],
    [ "CoeffZPower3Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#aa04e6b4da6aaf59069aeb39e7bcfbe53", null ],
    [ "CoeffZPower4", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#a74c35c69c72b5cecb0c312405da527c9", null ],
    [ "CoeffZPower4Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#a974f290dcac2f0ab522333383555c380", null ],
    [ "CoeffZPower5", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#a2d237e059a148efb3a7d6e18d6b9f133", null ],
    [ "CoeffZPower5Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#a58202ccce798557ef715ca6f6c165aa3", null ],
    [ "R0", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#a0d4e3200610e4edc18e06598278fb051", null ],
    [ "R0Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#af723674439b487b35088abde7924767b", null ],
    [ "ZLength", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#a7e2100c00d031a2a60dbffa971943634", null ],
    [ "ZLengthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_wolter_surface.xhtml#a6295055ba1a7eb473ad44fabdc2dafb6", null ]
];