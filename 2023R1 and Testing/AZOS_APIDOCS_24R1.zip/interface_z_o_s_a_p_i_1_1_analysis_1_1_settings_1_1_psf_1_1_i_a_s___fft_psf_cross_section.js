var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section.xhtml#a96aeb253cd1c6cc800febcf735103ba1", null ],
    [ "Normalize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section.xhtml#a9ecfd43751162471880f529c252a5f2e", null ],
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section.xhtml#a7ae145e251b3d0e36108b2047f51a47a", null ],
    [ "RowCol", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section.xhtml#a66d014f8ceb79d37734953149593b189", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section.xhtml#a41382da22e7ae4c59b8c69edfa5171c1", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section.xhtml#af9d7308b7b7b047c645f52171c308307", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section.xhtml#a66d86c907122f9358c9022741b0bff67", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_psf_1_1_i_a_s___fft_psf_cross_section.xhtml#a82ef269530db72584e02436475fa405f", null ]
];