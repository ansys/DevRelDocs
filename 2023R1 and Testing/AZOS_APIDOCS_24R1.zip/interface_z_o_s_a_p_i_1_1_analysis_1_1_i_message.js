var interface_z_o_s_a_p_i_1_1_analysis_1_1_i_message =
[
    [ "ErrorCode", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_message.xhtml#a971ba36d315635effcfd1be7adf0af07", null ],
    [ "Text", "interface_z_o_s_a_p_i_1_1_analysis_1_1_i_message.xhtml#a4f7427e386b5989820b5faaa2ef94115", null ]
];