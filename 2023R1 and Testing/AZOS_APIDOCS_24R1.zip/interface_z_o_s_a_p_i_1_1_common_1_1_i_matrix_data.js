var interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data =
[
    [ "GetValueAt", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#a4ef9bd3d9a8d524557429f6a52a7015f", null ],
    [ "ReadData", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#aa49c89d261a4efe69ff44f7bf33535ee", null ],
    [ "SetValueAt", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#a426beefccb6f8def701be9846bd01af5", null ],
    [ "WriteData", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#ac3f6ad4254a30411d5b2c24ef768d7e2", null ],
    [ "Cols", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#a10eadfeda08264d57ed5a1571d46eb1d", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#ac67e94012c9a0c71e0a07b4f840df945", null ],
    [ "IsReadOnly", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#a39a99cc331e4a39fbf67aaffb778efd9", null ],
    [ "Rows", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#aeb197859118e7e78c28f88292df17079", null ],
    [ "TotalLength", "interface_z_o_s_a_p_i_1_1_common_1_1_i_matrix_data.xhtml#a3c7eadfbaab39467be5daa3fc12a4625", null ]
];