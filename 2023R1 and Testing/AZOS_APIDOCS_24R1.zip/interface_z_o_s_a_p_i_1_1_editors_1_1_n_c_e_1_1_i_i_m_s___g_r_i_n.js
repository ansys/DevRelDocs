var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n =
[
    [ "GetAvailableDLLs", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#ada7993d95c0bd55a70bb46da29ed5b10", null ],
    [ "GetAvailableFiles", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#ad7edae470f92c4bb7e6263ce9fc4c3ef", null ],
    [ "GetParameterName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#a356667c9bf96b9f492af5c2ad4252096", null ],
    [ "GetParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#ab3bcb82d8671ab57c320370fd92df425", null ],
    [ "SetParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#a3f0cc71d055f1bbdd16bf326e7890d6e", null ],
    [ "DLL", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#a7863b66ce294f61b29d7d69a2427d1c1", null ],
    [ "File", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#a8a6b0d1ec8d995e0a44932d0af403efb", null ],
    [ "MaximumStepSize", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#ab390eefb3634f6f2c187f24003ff710f", null ],
    [ "NumberOfParameters", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#a1f7cfc36f524aec57725836d4f209497", null ],
    [ "UsesFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_i_m_s___g_r_i_n.xhtml#ac3d391a020a9101bd79bfa9613669690", null ]
];