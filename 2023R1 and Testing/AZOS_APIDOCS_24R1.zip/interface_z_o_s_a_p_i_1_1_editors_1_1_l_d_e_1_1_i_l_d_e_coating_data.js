var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data =
[
    [ "GetAvailableCoatings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#ad180bcd939506bfea7e6341d4412eabb", null ],
    [ "GetLayerSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a64a25977ad5af7bebca431d30a015123", null ],
    [ "SetAllExtinctionFixed", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a98213d317df0110c1a389b189ae1e557", null ],
    [ "SetAllExtinctionVariable", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a6920aa1fd90185bc2817b5a245b7b1bd", null ],
    [ "SetAllExtinctionZero", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a7adf644c207115fce9fa8d27a8de881c", null ],
    [ "SetAllIndexFixed", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a8eb5a666086bd1bbcab9e87c10024da3", null ],
    [ "SetAllIndexVariable", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#aeaac1305aadd200a7e78f0fc40d0da48", null ],
    [ "SetAllIndexZero", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a0e96152a37a1d0f8bf4a94056d20cac9", null ],
    [ "SetAllThicknessFixed", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a9ce680147a1925e534c36fdfbd326bd0", null ],
    [ "SetAllThicknessOne", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#ab67afaf7b0044ba5731fbd51ebd9ba06", null ],
    [ "SetAllThicknessVariable", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#afcde6a7c6c568cb1008a6ca708249ad9", null ],
    [ "SetLayerSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a21551fb5dbe90694d5750898bc084962", null ],
    [ "Coating", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a1441d26960984da499d151c4deaab6d6", null ],
    [ "NumberOfLayers", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#abf38e2fa32c2ab55db55f19ca00a8e8e", null ],
    [ "UseLayerMultiplierAndOffsets", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_data.xhtml#a1a0d92693cf122d5c5685888273c8376", null ]
];