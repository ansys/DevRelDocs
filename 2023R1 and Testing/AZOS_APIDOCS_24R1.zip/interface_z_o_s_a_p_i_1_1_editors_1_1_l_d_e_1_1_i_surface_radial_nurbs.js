var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs =
[
    [ "GetWn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#a3e03ae939f03278c8aad1a2322f4d8e7", null ],
    [ "GetYn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#a02f0ff733323e7235dd760338676e0d1", null ],
    [ "GetZn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#a13d2f66735193f274d098e37f31e9c04", null ],
    [ "SetWn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#a1a170b1da132f5ec672dda1e56b13812", null ],
    [ "SetYn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#ad0a698ffd36e19cb7b345a32de34ab78", null ],
    [ "SetZn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#af1290bbe2cca5fadbc0cc033798693d9", null ],
    [ "WnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#a2525c22001f35895494e56a91d3ebcf1", null ],
    [ "YnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#acf5e037587031fea231760b8cbee3f7d", null ],
    [ "ZnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#a323962ea3750f3e2cdab8d5d50a2cd06", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#ae9568bbe25c1d5c792cdf988ecf41258", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_radial_nurbs.xhtml#a2ff258246d0d5a53788dcd534e95933f", null ]
];