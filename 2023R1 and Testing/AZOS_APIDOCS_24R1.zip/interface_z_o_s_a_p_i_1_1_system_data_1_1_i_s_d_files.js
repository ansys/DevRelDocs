var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files =
[
    [ "GetABgDataFiles", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#a249d16391db6f7802dc8309e8b574766", null ],
    [ "GetCoatingFiles", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#a4ba9c4fc32ef321b7eea80bb11b9cfea", null ],
    [ "GetGradiumProfiles", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#a9f18b4bcbd12de678814594568031112", null ],
    [ "GetScatterProfiles", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#adefafa097913f87a60ebc5481068272b", null ],
    [ "ReloadFiles", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#a1ac7484a1768874af69485fe9255a13c", null ],
    [ "ABgDataFile", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#ac9512b4a64e7a98020c0f2e61c7c34d8", null ],
    [ "CoatingFile", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#a2fa65dd15661323ab598405b776b853c", null ],
    [ "GradiumProfile", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#a000be1845a679b09d7ce4d4005a6b433", null ],
    [ "ScatterProfile", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_files.xhtml#aba0d630dfce3e750afced863102b3cac", null ]
];