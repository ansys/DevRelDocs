var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase =
[
    [ "ContourFormat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#a390c490db55121a53a15b94c1943efbf", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#aa0546d6dd781b67a2827e68c5db5a410", null ],
    [ "RemovePiston", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#a456976fdf83323dada5dc8f177ee816c", null ],
    [ "RemovePower", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#ac752a13607e39961b1990916960f05dc", null ],
    [ "RemoveTiltX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#a6ec0a50e41172f9a4b9b486633af2aed", null ],
    [ "RemoveTiltY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#a3b107bfbf653a94044fbd960126adec0", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#afead83db21150dade6d3e9ddf59f4c02", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#a6fa46725fe68f2654375a2c6ac4edd45", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_phase.xhtml#a8aa564a15cde8bb1fd178170ecdc56eb", null ]
];