var interface_z_o_s_a_p_i_1_1_i_preferences =
[
    [ "ResetToDefaults", "interface_z_o_s_a_p_i_1_1_i_preferences.xhtml#a46785d61c4607d6b571022ac4a47f208", null ],
    [ "Editor", "interface_z_o_s_a_p_i_1_1_i_preferences.xhtml#a0c4297664111342cd79f1b101446f56e", null ],
    [ "Folders", "interface_z_o_s_a_p_i_1_1_i_preferences.xhtml#a20345599f76c848812aee06adb4d589a", null ],
    [ "General", "interface_z_o_s_a_p_i_1_1_i_preferences.xhtml#a962ef89db42273aca29102b6fb812d4a", null ],
    [ "IsReadOnly", "interface_z_o_s_a_p_i_1_1_i_preferences.xhtml#a65d917d1241bfdfacc0b4af44a4ae809", null ]
];