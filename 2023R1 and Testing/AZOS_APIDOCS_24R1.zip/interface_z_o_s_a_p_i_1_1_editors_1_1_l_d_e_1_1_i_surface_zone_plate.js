var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_zone_plate =
[
    [ "Delta_R", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_zone_plate.xhtml#a838981548244c6fb0551b5b41540bbc7", null ],
    [ "Delta_R_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_zone_plate.xhtml#a69d3a3c4fea5f1689f77c9939dd8f2b8", null ],
    [ "Mode", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_zone_plate.xhtml#af58ad9049a346aaaee7993e99755de5f", null ],
    [ "ModeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_zone_plate.xhtml#a19769d53851922d0801600b60b90080d", null ],
    [ "ReferenceWave", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_zone_plate.xhtml#aa3706bd8cd92a97db30d8b1b49ffa60b", null ],
    [ "ReferenceWaveCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_zone_plate.xhtml#acfa66e441093699f44f780924a13ee12", null ]
];