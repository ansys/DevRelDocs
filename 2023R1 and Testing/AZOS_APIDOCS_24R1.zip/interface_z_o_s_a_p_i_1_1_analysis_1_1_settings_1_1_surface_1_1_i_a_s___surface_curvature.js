var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature =
[
    [ "BestFitSphereOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#aff56af70ad20e0f506fc89961d35ac58", null ],
    [ "ConsiderOffAxisAperture", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#aa5b072d913b7d594588b5129db95e346", null ],
    [ "ContourFormat", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#aa13b85ff4c42f39fbfbb9b3ad0322768", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#a7e841c4e34b576e29fbb5bbe41323f7e", null ],
    [ "RemoveOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#a6cbbc5236cd99bb85856beee257816db", null ],
    [ "ReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#abe85803dc256d5a6b5eff74be0f3ad4e", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#a95439478b084a4c9a803fc6cfd1a4430", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#a68272de1ad6c30bbb42a3b7f3050b4d1", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature.xhtml#af9be8cc37a40f559a2ea7425a533a6e7", null ]
];