var interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general =
[
    [ "GetIsGPUEnabled", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a14b08279de18f91f67baf7e7e8a40d93", null ],
    [ "GetUseACIS", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a715a2a6538d171c4a7e89ace47297066", null ],
    [ "GetUseParasolid", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a0bc47bc9f705df21784ffc0c5b00755b", null ],
    [ "SetIsGPUEnabled", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a67cdd1f0e7d3bb6ba09101224db6ec89", null ],
    [ "SetUseACIS", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a712281ee279ce2780ee4d3e53bee9a3b", null ],
    [ "SetUseParasolid", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#aafdfb86e0a067da09618a648ab88b362", null ],
    [ "DateTimeFormat", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a08c9851a5c9e95249e247964f4d8246c", null ],
    [ "IncludeCalculatedDataInSession", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a5dedeeb661115644cc06de1688cf5c95", null ],
    [ "IncludeToleranceDataInSession", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#ada277e7ee51fe6001913a54ae78f4b6f", null ],
    [ "Language", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#acdb183b72e7c6d518ab2498266d96120", null ],
    [ "TXTFileEncoding", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a32c4bdb3c87442c8e25f1b3fff721c68", null ],
    [ "UpdateMostRecentlyUsedList", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a2efa6ee6fe4db0f5cc839ab473462272", null ],
    [ "UserPreferences", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#ac46784a53f375871f7050942ea3ef76b", null ],
    [ "UseSessionFiles", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a05297c825e3d5db4b61b39f312fd0e07", null ],
    [ "ZMXFileEncoding", "interface_z_o_s_a_p_i_1_1_preferences_1_1_i_preferences_general.xhtml#a00b869844d613fba6402c2e08433eb7a", null ]
];