var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings =
[
    [ "_S_BlackBodySpectrum", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a1a917872c01d94541671d621c7a97a3a", null ],
    [ "_S_CIE1931Chromaticity", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a31773130dad21880b838349dd6eb2c49", null ],
    [ "_S_CIE1931RGB", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a99a24e219d75761400b35d291ab85a0d", null ],
    [ "_S_CIE1931Tristimulus", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a8fe23a4cead8da56de46f123cdced3df", null ],
    [ "_S_CIE1976", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a60c3b417edd7e3ba6be54a2da0e58ec9", null ],
    [ "_S_ColorTemperature", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a5357f6f44fb6a4d79db8da3b5605a7c9", null ],
    [ "_S_D65White", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a576f5020d8e422236f60b4028e061e76", null ],
    [ "_S_SpectrumFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#ac7c8ec53eba2a8b0df2c891fbcdd163c", null ],
    [ "_S_SystemWavelengths", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a2db7f0040ffbeea9e03f5f718a1336e7", null ],
    [ "_S_UniformPowerSpectrum", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a633d901fee026a38e1d2bab97b672e2e", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#a7bc81ddad0da90bb5adbab01b4080378", null ],
    [ "Mode", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_source_color_settings.xhtml#aa2ca6252701018d673516cf1cc33dead", null ]
];