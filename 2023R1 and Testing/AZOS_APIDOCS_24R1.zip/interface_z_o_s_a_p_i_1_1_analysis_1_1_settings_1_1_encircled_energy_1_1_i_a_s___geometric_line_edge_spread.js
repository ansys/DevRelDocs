var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_line_edge_spread =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_line_edge_spread.xhtml#ac7f568c9fa2fa0d443f65bef3c65447a", null ],
    [ "RadiusMaximum", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_line_edge_spread.xhtml#a155a0c0744e0541c63bef0f955b604d3", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_line_edge_spread.xhtml#a835bcb533d5bb80461c5ee2b45a3a430", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_line_edge_spread.xhtml#aa775b4dca3a0fa2a20d7bc09e4855056", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_line_edge_spread.xhtml#ad4bc3192583f7f93938cb5ed674c8b95", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_line_edge_spread.xhtml#a5495ad1c70ae4272e0c66480801b43ac", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_line_edge_spread.xhtml#a0584daf0155d46fb356c610d593e5f6a", null ]
];