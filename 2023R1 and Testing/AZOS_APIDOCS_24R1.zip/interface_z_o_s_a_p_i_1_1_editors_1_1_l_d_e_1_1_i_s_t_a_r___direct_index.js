var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index =
[
    [ "IsDataLocalCS", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index.xhtml#a01d6f6b66b5eab65dd523ec0f18db2bb", null ],
    [ "SetDataIsGlobal", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index.xhtml#af854223adcb1054d08d8ab3ff9d6599c", null ],
    [ "SetDataIsLocal", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index.xhtml#afc5a7984b23603a0a7838402577341ab", null ],
    [ "CoordinateTransform", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index.xhtml#af1a840371b0fe1bc7a5def9f5ff3bc3b", null ],
    [ "FEAData", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index.xhtml#af57a83f4545a70a5694020da78442aab", null ],
    [ "Fits", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index.xhtml#aa988a1e6f608f9a5210f77e6fc19399e", null ],
    [ "GRINStep", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index.xhtml#a93fa42c71e821a8244486f5971d89c74", null ],
    [ "SurfaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___direct_index.xhtml#ad0fe11b13a548fb4ae51ed0d2b398d26", null ]
];