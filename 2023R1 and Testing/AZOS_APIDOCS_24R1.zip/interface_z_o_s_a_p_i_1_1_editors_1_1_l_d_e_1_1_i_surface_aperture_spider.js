var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_spider =
[
    [ "ApertureXDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_spider.xhtml#a84425a9b6ef8208787e02a48bd233c44", null ],
    [ "ApertureYDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_spider.xhtml#a2be803326b26a4b4e62e38e14a338da0", null ],
    [ "NumberOfArms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_spider.xhtml#a162f20c53edd7e143d76f4a826f86b60", null ],
    [ "WidthOfArms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_aperture_spider.xhtml#ac3325fed591408d851b8382db3bc8bfa", null ]
];