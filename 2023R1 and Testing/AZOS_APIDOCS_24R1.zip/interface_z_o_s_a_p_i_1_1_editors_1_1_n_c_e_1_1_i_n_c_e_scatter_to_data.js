var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_scatter_to_data =
[
    [ "GetRayData", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_scatter_to_data.xhtml#a0eb3fa0cec7f66260be2eae328cb2965", null ],
    [ "SetRayData", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_scatter_to_data.xhtml#acd71af34d74d1c79d05e5df16e6bfd78", null ],
    [ "IsScatterToAvailable", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_scatter_to_data.xhtml#a621e0230f99a47dbc4fe2043fe946582", null ],
    [ "NumberOfRayData", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_scatter_to_data.xhtml#a18ca837de813fae407fcf8c39685e087", null ],
    [ "ScatterToList", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_scatter_to_data.xhtml#ab0949ac686b819d302a21432bfe411a8", null ],
    [ "ScatterToMethod", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_scatter_to_data.xhtml#abb2779c915334fadd8ea1bd4697794e8", null ]
];