var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf =
[
    [ "Configuration", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#a68ab8d052b13174eafd0bfe7e1f9bd01", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#a9bfc51db0ba39433f258194d93ea733c", null ],
    [ "ImageDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#a7164fe8fe92580d4a3bc8061777dde5e", null ],
    [ "ImageSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#a46a9ffe30612eee7f85319223c5a213a", null ],
    [ "MaximumFrequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#a15c65eb35809fcd1c0db1a49d5c213c1", null ],
    [ "PupilSampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#ade13a5c12366db110d53c065aaf089fc", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#a5105d032d5874b40754a6f85fe2bf031", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#ad448225f9d53db7b8c79635cd011b164", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#a9c9c58cda73efe6da60765e444d5cac3", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtf.xhtml#a8bdb1b9756673f30935b30910905ad71", null ]
];