var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform =
[
    [ "ConicX", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#a3e0bbe36e32b304540a9a4e101e1162a", null ],
    [ "ConicXCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#a8ed0ba399738029190fc7dae52f1dd42", null ],
    [ "NumVariablePoints", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#adb059f968e04cf8f153ebe9e629a961f", null ],
    [ "NumVariablePointsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#a8e029b49831ba285d8dd56a908c7c4ff", null ],
    [ "RadiusX", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#aee828b8f0da71933d4963ebf100b2240", null ],
    [ "RadiusXCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#a1a72d99dae5a7ece7d5ff59da7dac7cd", null ],
    [ "ZernikeDecenter_X", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#ad8c456ece9bb877074feef1beb08a16e", null ],
    [ "ZernikeDecenter_X_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#a93359f8a565e35e06ab64a6358b3c504", null ],
    [ "ZernikeDecenter_Y", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#ad1ca308d3aca59490a1c896c04f5a518", null ],
    [ "ZernikeDecenter_Y_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_true_freeform.xhtml#a3b6b66c8bc4ff1066f12226536e900d3", null ]
];