var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs =
[
    [ "GetWn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a2df5c3cc08945865141f3da5f8540f07", null ],
    [ "GetYn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a3c93782eb20b23b089542a543e462c27", null ],
    [ "GetZn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a7564372e652a1bda6611d137d3f85e63", null ],
    [ "SetWn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#abba5d2adabf4389651154a21a0168ad9", null ],
    [ "SetYn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#aaa3776e3e44012361ac2eb3cec9d500f", null ],
    [ "SetZn", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#af6b864e0ffa49c829d3091c6dd394d91", null ],
    [ "WnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#ae0d988b971e32fec2eb0ca52802ec6e3", null ],
    [ "YnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a46a9120a2d2c48fe22354cead768c164", null ],
    [ "ZnCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#ad24bb1e91daa41e91f82741e098437ba", null ],
    [ "Maximum_X", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#aff5fc28060959ad23f2eb261f124dc28", null ],
    [ "Maximum_X_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a6f217a77f050aea0279fc47e195a8430", null ],
    [ "MaximumAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#ad312f8aeb53dbc4b081d7a63973df5b9", null ],
    [ "MaximumAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#af4372d08b4cb71b6a3c5f426127898ed", null ],
    [ "Minimum_X", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a1baaa44144caeaf787da2a24611dd136", null ],
    [ "Minimum_X_Cell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a3c426b53c52fb649b770ceff6e918c1f", null ],
    [ "MinimumAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a33fd25eb54461016aafcb13a769839c2", null ],
    [ "MinimumAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#a107ba3f37d74ff0839d99484fe433d13", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#ae90d4e6851c959cc92d267b319bb3cc1", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#ad663d61635f81f0b6674fe39f9110745", null ],
    [ "RadiusOfRotation", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#abcbedecad2c3d9f142e1a271bc3a0966", null ],
    [ "RadiusOfRotationCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_toroidal_nurbs.xhtml#ab24391fbbd23f93017e7e2ce417fe8a9", null ]
];