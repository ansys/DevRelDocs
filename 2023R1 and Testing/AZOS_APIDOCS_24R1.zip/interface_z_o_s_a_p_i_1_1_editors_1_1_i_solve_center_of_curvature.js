var interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_center_of_curvature =
[
    [ "RefSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_i_solve_center_of_curvature.xhtml#a3fcdb2ed42a64c10f2dec71d6b2ac8f6", null ]
];