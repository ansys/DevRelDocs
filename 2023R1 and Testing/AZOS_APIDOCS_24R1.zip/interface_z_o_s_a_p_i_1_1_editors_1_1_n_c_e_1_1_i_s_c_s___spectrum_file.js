var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___spectrum_file =
[
    [ "GetAvailableSpectrumFiles", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___spectrum_file.xhtml#ac250b2a8a078de23fe2ffe6b658453b5", null ],
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___spectrum_file.xhtml#a3fa521e62d9972ff5596b2894e5eb79a", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___spectrum_file.xhtml#a1759042b493b04343cc1510737d156a6", null ],
    [ "SpectrumFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___spectrum_file.xhtml#af978418ba4c742729eb6ad9ecfb6fd96", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___spectrum_file.xhtml#a315768e303be02a94cc1d78f9d5183fb", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___spectrum_file.xhtml#a3e561e69a36a25bdac1b51b50e083f8e", null ]
];