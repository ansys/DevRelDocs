var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_title_notes =
[
    [ "Author", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_title_notes.xhtml#a8c8c8a7719f249904f6b4673a0863115", null ],
    [ "Notes", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_title_notes.xhtml#a7b8c52bb0bd1126bc9b08728e266e40d", null ],
    [ "Title", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_title_notes.xhtml#a0df9898f1c7fdd32d6bddf70ccb54419", null ]
];