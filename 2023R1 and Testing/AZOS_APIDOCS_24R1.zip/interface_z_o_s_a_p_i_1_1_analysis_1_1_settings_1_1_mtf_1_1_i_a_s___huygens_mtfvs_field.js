var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field =
[
    [ "FieldDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#a73b12282f688f6a1276ac86f5fa2a289", null ],
    [ "Freq_1", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#af534617421cbf164d91e706efc3ff5f0", null ],
    [ "Freq_2", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#a106a2557c101eafdbbd2ee52e5fc79a1", null ],
    [ "Freq_3", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#a67d0d414e81efcf4cf1abb5a3f9014db", null ],
    [ "Freq_4", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#ad4e864f302163c8025ca2b013e0a3b0b", null ],
    [ "Freq_5", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#a5d41291f710ae1e0c580202629676c46", null ],
    [ "Freq_6", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#a66e29856138e9e578abe91326cdedb4f", null ],
    [ "ImageDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#aa1bfe3843dc455386ae471187d203e8e", null ],
    [ "RemoveVignetting", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#a6b32b9319d1d4b4d2bccac3fb1a9ab6a", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#a592a3c4f78ff8e111a567ae413c8d17f", null ],
    [ "ScanType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#aaf75edf2e3617c690b3a514fbca7744e", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#a154fcc2577f3482d9a71a114b0e7c293", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#ac6a1666a906cb5ad3c4adb0d3b8a601e", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___huygens_mtfvs_field.xhtml#ad7797efa5d5f5303377e88d6e989185e", null ]
];