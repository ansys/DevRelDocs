var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings =
[
    [ "SetExtinctionStatusFixed", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#adf777bfb5454a1eabf8f70423c1c9202", null ],
    [ "SetExtinctionStatusPickup", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#ad1a38fc51c1edbb20f57d30e1215858c", null ],
    [ "SetExtinctionStatusVariable", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a32b2be9126984b1ba2817b87dee05218", null ],
    [ "SetIndexStatusFixed", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#abf04002e359b787f329a5f4d4499ebb9", null ],
    [ "SetIndexStatusPickup", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a64007acc9914db497b65ad5919e4d350", null ],
    [ "SetIndexStatusVariable", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#af37469514ebad18105138fff6cb7c2c4", null ],
    [ "SetThicknessStatusFixed", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a9ca721d5b2bbdc5cc38036ee691ef978", null ],
    [ "SetThicknessStatusPickup", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a3482456aabb5851e888a04247ba7b179", null ],
    [ "SetThicknessStatusVariable", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a6da7d721226f954a9a241a7f995cd557", null ],
    [ "ExtinctionOffset", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#aca062848debcb3e410a1a0a09911ed33", null ],
    [ "ExtinctionPickupFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#add5fd891939b71f3279415b7c7c34228", null ],
    [ "ExtinctionStatus", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a8b5bb118e21a4937fe704da595e28ad9", null ],
    [ "IndexOffset", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a091dff30875a7a68ca3d30a2c88b43b3", null ],
    [ "IndexPickupFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#aa5c53c241b93f0e3c0660d20eda8a6d0", null ],
    [ "IndexStatus", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#ac5387c89aca3aaa317146e1c16687bd3", null ],
    [ "Layer", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a965204d40bc329a546b45e6decee44a6", null ],
    [ "ThicknessMultiplier", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a5908df12527406502384462f870719d9", null ],
    [ "ThicknessPickupFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#a1199f298dec9e9b3fb2bffbcc167cda3", null ],
    [ "ThicknessStatus", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_coating_settings.xhtml#afff97a144119edd29a9b4f50fe8f8331", null ]
];