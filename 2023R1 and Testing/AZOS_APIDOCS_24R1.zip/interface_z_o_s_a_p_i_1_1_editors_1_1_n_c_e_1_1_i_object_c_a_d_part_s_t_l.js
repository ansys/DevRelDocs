var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_a_d_part_s_t_l =
[
    [ "IsVolume", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_a_d_part_s_t_l.xhtml#a0b0ffae828f3070c8ebb944c21b1e760", null ],
    [ "IsVolumeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_a_d_part_s_t_l.xhtml#a90791331e1f4647a4128f9a678feba9b", null ],
    [ "Scale", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_a_d_part_s_t_l.xhtml#a8568dade1611e7a9bc09d84b924a5d7e", null ],
    [ "ScaleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_c_a_d_part_s_t_l.xhtml#a2442fb9d714fa29b58cc2421bfe041c1", null ]
];