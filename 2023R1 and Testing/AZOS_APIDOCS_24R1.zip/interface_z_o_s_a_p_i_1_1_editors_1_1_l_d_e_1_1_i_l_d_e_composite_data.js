var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_composite_data =
[
    [ "SetOffAxisTiltAndDecenter", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_composite_data.xhtml#a4b63b5695bf260c03c7a72aa608c3ef0", null ],
    [ "IsCompositeSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_composite_data.xhtml#ac9964a36de9ba8a93a823d0ca4eb994e", null ]
];