var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data =
[
    [ "GetAvailableDLLs", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#aa82bc28a64bcce0b67c9cce22b9c3a1a", null ],
    [ "GetReflectParameterName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a5208283c5bc3bb95c87f707b5ae8ff1b", null ],
    [ "GetReflectParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a0bff39be58406109592e2ab0e3b0f64c", null ],
    [ "GetTransmitParamaterName", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a4bb5373113a77fa06a773f0a07663d94", null ],
    [ "GetTransmitParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a05d13048de5ea3e43e5706d33829f24b", null ],
    [ "SetReflectParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a74ba5ae3b8f5abc925b72c915fc4ccbf", null ],
    [ "SetTransmitParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a584d6c21d0be4e7eb9b0e59b71372b3f", null ],
    [ "DLL", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#af77997ec48cc1b4423ed8fe47392ece9", null ],
    [ "IsDiffractionAvailable", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#aecb1c09cec9c4c90363aa5150e82659e", null ],
    [ "IsDLLRequired", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a23d158b4432aa4f0157fa45d4ed5c8c1", null ],
    [ "NumberOfParameters", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a81b01464cee552268ade5bb3d8a775f3", null ],
    [ "Split", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a2c8e47a55ca932a46cbe42ed3351929d", null ],
    [ "StartOrder", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#adb31acb37d83b8475e6ce165f89030b7", null ],
    [ "StopOrder", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_diffraction_data.xhtml#a895282a1c095ff5e6d6e1d6568b8acdd", null ]
];