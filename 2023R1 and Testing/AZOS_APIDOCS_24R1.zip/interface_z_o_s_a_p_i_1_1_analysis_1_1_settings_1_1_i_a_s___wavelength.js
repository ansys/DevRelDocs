var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavelength =
[
    [ "GetWavelengthNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavelength.xhtml#abbef90f3a3ac623a56d3f33b02d92fa4", null ],
    [ "SetWavelengthNumber", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavelength.xhtml#ad1d058bf101a8055b9280b0ead9ae5c5", null ],
    [ "UseAllWavelengths", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_i_a_s___wavelength.xhtml#a705563143354dc20713a8f169911bc83", null ]
];