var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_data =
[
    [ "GetFaceData", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_data.xhtml#a36212ee928b687a568882fbf1ab2917d", null ],
    [ "NumberOfFaces", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_data.xhtml#a64a9135469e1f08c2ccefdc70821c0a5", null ]
];