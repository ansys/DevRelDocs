var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_polygon =
[
    [ "IsVolume", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_polygon.xhtml#a6f1a86707ef4ea1eee8346dd93c7a10d", null ],
    [ "IsVolumeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_polygon.xhtml#ac4e692c63ab78ac147dc36e6cce86df2", null ],
    [ "Scale", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_polygon.xhtml#a8a50c9b4226e55d7b13ea2bb21b8f93e", null ],
    [ "ScaleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_polygon.xhtml#a8f4b032126c191e0ed6c9a3a14cca72f", null ]
];