var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross =
[
    [ "Angle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross.xhtml#a81e6e76e90cc74dc05c03e3d7ac06d4d", null ],
    [ "BestFitSphereOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross.xhtml#a1c8faadcc687b67e25cbdae8306f0436", null ],
    [ "ConsiderOffAxisAperture", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross.xhtml#a41b0b7d01a46ddd6647191179b786324", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross.xhtml#a40ccfbb49c356b7534303d90654ad67c", null ],
    [ "RemoveOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross.xhtml#a4b6e2b2904eee4404c1daa586f9166d7", null ],
    [ "ReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross.xhtml#ac4b2b8769d8731b9dd4334450a539034", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross.xhtml#a0cca7890388959db0cd3797b376a795c", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_curvature_cross.xhtml#a66aa6ad435521c3ce86309df6c6f03fd", null ]
];