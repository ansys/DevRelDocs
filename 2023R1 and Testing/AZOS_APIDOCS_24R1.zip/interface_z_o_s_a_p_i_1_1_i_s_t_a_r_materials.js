var interface_z_o_s_a_p_i_1_1_i_s_t_a_r_materials =
[
    [ "GetDNDT", "interface_z_o_s_a_p_i_1_1_i_s_t_a_r_materials.xhtml#a3e2d6236629f57eee09bf3b6d84ca8df", null ],
    [ "GetRefractiveIndex", "interface_z_o_s_a_p_i_1_1_i_s_t_a_r_materials.xhtml#a1238b9bbb749c1e83b75b4c6e51c95fd", null ]
];