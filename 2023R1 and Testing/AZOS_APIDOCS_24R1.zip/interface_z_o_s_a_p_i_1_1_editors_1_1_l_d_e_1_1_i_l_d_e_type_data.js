var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data =
[
    [ "CanBeGCR", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#a5d6bedd30cae712f06ae6bcf8fb4a4a5", null ],
    [ "CanBeStop", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#a81a526f57cf9fa20779004e77e00cc7f", null ],
    [ "IgnoreSurface", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#a35ec60996a247aadfff3fdbea73e6a88", null ],
    [ "IsGlobalCoordinateReference", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#a9e7f4b6e65bb619baaa230deb6d15848", null ],
    [ "IsStop", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#a6a32c2330b050886d800ac263bc1f1ae", null ],
    [ "RowColor", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#ad686151d0d3fef0e4dbe7d9780cb8351", null ],
    [ "SurfaceCannotBeHyperhemispheric", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#a916e65e128931e11fcb024ed1b07754b", null ],
    [ "SurfaceColor", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#ab33e363787c8c57c93af07642e45b302", null ],
    [ "SurfaceOpacity", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_type_data.xhtml#a884b5937c86589e71f5e37280afd75b4", null ]
];