var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits =
[
    [ "ApplyTemperatures", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#af8a1afbeff6b46e5692c6c36f695728a", null ],
    [ "GetFittedIndex", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#aa163c2d148af2a89a777955be5de4ef0", null ],
    [ "GetFittedTemperature", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#a777847917e5b3ebb43e206a2da8a4fac", null ],
    [ "ListFittedIndexSafe", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#abe05a71d538abde36092002c403bb5b3", null ],
    [ "MeshFittedIndexSafe", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#acd05468c262eca5fc9654c45bdf10bbc", null ],
    [ "Refit", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#a4e5230316dbf1e34244c59927303bc4d", null ],
    [ "RemoveTemperatures", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#aa7b9ca55cfc9b330a0ba67ebb270ba40", null ],
    [ "FitResultsIndex", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#a36d1deacf9f06e5048bccfa314488787", null ],
    [ "GRINStep", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#ab057709dbc2c628aa7c31b535f54e457", null ],
    [ "IsTemperatureProfileEnabled", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#aeb74003a7619b0053899da2d459b46e9", null ],
    [ "Settings", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#a3b0e2b9fba4cb4b76ade6481de00f92f", null ],
    [ "SurfaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_fits.xhtml#ab0097049b0f98a3e678c94a2a8ea7fa8", null ]
];