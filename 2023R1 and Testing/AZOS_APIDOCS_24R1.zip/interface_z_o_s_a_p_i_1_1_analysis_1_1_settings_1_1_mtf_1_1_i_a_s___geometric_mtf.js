var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf.xhtml#a51b2ed3694e903abfe7d67416239f86e", null ],
    [ "MaximumFrequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf.xhtml#a4f5870b7271cdc49f07c4bedf15b5a21", null ],
    [ "MultiplyByDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf.xhtml#aeda18892752c00cc86f463ad222d7a06", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf.xhtml#a1a19a9cf15239567ec81448b7a49dfec", null ],
    [ "ScatterRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf.xhtml#a4911434604ba90bd6c75865376866264", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf.xhtml#a0f991e070c804b301a5be7db644449f7", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf.xhtml#af0a43f625674fe8026f12bf39cdfaa8c", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf.xhtml#a315657291882ec49f93a97110f4acf92", null ]
];