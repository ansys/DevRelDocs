var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#a0e23359a70200d4b1448487f6d5d43ba", null ],
    [ "FieldSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#a6a4704cc9ba48e07b61ac61c8fea2490", null ],
    [ "ImageName", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#adab993f9bef45f92872dca6f3a017b9e", null ],
    [ "MaximumDistance", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#a8e82b3dca71fa9bd492e7d764d41bacf", null ],
    [ "MultiplyByDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#aa837271aa38ea52939a184b9c490e41e", null ],
    [ "RaysX1000", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#a5f430789831545b944e73fd14a3df446", null ],
    [ "ReferTo", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#acc0225b911369bfb33519e6d47d98aa6", null ],
    [ "RemoveVignettingFactors", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#a71d1e008430a720f875d71e422d65d1d", null ],
    [ "Rotation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#ac2533e211185368e08f414c4f9ae7ea1", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#a61cf50c7f2b6fac8d3a00dbdcf4ac308", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#ac9a39311e13c9495c32a163e085f932e", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#ad40c16224c09bdc5d5bd5757949373c4", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#a64646563afb1bc890b6be3f5b832fef8", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___extended_source_encircled_energy.xhtml#a905f53131e363dae83c9c06b2db2ed02", null ]
];