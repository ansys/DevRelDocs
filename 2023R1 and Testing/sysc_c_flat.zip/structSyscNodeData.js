var structSyscNodeData =
[
    [ "nodeCoords", "structSyscNodeData.xhtml#a4da0b55605c39346dd83b830ab7eb54e", null ],
    [ "nodeIds", "structSyscNodeData.xhtml#a227ac3d62c2c7224c7844028b014d6c8", null ]
];