var structSyscSetupFileInfo =
[
    [ "restartsSupported", "structSyscSetupFileInfo.xhtml#aa14b79eae6d4d1bc320ac13358a7f09f", null ],
    [ "setupFileName", "structSyscSetupFileInfo.xhtml#ab2c5f41a9396745b156bc62d5ea4e860", null ]
];