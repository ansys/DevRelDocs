var searchData=
[
  ['access_20to_20heavyweight_20data_0',['Access to Heavyweight Data',['../md_10_HeavyweightDataAccess.xhtml',1,'']]],
  ['amountofsubstance_1',['amountOfSubstance',['../structSyscDimensionality.xhtml#a7cb2bcc42a70ccbcbc067d2f8e3537f1',1,'SyscDimensionality']]],
  ['analysistype_2',['analysisType',['../structSyscSetupInfo.xhtml#ac769cbb25b2b34dbb5bc44f281299780',1,'SyscSetupInfo']]],
  ['angle_3',['angle',['../structSyscDimensionality.xhtml#a97ee853763b54b62bbd1ead7cbd1a761',1,'SyscDimensionality']]]
];
