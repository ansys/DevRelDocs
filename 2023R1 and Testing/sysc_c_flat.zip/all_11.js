var searchData=
[
  ['value_0',['value',['../structSyscRealAttribute.xhtml#ac6dd95726f82ff857471b1967c42b235',1,'SyscRealAttribute::value()'],['../structSyscIntegerAttribute.xhtml#a272f235cfc28cb256a9f5793cb3d51f4',1,'SyscIntegerAttribute::value()']]]
];
