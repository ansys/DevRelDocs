var files_dup =
[
    [ "fmop_solver.h", "fmop__solver_8h.xhtml", "fmop__solver_8h" ],
    [ "FMOPSolver.h", "_f_m_o_p_solver_8h_source.xhtml", null ],
    [ "sos_capi_common.h", "sos__capi__common_8h.xhtml", "sos__capi__common_8h" ],
    [ "sos_capi_script.h", "sos__capi__script_8h.xhtml", "sos__capi__script_8h" ]
];