var a00702 =
[
    [ "sampling_rate", "a00702.xhtml#ac098f62c7cf0a449309e2b5890cfeb38", null ]
];