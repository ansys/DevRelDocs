var a00662 =
[
    [ "antialiasing_factor", "a00662.xhtml#aab26495174f7c707086b4e3fb9598117", null ],
    [ "camera_far_plane", "a00662.xhtml#a3aef4baee872dd0a8c98e625fde169f3", null ],
    [ "camera_ground_truth_parameters", "a00662.xhtml#ae8465bb1624d789f2606ec344d9f8ab1", null ],
    [ "camera_near_plane", "a00662.xhtml#a7c98a01e825f8aa05938975bd5618ffe", null ],
    [ "shadow_quality", "a00662.xhtml#ab65534ee12eef2af72263b2e5d27cd3a", null ],
    [ "texture_quality", "a00662.xhtml#a2eafeed1d033b7c9ae74df42769908c5", null ]
];