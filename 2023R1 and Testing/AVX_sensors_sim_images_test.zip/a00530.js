var a00530 =
[
    [ "analog_to_digital_converter_samples", "a00530.xhtml#a6aa7d60dffc7da404f55df76778668a3", null ],
    [ "frequency_pulse_response", "a00530.xhtml#a4af108854d8a98a4414baf026fbd110d", null ],
    [ "mode_identifier", "a00530.xhtml#ac0f01e07c235ffe8ee6cb49bc7f35b62", null ],
    [ "range_doppler_response", "a00530.xhtml#ad5fe7e97dcb9554c21bbfa560fd0201d", null ],
    [ "tx_waveform", "a00530.xhtml#a113beb5b26dc6c8d136768aff5c39b53", null ]
];