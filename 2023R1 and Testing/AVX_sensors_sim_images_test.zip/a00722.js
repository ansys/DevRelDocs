var a00722 =
[
    [ "resource_identifier", "a00722.xhtml#aef069f6bd46cea43ac09d1880b09577a", null ]
];