var a00138 =
[
    [ "horizontal_resolution", "a00138.xhtml#a13f8465964b091b643be7a42fd3ea09c", null ],
    [ "vertical_resolution", "a00138.xhtml#a88dd89f8a9fcebfa3f741a6a8d1dfff2", null ]
];