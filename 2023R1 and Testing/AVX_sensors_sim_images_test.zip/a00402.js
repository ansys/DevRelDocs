var a00402 =
[
    [ "items", "a00402.xhtml#ac8caf61705b0f998688f5ace29e3a594", null ],
    [ "status", "a00402.xhtml#aac8105451626f3f5922e567b5940391e", null ]
];