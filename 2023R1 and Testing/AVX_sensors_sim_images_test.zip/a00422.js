var a00422 =
[
    [ "material_path", "a00422.xhtml#aaceb40631c9f8ebf46ec816d67aac87e", null ],
    [ "mesh_part_name", "a00422.xhtml#a33b485a1c16a89ed529e1041f2bcd804", null ]
];