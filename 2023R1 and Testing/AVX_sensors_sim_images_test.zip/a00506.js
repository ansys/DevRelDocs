var a00506 =
[
    [ "data", "a00506.xhtml#ace2e1c0e5eee75a3245447ed2e8f1948", null ],
    [ "waveform_length", "a00506.xhtml#a996e4b3405c200f73d0761573fea1e62", null ]
];