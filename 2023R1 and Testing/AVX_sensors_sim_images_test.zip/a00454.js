var a00454 =
[
    [ "flux", "a00454.xhtml#a436692a2101f1e83cf119bae9591faae", null ],
    [ "lamp_name", "a00454.xhtml#acb0a411d1549c7f6a29204dcbe77efd9", null ]
];