var a00214 =
[
    [ "dark_current_average_value", "a00214.xhtml#ad57972e361cbcda79719bf16296211c6", null ]
];