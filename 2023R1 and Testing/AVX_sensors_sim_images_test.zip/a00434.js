var a00434 =
[
    [ "lighting_system_state", "a00434.xhtml#ae0b150d0fb0b5a1bc5ee331fd5f9b07d", null ],
    [ "simulation_time", "a00434.xhtml#a1496c37bb746ba39c02a65c9f7d3cc24", null ]
];