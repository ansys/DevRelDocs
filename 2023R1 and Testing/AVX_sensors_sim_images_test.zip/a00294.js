var a00294 =
[
    [ "horizontal", "a00294.xhtml#a60d976f1081d89407364d5ca6f20a12f", null ],
    [ "vertical", "a00294.xhtml#af307fb4203ec6300ef2e4e0dafb9270c", null ]
];