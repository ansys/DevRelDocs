var a00370 =
[
    [ "range_ambiguity", "a00370.xhtml#acceab80292e9f6e2e4f7bf15459d786b", null ],
    [ "range_resolution", "a00370.xhtml#a3a5ed74da68d606d777412ead65f3c3f", null ],
    [ "velocity_ambiguity", "a00370.xhtml#aa84edf163179103b71e5ac773083cccf", null ],
    [ "velocity_resolution", "a00370.xhtml#a62d7f953fabe6817b218c9f50ddd68e6", null ]
];