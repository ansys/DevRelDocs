var a00534 =
[
    [ "data", "a00534.xhtml#ac143decc13d31809c70e4a4d23af8e3c", null ],
    [ "range_domain", "a00534.xhtml#a9c5950de193800c0f9bb06d03dbd8330", null ],
    [ "rx_identifiers", "a00534.xhtml#a148b55814edbca5cd633a108b535cf99", null ],
    [ "tx_identifiers", "a00534.xhtml#acba5b5c3fc8594c1b9469f77a06313db", null ],
    [ "velocity_domain", "a00534.xhtml#a16ca4a5c5b29bed86ef3b987d35dc6aa", null ]
];