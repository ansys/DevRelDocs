var a00670 =
[
    [ "gpu_by_modes", "a00670.xhtml#a15f4e71c164a370c56782ead8840638d", null ],
    [ "number_of_ray_batches", "a00670.xhtml#a353400d16fd569d8a637ef5b8e3e615f", null ],
    [ "rx_batching", "a00670.xhtml#a8ae410483ac9a32fb75bc3ec37ab75cd", null ]
];