var a00222 =
[
    [ "bit_depth_reduction", "a00222.xhtml#ad629e14835cd31ec5a891351347f79ab", null ]
];