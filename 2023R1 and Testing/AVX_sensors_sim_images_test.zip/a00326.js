var a00326 =
[
    [ "activate_mode", "a00326.xhtml#a72c8613ba077caf9ed8e6d863267497b", null ],
    [ "Gain", "a00326.xhtml#ab760d4f32afb92f360b3759d7b89b3de", null ],
    [ "identifier", "a00326.xhtml#a90979cdeecc9023962b2aaec60ad29ab", null ],
    [ "Noise", "a00326.xhtml#a2d734e8160eb2c4447223ddb23e5ded3", null ],
    [ "range_doppler_processor", "a00326.xhtml#aa52f02153c26ff4466ef92f20f81195a", null ],
    [ "rx_antenna_ids", "a00326.xhtml#a51e029d0177acb5c2e16eb9227b3e3ef", null ],
    [ "start_delay", "a00326.xhtml#adf3fca41a02d788fc6b0001e43fe56f6", null ],
    [ "tx_antenna_ids", "a00326.xhtml#a91887bae2eecd11f76e6710514fd9509", null ],
    [ "waveform", "a00326.xhtml#a0e5d0c3d82a97723b15b8a39261a50cc", null ]
];