var a00478 =
[
    [ "camera_data", "a00478.xhtml#a11e90704a24ec6960477c5cea0ac90ae", null ],
    [ "resolution", "a00478.xhtml#a4ddb69568d2cb4dcf8fd8bbf933401ad", null ],
    [ "spectral_sampling", "a00478.xhtml#ace7ea5433bb0784cd241236dc0cc2d01", null ]
];