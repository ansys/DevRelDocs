var class_f_m_o_p_group =
[
    [ "activeInputIdent", "class_f_m_o_p_group.xhtml#ab19fdf8d3eb67cc0d77cbbff38ff4b83", null ],
    [ "activeInputIndices", "class_f_m_o_p_group.xhtml#a97d8c95149fcbad589a47edda7312f95", null ],
    [ "centerInputValues", "class_f_m_o_p_group.xhtml#a9ca3566a6a41c169f8a05ac86398ae86", null ],
    [ "copyFCoPToDatabase", "class_f_m_o_p_group.xhtml#a6e7525a2108e3ba5f8e84849d5f3a812", null ],
    [ "copyMostSensitiveToDatabase", "class_f_m_o_p_group.xhtml#af90a5eb5a4aed2af1bbd69207298a721", null ],
    [ "copyRSigmaToDatabase", "class_f_m_o_p_group.xhtml#afab06d15908af8a8ad391c3c62f1ef1b", null ],
    [ "elementResults", "class_f_m_o_p_group.xhtml#aac50f586ee1030fe28f7ceb82596d843", null ],
    [ "eraseDatabaseCopies", "class_f_m_o_p_group.xhtml#a37662babd77d3217b300cc31a4ddf4af", null ],
    [ "evaluateAmplitudes", "class_f_m_o_p_group.xhtml#a7c58b7d50ad5676db022df82715e5156", null ],
    [ "inputCoP", "class_f_m_o_p_group.xhtml#ab31984f5281c2b1663f4e2d0e2a2a867", null ],
    [ "inputIdent", "class_f_m_o_p_group.xhtml#a8f7106d9165b855c958678be43c9e4f5", null ],
    [ "inputIdentsVector", "class_f_m_o_p_group.xhtml#a90e1ef91ed7f9d7c3448cb01d7bab656", null ],
    [ "mop", "class_f_m_o_p_group.xhtml#a4b3fc118553a130abbc8bd565e563184", null ],
    [ "nodeResults", "class_f_m_o_p_group.xhtml#a3d6b0f14ad9c641ec27d77f7440b17cb", null ],
    [ "numActiveInputs", "class_f_m_o_p_group.xhtml#ac8434f6aa78120ee35c1e32423589f74", null ],
    [ "numInputs", "class_f_m_o_p_group.xhtml#a2556eb3339693ac4a80b79c2a93c2990", null ],
    [ "overlaps", "class_f_m_o_p_group.xhtml#aab5e2780b896d345d6aca1405d7a18d6", null ],
    [ "rfGroup", "class_f_m_o_p_group.xhtml#a3f590a32d0900910a06cb38e521e3c06", null ],
    [ "scalarResults", "class_f_m_o_p_group.xhtml#a5fadc1fe1dfaeb5abab01182e9cb6fad", null ],
    [ "totalCoP", "class_f_m_o_p_group.xhtml#a2d040ac739a6e430c7e75137975004c2", null ],
    [ "useMOQ", "class_f_m_o_p_group.xhtml#a2052120d018f605d07dc78a14069463f", null ]
];