var struct_quality_measure_base =
[
    [ "error", "struct_quality_measure_base.xhtml#ac8a977438da39c4eb58c837aecf65ab4", null ],
    [ "expectsCrossValidation", "struct_quality_measure_base.xhtml#a449a0307ef1718dade4bf32512fefca9", null ],
    [ "measure", "struct_quality_measure_base.xhtml#a8d0dfd88a4f82ebefd1210abe81a82d0", null ],
    [ "write", "struct_quality_measure_base.xhtml#a8feeac45da67267b069723ad19404224", null ]
];