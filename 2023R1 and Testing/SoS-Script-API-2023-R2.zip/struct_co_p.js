var struct_co_p =
[
    [ "CoP", "struct_co_p.xhtml#adca3e46224da11f75247ecb839723c86", null ],
    [ "CoP", "struct_co_p.xhtml#a4702894ea742a06b44535da67267b407", null ],
    [ "error", "struct_co_p.xhtml#a4a4f4dfb26f77b55280f37a0610dd5f9", null ],
    [ "expectsCrossValidation", "struct_co_p.xhtml#ad9917a97363feb7eeee81a1b47fc41fa", null ],
    [ "loadJson", "struct_co_p.xhtml#ae5700ae63985e3e6b30cb716ddb5fdd0", null ],
    [ "measure", "struct_co_p.xhtml#a4b157842a805ad774da2ab43e530e3d4", null ],
    [ "operator=", "struct_co_p.xhtml#a052c74a9131f44b75aca6bcd6f18828c", null ],
    [ "saveJson", "struct_co_p.xhtml#ab4587af0230811304c91f1c0aaa1c9ce", null ],
    [ "write", "struct_co_p.xhtml#a77047bf810e52c1c56fa06464a9ecc3f", null ]
];