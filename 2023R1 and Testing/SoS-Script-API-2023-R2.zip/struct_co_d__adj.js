var struct_co_d__adj =
[
    [ "CoD_adj", "struct_co_d__adj.xhtml#a9a386c096fd74be8a67efb2d12ea5324", null ],
    [ "CoD_adj", "struct_co_d__adj.xhtml#a094d5f6cca73c38195d17f8dda7f1d74", null ],
    [ "error", "struct_co_d__adj.xhtml#a4a4f4dfb26f77b55280f37a0610dd5f9", null ],
    [ "expectsCrossValidation", "struct_co_d__adj.xhtml#ad9917a97363feb7eeee81a1b47fc41fa", null ],
    [ "loadJson", "struct_co_d__adj.xhtml#ae5700ae63985e3e6b30cb716ddb5fdd0", null ],
    [ "measure", "struct_co_d__adj.xhtml#a4b157842a805ad774da2ab43e530e3d4", null ],
    [ "operator=", "struct_co_d__adj.xhtml#ac2f048990cb0b5372889da1dd67a0262", null ],
    [ "saveJson", "struct_co_d__adj.xhtml#ab4587af0230811304c91f1c0aaa1c9ce", null ],
    [ "write", "struct_co_d__adj.xhtml#a77047bf810e52c1c56fa06464a9ecc3f", null ]
];