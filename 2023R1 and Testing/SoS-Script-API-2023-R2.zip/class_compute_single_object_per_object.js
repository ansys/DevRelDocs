var class_compute_single_object_per_object =
[
    [ "TAlgorithmFunction", "class_compute_single_object_per_object.xhtml#afe5cfc4ea6277ec393adca68465c9a5e", null ],
    [ "TAlgorithmFunction2", "class_compute_single_object_per_object.xhtml#adbff8fbbd061127936232ab5600cbe01", null ],
    [ "ComputeSingleObjectPerObject", "class_compute_single_object_per_object.xhtml#a432f44acdb38cd43ae8703c0686c0943", null ],
    [ "ComputeSingleObjectPerObject", "class_compute_single_object_per_object.xhtml#a84c9f6ead5046474a0f7835eb67ef672", null ],
    [ "check", "class_compute_single_object_per_object.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "class_compute_single_object_per_object.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "compute", "class_compute_single_object_per_object.xhtml#a2ee6c389c27f8cb563b6b1aa31f6bf17", null ],
    [ "data", "class_compute_single_object_per_object.xhtml#aff21fffab499ea652443206d66e1a9bb", null ],
    [ "new_quantity_idents", "class_compute_single_object_per_object.xhtml#a30b1bcf63b9bdc707fea30bd96d70447", null ],
    [ "overwrite_existing", "class_compute_single_object_per_object.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "quantity_idents", "class_compute_single_object_per_object.xhtml#aced57c746ae1d69d2fd56872fa1768bf", null ]
];