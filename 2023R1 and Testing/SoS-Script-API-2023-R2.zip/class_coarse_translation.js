var class_coarse_translation =
[
    [ "Type", "class_coarse_translation.xhtml#a1d1cfd8ffb84e947f82999c682b666a7", [
      [ "eNEUTRAL_TRANS", "class_coarse_translation.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a2d5c3933900d9305ee3ab4eaf1c8eb41", null ],
      [ "eCOARSE_TRANS", "class_coarse_translation.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a8ac858363c69f6aa4f5c8c53707e59d9", null ],
      [ "eCOARSE_ROT", "class_coarse_translation.xhtml#a1d1cfd8ffb84e947f82999c682b666a7aea911dad52b010b8282c411af58e6539", null ],
      [ "eCOARSE_ROT_TRANS", "class_coarse_translation.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a4f10521c7d01709e9fe29913bc74dc47", null ],
      [ "eFINE_ROT_TRANS", "class_coarse_translation.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a8f71931fda1acc6fdf8e362cbb879ebb", null ],
      [ "eFINE_ROT_TRANS_PREALIGNED", "class_coarse_translation.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a639264569cf302a509a30ecd4f9742f3", null ]
    ] ],
    [ "applyTransformation", "class_coarse_translation.xhtml#afdd491598da35029e3a478c72526fe8c", null ],
    [ "doesNonRigid", "class_coarse_translation.xhtml#ac87710c0a9a888274234344ca0aae257", null ],
    [ "doesRotate", "class_coarse_translation.xhtml#ae1841e85a58acb38cc648818485e265f", null ],
    [ "doesTranslate", "class_coarse_translation.xhtml#a0c6d1696bb7fa057700433a238ac628b", null ],
    [ "generateScriptOfSettingsDefinition", "class_coarse_translation.xhtml#ac225d733c7c2cc84e76682c9f5b4c7d2", null ],
    [ "trafoType", "class_coarse_translation.xhtml#a54b19d55d0fc1d118b49c425a6b71d12", null ],
    [ "trafo_ref_node_set", "class_coarse_translation.xhtml#a82e5d668866e3c7af7831eb0463db6f1", null ]
];