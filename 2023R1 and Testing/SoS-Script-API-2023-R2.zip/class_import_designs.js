var class_import_designs =
[
    [ "ImportDesigns", "class_import_designs.xhtml#a172a1dfa5c3ddbbfee43f7dd0d9a4d9c", null ],
    [ "check", "class_import_designs.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "filterDesignsByOptiSLang", "class_import_designs.xhtml#a5c801245230e33fcaa093d72cba5f117", null ],
    [ "getDesignNumbers", "class_import_designs.xhtml#a34c4b23f216aeb33d79984bca8041ea4", null ],
    [ "getDesignNumbersString", "class_import_designs.xhtml#a91d115ad2f6b884384893cb38c794ea7", null ],
    [ "getDesignPathNames", "class_import_designs.xhtml#abec8ff4bd28cc81e9c577b482291b498", null ],
    [ "import", "class_import_designs.xhtml#a73dd3f56399568385400db0c3fc08295", null ],
    [ "scanDesignRanges", "class_import_designs.xhtml#a54f34c64e9326398eaaf5cdcb8127e08", null ],
    [ "setDesignNumbers", "class_import_designs.xhtml#a2c914c9ef85b4d3a481ed5e3b56da7f1", null ],
    [ "unifyDesignNumbers", "class_import_designs.xhtml#ad011ce88ed992315a48040de3edbf675", null ],
    [ "base_path", "class_import_designs.xhtml#a1be53c8e392d898f99ddc804ff403c84", null ],
    [ "design_name_format", "class_import_designs.xhtml#aa25e23bc102293eb390ebd22691c1a90", null ],
    [ "max_num_threads", "class_import_designs.xhtml#ab00d7e5b521806ef2f1ac2e9e45fee82", null ],
    [ "ranges_from", "class_import_designs.xhtml#a845f0717e285151b07a57d047b4dd84e", null ],
    [ "ranges_to", "class_import_designs.xhtml#ac1cd6c172f196f452af5d57b7299b471", null ],
    [ "reference_design", "class_import_designs.xhtml#ab0f4ff8e7cbf191376f5487872de03f7", null ],
    [ "start_design_number", "class_import_designs.xhtml#a72dfcf1d918d2b4c2eaa79e34becc576", null ]
];