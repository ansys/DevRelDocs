var class_modify_mesh_base =
[
    [ "ModifyMeshBase", "class_modify_mesh_base.xhtml#aa710d378af429cd684644505082f9986", null ],
    [ "isAnyCoordinateSet", "class_modify_mesh_base.xhtml#a7fe742a326ed093610a77be41f0d5daf", null ],
    [ "isXCoordinateSet", "class_modify_mesh_base.xhtml#a3d06db310cea1faa5f35b16e4a863883", null ],
    [ "isYCoordinateSet", "class_modify_mesh_base.xhtml#ace43862f6f933e57005e4d669bf95ec8", null ],
    [ "isZCoordinateSet", "class_modify_mesh_base.xhtml#af263b289cd0bc9436b144c942ba18b9d", null ],
    [ "coor_increment_factor", "class_modify_mesh_base.xhtml#ae41d9f831e08fa05af4ff8562081865f", null ],
    [ "mesh_stabilization", "class_modify_mesh_base.xhtml#ab017799d29c8279bc2b4976f4aa3e4d0", null ],
    [ "node_coor_increment_x", "class_modify_mesh_base.xhtml#a2716ab8a487117f921f7a6827212d79f", null ],
    [ "node_coor_increment_y", "class_modify_mesh_base.xhtml#aeb73eaa26c8065e09713c94bcd61b920", null ],
    [ "node_coor_increment_z", "class_modify_mesh_base.xhtml#a33fde5ec2727661509ed1414a90db1bd", null ],
    [ "node_coor_x", "class_modify_mesh_base.xhtml#a159f2eb0ab4b04af4c6f560808af08b6", null ],
    [ "node_coor_y", "class_modify_mesh_base.xhtml#aa0300af1da21afa4e43fd0e64533e189", null ],
    [ "node_coor_z", "class_modify_mesh_base.xhtml#a5cc7124a1cba852c8dba82d827896358", null ],
    [ "throw_error_on_unstable_mesh", "class_modify_mesh_base.xhtml#ac92d2c3e8ade2a17ee2edb8eb6747008", null ]
];