var class_create_simple_training_plan =
[
    [ "CreateSimpleTrainingPlan", "class_create_simple_training_plan.xhtml#adf28cf2efd51b035883ceb37db728a71", null ],
    [ "cleanup", "class_create_simple_training_plan.xhtml#aee46840a9742d1ef1acbcbc0a0558d6a", null ],
    [ "compute", "class_create_simple_training_plan.xhtml#a21378382fcea59d7dac4cc95d221b79a", null ],
    [ "getInputs", "class_create_simple_training_plan.xhtml#a3a0b3b5d7b78bf28baeb3687819720c3", null ],
    [ "initialize", "class_create_simple_training_plan.xhtml#aee74475a8bc2fdc6d1a0fed306f683b7", null ],
    [ "unusedSamples", "class_create_simple_training_plan.xhtml#a6d765744e1b403aacd8ece89b42de38a", null ],
    [ "input_importances", "class_create_simple_training_plan.xhtml#afff2ed8fc84ff999a9ff1b187dc4fe8a", null ],
    [ "number_of_folds", "class_create_simple_training_plan.xhtml#ae29a97cfbae42dc37b7a9be964b5d266", null ],
    [ "training", "class_create_simple_training_plan.xhtml#a874a26feda81485f63f6bc9d791c8c86", null ]
];