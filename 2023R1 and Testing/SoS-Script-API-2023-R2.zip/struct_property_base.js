var struct_property_base =
[
    [ "__str__", "struct_property_base.xhtml#a3031d648b73235d11d64df95db3d84ce", null ]
];