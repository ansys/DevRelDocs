var class_compute_correlation =
[
    [ "ComputeCorrelation", "class_compute_correlation.xhtml#a773e498496fced65aeb2fdf0d7eabd86", null ],
    [ "check", "class_compute_correlation.xhtml#a47c34ec1e578c2ce27cf1c5fcd0d1704", null ],
    [ "compute", "class_compute_correlation.xhtml#ab08e112d95fe611e7eb25491c354d115", null ],
    [ "compute", "class_compute_correlation.xhtml#af6a8a462fbadda0123a0ea51e64534a0", null ],
    [ "field_data", "class_compute_correlation.xhtml#af22724fd9c1e0dd42ec296e4784b9df8", null ],
    [ "field_quantity_idents", "class_compute_correlation.xhtml#ab01db6dea146fd2a35511af297363e7b", null ],
    [ "new_design_idents", "class_compute_correlation.xhtml#a92a339e93315b87782ce1744408c370d", null ],
    [ "new_quantity_idents", "class_compute_correlation.xhtml#a30b1bcf63b9bdc707fea30bd96d70447", null ],
    [ "overwrite_existing", "class_compute_correlation.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "scalar_data", "class_compute_correlation.xhtml#a0c1c80374ba4d28153ed219819d24612", null ],
    [ "scalar_quantity_idents", "class_compute_correlation.xhtml#aeff6fae62a2847852dc0cc49fa48d31d", null ]
];