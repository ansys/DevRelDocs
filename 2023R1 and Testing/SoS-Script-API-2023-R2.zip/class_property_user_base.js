var class_property_user_base =
[
    [ "addProperty", "class_property_user_base.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "getProperties", "class_property_user_base.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "transferProperties", "class_property_user_base.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ]
];