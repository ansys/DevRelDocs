var struct_serializable_traits =
[
    [ "CreateRange", "struct_serializable_traits.xhtml#aa1bfb2e6cce804883a900653fdf640db", null ],
    [ "SerializedType", "struct_serializable_traits.xhtml#ab097986696f004853b8989b257f6bcdf", null ],
    [ "Type", "struct_serializable_traits.xhtml#a19462713b2aab2dae2c87c15f262c1df", null ],
    [ "access", "struct_serializable_traits.xhtml#a722bfc2616239aa9f198a76b73b69743", null ],
    [ "convertFrom", "struct_serializable_traits.xhtml#a1d26534c31e8c5b1b9c9684c59c1a524", null ],
    [ "convertTo", "struct_serializable_traits.xhtml#add861d4bddc999ecd369aa4f9709973a", null ],
    [ "name", "struct_serializable_traits.xhtml#a707b939a71a610e3f3dcb789ccf014b8", null ]
];