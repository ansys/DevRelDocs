var class_data_object_key =
[
    [ "DataObjectKey", "class_data_object_key.xhtml#a011752ed10fd6e449cfce53a740f3fac", null ],
    [ "design", "class_data_object_key.xhtml#a1aa358e9c7ca3104d4cf94831785854c", null ],
    [ "isEmpty", "class_data_object_key.xhtml#af337ffd75e4f019ce15302c60715d84b", null ],
    [ "quantity", "class_data_object_key.xhtml#a1bcba3323e99209861bb69899ff07022", null ]
];