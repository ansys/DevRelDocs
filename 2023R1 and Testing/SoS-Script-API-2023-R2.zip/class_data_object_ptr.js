var class_data_object_ptr =
[
    [ "Base", "class_data_object_ptr.xhtml#a09f51db57aeca694ba21f535268b2caf", null ],
    [ "ObserverPtr", "class_data_object_ptr.xhtml#afa0bd4d832168701ce39642b559bf810", null ],
    [ "ObserverPtrList", "class_data_object_ptr.xhtml#a46d3f34a7866e39589a2b26177a3c85b", null ],
    [ "Ptr", "class_data_object_ptr.xhtml#a05d711ff954f9f9ce0c2bd74419b2866", null ],
    [ "string_type", "class_data_object_ptr.xhtml#aa1ded226048e7a66da648cffd6711135", null ],
    [ "generateDescription", "class_data_object_ptr.xhtml#adb4ae4fd523acf2d4e22f98f6e49bd29", null ],
    [ "getData", "class_data_object_ptr.xhtml#aa34d981457a2c81fc0b5a82480dc309f", null ],
    [ "getFullData", "class_data_object_ptr.xhtml#ab6b7802b0e7a9913022f60f84af8d7a8", null ],
    [ "getMissingData", "class_data_object_ptr.xhtml#a409999570abae1c6fb513f7a05ff28d9", null ],
    [ "ident", "class_data_object_ptr.xhtml#a0d8af7ea437aff47519ec89fbdcec396", null ],
    [ "isValid", "class_data_object_ptr.xhtml#afe93e17ac89cd97917811068ba2af214", null ],
    [ "operator!=", "class_data_object_ptr.xhtml#a5fcde290fd88681d2e9e001a32b459c2", null ],
    [ "operator*", "class_data_object_ptr.xhtml#a1d75b51141d0038b899c559556099eb9", null ],
    [ "operator->", "class_data_object_ptr.xhtml#a7ec341e963e6523d0dc675e834a55260", null ],
    [ "operator->", "class_data_object_ptr.xhtml#a7ec341e963e6523d0dc675e834a55260", null ],
    [ "operator==", "class_data_object_ptr.xhtml#a04290a57633bc8e5f56db69143d21ae1", null ],
    [ "setActive", "class_data_object_ptr.xhtml#a74f4470cdd92983fd2bc8947c68f863e", null ],
    [ "setDescription", "class_data_object_ptr.xhtml#a4260ac809eb735741f23b5bf8184d51e", null ],
    [ "setInactive", "class_data_object_ptr.xhtml#af3f6a8f453e6bc82d6b23f0b29379e2c", null ]
];