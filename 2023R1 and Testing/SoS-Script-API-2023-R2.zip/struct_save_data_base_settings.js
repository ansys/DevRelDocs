var struct_save_data_base_settings =
[
    [ "SaveDataBaseSettings", "struct_save_data_base_settings.xhtml#a6e995b305e08e7dcc200741448b9b06c", null ],
    [ "check", "struct_save_data_base_settings.xhtml#aa41227b9a864188eba2bf5cc4540a9b1", null ],
    [ "filename", "struct_save_data_base_settings.xhtml#a3a1a90139c2c8ab1fca0ea8b1790b7b2", null ],
    [ "replace_files", "struct_save_data_base_settings.xhtml#a2f8b3cba47ad64fb6bda4b6428a032d3", null ]
];