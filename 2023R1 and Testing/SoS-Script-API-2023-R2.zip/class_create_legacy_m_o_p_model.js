var class_create_legacy_m_o_p_model =
[
    [ "CreateLegacyMOPModel", "class_create_legacy_m_o_p_model.xhtml#ad61adf030cb568f50d71d165d420b61e", null ],
    [ "CreateLegacyMOPModel", "class_create_legacy_m_o_p_model.xhtml#a76549ea2eabdc1ff32424f570ad5e41f", null ],
    [ "__str__", "class_create_legacy_m_o_p_model.xhtml#a3031d648b73235d11d64df95db3d84ce", null ],
    [ "addProperty", "class_create_legacy_m_o_p_model.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "compute", "class_create_legacy_m_o_p_model.xhtml#a428e7ba979340c651ec1372a3307e037", null ],
    [ "getProperties", "class_create_legacy_m_o_p_model.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "isValid", "class_create_legacy_m_o_p_model.xhtml#a1a42d0ff7ef3b9c17965ecc14310ed5d", null ],
    [ "operator=", "class_create_legacy_m_o_p_model.xhtml#a3b2ee4d9715a1fa272b70b3f62f78955", null ],
    [ "transferProperties", "class_create_legacy_m_o_p_model.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ],
    [ "use_BoxCox", "class_create_legacy_m_o_p_model.xhtml#ae3a2c0110357b15e55285a625c21e028", null ],
    [ "use_CoD_filter", "class_create_legacy_m_o_p_model.xhtml#ad454212264147757ead8a6b1a702019d", null ],
    [ "use_CoI_filter", "class_create_legacy_m_o_p_model.xhtml#adb678f343269092390e130a99b1d2dad", null ],
    [ "use_correlation_filter", "class_create_legacy_m_o_p_model.xhtml#afd89ea7f62227924199890c55f41439f", null ],
    [ "use_input_correlation_filter", "class_create_legacy_m_o_p_model.xhtml#a7bc1de6eaf8c93f135797f06992972a4", null ],
    [ "use_kriging", "class_create_legacy_m_o_p_model.xhtml#a777c1c86f4a98e63b65b2b395b8b551c", null ],
    [ "use_kriging_anisotropic", "class_create_legacy_m_o_p_model.xhtml#a21ae967782584b3e9eedcde16144132d", null ],
    [ "use_MLS", "class_create_legacy_m_o_p_model.xhtml#ae1d69f069ec0d2747cbee8c5e629dfd7", null ],
    [ "use_polynomials", "class_create_legacy_m_o_p_model.xhtml#a705beab6587cd69b7d89d4ea6d830a2e", null ],
    [ "use_significance_filter", "class_create_legacy_m_o_p_model.xhtml#aea97490d1b9082db4c2ec6b37012c17e", null ],
    [ "use_Spearman_filter", "class_create_legacy_m_o_p_model.xhtml#a4545c85407236294e80529caabe599af", null ]
];