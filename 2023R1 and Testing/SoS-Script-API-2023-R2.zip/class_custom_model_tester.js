var class_custom_model_tester =
[
    [ "CustomModelTester", "class_custom_model_tester.xhtml#a3343f987a44114a7ec902f90e3a25085", null ],
    [ "__str__", "class_custom_model_tester.xhtml#a3031d648b73235d11d64df95db3d84ce", null ],
    [ "deserializeModel", "class_custom_model_tester.xhtml#a450f9bf11531eb63544171e8a826b27d", null ],
    [ "serializeModel", "class_custom_model_tester.xhtml#aa31948651298e7baa48185a94586a3d8", null ],
    [ "test", "class_custom_model_tester.xhtml#a5cd36c1eb84f60075b42c405265d0fc1", null ],
    [ "testSerialization", "class_custom_model_tester.xhtml#a63d9add55ef26eefce14e92c7efbd72b", null ],
    [ "DISOWN", "class_custom_model_tester.xhtml#aa936348f586ed71a2a8585a4b16b20fc", null ]
];