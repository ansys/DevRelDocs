var class_compute_relative_error =
[
    [ "eType", "class_compute_relative_error.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60e", [
      [ "ACCURACY", "class_compute_relative_error.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60ea099d39fb970cfb7d422a9742d608bbc3", null ],
      [ "UNSIGNED_ERROR", "class_compute_relative_error.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60ea30cb2ef9f904d87ebbd15a4244d6892f", null ],
      [ "SIGNED_ERROR", "class_compute_relative_error.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60eabb8dbeab89d2a5313873605f5cdf5a13", null ],
      [ "DIFF", "class_compute_relative_error.xhtml#a12f8ec8f0e7a4584b9fe481bb53fa60eaa5d305f703cfce63b982a4cba74f64ec", null ]
    ] ],
    [ "ComputeRelativeError", "class_compute_relative_error.xhtml#adc93cac1c027c5fb8a720d580ec3f2fa", null ],
    [ "ComputeRelativeError", "class_compute_relative_error.xhtml#a8e986e5aceb797c81f17a3f8c2b93697", null ],
    [ "error_type", "class_compute_relative_error.xhtml#a5691769acfd1bf8c400d92e360066619", null ],
    [ "interpolate_missing_items", "class_compute_relative_error.xhtml#a80ad12816b0c0674c578048eb2fd0afe", null ],
    [ "other", "class_compute_relative_error.xhtml#ac73a7eae6d39beb3f741dadfd254bf55", null ],
    [ "output_quantity_ident", "class_compute_relative_error.xhtml#a17a0b08032f8c37e624459b892cc3beb", null ],
    [ "overwrite_existing", "class_compute_relative_error.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "reference", "class_compute_relative_error.xhtml#aa765c055b5f09bff957e2529c4b728fe", null ]
];