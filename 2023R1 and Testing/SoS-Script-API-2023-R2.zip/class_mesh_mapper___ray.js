var class_mesh_mapper___ray =
[
    [ "CoorTransformationBasePtr", "class_mesh_mapper___ray.xhtml#a7c3eb7b21b8e3254d697b15a4192a7fe", null ],
    [ "Type", "class_mesh_mapper___ray.xhtml#a1d1cfd8ffb84e947f82999c682b666a7", [
      [ "eCOMPATIBLE", "class_mesh_mapper___ray.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a459203ce56429dc8706ca2740bd69841", null ],
      [ "eINCOMPATIBLE", "class_mesh_mapper___ray.xhtml#a1d1cfd8ffb84e947f82999c682b666a7abb012f96e4409688aa1c1b06b645f184", null ],
      [ "eINCOMPATIBLE_CPP", "class_mesh_mapper___ray.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a29ad298ad8ef76fee66b8f94a6d463c3", null ],
      [ "eINCOMPATIBLE_RAY", "class_mesh_mapper___ray.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a5a8514eef49d57792d68c382249f7e77", null ],
      [ "eGRID", "class_mesh_mapper___ray.xhtml#a1d1cfd8ffb84e947f82999c682b666a7a284b6ad33acf2df5fcd062adc42ad59c", null ],
      [ "eP2VOLUME", "class_mesh_mapper___ray.xhtml#a1d1cfd8ffb84e947f82999c682b666a7adede4088d718f7458095afc816edd231", null ],
      [ "eMORPHED_MESH", "class_mesh_mapper___ray.xhtml#a1d1cfd8ffb84e947f82999c682b666a7afc6b02161f5d04720e7f94015730e580", null ]
    ] ],
    [ "MeshMapper_Ray", "class_mesh_mapper___ray.xhtml#ae918c8e7ca06023b5aa8bd64ab2b3dfc", null ],
    [ "add_offset_to_deviation", "class_mesh_mapper___ray.xhtml#a834cc6bbd493201332159c1af8facc7e", null ],
    [ "maximum_search_distance", "class_mesh_mapper___ray.xhtml#ac94d772107063be0645673d9156260dd", null ],
    [ "offset_x", "class_mesh_mapper___ray.xhtml#ad4e70c1e25e4b302401e855737311613", null ],
    [ "offset_y", "class_mesh_mapper___ray.xhtml#a3cc33bdebe396bd366d6f90bf4db94c8", null ],
    [ "offset_z", "class_mesh_mapper___ray.xhtml#ac51e80d987e5d67c6d63e66fe2cbcc66", null ],
    [ "overwrite_existing", "class_mesh_mapper___ray.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ],
    [ "ray_x", "class_mesh_mapper___ray.xhtml#a1379192cc58ef763a3602bba5635758f", null ],
    [ "ray_y", "class_mesh_mapper___ray.xhtml#ab18ac8d36e0e7948cfd2129f9f5f50f2", null ],
    [ "ray_z", "class_mesh_mapper___ray.xhtml#af2cd7d65ad2244fa54cc55d4bb4d340c", null ],
    [ "transferred_data_ident_prefix", "class_mesh_mapper___ray.xhtml#ae79cc32e0a89d7a67bb2cfc469d95e6a", null ],
    [ "use_half_space_test_for_associating_faces", "class_mesh_mapper___ray.xhtml#a25dc38ad33af95b4c9b51c09e532c46f", null ],
    [ "use_other_reference_node_set", "class_mesh_mapper___ray.xhtml#a393478609eb7352fa6ef03969634db35", null ],
    [ "use_reference_node_set", "class_mesh_mapper___ray.xhtml#ad0f3248d847b16ce1863e98c8e41d451", null ]
];