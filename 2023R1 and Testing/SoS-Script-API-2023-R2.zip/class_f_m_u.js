var class_f_m_u =
[
    [ "FMU", "class_f_m_u.xhtml#afd991456ba917c9eb24f61de4658db22", null ],
    [ "addScalarVariable", "class_f_m_u.xhtml#ad17d22fdec61fd737e9563a3f7714a05", null ],
    [ "setAuthor", "class_f_m_u.xhtml#a325871988fd80bf568d4b628fb2855d6", null ],
    [ "setDllPath", "class_f_m_u.xhtml#a682461752380b2bbb0339143e5bd5a5e", null ],
    [ "setModelDescription", "class_f_m_u.xhtml#a24298d9edfff27ce9f3b41a1c767f9c5", null ],
    [ "setModelName", "class_f_m_u.xhtml#ab4ad00113667a54fc86a2d648e8190f6", null ],
    [ "setScript", "class_f_m_u.xhtml#af6945a63033b7df33729c5b2f610d409", null ],
    [ "setScriptFile", "class_f_m_u.xhtml#a313630bccd6d99a3c2cabdd1932beabf", null ],
    [ "writeFMU", "class_f_m_u.xhtml#a6938dac8b406b7f3c9d37b6e99bd805e", null ]
];