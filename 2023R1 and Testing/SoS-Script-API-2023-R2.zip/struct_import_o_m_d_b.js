var struct_import_o_m_d_b =
[
    [ "ImportOMDB", "struct_import_o_m_d_b.xhtml#a309c2d0c2127659dc18b083da314eb4e", null ],
    [ "check", "struct_import_o_m_d_b.xhtml#a483e471aa905217dc69d9b12390ba367", null ],
    [ "import", "struct_import_o_m_d_b.xhtml#aede94ac324007dfdc28cad1dd38e158f", null ],
    [ "filename", "struct_import_o_m_d_b.xhtml#a3a1a90139c2c8ab1fca0ea8b1790b7b2", null ],
    [ "import_inputs", "struct_import_o_m_d_b.xhtml#a1779fd0ed7406bcf8b1a33cb53b102ea", null ],
    [ "import_responses", "struct_import_o_m_d_b.xhtml#a0086995286c153dec1bb8615e26c480b", null ],
    [ "overwrite_existing", "struct_import_o_m_d_b.xhtml#ade25e60bd85c8b4abd4f5b416cae0eb9", null ]
];