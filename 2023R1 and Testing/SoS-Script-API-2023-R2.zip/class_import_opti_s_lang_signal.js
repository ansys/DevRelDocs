var class_import_opti_s_lang_signal =
[
    [ "ImportOptiSLangSignal", "class_import_opti_s_lang_signal.xhtml#a728c7c7a95005527ecb79ae0f5356fd3", null ],
    [ "importData", "class_import_opti_s_lang_signal.xhtml#a990ac4d4d6b49f8ce6f253c6d7b619d5", null ],
    [ "importMesh", "class_import_opti_s_lang_signal.xhtml#a7c46ddb26ae2f6cafd85ca6e7b7128fc", null ],
    [ "signalIdents", "class_import_opti_s_lang_signal.xhtml#a0799bab98eadfaca1bed3ceacc1b2f2e", null ],
    [ "filename", "class_import_opti_s_lang_signal.xhtml#a3a1a90139c2c8ab1fca0ea8b1790b7b2", null ],
    [ "resample_abscissa", "class_import_opti_s_lang_signal.xhtml#ad737785c9535293035604d481a12bbfb", null ],
    [ "shrink_abscissa", "class_import_opti_s_lang_signal.xhtml#a205eefb25638b78327b52649977a67d3", null ]
];