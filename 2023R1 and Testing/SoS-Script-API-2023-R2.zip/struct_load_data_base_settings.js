var struct_load_data_base_settings =
[
    [ "LoadDataBaseSettings", "struct_load_data_base_settings.xhtml#a09381b08c9df0cfd860cb4a2b1d27f8e", null ],
    [ "check", "struct_load_data_base_settings.xhtml#aa41227b9a864188eba2bf5cc4540a9b1", null ],
    [ "create_reference_mesh", "struct_load_data_base_settings.xhtml#a2fb04e13802924a2ebc0b2b17e065850", null ],
    [ "filename", "struct_load_data_base_settings.xhtml#a3a1a90139c2c8ab1fca0ea8b1790b7b2", null ]
];