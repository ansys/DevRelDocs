var class_residuals =
[
    [ "Residuals", "class_residuals.xhtml#a03801914800cc202cd858c6702493859", null ],
    [ "Residuals", "class_residuals.xhtml#a6f2b1c38c3523414fe721c5a0f44d0b2", null ],
    [ "Residuals", "class_residuals.xhtml#a54041735a9cd5871b43643a98e8612af", null ],
    [ "__getstate__", "class_residuals.xhtml#a9350cb76131731f942f48489020fa0b2", null ],
    [ "__setstate_internal", "class_residuals.xhtml#a63341b304935e7b46f1e215161f07671", null ],
    [ "adjustmentCoefficient", "class_residuals.xhtml#a8dd7f15655b57d7cc35407bc11334bb2", null ],
    [ "adjustmentCoefficientRef", "class_residuals.xhtml#a72fbb0caf78eef1bce91de6e9b1249a7", null ],
    [ "approximationValues", "class_residuals.xhtml#a628146b05607ddc049415f176de09828", null ],
    [ "approximationValuesRef", "class_residuals.xhtml#a4715cc9b7cdd549625596777ecf92856", null ],
    [ "crossValidationValues", "class_residuals.xhtml#a19a8dd18ea4cba56a3546a9d7db7be47", null ],
    [ "crossValidationValuesRef", "class_residuals.xhtml#adb0fcf21491d18d53b6d9b6db7446ea2", null ],
    [ "operator=", "class_residuals.xhtml#a63221de26f2540b1609bbde9e0c165b9", null ],
    [ "originalValues", "class_residuals.xhtml#a12d59f25cbe442106a8d89c13fc96852", null ],
    [ "originalValuesRef", "class_residuals.xhtml#a75d50538e802e65a662fa2bf3923ba4d", null ],
    [ "serialize", "class_residuals.xhtml#aaa3a4f99152c0c2dce6c8794c9b1ee49", null ]
];