var class_custom_model =
[
    [ "CustomModel", "class_custom_model.xhtml#a4157584723d8c5006120f80f35c39062", null ],
    [ "CustomModel", "class_custom_model.xhtml#aacf86a2314d5ac9cf1771ca029dce7b9", null ],
    [ "CustomModel", "class_custom_model.xhtml#a40e7ff8e5f1af327a84222a105453b44", null ],
    [ "activeVariables", "class_custom_model.xhtml#a5f1838dd858c10b0fd7437d43ac4ea33", null ],
    [ "addProperty", "class_custom_model.xhtml#aedfb47575823522e6a6d22ce6c12e826", null ],
    [ "cvOutputs", "class_custom_model.xhtml#a85e586564296f496505584cce05a2654", null ],
    [ "evaluate", "class_custom_model.xhtml#a85c04b0ec7ee1ee66e21af920faabb73", null ],
    [ "getProperties", "class_custom_model.xhtml#a0e1dd7df82728594fc128ed1c797b0c0", null ],
    [ "hasRegisteredModel", "class_custom_model.xhtml#aba852c1478ec4cf87b7510ea87aaec0b", null ],
    [ "operator=", "class_custom_model.xhtml#a29255ab840bc80a9f21abd179f216d9d", null ],
    [ "residuals", "class_custom_model.xhtml#afe90ce58ae457fa0cecebf5f154edc30", null ],
    [ "serialize", "class_custom_model.xhtml#ae3fa2bc56690639794d33188524b0dfe", null ],
    [ "transferProperties", "class_custom_model.xhtml#ab9507274f126b856fb69cd621f0f9fb4", null ],
    [ "write", "class_custom_model.xhtml#a1aafb5e0753eea90b54a7c1f9bb27741", null ]
];