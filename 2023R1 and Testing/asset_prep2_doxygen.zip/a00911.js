var a00911 =
[
    [ "custom_temperature", "a00911.xhtml#a1ded52a625989f2c9ca71ff02ca1ce8a", null ],
    [ "no_custom_temperature", "a00911.xhtml#a96a0cfbb39b9429e8993544e8deb444c", null ]
];