var a00843 =
[
    [ "node_id", "a00843.xhtml#af00d6437fc94e7262d61cd694c37075e", null ],
    [ "properties", "a00843.xhtml#a071f772f0b0aa4b60a6ab5e5cc1ac403", null ]
];