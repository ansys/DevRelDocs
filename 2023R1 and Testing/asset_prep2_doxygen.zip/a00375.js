var a00375 =
[
    [ "name", "a00375.xhtml#ad763d7695fac52638a7ca7898d1ba320", null ],
    [ "winding_order", "a00375.xhtml#a3fd823c33d7ab171a8e05d02d63ad889", null ]
];