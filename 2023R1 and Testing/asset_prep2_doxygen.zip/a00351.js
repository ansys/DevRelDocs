var a00351 =
[
    [ "id", "a00351.xhtml#a9adc4d432701af2760986e5f2e45c112", null ],
    [ "properties", "a00351.xhtml#ae16dc93a8856209f0ab5d4a47fb2f98a", null ],
    [ "status", "a00351.xhtml#a561caf36b32b7ef97e5b942ae7c1fd39", null ]
];