var a00815 =
[
    [ "instance_id", "a00815.xhtml#a24c484d206409ef90a076cca5eb99ee2", null ],
    [ "node_id", "a00815.xhtml#afb4102b91a6eefc64eea16f4bfbc10c8", null ],
    [ "status", "a00815.xhtml#a601216d9042eaaab3db2532229182a52", null ]
];