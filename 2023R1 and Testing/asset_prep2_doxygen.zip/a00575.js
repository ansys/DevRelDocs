var a00575 =
[
    [ "hue", "a00575.xhtml#a569d7bff6e9deaf71897f3bfffd3fec0", null ],
    [ "saturation", "a00575.xhtml#a361404c75c26c83cd1826d7d9084e266", null ],
    [ "value", "a00575.xhtml#af851193b75f17567c58a1759e4760b69", null ]
];