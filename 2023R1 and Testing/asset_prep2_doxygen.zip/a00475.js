var a00475 =
[
    [ "anisotropy_properties", "a00475.xhtml#aea996e700ea71355c754c0215fe39900", null ],
    [ "diffuse_properties", "a00475.xhtml#a452ef55a0b0a4c2aa0abd3ff7e56a4aa", null ],
    [ "mask_properties", "a00475.xhtml#acedafdd8aab958e96baaecef06762070", null ],
    [ "normal_properties", "a00475.xhtml#abe296331702f241b6bb4aa7b193d658c", null ],
    [ "reflectivity", "a00475.xhtml#a69b157dbdf5fe254de32af1d7347ad79", null ]
];