var a00559 =
[
    [ "emissivity", "a00559.xhtml#abb6a1b5dffb8e1ddd1274b5d05401e98", null ],
    [ "emissivity_variation_amplitude", "a00559.xhtml#a8bb0bdc9ac64a95548a91e8bed9f02b1", null ],
    [ "emissivity_variation_texture_id", "a00559.xhtml#a135c7ed2a5aa9c872570416b3356fa37", null ],
    [ "emissivity_variation_uv_channel", "a00559.xhtml#a1dba473c3d3dabc7b444d1a1e15fb5a4", null ],
    [ "reflection_coefficient", "a00559.xhtml#aa509b70baf6b5290d86297678da17192", null ],
    [ "shininess", "a00559.xhtml#a9d7d03fdca5b2c51f75f5c126725d6ce", null ],
    [ "thermal_coefficient", "a00559.xhtml#ad36858adba66b6ffc5186bf1bb8befab", null ]
];