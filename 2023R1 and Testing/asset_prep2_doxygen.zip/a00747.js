var a00747 =
[
    [ "node_id", "a00747.xhtml#ab48e2a2cb8b8121c670d7cec857627d6", null ],
    [ "properties", "a00747.xhtml#a302ee514bfbe9ec2ef393df97a3eaf69", null ],
    [ "scene_tree_id", "a00747.xhtml#a8f2006ca4876a7486d4250ae1e789af2", null ]
];