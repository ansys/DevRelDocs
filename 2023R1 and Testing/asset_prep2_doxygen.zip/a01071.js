var a01071 =
[
    [ "angular_precision", "a01071.xhtml#a961f870b09e39ca49d9289743ce4d81c", null ],
    [ "black_body", "a01071.xhtml#a23c338683c281aa0c4ab5890aa1bc222", null ],
    [ "diagram_library", "a01071.xhtml#aa97934561b09f933cf6a4a5bdb3dd0ae", null ],
    [ "exitance", "a01071.xhtml#aadb5e097e2c3cb608bdd2465282f05a4", null ],
    [ "gaussian", "a01071.xhtml#a6330f39fa0f42bee918322cad9f3a1b1", null ],
    [ "lambertian", "a01071.xhtml#a16634dfa1f7aeb1ba5c30f17ca7f7b12", null ],
    [ "lighting_contribution", "a01071.xhtml#a6721ecb053a7ce32c7155389261fec1e", null ],
    [ "monochromatic", "a01071.xhtml#a52799ef7cd3fc91c65af4459c253fd5a", null ],
    [ "no_contribution", "a01071.xhtml#a2eddbfe71d0e1d8aeb5cfd80f77f4c26", null ],
    [ "reverse_direction", "a01071.xhtml#ab8c981712416d964f58325a13701352f", null ],
    [ "spectrum_library", "a01071.xhtml#a3f82d49a57ebcd632e2367959ea8ee78", null ]
];