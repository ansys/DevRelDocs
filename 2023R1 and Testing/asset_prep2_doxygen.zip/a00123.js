var a00123 =
[
    [ "basic_type", "a00123.xhtml#a6b802073a1be9e307f213ad6ba2a8f18", null ],
    [ "lighting_type", "a00123.xhtml#a03a4dfc5bffb37999d12da671413e100", null ],
    [ "properties", "a00123.xhtml#ac2d8c7257fd3977c050966e7bff21975", null ]
];