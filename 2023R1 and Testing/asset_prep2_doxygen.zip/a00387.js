var a00387 =
[
    [ "has_binormals", "a00387.xhtml#af4f8da35a2d2d51f0bc0f255bfb305e5", null ],
    [ "has_tangents", "a00387.xhtml#a9991ea6f2a08232adbae38c698bf2439", null ],
    [ "uv_count", "a00387.xhtml#a82274371e5fba72137f71dc34c4d1ddb", null ]
];