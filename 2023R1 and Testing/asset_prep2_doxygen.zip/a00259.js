var a00259 =
[
    [ "id", "a00259.xhtml#a13ebef8c95560811a6c9c63546f7e320", null ],
    [ "name", "a00259.xhtml#aef47340258dab633eb3bee3c8ce14559", null ]
];