var a01015 =
[
    [ "cardinal_direction", "a01015.xhtml#a063ed1bdf77f812cd6afd29d3b152e2d", null ],
    [ "latitude", "a01015.xhtml#a367a76401413686965420af4cf2f4e66", null ],
    [ "longitude", "a01015.xhtml#a92c44598151993addf8bd1fd346c3251", null ]
];