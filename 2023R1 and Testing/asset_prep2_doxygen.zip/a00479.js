var a00479 =
[
    [ "anisotropy_properties", "a00479.xhtml#a078543746854e5a84595d7deaed05684", null ],
    [ "diffuse_properties", "a00479.xhtml#a7690a7b892226a702a3707b7b37ba478", null ],
    [ "mask_properties", "a00479.xhtml#a57353529f15308942d82a0dfe62e983c", null ],
    [ "normal_properties", "a00479.xhtml#a6665644d071cacce05295a075d61047a", null ],
    [ "surface_state_id", "a00479.xhtml#a54ce870a96a94f5a7987ca9c89b241f6", null ]
];