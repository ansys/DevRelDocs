var a00191 =
[
    [ "near_field_precision", "a00191.xhtml#a8ab9cec798da9d83fabb0144cccaa3e2", null ],
    [ "resolution", "a00191.xhtml#a395248cee7ed2e82a80243333d48614b", null ],
    [ "shadow_offset_ratio", "a00191.xhtml#a0081b6b9024df32e5aa19315ff276f5f", null ],
    [ "shadow_radius", "a00191.xhtml#afbf488648b9ced94fed159bc1c1387ba", null ],
    [ "softness", "a00191.xhtml#a15b9f34b35d680e64e47923c79c0135e", null ]
];