var a00507 =
[
    [ "map_id", "a00507.xhtml#a56fb6065e91873cf8d4b3c2e9d00a25f", null ],
    [ "map_uv_channel", "a00507.xhtml#ae9d29b588beb8271a9d4cc380dac146d", null ]
];