var a00679 =
[
    [ "file_path", "a00679.xhtml#a1c8ddfaefea1478d9e6fb94f4b56606b", null ],
    [ "identifier", "a00679.xhtml#a124719bb37d71ac6fa5eabf065772105", null ],
    [ "overwrite", "a00679.xhtml#af690d18e7344a6149936ef50570af3de", null ],
    [ "type", "a00679.xhtml#acd9c22621af0e1b5c1ef146321a9c410", null ]
];