var a00135 =
[
    [ "CreateDirectionalLight", "a00135.xhtml#aab8322dd90f821e131a05966333a1cf8", null ],
    [ "DeleteDirectionalLight", "a00135.xhtml#a1de42836c4ac6b4b70cca92a46e10de4", null ],
    [ "GetDirectionalLight", "a00135.xhtml#a38ac22635a3daf8c87773ebe74564b21", null ],
    [ "ListDirectionalLights", "a00135.xhtml#af572c8ee54a2ca0df0ac75abd1517007", null ],
    [ "UpdateDirectionalLight", "a00135.xhtml#a293b5f6c4cdaa4011063cc0ea27e0f8d", null ]
];