var a00783 =
[
    [ "instance_id", "a00783.xhtml#ab14b92f58d285c44b11f8f6538753f43", null ],
    [ "node_id", "a00783.xhtml#ae2d6aba125b7a6025311b80ef2c7badf", null ],
    [ "status", "a00783.xhtml#afede8f66846dd80899c28115e4e9c6ee", null ]
];