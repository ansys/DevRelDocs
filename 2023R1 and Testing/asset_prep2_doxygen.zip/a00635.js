var a00635 =
[
    [ "angular_precision", "a00635.xhtml#aeac421252c5a92e0e26957978ef68a2c", null ],
    [ "diagram_library", "a00635.xhtml#a5fb492f68336081c050f53abc7844e13", null ],
    [ "flux", "a00635.xhtml#a6146e9c4063c85258c6b0e1e95fe94a2", null ],
    [ "gaussian", "a00635.xhtml#a9f4c26105d8b8552350b2e623feb0b04", null ],
    [ "isotropic", "a00635.xhtml#ad57ff5ff439d1e5980a36736821ee835", null ],
    [ "lambertian", "a00635.xhtml#ad6c851dddc7682d43ac2e075c0608b32", null ]
];