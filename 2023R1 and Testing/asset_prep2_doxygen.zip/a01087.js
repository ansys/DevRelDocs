var a01087 =
[
    [ "x", "a01087.xhtml#ad5db7413fa60bec5bf67dbafcdcf6163", null ],
    [ "y", "a01087.xhtml#ad2d8492c24324b511d0625cc76a1ea4c", null ]
];