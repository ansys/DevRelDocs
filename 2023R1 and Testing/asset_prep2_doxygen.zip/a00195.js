var a00195 =
[
    [ "spectrum_id", "a00195.xhtml#a6287a854300900087d4607d21524b675", null ]
];