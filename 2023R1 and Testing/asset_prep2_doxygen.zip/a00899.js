var a00899 =
[
    [ "added_tags", "a00899.xhtml#a16a41c49fe6950b0c7bc203d521b3ae9", null ],
    [ "name", "a00899.xhtml#a71047ecdfd69ab9cff3fe0a661150f9c", null ],
    [ "removed_tags", "a00899.xhtml#a71cef5be650a05bf3d32a67ac443f706", null ],
    [ "transform", "a00899.xhtml#a9a8ef6ac03cdc33d5ebd6f943cfea746", null ],
    [ "visibility", "a00899.xhtml#afd98614ffb96bee85f4fc6a022323424", null ]
];