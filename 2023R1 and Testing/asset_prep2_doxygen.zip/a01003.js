var a01003 =
[
    [ "ambient_factor", "a01003.xhtml#aa80e13871671ae31acbd4164cfbfdade", null ],
    [ "ground_radius", "a01003.xhtml#aa3094ca316f39145e0bb3436d38a6850", null ],
    [ "luminance_factor", "a01003.xhtml#aa79a6bed22e4aaa4a07416147eff84ca", null ],
    [ "orientation", "a01003.xhtml#ae942d8ec37a033a565ff0eb5a8824403", null ],
    [ "projection_type", "a01003.xhtml#a1497b1ff3f6ffa36910987ebe060561b", null ],
    [ "texture_id", "a01003.xhtml#a38ab281918308bbea855a5fa50df2f82", null ]
];