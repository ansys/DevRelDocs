var a01095 =
[
    [ "disjoint_surfaces", "a01095.xhtml#a58dcc327afd3cf02fb29571e3f55ab7d", null ],
    [ "dynamic_shadows", "a01095.xhtml#a7bc32384ea0f724cfbce1b770df60639", null ],
    [ "no_shadow", "a01095.xhtml#ac19a47a29a15271d52e4db6235981719", null ],
    [ "orientation_offset", "a01095.xhtml#abc417da77c403dafd792d2a88a329dfc", null ],
    [ "position_offset", "a01095.xhtml#aec92f4374b3ff599e31bea07b2c47330", null ],
    [ "rendering", "a01095.xhtml#abfa42ceeaf611655c70b0804707405f0", null ],
    [ "static_shadows", "a01095.xhtml#a996c0d1c8ae4db5f6bc5dc2b0934909d", null ]
];