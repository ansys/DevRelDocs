var a00343 =
[
    [ "material_part_id", "a00343.xhtml#ae1d453aadeca39aed13dba7287d5be79", null ],
    [ "status", "a00343.xhtml#a33d837fd43abbcadafc3b0604b32ebf6", null ],
    [ "vertices_array_id", "a00343.xhtml#af2c94eca3f123085edcd101875da156c", null ]
];