var a00847 =
[
    [ "instance_id", "a00847.xhtml#a855c876506ea99e76a22a3c91e32ce70", null ],
    [ "node_id", "a00847.xhtml#a17dd49cbe63152b3dc3d97716432a3d5", null ],
    [ "status", "a00847.xhtml#a1ab41c9267ae4053c7f50349b9fe8bfe", null ]
];