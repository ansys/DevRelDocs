var a00779 =
[
    [ "node_id", "a00779.xhtml#a3bf0d3cb5196629fca8994f42e6f1686", null ],
    [ "properties", "a00779.xhtml#a5e81b8fe74c56cbc0256c18f4a8b025f", null ]
];