var a00571 =
[
    [ "blue", "a00571.xhtml#a86f8b0920251c607791ad47272ebd8a5", null ],
    [ "green", "a00571.xhtml#a7be727153bfd9c27e42828429bd0f0ca", null ],
    [ "red", "a00571.xhtml#a7364632cf3b9cccbb5c14ac9b975cae4", null ]
];