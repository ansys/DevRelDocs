var a00411 =
[
    [ "CreateMaterial", "a00411.xhtml#a8cf1d27cf8ff0c8c8514283625ccbf5c", null ],
    [ "DeleteMaterial", "a00411.xhtml#a8b33c37312752e73c1032eaf637b0ee7", null ],
    [ "GetMaterial", "a00411.xhtml#ad66e7fa79f9b4a032bdccf93edc03cd8", null ],
    [ "ListMaterials", "a00411.xhtml#a6160cb88901e2206a43b880bc72e3d0d", null ],
    [ "UpdateMaterial", "a00411.xhtml#afdad218dc39234f40f67e28793d5215b", null ]
];