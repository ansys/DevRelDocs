var a00963 =
[
    [ "id", "a00963.xhtml#a11e50133d543c8d3c6f04e4303c71c57", null ],
    [ "properties", "a00963.xhtml#aa59b7a8080270a3fc123c2db0c8d9df0", null ],
    [ "status", "a00963.xhtml#af52294dcf6727c9961c142d779606fb3", null ]
];