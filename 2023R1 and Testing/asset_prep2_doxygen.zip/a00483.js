var a00483 =
[
    [ "anisotropy_properties", "a00483.xhtml#a243435000f5c6ea556b02cf5bd88d910", null ],
    [ "diffuse_properties", "a00483.xhtml#a6736db341ece953f3436df60e70b0583", null ],
    [ "mask_properties", "a00483.xhtml#a953605de6cdafb1594b043dc09d084bc", null ],
    [ "normal_properties", "a00483.xhtml#a623711cc1a9f6d52f632e491d1321094", null ],
    [ "roughness_properties", "a00483.xhtml#a7e01175faf00373fff3f2aadec5d26fe", null ],
    [ "specular_properties", "a00483.xhtml#a70f0be646fbf3e74051d0a1e926f8bd8", null ]
];