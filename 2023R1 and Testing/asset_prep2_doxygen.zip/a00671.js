var a00671 =
[
    [ "identity", "a00671.xhtml#a5f1ecfb17cfc2de667dd53b632a3ed0d", null ],
    [ "status", "a00671.xhtml#acca3ca92386da2e4c5714016b978f240", null ]
];