var a00523 =
[
    [ "intensity", "a00523.xhtml#ab35587097e3a66fbcf853181071721da", null ],
    [ "map_id", "a00523.xhtml#aa7e1ad0c24afcfa9fc624c317c17a148", null ],
    [ "map_uv_channel", "a00523.xhtml#a4cfb0cf8c8d3553bbd30780cc7c033d5", null ]
];