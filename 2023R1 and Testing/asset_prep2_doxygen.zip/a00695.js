var a00695 =
[
    [ "identifier", "a00695.xhtml#ad55bd130a6d4d74c0a9254b73d79c506", null ],
    [ "type", "a00695.xhtml#afa82df0077dd11338ce702505bcadc8b", null ]
];