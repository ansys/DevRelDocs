var a01075 =
[
    [ "angular_precision", "a01075.xhtml#add8aef8cf90b84c3c0ada210129fc93d", null ],
    [ "black_body", "a01075.xhtml#a42abbeb32f4c83450fd16ad1e6c02ff4", null ],
    [ "diagram_library", "a01075.xhtml#adba3095f94f58acf458fbe46f92acf4f", null ],
    [ "gaussian", "a01075.xhtml#a2867131c92723f74dc8245288391e005", null ],
    [ "lambertian", "a01075.xhtml#a7adaa3724fed485be9c635a8727469c8", null ],
    [ "lighting_contribution", "a01075.xhtml#a1878b43a4f7c218d8f1d1492718b7873", null ],
    [ "luminance", "a01075.xhtml#a4400d33f69135626138b62b869906261", null ],
    [ "monochromatic", "a01075.xhtml#ab6264befe059add370f3d5a9c789cac6", null ],
    [ "no_contribution", "a01075.xhtml#ac070e6c02189f07ad52ebf7f1ffe18d4", null ],
    [ "reverse_direction", "a01075.xhtml#a4a4c9055c2238942884e44d3facfc4c8", null ],
    [ "spectrum_library", "a01075.xhtml#a6286a4a2c25c4a50bcfc7a80c1f199d4", null ],
    [ "texture_id", "a01075.xhtml#a920114f3d18c4bdfa8d990afe4fa3508", null ],
    [ "uv_channel", "a01075.xhtml#a61080203364ea8bdd65c3f0fa326fcc5", null ]
];