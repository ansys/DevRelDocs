var a00119 =
[
    [ "code", "a00119.xhtml#a210444a37711a8294254ca15d29779f0", null ],
    [ "feedback_message", "a00119.xhtml#a67c67dc568c9729f617453da00747d97", null ],
    [ "level", "a00119.xhtml#aec9e0259a851d382c54e46ef54413388", null ]
];