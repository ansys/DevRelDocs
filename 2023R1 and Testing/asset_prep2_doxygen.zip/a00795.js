var a00795 =
[
    [ "instance_id", "a00795.xhtml#ab314eccb2ff69cf7361d3549fb7906d3", null ],
    [ "node_id", "a00795.xhtml#a9e2fb3e45e25afdb6b8dafc25d1dba79", null ],
    [ "properties", "a00795.xhtml#abf8e10a91cd44494759c232f98908bff", null ]
];