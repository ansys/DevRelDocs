var a00395 =
[
    [ "ambient_occlusion", "a00395.xhtml#a625f825a7aef03fb175dad677e3b8a64", null ],
    [ "uv_coordinates", "a00395.xhtml#a5f727e37d458d0c5c6f01b2601f1e4fe", null ],
    [ "x_binormal", "a00395.xhtml#a049d594871dc0373b0f327749dad2c44", null ],
    [ "x_normal", "a00395.xhtml#a4ffd8ba89194e6ff99b51328e6c7f034", null ],
    [ "x_position", "a00395.xhtml#a296b642481b5d6c2ebe687cc356ae3c1", null ],
    [ "x_tangent", "a00395.xhtml#aa0d8f3cd5d62a59cc0fd01406e5b0fcd", null ],
    [ "y_binormal", "a00395.xhtml#a2c7c2f1e460b1f613285bb33d4b02a81", null ],
    [ "y_normal", "a00395.xhtml#a08a1053a29232427eca24a5c2bff9522", null ],
    [ "y_position", "a00395.xhtml#a2a1af5266627ba76c2c5759cfa8b5e2a", null ],
    [ "y_tangent", "a00395.xhtml#a27a44f86d6a8f11f424a3d95f7e61544", null ],
    [ "z_binormal", "a00395.xhtml#a8e670427f53737aa9da21471c84f8182", null ],
    [ "z_normal", "a00395.xhtml#a7f8ac70a736638f47a60535892c5d30b", null ],
    [ "z_position", "a00395.xhtml#a28062610e368475f658cca19317a834a", null ],
    [ "z_tangent", "a00395.xhtml#a67d05586b10c7981b2711ce7edf45d38", null ]
];