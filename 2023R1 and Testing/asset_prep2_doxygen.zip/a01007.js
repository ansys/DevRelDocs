var a01007 =
[
    [ "hours", "a01007.xhtml#a2c00db0203bfe7c3bdd3cde8fe70da54", null ],
    [ "minutes", "a01007.xhtml#aaae1fcab6ee622aaaa2c77940d7f0a2c", null ]
];