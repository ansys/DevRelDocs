var a00703 =
[
    [ "identifier", "a00703.xhtml#aab22beb66684d1a58b6e22fd4efdeb7e", null ],
    [ "name", "a00703.xhtml#a271ceede803acbe173c8e19ecfe85522", null ],
    [ "type", "a00703.xhtml#a34e98726d783005288f5f0cacefe03f7", null ]
];