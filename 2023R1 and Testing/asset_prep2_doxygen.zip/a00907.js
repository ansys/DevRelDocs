var a00907 =
[
    [ "added_tags", "a00907.xhtml#a85d94ff59d429e097bfb5147bee5d995", null ],
    [ "geometry_id", "a00907.xhtml#aef34baef30e14b2402cd6dadb58eb885", null ],
    [ "name", "a00907.xhtml#a01152e264b7bc61b5d19cbc51138f3dd", null ],
    [ "removed_tags", "a00907.xhtml#a0ff3d4edb8af3f6f2de75663c4230acd", null ],
    [ "thermal_properties", "a00907.xhtml#af683651dc97bb3ac3e73b6eeb3269f24", null ],
    [ "transform", "a00907.xhtml#a61041a24467d223fc693ed947a9b1058", null ],
    [ "visibility", "a00907.xhtml#a520f38120cf15b15ca7015d835cd1bfe", null ]
];