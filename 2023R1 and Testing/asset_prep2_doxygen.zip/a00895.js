var a00895 =
[
    [ "id", "a00895.xhtml#a0bb4441901ccbfb6643e668aa8a354de", null ],
    [ "name", "a00895.xhtml#a6c443f28ce7bd4008db80dc40be2e702", null ]
];