var a00935 =
[
    [ "euler_angles", "a00935.xhtml#ac1d24f40a8feddb593a5ced47c9e6d19", null ],
    [ "quaternion", "a00935.xhtml#a793e0aebed768fc7f57ba43377ba7325", null ],
    [ "relativity", "a00935.xhtml#a1753d8d409d934f5d8f19b7cbee2b860", null ],
    [ "x_position", "a00935.xhtml#a264bdf8d6b8719849463143b448fe340", null ],
    [ "x_scale", "a00935.xhtml#a5877d43d5bfe1d99f97d4511b00cd775", null ],
    [ "y_position", "a00935.xhtml#a9c08d0cee295c8b455814ce00e3f40ed", null ],
    [ "y_scale", "a00935.xhtml#abcb67a74c021c5275a5cbac3b2046d17", null ],
    [ "z_position", "a00935.xhtml#a6ea397af4b96c82f8b48bb25df251745", null ],
    [ "z_scale", "a00935.xhtml#ac4e1ea3486d655fb9d7ae0896cfc7ca1", null ]
];