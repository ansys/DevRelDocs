var a00491 =
[
    [ "intensity", "a00491.xhtml#a04b2036f9131262a5f5f3fa50cf891e8", null ],
    [ "map_id", "a00491.xhtml#a4020dee5fa2e495b2531c2771c27a877", null ],
    [ "map_uv_channel", "a00491.xhtml#a6db3f38bbea8891f5fb60f2f14cef829", null ]
];