var a00667 =
[
    [ "DeleteResource", "a00667.xhtml#addc4afe3744e0e761dec00ba418b4ee1", null ],
    [ "DownloadResourceAsChunks", "a00667.xhtml#a65130b5ef80f83251335c2eb0d35bb8d", null ],
    [ "DownloadResourceAsFile", "a00667.xhtml#aa0b3c9bb99caa6b3a15b844d5ee7d4d8", null ],
    [ "ListResources", "a00667.xhtml#a41f6066a3f330b78de9f1188170291d5", null ],
    [ "UploadResource", "a00667.xhtml#ad438badfd6ba221dadad236482d48087", null ]
];