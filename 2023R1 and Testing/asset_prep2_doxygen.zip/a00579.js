var a00579 =
[
    [ "CreatePointLight", "a00579.xhtml#a5c48b4b33b64bffa13713c4b931bbedd", null ],
    [ "DeletePointLight", "a00579.xhtml#a453e3cbd0448c8b4fdd20bf7fd10607e", null ],
    [ "GetPointLight", "a00579.xhtml#a2cf7ee235a6ee413441ad5ce8fc584d9", null ],
    [ "ListPointLights", "a00579.xhtml#a4c5d1c769aae58a6f1b53b4ce94248a2", null ],
    [ "UpdatePointLight", "a00579.xhtml#a6344fdb8d9fa9c7a430f5cc0038e51cd", null ]
];