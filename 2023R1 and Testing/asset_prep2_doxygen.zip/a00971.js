var a00971 =
[
    [ "id", "a00971.xhtml#a2083bfc969d41b51137b888419c57f80", null ],
    [ "properties", "a00971.xhtml#a6040e0ff93c9b62c681c10e91c0de8c2", null ]
];