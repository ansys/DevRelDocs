var a00419 =
[
    [ "id", "a00419.xhtml#a31f6306ab4f680d4dee76b2b5ef35d18", null ],
    [ "status", "a00419.xhtml#a97b8b85051755560c6d2e1e035bfd688", null ]
];