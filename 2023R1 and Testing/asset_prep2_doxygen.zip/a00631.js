var a00631 =
[
    [ "near_clip", "a00631.xhtml#ac2e061157b8ca0f8b835be5b4cbba45d", null ],
    [ "shadows_offset_ratio", "a00631.xhtml#a197347d07667c681442ec43235853669", null ],
    [ "softness", "a00631.xhtml#acfac02c22db183a0235bb41ce1efc836", null ]
];