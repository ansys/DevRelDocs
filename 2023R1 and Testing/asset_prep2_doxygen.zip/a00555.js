var a00555 =
[
    [ "index_of_refraction", "a00555.xhtml#a689a8e19e811c69e1221bf7c638d18a0", null ],
    [ "reflectivity", "a00555.xhtml#a0d9c0577c9478c7140413fffa7404c00", null ],
    [ "size", "a00555.xhtml#aa56e4e1dcebb762585b695e586881a86", null ]
];