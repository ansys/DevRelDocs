var a00931 =
[
    [ "added_tags", "a00931.xhtml#a6f59847a4f5395db6d764a0a4610102c", null ],
    [ "name", "a00931.xhtml#aa67bdaddd716de59fe0aef356257aed9", null ],
    [ "point_light_id", "a00931.xhtml#a4252ef7e2e60c566c0f1746b8e4dad67", null ],
    [ "removed_tags", "a00931.xhtml#a27ebf1ebd4570459f9767837d5c1929a", null ],
    [ "transform", "a00931.xhtml#a663715b036d0ec98ffb5199d1d419f42", null ],
    [ "visibility", "a00931.xhtml#a3d0aa51b719904787a4f4d000297384d", null ]
];