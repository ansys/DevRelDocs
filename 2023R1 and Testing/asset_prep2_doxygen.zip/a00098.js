var a00098 =
[
    [ "AmbientConditions", "a01019.xhtml", "a01019" ],
    [ "CreateSkyRequest", "a00951.xhtml", "a00951" ],
    [ "CreateSkyResponse", "a00955.xhtml", "a00955" ],
    [ "Date", "a01011.xhtml", "a01011" ],
    [ "DeleteSkyRequest", "a00979.xhtml", "a00979" ],
    [ "DeleteSkyResponse", "a00983.xhtml", "a00983" ],
    [ "DynamicAccurateShadows", "a00999.xhtml", "a00999" ],
    [ "GetSkyRequest", "a00959.xhtml", "a00959" ],
    [ "GetSkyResponse", "a00963.xhtml", "a00963" ],
    [ "Hdri", "a01003.xhtml", "a01003" ],
    [ "ListSkiesResponse", "a00967.xhtml", "a00967" ],
    [ "Location", "a01015.xhtml", "a01015" ],
    [ "Natural", "a00995.xhtml", "a00995" ],
    [ "SkyIdentity", "a00987.xhtml", "a00987" ],
    [ "SkyPreparation", "a00947.xhtml", "a00947" ],
    [ "SkyProperties", "a00991.xhtml", "a00991" ],
    [ "Time", "a01007.xhtml", "a01007" ],
    [ "UpdateSkyRequest", "a00971.xhtml", "a00971" ],
    [ "UpdateSkyResponse", "a00975.xhtml", "a00975" ]
];