var a00595 =
[
    [ "id", "a00595.xhtml#a79921c0490d6536a01ba0b197b09f81e", null ],
    [ "properties", "a00595.xhtml#a02d8f33ee41e02d86f4c3b3505a55364", null ],
    [ "status", "a00595.xhtml#a9e73572aa9e3ccd8806f702224d2ca3a", null ]
];