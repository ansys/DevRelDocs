var a00947 =
[
    [ "CreateSky", "a00947.xhtml#a733ee07290c0cdab885b95a75465f2e4", null ],
    [ "DeleteSky", "a00947.xhtml#a84f6c3ea210efb4a018a0f7ec0165fc7", null ],
    [ "GetSky", "a00947.xhtml#a90f22da8d6ec0aa78344d62d6a811057", null ],
    [ "ListSkies", "a00947.xhtml#a005b607e7157829ef60355700b9b3eec", null ],
    [ "UpdateSky", "a00947.xhtml#a54d1bda2337b05475cb8f1e7b1f1fbdb", null ]
];