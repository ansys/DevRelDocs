var a01103 =
[
    [ "near_clip", "a01103.xhtml#aff16450d1386e02d67eb96732ed55d7f", null ],
    [ "shadows_offset_ratio", "a01103.xhtml#aeed12007e03edd7382dee52cd3213d77", null ],
    [ "softness", "a01103.xhtml#a2d504c125a1a13cf7b368b43fd796a27", null ]
];