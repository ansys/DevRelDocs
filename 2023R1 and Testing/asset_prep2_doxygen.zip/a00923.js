var a00923 =
[
    [ "directional_light_id", "a00923.xhtml#a6707c592b202f9d93284967b97b678b7", null ],
    [ "name", "a00923.xhtml#af0667fe627710095704243c6f57dd9f0", null ],
    [ "transform", "a00923.xhtml#a3b9b96d81467904039001c4d7716bce6", null ],
    [ "visibility", "a00923.xhtml#a9b9ebb59aeb3207601d1ca1b22a8baac", null ]
];