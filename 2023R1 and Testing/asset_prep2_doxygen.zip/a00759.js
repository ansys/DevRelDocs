var a00759 =
[
    [ "directional_light_instances", "a00759.xhtml#a0f3d448aa92df194bc3afd9e87798fc3", null ],
    [ "geometry_instances", "a00759.xhtml#ab70151cf1b4167dd9db135a7f5e0f96f", null ],
    [ "id", "a00759.xhtml#adc447673cef9648d3128e2589e367d6f", null ],
    [ "nodes", "a00759.xhtml#a1f118d59562f76f13aecea13ca2317d1", null ],
    [ "point_light_instances", "a00759.xhtml#abc6388b80a08c547a4b70ca47e6ce466", null ],
    [ "properties", "a00759.xhtml#af85f9315ebc88ff0a4e0480326d7b511", null ],
    [ "status", "a00759.xhtml#a2fbda7b8517d224402a0d357e9bc8717", null ]
];