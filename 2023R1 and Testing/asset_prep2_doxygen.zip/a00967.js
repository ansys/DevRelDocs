var a00967 =
[
    [ "skies", "a00967.xhtml#a92c5c5b41f0ed925d8d84df54375b8ab", null ],
    [ "status", "a00967.xhtml#a63c2f16377f442834e6cc80a90a36b87", null ]
];