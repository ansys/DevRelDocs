var a00455 =
[
    [ "dielectric_properties", "a00455.xhtml#abbaa529cab84d2afabe665f794b9a8a6", null ],
    [ "name", "a00455.xhtml#ab2aacb2c4350d2ab5faf366b9cb6e633", null ],
    [ "reflection_effect", "a00455.xhtml#a65a94f0c46b330891046bdf11e2a2802", null ],
    [ "surface_optical_properties", "a00455.xhtml#a34da35f360db821ce2d72e51abaf068f", null ],
    [ "thermal_properties", "a00455.xhtml#a29dc06c611390e0ac9768fdea8519bf9", null ],
    [ "volume_optical_properties", "a00455.xhtml#a28eee6f93468e344514cca0eb849d87f", null ]
];