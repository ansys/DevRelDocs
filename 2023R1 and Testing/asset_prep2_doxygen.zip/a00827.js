var a00827 =
[
    [ "instance_id", "a00827.xhtml#a71e15010bea3ddc6386b2302ec1e8c4b", null ],
    [ "node_id", "a00827.xhtml#a76f94e922fbab32ddfbda360cc10e964", null ],
    [ "properties", "a00827.xhtml#a58d1fbcf69014a9a83b1891dc200a530", null ]
];