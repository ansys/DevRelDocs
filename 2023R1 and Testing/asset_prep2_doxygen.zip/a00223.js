var a00223 =
[
    [ "id", "a00223.xhtml#a6825c7196408373e10be1c23fa0910ef", null ],
    [ "properties", "a00223.xhtml#a57c08c1cbc19e70037b47cff25cd35c3", null ],
    [ "status", "a00223.xhtml#af26732b263d88c4a423951ad7c24e3b8", null ]
];