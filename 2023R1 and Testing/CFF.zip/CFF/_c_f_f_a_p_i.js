var _c_f_f_a_p_i =
[
    [ "Introduction", "_c_f_f_a_p_i.xhtml#CFFAPIIntro", null ],
    [ "Background to Using the Common Fluids API", "_c_f_f_a_p_i.xhtml#APIBackground", null ],
    [ "Using the Common Fluids Format API", "_c_f_f_a_p_i.xhtml#Usage", null ],
    [ "Opening Files for Read", "_c_f_f_a_p_i.xhtml#OpenCffProvider", [
      [ "Opening Case (cas) and Results (dat) Files for Read", "_c_f_f_a_p_i.xhtml#OpenCaseAndDataForRead", null ]
    ] ],
    [ "APIIndex", "_c_f_f_a_p_i.xhtml#APIIndex", null ],
    [ "Ansys Common Fluids API Requirements", "_requirements.xhtml", [
      [ "Prerequisites for Using the Ansys Common Fluids API", "_requirements.xhtml#RequirementsIntro", null ]
    ] ],
    [ "Ansys Common Fluids API Build and Usage", "_build_and_usage.xhtml", [
      [ "CFF SDK Content", "_build_and_usage.xhtml#SDKContent", null ],
      [ "Compiling and Linking on Windows", "_build_and_usage.xhtml#BuildWindows", null ],
      [ "Compiling and Linking on Linux", "_build_and_usage.xhtml#BuildLinux", null ]
    ] ],
    [ "Ansys Common Fluids Factory API", "_factory_a_p_i.xhtml", [
      [ "Introduction", "_factory_a_p_i.xhtml#FactoryAPIIntro", null ],
      [ "Obtaining an Object to Read a CFF File", "_factory_a_p_i.xhtml#FactoryAPIRead", [
        [ "How to determine which cas file goes with which dat file?", "_factory_a_p_i.xhtml#FactoryCasFromDat", null ]
      ] ],
      [ "Obtaining an Object to Write a CFF File", "_factory_a_p_i.xhtml#FactoryAPIWrite", null ]
    ] ],
    [ "Ansys Common Fluids CffConsumer API (for writing data)", "_consumer_a_p_i.xhtml", [
      [ "Using the Ansys Common Fluids API to Write Data", "_consumer_a_p_i.xhtml#ConsumerAPIIntro", null ]
    ] ],
    [ "Ansys Common Fluids CffProvider API (for reading data)", "_provider_a_p_i.xhtml", [
      [ "Using the Ansys Common Fluids API to Read Data", "_provider_a_p_i.xhtml#ProviderAPIIntro", null ]
    ] ],
    [ "Project API", "_project_a_p_i.xhtml", [
      [ "The Project Concept", "_project_a_p_i.xhtml#ProjectIntro", null ],
      [ "Project Buiding Blocks", "_project_a_p_i.xhtml#PItems", null ],
      [ "Simulations", "_project_a_p_i.xhtml#Simulations", null ],
      [ "Iterators", "_project_a_p_i.xhtml#Iterator", null ]
    ] ]
];