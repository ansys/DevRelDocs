var classansys_1_1_project_1_1_query =
[
    [ "Query", "classansys_1_1_project_1_1_query.xhtml#accc4b3a49109a0d992c9bea5f67de8b2", null ],
    [ "Query", "classansys_1_1_project_1_1_query.xhtml#aa11759b898e8ce9ad56ea93b5e7f3fe9", null ],
    [ "evaluate", "classansys_1_1_project_1_1_query.xhtml#a2954de4bce6cb1e254c5fc05071d05aa", null ],
    [ "evaluate", "classansys_1_1_project_1_1_query.xhtml#adb860209358e8dffe5703593f991637f", null ],
    [ "operator+=", "classansys_1_1_project_1_1_query.xhtml#a94479fcb90a6a98679740625ceeef0a9", null ]
];