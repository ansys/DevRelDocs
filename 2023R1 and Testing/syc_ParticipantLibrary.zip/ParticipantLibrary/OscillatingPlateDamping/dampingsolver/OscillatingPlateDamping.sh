#!/bin/sh

# Set version-specific environment variables
export ANSYS_INSTALL_DIR="$AWP_ROOT222"
export FLUENT_MULTIPORT_VERSION=22.2.0

# Setup run-time environment
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH":"${ANSYS_INSTALL_DIR}"/SystemCoupling/runTime/linx64/bin/compiler
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH":"${ANSYS_INSTALL_DIR}"/SystemCoupling/runTime/linx64/bin
export LD_LIBRARY_PATH="$LD_LIBRARY_PATH":"${ANSYS_INSTALL_DIR}"/SystemCoupling/runTime/linx64/cnlauncher/fluent/fluent${FLUENT_MULTIPORT_VERSION}/multiport/mpi_wrapper/lnamd64/stub

# Run the application
./OscillatingPlateDamping "$@"
exit $?
