var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a5543cef1cf69e03f753aaf99ed0c0eda", null ],
    [ "HuygensDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a54a89fc317a3c8f815fd21adff0be890", null ],
    [ "HuygensSample", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a2a24cd3e303065e1db5c707224dba2e2", null ],
    [ "RadiusMaximum", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a42da2bba735699456f6de8f9d28016cf", null ],
    [ "ReferTo", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a05759e274a39881b99625869c8e410cd", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a758caac8a188bf89765b51a83ab24c91", null ],
    [ "ScatterRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a6dbb32286a677c490c6fb6ec9a0658ef", null ],
    [ "ShowDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a6f242b7d87647c8cf6e2bb49d5794a38", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a71c98a16f53fd58910cb45768496aa5a", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a65140bdd6d53341a49bd6b09ee07a30a", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a31895e37e476d6574404ad5d121632ab", null ],
    [ "UseHuygensPSF", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#afb617aa5217744a86fba5865d77f2914", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#acdebb29d2812d042df2e9ceaa5cdddca", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___geometric_encircled_energy.xhtml#a6debc386e20a36825e58cfb5a2fa43f0", null ]
];