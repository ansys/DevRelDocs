var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross =
[
    [ "Angle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross.xhtml#acbbc8621a853e8037f4e5446dd9c7fa7", null ],
    [ "BestFitSphereOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross.xhtml#a43a0ceeb66c4e29471b6891c2a5ae62d", null ],
    [ "ConsiderOffAxisAperture", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross.xhtml#a7de35108b3091abd27d92a1ad027e791", null ],
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross.xhtml#a3903fde9303ede0ab83afe384b0c4e84", null ],
    [ "RemoveOption", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross.xhtml#ac7ac61f02c5294345672f2b6cbcf006a", null ],
    [ "ReverseDirection", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross.xhtml#adf87c2293a6197cca61e7f7dbb107203", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross.xhtml#a4aea5355136b792822d6be6a91cd94b3", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_surface_1_1_i_a_s___surface_slope_cross.xhtml#a9d0b5ef23b968e3282b47aab078a6ade", null ]
];