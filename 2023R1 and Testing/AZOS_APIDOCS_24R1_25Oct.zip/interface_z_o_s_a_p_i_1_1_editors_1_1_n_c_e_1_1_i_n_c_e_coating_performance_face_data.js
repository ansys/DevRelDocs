var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data =
[
    [ "GetCoatingPerformance", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#ab3acdf653e7651ac4504e474e8641c20", null ],
    [ "Absorption", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#ab285b040d9e782e4063a87e30def88a1", null ],
    [ "Diattenuation", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#a5278bec61b2796b9ac4f7389d4fbb3c4", null ],
    [ "FaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#a877fdfdb3d5abc1f7e48a6220f60eef0", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#a9e0b5d33e784fc79560b1581b05a311e", null ],
    [ "Phase", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#af0dc917fa8f82f2e055f511b74468cb9", null ],
    [ "Reflection", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#afb53a5039c0862ef197737d1111a5c3b", null ],
    [ "Retardation", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#a63b34f933ebeb4d4473a7a370f54efd8", null ],
    [ "Transmission", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_coating_performance_face_data.xhtml#a4d5b303f09978fefa13e09fef943284a", null ]
];