var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d =
[
    [ "AmbientObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#abc8ba966ebe568f95a62a3a5e4527309", null ],
    [ "DetectorObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a6ffc0af9918f92c266dbf9a25849bb89", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#afc42979bbded58ed10501bd3e501ec4b", null ],
    [ "HologramObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a36c97167b6d9f3ac9d7bafd539008041", null ],
    [ "InsideOfObject", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a57b487e67bebbed660ea5dd3b0e17bab", null ],
    [ "MaxAngle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a6d198fc7740cbad47d0e3834146cac80", null ],
    [ "MaxWavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a33ef18462df96aceb94bd4955b9765c4", null ],
    [ "MinAngle", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#af770fe4c5649451002ab1c46d79701b8", null ],
    [ "MinWavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a5d8db433e8b7a30f4f3d9dbb9dfc04c8", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a136fa3430bcfb2280d74f23710eb2f48", null ],
    [ "srcPolJx", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a1322151f693b52e96564b51ed8ad0133", null ],
    [ "srcPolJy", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#ae9e61db5edc55748cf9d19323dfb12ef", null ],
    [ "srcPositionX", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#ad6123cd52765ab9eeb06bddc970d37c4", null ],
    [ "srcPositionY", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a550b3a208776fc91f6d00ebb483e51ce", null ],
    [ "srcPositionZ", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#ad2a51743510b70ba8005a1aa4e3eff47", null ],
    [ "srcPrePropagation", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a9cc5c95931e0ac8a7d4f4d866ad9530d", null ],
    [ "srcUnpolarized", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#a11077f6e1558dd62843562260e4fe1e2", null ],
    [ "srcXTitled", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#ac8c5d1a9c277d2d92376c6854d79193d", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#ac43279194c9be35803032c76ccddbaf7", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_diffraction_efficiency_1_1_i_a_s___diff_efficiency2_d.xhtml#ae3f39d0acc3c0a576e627b6a09a45999", null ]
];