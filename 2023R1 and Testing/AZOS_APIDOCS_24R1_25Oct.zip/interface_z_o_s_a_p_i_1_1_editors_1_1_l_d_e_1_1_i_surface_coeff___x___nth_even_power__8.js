var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power__8 =
[
    [ "Coeff_X_NthEvenPowerCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power__8.xhtml#a0c97947e5eb0af526a4e58bb703f00c0", null ],
    [ "GetCoeff_X_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power__8.xhtml#a3b4f1f270f71d85e7a4c8f1bf2f9c67e", null ],
    [ "SetCoeff_X_NthEvenPower", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_coeff___x___nth_even_power__8.xhtml#a9490b87267121a0fa836969d8e018c42", null ]
];