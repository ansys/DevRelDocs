var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_catalog =
[
    [ "GetAvailableFiles", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_catalog.xhtml#a7fdc741397e31de9237ecf2f1f75f476", null ],
    [ "GetFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_catalog.xhtml#a17e56ca453d408f28b6df9cd8cfc40c8", null ],
    [ "GetSampleSides", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_catalog.xhtml#a51945c5b1878e969d6cdd027bdbac2fc", null ],
    [ "SetFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_catalog.xhtml#aa51a8688357f35fd0cec4b4fac1d716a", null ],
    [ "Angle", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_catalog.xhtml#a0eab283d49fbe24446de6dc37b164455", null ],
    [ "SampleSide", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_catalog.xhtml#a9cd32801ec47dbb2ba68a5a358deb043", null ],
    [ "Sampling", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_catalog.xhtml#a783dba1032b6fd8c3fac89c1d46489b0", null ]
];