var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map =
[
    [ "Frequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#ae92d679d24cc577847e5cc7230be71c0", null ],
    [ "MTF_DataType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#a1fd91d807ae35e43fc5330a7f028bee1", null ],
    [ "ReferenceField", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#a9523217159bd1ce173dd691483feaaeb", null ],
    [ "RemoveVignetting", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#a53cf26f157188fc7f0049ca9436a9dc2", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#a4ecf2454ad49e4beebfb138663090ee1", null ],
    [ "ScatterRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#ac2940ae4796d5613804ac63981dd5b40", null ],
    [ "ShowAs", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#af5497f6bdf7e80c4ea76e0d5bf376d5c", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#a8bea49e1457fd870652a365fc1d950fd", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#afdbcefd5bc41bbd4d76d12f9685f7aad", null ],
    [ "X_Field_Width", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#a5488a1b168e814cf0cab81fe817995bd", null ],
    [ "X_Pixels", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#ab7aa68d82aa48f65362d9e76c00074a4", null ],
    [ "Y_Field_Width", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#ada99b5cd95c434f7ea248d4321075b46", null ],
    [ "Y_Pixels", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtf_map.xhtml#adee05a75920daddc842796441b1a1a30", null ]
];