var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures =
[
    [ "GetThermalFEAFitType", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a9aa8dfd563ecc028e0bd1248e695fd6c", null ],
    [ "GetWorkingWavelength", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a2b560f1867d7a5fe4c8dc479a3a7067e", null ],
    [ "IsDataLocalCS", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a185a22293921c18c19b87b67289490bb", null ],
    [ "SetDataIsGlobal", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a235bf2944671b2a8dd77967c1a9e09a0", null ],
    [ "SetDataIsLocal", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#af2fc20c68c4d1b4222d1d70e8f7deeb7", null ],
    [ "SetThermalFEAFitType", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a1fc7e0bc50af8eddd3d55d8a8017eab7", null ],
    [ "SetWorkingWavelength", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a324df8ac14b8170d4023fe6343273c58", null ],
    [ "CoordinateTransform", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a0099868e88f31653b114f11e4866b4f0", null ],
    [ "FEAData", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a56a6b405c4f864eba83ad0dccd211be1", null ],
    [ "Fits", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a8e9345a9eb4465b797a0083df3bf7f7f", null ],
    [ "GRINStep", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#ab40d0d2b5af7fb62de4b0a8b5cfba69a", null ],
    [ "PrimaryWavelengthValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#aa49f4f6f3bed95af1cbe9a2fd5117194", null ],
    [ "SurfaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures.xhtml#a25d6225ebbd424df780d7a9ba5294598", null ]
];