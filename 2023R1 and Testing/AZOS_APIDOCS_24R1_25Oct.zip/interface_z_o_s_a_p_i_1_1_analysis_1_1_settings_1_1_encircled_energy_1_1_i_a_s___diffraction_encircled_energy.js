var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy =
[
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a466393645e8ade3bf51d14225de63593", null ],
    [ "HuygensDelta", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a6168ab299d01c44221b7e3b7bc1f278e", null ],
    [ "HuygensSample", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#aa29150fc1a1e40ededde59197b92ed71", null ],
    [ "RadiusMaximum", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#aecc1f7ea700751ac9700edc1b417e024", null ],
    [ "ReferTo", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a64dbf1ec82faeaac7ad48daf80a20a8a", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#aff3477220de63f5007ac9fd0ef00a875", null ],
    [ "ScatterRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a507c393a3b9c70734ed2212614b54ccd", null ],
    [ "ShowDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a53a933bde2aa09c1cf7280e6917b623f", null ],
    [ "Surface", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a096863e6c3b95cf2fbc62c0da39beb79", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a7c311ec03fdf28fc30c205812ff53395", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a23db5525a21c209bacd41af093ac61cc", null ],
    [ "UseHuygensPSF", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a1974f0482754feaf8584ff02a50c9b0e", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#a783fd1d335dfb2f6c57b60a9c5d3ade9", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_encircled_energy_1_1_i_a_s___diffraction_encircled_energy.xhtml#af01cfd2a7871a74b51d92d35c78e759e", null ]
];