var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_import_data =
[
    [ "CopyImportDataFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_import_data.xhtml#a4bc9ac352ef0dba2cfc5067fcd202a75", null ],
    [ "GetImportFiles", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_import_data.xhtml#afdbb725a9ae3f4fc63ce83da310eabc2", null ],
    [ "ImportDataFile", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_import_data.xhtml#a63bee9c482754ea8fc4609d14a83c608", null ],
    [ "DefaultImportDirectory", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_l_d_e_import_data.xhtml#ae48f90ab8763d71f4d74d95eef91eac3", null ]
];