var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___lambertian =
[
    [ "ScatterFraction", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_o_s_s___lambertian.xhtml#af4254b9def3281f9c7262990a788608e", null ]
];