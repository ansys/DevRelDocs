var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z =
[
    [ "GetY", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#a126b1369e17fd8fd3ea557ada8497cc5", null ],
    [ "GetYCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#ac401828998e45682165489c3dc94e0ab", null ],
    [ "GetZ", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#a5ca26f3c28fa88037a12d8552f5c93fb", null ],
    [ "GetZCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#aefe2725beb3d2cbde651988605a727f7", null ],
    [ "SetY", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#af4587d969347c5718de2e97eb465a9dd", null ],
    [ "SetZ", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#a4fe9cbce19a1e6dba6fd1abd930b84b5", null ],
    [ "IsVolume", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#a107d7e5047120d830afdaf12d854d77a", null ],
    [ "IsVolumeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#a54e97487a82a487320e8ac119801dd62", null ],
    [ "NumberOfPoints", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#adb500c05dbc2bf17f014877282539f7d", null ],
    [ "NumberOfPointsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_freeform_z.xhtml#acd6192a8a0596b7c1e440c3371401ee1", null ]
];