var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data =
[
    [ "AutomaticallyCalculatePupilShiftsIsChecked", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#af02e24a1521a134140b7551aef7b9999", null ],
    [ "Method", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#a909e599ed767d9119d20f572c64161ea", null ],
    [ "NumStepsCacheSetup", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#a29aab454567901fde1d50b15a03a2a39", null ],
    [ "PupilCompressX", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#ab862f73475b83337feaeff0a47e3ce49", null ],
    [ "PupilCompressY", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#a3304d300642bc9d1676835c1466f9460", null ],
    [ "PupilShiftX", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#afa7608bbb4f4855d5f89eff07d6395d9", null ],
    [ "PupilShiftY", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#a8bf57bd3780aada3124ff96588318680", null ],
    [ "PupilShiftZ", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#aa7b44c97d7d41b8f19935a14290dedb0", null ],
    [ "RayAiming", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#afd1700b130f667067f6289104eb4970e", null ],
    [ "ScalePupilShiftFactorsByField", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#ac71dbbcdfc8cd8d6e1e3b18e00fca6d1", null ],
    [ "UseAdvancedConvergence", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#a9452f6fde0ef7e75eb0a70902ebeeab2", null ],
    [ "UseEnhancedRayAiming", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#a7ab68187e0b31a6ea53a2dae0e27eaaa", null ],
    [ "UseFallBackSearchDuringCacheSetup", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#abb56016d2436fd5e132c2d6d66c992f3", null ],
    [ "UseRayAimingCache", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#ad609b88c03dfd4b26771636c3c58e36d", null ],
    [ "UseRobustRayAiming", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_ray_aiming_data.xhtml#a2f6e9c3adea89ae1ab13330fb81f5f95", null ]
];