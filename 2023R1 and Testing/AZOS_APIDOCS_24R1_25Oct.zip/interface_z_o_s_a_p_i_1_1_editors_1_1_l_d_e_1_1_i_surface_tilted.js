var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_tilted =
[
    [ "X_Tangent", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_tilted.xhtml#a2ee03bb64bc2b1a1ee54473d31481332", null ],
    [ "X_TangentCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_tilted.xhtml#a5faf2bf5a5482588d219ec153513de9a", null ],
    [ "Y_Tangent", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_tilted.xhtml#ad6098c991976fad93ca833b51e1dc669", null ],
    [ "Y_TangentCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_tilted.xhtml#a95a98249a5ce9bbf4d2318452c69f107", null ]
];