var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus =
[
    [ "Data", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#a4c1cd4aa01d76d2aea10571cc6004abc", null ],
    [ "FocusDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#aefa727db3df10346fbb344e09f0e84e9", null ],
    [ "MaximumFocus", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#abcdcbea7a8a25be6a61e76cefe5310c5", null ],
    [ "Method", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#a1932dde584af27ba23e752eca37cc213", null ],
    [ "MinimumFocus", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#a0759958601db14944e7c68da20a531c5", null ],
    [ "PlotScale", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#a7a1f7f5ce206f6990f5c2ed36c644db0", null ],
    [ "RayDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#a9ad1738a09127c72ef169f8380da60fd", null ],
    [ "ReferTo", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#aa2a46a4e775e8b7b3dd859ea3768ab7d", null ],
    [ "ShowDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#a3809b4a8bc7eb797134e47c2672adb7d", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#a7a0ebb51d96071d177e47a52fcf7f1e0", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#aca4636ebb11b75aeac747cb2e1ba1011", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_r_m_s_1_1_i_a_s___r_m_s_focus.xhtml#a0c270285e0fb0bda821218c98d303643", null ]
];