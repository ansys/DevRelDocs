var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_ellipse =
[
    [ "XHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_ellipse.xhtml#a13dabfaab5180684d8de74e4e74a6259", null ],
    [ "XHalfWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_ellipse.xhtml#a0d745e4186e34d47072168b9094b9f46", null ],
    [ "YHalfWidth", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_ellipse.xhtml#a28f5d1dd32b1f70d2169b7780a117ebe", null ],
    [ "YHalfWidthCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_ellipse.xhtml#aaf7886bbdbfcd78916f919f67b5960e4", null ]
];