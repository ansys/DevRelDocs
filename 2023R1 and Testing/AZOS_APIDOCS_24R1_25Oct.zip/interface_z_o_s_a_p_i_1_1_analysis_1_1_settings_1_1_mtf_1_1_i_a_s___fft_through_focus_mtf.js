var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf =
[
    [ "DeltaFocus", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#aa27602e631ea6be1d5157bf8a10f5839", null ],
    [ "Field", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#aae418944be8bf304f663585c63c0d7c4", null ],
    [ "Frequency", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#aa5ef4ee0f63b86571cdb39708c6d36bb", null ],
    [ "NumberOfSteps", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#acedcbf2612deb234f7cfbd302a4e1976", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#ade329a4d4658573be26a325995ea0dc1", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#a59468d003350e6b6b6057b759326bc7d", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#ab56cc240764e116fe3003243f1c3bfdd", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#a900fe7989371ddf638eb61eac7e6699f", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___fft_through_focus_mtf.xhtml#a5887af0920900e8475842db1fff941cd", null ]
];