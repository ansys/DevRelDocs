var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_volume_physics_data =
[
    [ "IsVolumePhysicsAvailable", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_volume_physics_data.xhtml#abd2078f16e29cdfbfb664c06587f855a", null ],
    [ "Model", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_volume_physics_data.xhtml#a2809e426524d29845e0767b0a8ba8c40", null ],
    [ "ModelSettings", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_volume_physics_data.xhtml#ab88387c98188498097b0cebd62072cc1", null ],
    [ "WavelengthShift", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_n_c_e_volume_physics_data.xhtml#ada6fb11fd22a41077940a58871889852", null ]
];