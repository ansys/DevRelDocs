var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid =
[
    [ "GetZoneIFacets", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#a905c0710f3eca950177de75cb14c35c7", null ],
    [ "SetZoneIFacets", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#a1326364f0f492408f6abecfd2ba83b27", null ],
    [ "ZoneIFacetsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#a91a9581622d12a26e54a1d77b0feab60", null ],
    [ "Radius", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#ab17efa4b724699f5c1ce3200cf153eab", null ],
    [ "RadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#a5b328c5420a9166ff240ade66943cfe7", null ],
    [ "Scale", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#ab4407ae9a3da66feb874323b868f3964", null ],
    [ "ScaleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#a3e4e9c1ab2c56c247f1d5fbe360fca6f", null ],
    [ "StartAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#ab06ecb900ed97b839f913d3d92ff87df", null ],
    [ "StartAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#aa6879af77a4a41f07262ce955a03d258", null ],
    [ "StopAngle", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#afc5e8dc22df219707d3ba23a807a2d02", null ],
    [ "StopAngleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_facted_toroid.xhtml#a5c995cfc46ae7bcbe35aec7a5bd7a778", null ]
];