var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object =
[
    [ "Id", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object.xhtml#ae417b5ad2c31f1142a793c586968a41f", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object.xhtml#a26e6adbbd23135e3a72ee11e7b123a96", null ],
    [ "Row", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object.xhtml#afa5e824950dbeeadae6a34a4bd179605", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object.xhtml#a99f40e283bd5643d60beeb6a1bd586ba", null ]
];