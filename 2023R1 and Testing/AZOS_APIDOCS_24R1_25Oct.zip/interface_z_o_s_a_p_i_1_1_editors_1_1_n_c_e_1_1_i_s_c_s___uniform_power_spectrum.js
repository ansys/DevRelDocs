var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___uniform_power_spectrum =
[
    [ "Fit", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___uniform_power_spectrum.xhtml#aeb767993c698d36c2efc74b3aad293a4", null ],
    [ "SpectrumCount", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___uniform_power_spectrum.xhtml#a4274ff710f27f8a32ac30effcd11c9db", null ],
    [ "WavelengthFrom", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___uniform_power_spectrum.xhtml#a4508cadf6b614cd480022f1d696d546f", null ],
    [ "WavelengthTo", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_s_c_s___uniform_power_spectrum.xhtml#af71d6aa3533c1c9e31e0732244aa687f", null ]
];