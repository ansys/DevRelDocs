var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_user =
[
    [ "GetAvailableDLLNames", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_user.xhtml#a517df915736e52ce26bd70dc045ffb75", null ],
    [ "GetParameterName", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_user.xhtml#ad10a5ac3b49b4bcae563d9655c8774ca", null ],
    [ "GetParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_user.xhtml#ab6cee778ab4e32ad7600643c6b8fffee", null ],
    [ "SetParameterValue", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_user.xhtml#aec1c505471525575c1b3c2dba9165430", null ],
    [ "DLLName", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_user.xhtml#a9222dbb7e7b72a756dbdde2404c1f571", null ],
    [ "NumberOfParameters", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_user.xhtml#aa5dee24030b98cd6e64757bc27b145ee", null ]
];