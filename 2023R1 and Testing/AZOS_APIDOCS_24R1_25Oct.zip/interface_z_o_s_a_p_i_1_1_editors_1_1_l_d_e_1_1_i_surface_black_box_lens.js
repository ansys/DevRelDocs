var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_black_box_lens =
[
    [ "GetBlackBoxLensFilenameAt", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_black_box_lens.xhtml#ae2f45a858772b3fbd0eb3f87d19d82b3", null ],
    [ "BlackBoxLensFilename", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_black_box_lens.xhtml#a181baff72421cc4253718e72227884b3", null ],
    [ "NumberOfAvailableBlackBoxLensFilenames", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_black_box_lens.xhtml#a403cb3ecdc3124c61547534da55ed69d", null ]
];