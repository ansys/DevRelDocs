var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface =
[
    [ "GetRPowerI", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#ac395d94d0d035a147abb12fa638bdc37", null ],
    [ "RPowerICell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#af5b3e187ea0d6787437526002346c215", null ],
    [ "SetRPowerI", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#a17285bf1001b748e0e2e457698e14bc3", null ],
    [ "Conic", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#a547f755f2392548e6b46aa942b126810", null ],
    [ "ConicCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#aedc303b5dcce34b78ad5caaab7771aed", null ],
    [ "MaxAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#ae11a36a9bd02a98ce1d65de9d1b510af", null ],
    [ "MaxApertureCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#a44dc97d927b225fb85172036a704aa2e", null ],
    [ "MinAperture", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#af6299e885ab42bcdb16a4516e7acdc74", null ],
    [ "MinApertureCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#a3fcb7b713fece3504c900e4b0cf8febc", null ],
    [ "NumberOfTerms", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#a4b790510f1ee6c1e1e5f142ca7dd86f7", null ],
    [ "NumberOfTermsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#a3a39c1f0f548264174e32ee730118d46", null ],
    [ "Radius", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#af2dd6f54d21dd000669a1731b4ea06d0", null ],
    [ "RadiusCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_aspheric_surface.xhtml#a76931ded7390caf94f24bbb67c7e18b8", null ]
];