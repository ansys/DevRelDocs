var interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_frensel_radial =
[
    [ "IsVolume", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_frensel_radial.xhtml#a9299b88f36165fed08c73fa38653db86", null ],
    [ "IsVolumeCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_frensel_radial.xhtml#a26ac58ee2262b55e70d1b2b4b5bd4b6e", null ],
    [ "Scale", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_frensel_radial.xhtml#aaf1ab6d9fc1e772cd2a0e2152e63e58c", null ],
    [ "ScaleCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_n_c_e_1_1_i_object_tabulated_frensel_radial.xhtml#a644a99008f0656504dac28b92b49c412", null ]
];