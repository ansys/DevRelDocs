var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_gaussian =
[
    [ "ScatterFraction", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_gaussian.xhtml#a864d7a51e094988d4e19019bba2a638c", null ],
    [ "Sigma", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_scattering_gaussian.xhtml#a93dee135a0407607c93b150e5bb8f2dd", null ]
];