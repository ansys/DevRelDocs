var interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection =
[
    [ "ConnectAsExtension", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a1eaa04709326b1c5555804d032457eb9", null ],
    [ "ConnectToApplication", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a1fb4aeea3a2d1e610defd84ca777dcaa", null ],
    [ "CreateNewApplication", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#ab42ea0de15a6b7381834fd672e2bb33f", null ],
    [ "CreateZemaxServer", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a917c158004b79ecbd4b24a087f0fd0d2", null ],
    [ "CreateZemaxServerEx", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#ab494c6c51238d678c24ba8781d91c1e7", null ],
    [ "GetConfigSetting", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#ababe55569988d0242ff316f1fe9a30e9", null ],
    [ "RunCommand", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#ad6f282504d9ca5055a9d67a2f74f0cd0", null ],
    [ "SetConfigSetting", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a0be3dec0fbdec3177b651fa8aa8137bb", null ],
    [ "SetCreoInstallPath", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a47751cabe4c462f6e8a174204c89e085", null ],
    [ "ConnectionTimeoutSeconds", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a19fc1112ee2fcccb8d2184355540ed42", null ],
    [ "FormattingCulture", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a4ca7c7878ecdbb14590c3023f02a52bb", null ],
    [ "InitializationSettings", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a210cb0ba7563dd6a894732f612e8d7ac", null ],
    [ "IntializationProgress", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#aedc370317cd0a29648bc66b5360f230b", null ],
    [ "IsAlive", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#ad933c3f3f404c152346715e6ea2c8228", null ],
    [ "PreferencesFile", "interface_z_o_s_a_p_i_1_1_i_z_o_s_a_p_i___connection.xhtml#a2a1ed3c4f41d193e11035be2e5da1ca4", null ]
];