var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface =
[
    [ "Id", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface.xhtml#a3bebde6bca998efc4929dd5944f56a05", null ],
    [ "IsValid", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface.xhtml#accb58c34eb8388c0a77b9eb425329977", null ],
    [ "Row", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface.xhtml#a0478da8afc6b3d5b1ee2e3efc8c8092d", null ],
    [ "Type", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface.xhtml#aeb55c88397724346dbfef66d1fb3d497", null ]
];