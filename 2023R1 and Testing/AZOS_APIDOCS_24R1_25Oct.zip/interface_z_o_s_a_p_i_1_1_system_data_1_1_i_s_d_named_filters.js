var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_named_filters =
[
    [ "NamedFilters", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_named_filters.xhtml#a15a6ed03b68be25435e93516abdaa89c", null ]
];