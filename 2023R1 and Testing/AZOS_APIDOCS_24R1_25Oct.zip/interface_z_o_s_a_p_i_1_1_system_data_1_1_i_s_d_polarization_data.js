var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_polarization_data =
[
    [ "ConvertThinFilmPhaseToRayEquivalent", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_polarization_data.xhtml#a7210c553a503619c55367f7b374dd803", null ],
    [ "Jx", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_polarization_data.xhtml#a97306eedb85ef47cf0e12feacb0ec40f", null ],
    [ "Jy", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_polarization_data.xhtml#a83c1b722b247f693e79aa20714e67599", null ],
    [ "Method", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_polarization_data.xhtml#ad8e253c4e9f7adc7f68a3eb8c7200722", null ],
    [ "Unpolarized", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_polarization_data.xhtml#a1795e28161df86c766de7852e8241c16", null ],
    [ "XPhase", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_polarization_data.xhtml#a1e27366c117f2b8b4b2cedbc0454299f", null ],
    [ "YPhase", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_polarization_data.xhtml#a34de7a4aea8e2ae2351b0d23095a95dd", null ]
];