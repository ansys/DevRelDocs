var interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field =
[
    [ "FieldDensity", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a0e4b41a910f5cfbe9c1c592d5171352c", null ],
    [ "Freq_1", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a7959db8d875ffb9ac96cadb658bb9112", null ],
    [ "Freq_2", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#ae8d6daaf1632c66c2df4d8dfbcbb4021", null ],
    [ "Freq_3", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a1444da8f71f0d2fcac39ccbf4ee36e5f", null ],
    [ "Freq_4", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a864b932fa3d1465fc3e23e84bea7c428", null ],
    [ "Freq_5", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a6d987e4402d2d4ee05fc13e1286f5301", null ],
    [ "Freq_6", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#afd0f1950a8d5296451f75be3af531da4", null ],
    [ "MultiplyByDiffractionLimit", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#ad767e01df59eba6b725fc010f02c8620", null ],
    [ "RemoveVignetting", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a37e2d1924ee954d6d7a7dae861c4c7b3", null ],
    [ "SampleSize", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a75d48d53b94afc8798517ca27c6533bd", null ],
    [ "ScanType", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a840ededa0471aa651665b67f80588f7c", null ],
    [ "ScatterRays", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#aa920f896af1eb024ac48b8e81c013bc3", null ],
    [ "UseDashes", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a6bb6b2aa4a3d952f73cb6e6a764a4d7a", null ],
    [ "UsePolarization", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#ad5dc10ea327e98a614b92b6ea77f2a16", null ],
    [ "Wavelength", "interface_z_o_s_a_p_i_1_1_analysis_1_1_settings_1_1_mtf_1_1_i_a_s___geometric_mtfvs_field.xhtml#a447795513b9ee175f532b1851ad5eb2d", null ]
];