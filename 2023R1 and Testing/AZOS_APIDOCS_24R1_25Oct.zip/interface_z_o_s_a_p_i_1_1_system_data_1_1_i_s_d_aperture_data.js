var interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data =
[
    [ "AFocalImageSpace", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a128f10b02851cab311ef768c1749330a", null ],
    [ "ApertureType", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#ad9c32311e3c6eeb25b63203c13e2df44", null ],
    [ "ApertureValue", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a08f088415232a6044eff08f94bf2e84b", null ],
    [ "ApodizationFactor", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#acadab82854e57809c5191ddb826a46cd", null ],
    [ "ApodizationFactorIsUsed", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a42e94634cca25f2b2f655c2ab2f20467", null ],
    [ "ApodizationType", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a70c0506b7fead9b785d1c7c130755cab", null ],
    [ "CheckGRINApertures", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a9f8eaf2b11a9ba330114c3b4c0d9b5e3", null ],
    [ "FastSemiDiameters", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a7b0a2751b8ab841f83e3d0abb74d1271", null ],
    [ "GCRS", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a5a8a70f22cb0c10518087420f4b320a5", null ],
    [ "IterateSolvesWhenUpdating", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a5cb34fd99473e62fad7d100ecac7386e", null ],
    [ "SemiDiameterMargin", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a4a06600bd4ab3acc37f2e7a936e393f8", null ],
    [ "SemiDiameterMarginPct", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#a025e40cff0b1fea79675c53ddd84f39f", null ],
    [ "TelecentricObjectSpace", "interface_z_o_s_a_p_i_1_1_system_data_1_1_i_s_d_aperture_data.xhtml#af6348052c54737ba556a55b74ab5d1d1", null ]
];