var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data =
[
    [ "AreTemperaturesApplied", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a56cf409e05cf11225b905cca6b2f04ad", null ],
    [ "GetFEAPointsSafe", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a6ea0f0ff17b848deff4da3fa9b022078", null ],
    [ "GetFEAPointsSafeOld", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a7508ab5cbe254dfd54820ace8091f1fb", null ],
    [ "GetTransformedFEAPointsNoImportRequired", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a61b3cfe8e1fb9fd03b0f4e4a576ca5a2", null ],
    [ "GetTransformedFEAPointsSafe", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#adc1d279ce5ea00c2c51e9ba5458b1024", null ],
    [ "GetTransformValues", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a1b35d6266d309094f9eef5d55a50d982", null ],
    [ "ImportTemperatures", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a5c519459f1aef5476aa2425193f2f92d", null ],
    [ "UnloadData", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a2884ef85cec2ccc78670ad49d9915c88", null ],
    [ "AreTemperaturesImported", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#ab2c19dcfdbbe0443ca353cecb46847be", null ],
    [ "Filename", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a86d7961f0b6a5ce5066b4c92c287add9", null ],
    [ "NumberOfDataPoints", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#a98cfcbaf18a75d9ef2f8058a35230e63", null ],
    [ "SurfaceNumber", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_s_t_a_r___temperatures_f_e_a_data.xhtml#aee515fc9b95596319117eb384443c9a4", null ]
];