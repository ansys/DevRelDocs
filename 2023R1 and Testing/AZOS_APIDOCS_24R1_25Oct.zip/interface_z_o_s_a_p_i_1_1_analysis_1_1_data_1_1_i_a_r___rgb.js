var interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___rgb =
[
    [ "B", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___rgb.xhtml#a1daa31a2233cb59de1878169c6e05ac5", null ],
    [ "G", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___rgb.xhtml#a6261d56a10762feef013762a5df96038", null ],
    [ "R", "interface_z_o_s_a_p_i_1_1_analysis_1_1_data_1_1_i_a_r___rgb.xhtml#aa2515b240279c6d11885cc135c632e1d", null ]
];