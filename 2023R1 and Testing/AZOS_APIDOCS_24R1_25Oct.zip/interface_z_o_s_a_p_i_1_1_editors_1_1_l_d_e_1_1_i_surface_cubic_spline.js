var interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cubic_spline =
[
    [ "Get_Z_nEighths", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cubic_spline.xhtml#a07332016b6ba1802887e082378cb48fc", null ],
    [ "Set_Z_nEighths", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cubic_spline.xhtml#af12260068cda21cfedd6cb65094ba534", null ],
    [ "Z_nEigthsCell", "interface_z_o_s_a_p_i_1_1_editors_1_1_l_d_e_1_1_i_surface_cubic_spline.xhtml#aa8931ed7652e50bf73eb082b6e607b1b", null ]
];