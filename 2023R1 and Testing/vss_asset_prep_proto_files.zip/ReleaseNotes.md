﻿# Asset Preparation API Release Notes

## [V1] - 2023 - 03 - 27

- Remove tags management from Directional light instance in 'scenetree_description.proto'.

- ## [V1] - 2023 - 03 - 01

- Remove beta flag (From *asset_preparation.v1.Beta1* to *asset_preparation.v1*).

## [V1.Beta1] - 2023 - 02 - 27

- [tag.proto]:
  - Add irradiance map property for vehicle tags.

## [V1.Beta1] - 2023 - 02 - 21

- [reset.proto] & [reset_description.proto]:
  - Add a `Reset` service. The `Reset` method will clear the server with all collections and IDs.

## [V1.Beta1] - 2023 - 01 - 27

- [tag.proto]:
  - Replace the 'Repeated Property' field with a single element called 'Properties' composed of nullable elements.

## [V1.Beta1] - 2023 - 01 - 17

- [surface_source_description.proto]:
  - Replace rendering_range parameter in `LightingContribution` message with a `Rendering` message as in
    point_light_description.proto.

## [V1.Beta1] - 2023 - 01 - 11

- [geometry_description.proto]:
  
  - Rename BiNormal to Binormal.
  - Rename ID property in the following messages:
    - `GetMaterialPart[Request/Response]`
    - `GetVerticesArray[Request/Response]`

- [scenetree.proto]: Merge `CreateNodeUnderSceneTree` and `CreateNodeUnderNode` methods to `CreateNode` method.

- [scenetree_description.proto]:
  
  - Merge `CreateNodeUnderSceneTree[Request/Response]` and `CreateNodeUnderNode[Request/Response]` messages
    to `CreateNode[Request/Response]` message.
    `oneof` statement is used to specify the parent ID: `SceneTreeId` or `NodeId`.
  - Add the `oneof` statement for Parent in `UpdateNodeRequest` and `DeleteNodeRequest`. Only the parent type _scene
    tree_ was available.
  - Keep only the direct parent ID in the following messages:
    - `CreateNode[Request/Response]`
    - `[Update/Delete]NodeRequest`
    - `CreateGeometryInstance[Request/Response]`
    - `[Update/Delete]GeometryInstance`
    - `CreateDirectionalLightInstance[Request/Response]`
    - `[Update/Delete]DirectionalLightInstance`
    - `CreatePointLightInstance[Request/Response]`
    - `[Update/Delete]PointLightInstance`
  - Remove the parents IDs in the following messages:
    - `GetNode[Request/Response]`
    - `GetGeometryInstance[Request/Response]`
    - `GetDirectionalLightInstance[Request/Response]`
    - `GetPointLightInstance[Request/Response]`
  - Rename ID property in the following messages:
    - `CreateNodeResponse`
    - `[Update/Delete]NodeRequest`
    - `CreateGeometryInstanceResponse`
    - `[Update/Delete]GeometryInstanceRequest`
    - `GetNode[Request/Response]`
    - `GetGeometryInstance[Request/Response]`
    - `GetDirectionalLightInstance[Request/Response]`
    - `GetPointLightInstance[Request/Response]`
  - Rename ID and Name properties in the following messages:
    - `SceneTreeIdentity`
    - `NodeIdentity`
    - `GeometryInstanceIdentity`
    - `DirectionalLightInstanceIdentity`
    - `PointLightInstanceIdentity`

## [V1.Beta1] - 2022 - 12 - 21

- [geometry_description.proto]:
  - Keep only the direct parent ID in the following messages:
    - `CreateVerticesArray[Request/Response] `
    - `DeleteVerticesArrayRequest`
    - `PushVerticesRequest`
  - Remove the parents IDs in the following messages:
    - `GetMaterialPart[Request/Response]`
    - `GetVerticesArray[Request/Response]`

## [V1.Beta1] - 2022 - 12 - 12

- [status.proto]: Severity level added. Usage extended to warning and error management (no more exception thrown for
  most of the workflows).

## [V1.Beta1] - 2022 - 11 - 24

- [scenetree_description.proto]: Add thermal properties in geometry instances.

## [V1.Beta1] - 2022 - 11 - 18

- [point_light.proto]: Add point light creation.
- [scenetree_description.proto]: Add Point light instance management in scenetree with :
  - CreatePointLightInstance
  - GetPointLightInstance
  - UpdatePointLightInstance
  - DeletePointLightInstance

## [V1.Beta1] - 2022 - 10 - 06

- [All proto files]: Consolidation of the API
  - All rpc methods except listings use request and response messages.
  - A Status message is added in responses. It provides a code to identify the level of success of the calls, and a
    message for details.
    In this Beta version, only errors are addressed, and handled through RpcExceptions. Thus, the Status is not useful
    yet since it is only returned when the operation is successful.
  - Methods and messages are reordered for clarity to follow the pattern:
    - Create
    - Read (get, list)
    - Update
    - Delete
  - Names of methods and messages are harmonized.
  - Enum namings follow the same [convention](https://developers.google.com/protocol-buffers/docs/style#enums).
  - `oneof` statements are preferred over enums when possible.
  - `oneof` statements are preferred over the usage of a boolean associated to a value.
  - Nesting is reduced when possible.
  - All the properties of an entity can be provided upon creation and upon edition.
  - The identifier of the entities is returned by every Get and Create operation.
  - Messages are restructured for clarity and simplicity of use. The usage of a Properties level is harmonized.
  - Useless methods are removed.
  - Point light related protos are removed since the feature is not available yet.

## [V1.Beta1] - 2022 - 09 - 30

- [scenetree_description.proto]: Directional light instances can be exported.
  - The scale should not be specified for light instances.

## [V1.Beta1] - 2022 - 09 - 29

- [geometry_description.proto]: Rename `CreateVerticesRequest` to `PushVerticesRequest`.
- [geometry.proto] : Add `PushVertices` to stream a `PushVerticesRequest` and remove`CreateVertices`.

## [V1.Beta1] - 2022 - 09 - 27

- [resource_description.proto]: Allow users to provide a name when uploading resources.
  - The `ResourceIdentity` message includes a `name` parameter. This identity is still used in the `UploadResponse`
    and `ListResponse` messages.
  - The `DownloadFileRequest`, `DownloadChunkRequest` and `DeleteRequest` require the resource identifier and type as
    inputs rather than the identity.

## [V1.Beta1] - 2022 - 09 - 23

- [surface_source_description.proto] Define luminance for display sources and exitance for surface sources.
  - The `exitance` parameter in `CreateDisplaySourceRequest` has been replaced by a `luminance` parameter.
  - The `Intensity` message includes a new `luminance` parameter, to be defined only when is_display is set to true.
    The old `exitance` parameter is to be defined only when is_display is set to false.

## [V1.Beta1] - 2022 - 09 - 22

- [environment_description.proto] Update the default sky behavior.
  - The default sky has been removed from the skies collection, and is only added dynamically to environments upon
    export in case they instantiate no sky.
- [scenetree.proto and scenetree_description.proto] Add directional light instances (not exported yet).
  - Added capabilities to create a directional light instance under a node (`CreateDirectionalLightInstanceUnderNode`)
    ,
    to edit it (`UpdateDirectionalLightInstance`), and to delete it (`DeleteDirectionalLightInstance`).
  - The information about the directional light instances can be retrieved in the `NodeResponse` when calling
    `GetNode` on the parent node.

## [V1.Beta1] - 2022 - 09 - 20

- ReleaseNotes have been added for the first Beta version of the API.