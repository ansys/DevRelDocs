# Imagine.Api.AssetPreparation nuget

Imagine.Api.AssetPreparation nuget contains the Asset Preparation public API, e.g. all .proto files defining Grpc
messages and services available for an external application.

> The use of this nuget is restricted to internal developments.

## Use Imagine.Api.AssetPreparation nuget in a C# solution

### Generate and build Imagine.Api.AssetPreparation .proto files

Imagine.Api.AssetPreparation is the input to generate code using the Protobuf and Grpc tools provided by another
package.
Create a project dedicated to the Grpc compilation of the nuget proto files.

This project shall reference the nuget and include all Google Protobuf dependencies needed for building proto files.

To do so, add the following lines to the .csproj file and modify the package version according to your version:

```xml
<ItemGroup>
    <PackageReference Include="Grpc" />
    <PackageReference Include="Grpc.Tools">
        <PrivateAssets>all</PrivateAssets>
        <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
    </PackageReference>
    <PackageReference Include="Google.Protobuf" />
    <PackageReference Include="Imagine.Api.AssetPreparation" Version="0.0.0" GeneratePathProperty="true" />
</ItemGroup>
<ItemGroup>
    <Protobuf Include="$(PkgImagine_Api_AssetPreparation)\**\*.proto" ProtoRoot="$(PkgImagine_Api_AssetPreparation)\Api.AssetPreparation" GrpcServices="Both" />
</ItemGroup>
```

### Import .proto files of Imagine.Api.AssetPreparation nuget into .proto files belonging to another project

In order to import the nuget .proto files into .proto files belonging to another project, add the following lines to the
files:

```
package myPackage; // the name of the package that shall import Api.AssetPreparation 
import "imagine/AssetPreparation/common/message.proto"; // an imported Api.AssetPreparation file
```

The .csproj of the consumer project shall be updated to reference both the dedicated project (created before) and the
nuget.

In the nuget dedicated project, add the following lines to the consumer .csproj files (don't forget to modify the
package version according to your version) :

```xml
<ItemGroup>
	<PackageReference Include="Google.Protobuf" />
	<PackageReference Include="Grpc.Tools" />
	<PackageReference Include="Imagine.Api.AssetPreparation" Version="0.0.0" GeneratePathProperty="true" />
</ItemGroup>
<ItemGroup>
	<ProjectReference Include="..\NugetDedicatedProject\NugetDedicatedProject.csproj" />
</ItemGroup>
<ItemGroup>
	<Protobuf Include="$(PkgImagine_Api_AssetPreparation)\**\*.proto" ProtoRoot="$(PkgImagine_Api_AssetPreparation)\Api.AssetPreparation" CompileOutputs="false" />
	<Protobuf Include=".\**\*.proto" ProtoRoot="$(PkgImagine_Api_AssetPreparation)\Api.AssetPreparation; ." GrpcServices="Both" />
</ItemGroup>
```

### Use built Grpc files in another project

In case you just need to reference the build output of Api.AssetPreparation messages and services, just import the nuget
dedicated project:

```xml
<ItemGroup>
	  <ProjectReference Include="..\NugetDedicatedProject\NugetDedicatedProject.csproj" />
</ItemGroup>
```

