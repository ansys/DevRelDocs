/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Data Processing Framework: C++ APIs", "index.xhtml", [
    [ "Introduction", "index.xhtml", null ],
    [ "Getting started", "getting_started.xhtml", null ],
    [ "User guide", "modules.xhtml", "modules" ],
    [ "Operators", "operators_page.xhtml", null ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Typedefs", "namespacemembers_type.xhtml", null ],
        [ "Enumerations", "namespacemembers_enum.xhtml", null ],
        [ "Enumerator", "namespacemembers_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Data Structures", "annotated.xhtml", [
      [ "Data Structures", "annotated.xhtml", "annotated_dup" ],
      [ "Data Structure Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Data Fields", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ],
        [ "Enumerations", "functions_enum.xhtml", null ],
        [ "Enumerator", "functions_eval.xhtml", null ]
      ] ]
    ] ],
    [ "Examples", "examples.xhtml", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"AveragingTest_8cpp-example.xhtml",
"classansys_1_1dpf_1_1CyclicSupport.xhtml#a919b31109b428b4c1b01d0250692b2d2",
"classansys_1_1dpf_1_1EventHandler.xhtml#aa5dbd9875e86799e977a4ef66e78d640a3a282aed20a3d810ba9992e4727ee076",
"classansys_1_1dpf_1_1LabelSpace.xhtml",
"classansys_1_1dpf_1_1Model.xhtml#abadaeac1d698448632bc92df349f0ed9",
"classansys_1_1dpf_1_1Operator.xhtml#ae4a1191b90450b4e5f4c8c2158ae249b",
"classansys_1_1dpf_1_1OperatorSpecification.xhtml#af2335159650a865b5c7eab060d85da07",
"classansys_1_1dpf_1_1RuntimeClientConfig.xhtml#accdb5f4e700803b8bd6b6cf8cb8623d1",
"classansys_1_1dpf_1_1Unit.xhtml#af2bd161c5fa67f3f9bf58b9441692753",
"classansys_1_1dpf_1_1Workflow.xhtml#ab8b59d1d65ffb6df6845d98e321dfc20",
"namespaceansys_1_1dpf.xhtml#aa4a44a04a0aafb8fe0645f019bbd94d1af607f86e9475d2229252adf8e0b133ca",
"structansys_1_1dpf_1_1homogeneities.xhtml#a65341753499ded11d50306a6d7790d55",
"structansys_1_1dpf_1_1types.xhtml#aa6514ce8d3c27091d3b4a510f8a3260c"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';