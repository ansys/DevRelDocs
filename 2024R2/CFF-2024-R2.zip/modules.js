var modules =
[
    [ "Enumerations", "group__enums.xhtml", "group__enums" ],
    [ "Typedefs", "group__typedefs.xhtml", "group__typedefs" ]
];