/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Ansys Common Fluids Format SDK Reference", "index.xhtml", [
    [ "Ansys Common Fluids Format SDK", "index.xhtml", [
      [ "Introduction to the Ansys Common Fluids Format SDK", "index.xhtml#CFFSDKIntro", null ],
      [ "Application Programming Interface", "index.xhtml#API", [
        [ "Prerequisites for using the Application Programming Interface", "index.xhtml#Prerequestites", null ],
        [ "Overview", "index.xhtml#BriefAPIOverview", null ]
      ] ],
      [ "Data Models", "index.xhtml#DataModels", null ],
      [ "Files", "index.xhtml#Files", [
        [ "File Formats", "index.xhtml#FileFormats", null ]
      ] ],
      [ "Examples", "index.xhtml#Examples", null ]
    ] ],
    [ "Ansys Common Fluids API", "_c_f_f_a_p_i.xhtml", "_c_f_f_a_p_i" ],
    [ "Ansys Common Fluids Data Models", "_data_models_overview.xhtml", "_data_models_overview" ],
    [ "Ansys Common Fluids Examples", "_c_f_f_s_d_k_examples.xhtml", [
      [ "Introduction", "_c_f_f_s_d_k_examples.xhtml#ExamplesIntro", [
        [ "Reading Case and Data Files using C++ API", "_c_f_f_s_d_k_examples.xhtml#ImportExample", null ],
        [ "Writing Case and Data Files using C++ API", "_c_f_f_s_d_k_examples.xhtml#ExportExample", null ],
        [ "Writing Files with Parallel Compression Enabled Using C++ API", "_c_f_f_s_d_k_examples.xhtml#ParallelExportExample", null ],
        [ "Reading Settings Using C++ API", "_c_f_f_s_d_k_examples.xhtml#SettingImportExample", null ],
        [ "Reading Discrete Phase Model (DPM) Particle Data Using C++ API", "_c_f_f_s_d_k_examples.xhtml#Particles", null ],
        [ "Reading a CFF file Using C API", "_c_f_f_s_d_k_examples.xhtml#CImportExample", null ],
        [ "Writing a CFF File Using C API", "_c_f_f_s_d_k_examples.xhtml#CExportExample", null ]
      ] ]
    ] ],
    [ "Ansys Common Fluids File Formats", "_file_formats_overview.xhtml", [
      [ "CFF File Formats", "_file_formats_overview.xhtml#FileFormatsIntro", [
        [ "CFF Project Format", "_file_formats_overview.xhtml#CFFProject", null ],
        [ "CFF Restart Format", "_file_formats_overview.xhtml#CFFRestart", null ],
        [ "CFF Post Format", "_file_formats_overview.xhtml#CFFPost", null ],
        [ "Important Notes on Processing Files Containing CFF Restart and CFF Post Data", "_file_formats_overview.xhtml#FFFormatNodes", null ]
      ] ]
    ] ],
    [ "Modules", "modules.xhtml", "modules" ],
    [ "Namespaces", "namespaces.xhtml", [
      [ "Namespace List", "namespaces.xhtml", "namespaces_dup" ],
      [ "Namespace Members", "namespacemembers.xhtml", [
        [ "All", "namespacemembers.xhtml", null ],
        [ "Functions", "namespacemembers_func.xhtml", null ],
        [ "Typedefs", "namespacemembers_type.xhtml", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ],
      [ "Class Index", "classes.xhtml", null ],
      [ "Class Hierarchy", "hierarchy.xhtml", "hierarchy" ],
      [ "Class Members", "functions.xhtml", [
        [ "All", "functions.xhtml", "functions_dup" ],
        [ "Functions", "functions_func.xhtml", "functions_func" ],
        [ "Variables", "functions_vars.xhtml", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_build_and_usage.xhtml",
"classansys_1_1_cff_consumer.xhtml#a0b627f3b4c48a5d85a0531588a9e2702",
"classansys_1_1_cff_consumer.xhtml#acb74ee258ed3caca0b27f3a135d4854b",
"classansys_1_1_cff_provider.xhtml#a8145e423ecec3600ea46be3abd2ef643",
"classansys_1_1_project_1_1_iterator.xhtml#aec38d9ec2d30f32b6f4ed1c5fac0e9ce",
"classansys_1_1_project_1_1_result.xhtml#acfea7c7aac843ba7446fbc7702a00462",
"classansys_1_1_project_1_1_run_output_attr.xhtml#adbcf15409dbcf5051cc8fcb3afdf930f",
"functions_e.xhtml",
"group__typedefs.xhtml#ga9ea5e52d378f21da14e708300f91e71b"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';