var a00339 =
[
    [ "material_part_id", "a00339.xhtml#a48137e0863a37e6c235babf324f4c16d", null ],
    [ "properties", "a00339.xhtml#a147a170a665dd108319af25b4153853b", null ]
];