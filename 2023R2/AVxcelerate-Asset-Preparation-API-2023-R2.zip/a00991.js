var a00991 =
[
    [ "hdri", "a00991.xhtml#ae0b3026626aced4077297770b2d8b3f8", null ],
    [ "name", "a00991.xhtml#a43eb51808284bfa0ee71e318224d5d00", null ],
    [ "natural", "a00991.xhtml#a35bd4d7c0e633781d45a650bd67739f2", null ]
];