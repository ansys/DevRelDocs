var a01047 =
[
    [ "id", "a01047.xhtml#aadbccf24504388f1485e474d1c2363cc", null ],
    [ "properties", "a01047.xhtml#ad72fdb6ff89ec05f62162b58e23528b6", null ]
];