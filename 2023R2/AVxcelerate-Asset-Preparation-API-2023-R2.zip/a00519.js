var a00519 =
[
    [ "no_normal", "a00519.xhtml#ad7ceb5e3dd057a99998a260aa7993d89", null ],
    [ "texture", "a00519.xhtml#ad279355a2702ed3f8cfd86dc0fe64262", null ]
];