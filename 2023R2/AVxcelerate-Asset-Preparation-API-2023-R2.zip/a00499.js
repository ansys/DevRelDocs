var a00499 =
[
    [ "intensity", "a00499.xhtml#a057e0e7a3975e03ec8ad8bb386517fbf", null ],
    [ "map_id", "a00499.xhtml#a19304e94776c8946f2a47c1aa3784173", null ],
    [ "map_uv_channel", "a00499.xhtml#a502bd8f048b7f5a821cbd92d1f1e4eb5", null ]
];