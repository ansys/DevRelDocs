var a01067 =
[
    [ "display_source", "a01067.xhtml#ae981bfec5e2649cdaf905bf7a10c6099", null ],
    [ "name", "a01067.xhtml#acfad16093becb14012d6c597738bf831", null ],
    [ "surface_source", "a01067.xhtml#addb167e82ebbd5058f5eeee7c05a7ec8", null ]
];