var a00371 =
[
    [ "id", "a00371.xhtml#a65885113fb35202bab5247d83fc9f76c", null ],
    [ "name", "a00371.xhtml#ae2efb6a6eec15400c19844189d28d265", null ]
];