var a00539 =
[
    [ "absorption", "a00539.xhtml#a0df4487e11db7a08cb898b5cff1d5226", null ],
    [ "constringency", "a00539.xhtml#ac9c921f4586fc90d77a882cccab0e70b", null ],
    [ "refractive_index", "a00539.xhtml#a51aa6cf5c3a4d18057efdcffdfe0a62d", null ]
];