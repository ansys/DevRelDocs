var a00723 =
[
    [ "id", "a00723.xhtml#af893f7f775498120850a13e85d62198a", null ],
    [ "nodes", "a00723.xhtml#a45fa402816d59aea4a07c5966ca79cda", null ],
    [ "properties", "a00723.xhtml#aae6aae1bc7d287d0c9164c4eaf6cef0f", null ],
    [ "status", "a00723.xhtml#a943e08d9a120fb810209a4437a0d5e6b", null ]
];