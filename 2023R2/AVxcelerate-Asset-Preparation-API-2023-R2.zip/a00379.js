var a00379 =
[
    [ "id", "a00379.xhtml#a71855b06fed7353bcf06f9341188b495", null ],
    [ "name", "a00379.xhtml#ad74dfb879b13e5608159c94854ce3a44", null ]
];