var a00495 =
[
    [ "color", "a00495.xhtml#a503ff5211d3af859e9abfea4b681b28c", null ],
    [ "texture", "a00495.xhtml#a0b5d158e41c56acc8e7bb46ed6caf569", null ]
];