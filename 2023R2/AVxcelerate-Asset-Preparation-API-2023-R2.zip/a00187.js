var a00187 =
[
    [ "black_body", "a00187.xhtml#acb497840dca182972cce1d20d58fba7b", null ],
    [ "monochromatic", "a00187.xhtml#ad4d4ebd40276902e12c912d63e981a25", null ],
    [ "power", "a00187.xhtml#ac58aec2f6e521975bfe248e87ef12d0f", null ],
    [ "spectrum_library", "a00187.xhtml#a64f2abf45a5d9d09397bcfd75424054e", null ]
];