var a00131 =
[
    [ "basic_type", "a00131.xhtml#a2fda04435f7e0ac79d6fa0d7bba73cd6", null ],
    [ "lighting_type", "a00131.xhtml#a758531629f62b078a201906b9d126d48", null ],
    [ "name", "a00131.xhtml#a5ffbd205c35e5cc772371bde83aafff4", null ]
];