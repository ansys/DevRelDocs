var a01039 =
[
    [ "id", "a01039.xhtml#a4587c11ee30e1c8b2f3c39e28fb57cb1", null ],
    [ "properties", "a01039.xhtml#add85706385595378d7be4e88c06c84fa", null ],
    [ "status", "a01039.xhtml#acc54a31c2eaedf208a0b1ee2db1c9d30", null ]
];