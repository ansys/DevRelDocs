var a00763 =
[
    [ "id", "a00763.xhtml#a73d6e66ba8b8cb184c774c62315cf1eb", null ],
    [ "node_id", "a00763.xhtml#af8bd5eedec2f2cae30fb5db7b91f38ce", null ],
    [ "properties", "a00763.xhtml#a6f31b3a0e0d45d8237a747171e47ad38", null ],
    [ "scene_tree_id", "a00763.xhtml#aee1cf8ce66619fc425c4b59a025b9ab8", null ]
];