var a00999 =
[
    [ "near_field_precision", "a00999.xhtml#a02ea7bf58d9520d1414f98a7508031af", null ],
    [ "resolution", "a00999.xhtml#a18c519869662286ccb3814562fb4e97b", null ],
    [ "shadow_offset_ratio", "a00999.xhtml#a8691e6e5fd2e5cf0a985ea48f2eb2b8b", null ],
    [ "shadow_radius", "a00999.xhtml#a52b2fdfb6edb0d7c976f027bf8303098", null ],
    [ "softness", "a00999.xhtml#a6e1831706d2814fcfd4ad700f59049b7", null ]
];