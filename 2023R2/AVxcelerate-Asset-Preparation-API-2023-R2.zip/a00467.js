var a00467 =
[
    [ "absorption", "a00467.xhtml#a85d237bf633d9188279c96b24efee242", null ],
    [ "anisotropy_properties", "a00467.xhtml#a9178bd204cb7682fe434a099c2f39bfb", null ],
    [ "diffuse_properties", "a00467.xhtml#a777998de2a68f27c93621f51aaac332e", null ],
    [ "mask_properties", "a00467.xhtml#a888eb3699bb20aee04d4f3070420cda1", null ],
    [ "normal_properties", "a00467.xhtml#aedc377c6815244f15840457d40777e6d", null ]
];