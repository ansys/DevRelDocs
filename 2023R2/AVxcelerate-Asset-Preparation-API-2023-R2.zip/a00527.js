var a00527 =
[
    [ "color", "a00527.xhtml#aa7aaf2c19565338880fc579c1429c999", null ],
    [ "no_anisotropy", "a00527.xhtml#a440ff501636a26d9c1bb9e82829a6d9f", null ],
    [ "texture", "a00527.xhtml#a4c2c11e968293da50fa892c54c4a5fb7", null ]
];