var a00323 =
[
    [ "geometry_id", "a00323.xhtml#a6ffc4dc73e677c2e31a55c966c10854a", null ],
    [ "material_part_id", "a00323.xhtml#a43f24b88964666f98df1f5c57695ed7e", null ],
    [ "properties", "a00323.xhtml#af15874b157be4567660680a4cef95095", null ]
];