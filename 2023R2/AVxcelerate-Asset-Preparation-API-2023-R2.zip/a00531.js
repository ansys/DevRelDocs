var a00531 =
[
    [ "map_id", "a00531.xhtml#ae6089ab824337afd5e7cf1aa00a8cf2d", null ],
    [ "map_uv_channel", "a00531.xhtml#ab984a67025d0875ea569a04e89abc8f5", null ]
];