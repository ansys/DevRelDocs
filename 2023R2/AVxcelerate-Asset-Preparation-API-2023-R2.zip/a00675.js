var a00675 =
[
    [ "identifier", "a00675.xhtml#a15e6aa64b9866a25915400c90b974999", null ],
    [ "type", "a00675.xhtml#a4db31248b61ba7b43341abcf89fee6e1", null ]
];