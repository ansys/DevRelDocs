var a00179 =
[
    [ "custom", "a00179.xhtml#acc0e60b72a2ee28171218544fbd80acb", null ],
    [ "dynamic_accurate_shadows", "a00179.xhtml#abf50aa21a1e18b75dca35e5680b9558b", null ],
    [ "name", "a00179.xhtml#a798bab9622e59b37002ec98ec4cb3b12", null ],
    [ "no_shadow", "a00179.xhtml#ae69472ddaa868283c56f715c37fa11c8", null ],
    [ "sun", "a00179.xhtml#a7a56b0ad770e4e06a745ddbef2bc9a2a", null ]
];