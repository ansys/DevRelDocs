var a00263 =
[
    [ "active_sky", "a00263.xhtml#a37d955e178bc1d3d5d6b1b9c9717ac9f", null ],
    [ "added_skies", "a00263.xhtml#ab41b7ca5ed4b7ee38fa3286752b83676", null ],
    [ "name", "a00263.xhtml#a87a712fc93f28fc92c117eaeb3cfe7d4", null ],
    [ "removed_skies", "a00263.xhtml#adfc5524538832b3e2b04cfe39bbe5c7c", null ],
    [ "scene_tree", "a00263.xhtml#a81ca22076f29340ae9979ca172c02e35", null ]
];