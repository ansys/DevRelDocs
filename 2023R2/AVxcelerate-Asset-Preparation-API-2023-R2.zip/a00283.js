var a00283 =
[
    [ "id", "a00283.xhtml#ad2dafd0d917178af3c386628929f09eb", null ],
    [ "material_parts", "a00283.xhtml#ad2c7b1f664c3b804f97ba718ab6e72c3", null ],
    [ "properties", "a00283.xhtml#a6e82f444e96a59db7209fe091f1467b8", null ],
    [ "status", "a00283.xhtml#a0f9aab527808bd9e63780fdd224de076", null ]
];