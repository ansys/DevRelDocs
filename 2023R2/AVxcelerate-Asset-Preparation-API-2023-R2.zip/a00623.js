var a00623 =
[
    [ "black_body", "a00623.xhtml#a5197c2c29bdfec3bba486b83864cfbab", null ],
    [ "dynamic_shadows", "a00623.xhtml#a357e9359c630956976153be56c5acdc8", null ],
    [ "intensity", "a00623.xhtml#af3b9f595b38eb96423875020b6787924", null ],
    [ "monochromatic", "a00623.xhtml#a44e9bc70ac2c65799a6989b041b43257", null ],
    [ "name", "a00623.xhtml#abb369e624afa6fa81dad43f774054886", null ],
    [ "no_shadow", "a00623.xhtml#a21bfb399ceff6b7618e410343b3b24c3", null ],
    [ "rendering", "a00623.xhtml#ab2d745eb6603fd0f2a8cbb43fb185a99", null ],
    [ "spectrum_library", "a00623.xhtml#a5c0073722243bc66de427b77ad11c0fe", null ],
    [ "static_shadows", "a00623.xhtml#ac17d29450a25e6b6dde71115614cf9fa", null ]
];