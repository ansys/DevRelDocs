var a00090 =
[
    [ "BlackBody", "a00199.xhtml", "a00199" ],
    [ "CreateDirectionalLightRequest", "a00139.xhtml", "a00139" ],
    [ "CreateDirectionalLightResponse", "a00143.xhtml", "a00143" ],
    [ "Custom", "a00187.xhtml", "a00187" ],
    [ "DeleteDirectionalLightRequest", "a00167.xhtml", "a00167" ],
    [ "DeleteDirectionalLightResponse", "a00171.xhtml", "a00171" ],
    [ "DirectionalLightIdentity", "a00175.xhtml", "a00175" ],
    [ "DirectionalLightPreparation", "a00135.xhtml", "a00135" ],
    [ "DirectionalLightProperties", "a00179.xhtml", "a00179" ],
    [ "DynamicAccurateShadows", "a00191.xhtml", "a00191" ],
    [ "GetDirectionalLightRequest", "a00147.xhtml", "a00147" ],
    [ "GetDirectionalLightResponse", "a00151.xhtml", "a00151" ],
    [ "ListDirectionalLightsResponse", "a00155.xhtml", "a00155" ],
    [ "Monochromatic", "a00203.xhtml", "a00203" ],
    [ "SpectrumLibrary", "a00195.xhtml", "a00195" ],
    [ "Sun", "a00183.xhtml", "a00183" ],
    [ "UpdateDirectionalLightRequest", "a00159.xhtml", "a00159" ],
    [ "UpdateDirectionalLightResponse", "a00163.xhtml", "a00163" ]
];