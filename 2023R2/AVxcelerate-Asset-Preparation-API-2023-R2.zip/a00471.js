var a00471 =
[
    [ "anisotropy_properties", "a00471.xhtml#ad22046f4359aa465ac1397b45533c0a8", null ],
    [ "diffuse_properties", "a00471.xhtml#a8ff2df43eb087876f7908a1ade7c5e2c", null ],
    [ "mask_properties", "a00471.xhtml#a1f85aa02fe78346673a0f5f9ea33caf0", null ],
    [ "normal_properties", "a00471.xhtml#abfc5cca3901da4f3b78c16f7eb4cd8cd", null ]
];