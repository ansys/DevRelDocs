var a00995 =
[
    [ "ambient_conditions", "a00995.xhtml#abc290826e008afec42f333cd03be94ff", null ],
    [ "date", "a00995.xhtml#a0d225152c0ffc0e8128eef8b72ba5980", null ],
    [ "dynamic_accurate_shadows", "a00995.xhtml#aa543151e395961c3ed8e8b215cbb8092", null ],
    [ "location", "a00995.xhtml#aadff433b3324ef393dbb7bfd1d894da3", null ],
    [ "no_shadow", "a00995.xhtml#ad9eb77944efff9e8560a595f604781aa", null ],
    [ "time", "a00995.xhtml#a0850481886ead3cc954c2e6b77ee1be4", null ]
];