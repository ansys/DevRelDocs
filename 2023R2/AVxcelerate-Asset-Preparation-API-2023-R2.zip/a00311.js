var a00311 =
[
    [ "geometry_id", "a00311.xhtml#a2ce1cb0e458e8a126b80fa5d6d568da3", null ],
    [ "material_part_id", "a00311.xhtml#a0a9b9672d7ab78e58a975d0b8a9f77b6", null ],
    [ "status", "a00311.xhtml#ae594d478208535325de611978878ea5e", null ]
];