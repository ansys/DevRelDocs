var a00427 =
[
    [ "id", "a00427.xhtml#a31bcb648ee5e392244ceecba97972d4f", null ],
    [ "properties", "a00427.xhtml#a55b167e792c9e8fe117d71718b0c77b7", null ],
    [ "status", "a00427.xhtml#ac36b85dbc3037ba3a40a64fa41623f79", null ]
];