var a00383 =
[
    [ "added_tags", "a00383.xhtml#a39d869160cedb9b7259611c4e8babad2", null ],
    [ "material_id", "a00383.xhtml#a06b4168a78f1515c93b2b8c3c0a216f3", null ],
    [ "name", "a00383.xhtml#a5debc442754b0c129753701107b551f9", null ],
    [ "removed_tags", "a00383.xhtml#a7c900fdc3603880f03664ef62d5def15", null ],
    [ "surface_source_id", "a00383.xhtml#a168f516f327d49b05d35d0b6bece223c", null ],
    [ "transparency_mode", "a00383.xhtml#a325ead8067528d0894cb8187fc0c2e4d", null ]
];