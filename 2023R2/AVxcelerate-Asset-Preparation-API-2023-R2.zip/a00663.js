var a00663 =
[
    [ "wavelength", "a00663.xhtml#aaffa70d546a3c32dde98bc94b930dab2", null ]
];