var a00515 =
[
    [ "alpha_uv_channel", "a00515.xhtml#aebeee6f81d15270e5da1054a9236433f", null ],
    [ "map_id", "a00515.xhtml#ade75ecb6861f38f15e9ad78b8da282c9", null ],
    [ "map_uv_channel", "a00515.xhtml#a3b3c6b60b067871615dad44d7dd6c250", null ]
];