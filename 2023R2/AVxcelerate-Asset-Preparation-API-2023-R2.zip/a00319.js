var a00319 =
[
    [ "id", "a00319.xhtml#ab04a2ca9082d45c35461d10e82e6a4e6", null ],
    [ "properties", "a00319.xhtml#a7072393c85b55eeca983e0bf7ba65d72", null ],
    [ "status", "a00319.xhtml#a228561fa05148c30f71550a5dbf8f708", null ],
    [ "vertices_arrays", "a00319.xhtml#aca3fe37fda348fea2de43277242b7cbe", null ]
];