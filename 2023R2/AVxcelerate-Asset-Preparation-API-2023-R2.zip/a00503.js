var a00503 =
[
    [ "color", "a00503.xhtml#a4f8893f41f08161132d156679a1610c1", null ],
    [ "texture", "a00503.xhtml#aaafe67a69433157b9b2fb5124b4820b3", null ]
];