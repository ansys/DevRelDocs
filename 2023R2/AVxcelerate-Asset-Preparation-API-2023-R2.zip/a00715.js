var a00715 =
[
    [ "id", "a00715.xhtml#a6bae21ad95964e936b910aa6ef68f47a", null ],
    [ "status", "a00715.xhtml#afc9c29814fa5a1bee3de974e69cca9c3", null ]
];