var a00791 =
[
    [ "id", "a00791.xhtml#a16dfd29ea0bafc614fceeb6c2fea57e1", null ],
    [ "properties", "a00791.xhtml#a3f47c5589740ab0eeec735cc29c9fbb2", null ],
    [ "status", "a00791.xhtml#a0cbe47780d49a77b19c8725a6f150644", null ]
];