var a00823 =
[
    [ "id", "a00823.xhtml#a292da84fde9e6bdaccb4f1a305926019", null ],
    [ "properties", "a00823.xhtml#a019c9f08b7dbdd218a5dcbacd8c433ba", null ],
    [ "status", "a00823.xhtml#ae607ca95622211f3919c7f7b61ad2da3", null ]
];