/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "AVxcelerate Asset Preparation API", "index.xhtml", [
    [ "Overview", "index.xhtml#autotoc_md1", [
      [ "Current Version Limitations", "index.xhtml#autotoc_md2", null ],
      [ "Definition of Terms", "index.xhtml#autotoc_md3", null ],
      [ "gRPC Services", "index.xhtml#autotoc_md4", null ]
    ] ],
    [ "Asset Preparation Server", "index.xhtml#asset_prep_server", [
      [ "Port", "index.xhtml#autotoc_md5", null ],
      [ "Starting the Asset Preparation Server", "index.xhtml#autotoc_md6", null ],
      [ "Stopping the Asset Preparation Server", "index.xhtml#autotoc_md7", null ]
    ] ],
    [ "Status and Error Management", "index.xhtml#autotoc_md8", null ],
    [ "Streaming Data with Chunk", "index.xhtml#chunk_data_format", null ],
    [ "Services", "index.xhtml#autotoc_md9", [
      [ "Information Service", "index.xhtml#information_service", null ],
      [ "Reset Service", "index.xhtml#reset_service", null ],
      [ "Resource Preparation Service", "index.xhtml#resource_prep_service", [
        [ "Input", "index.xhtml#autotoc_md10", null ],
        [ "Output", "index.xhtml#autotoc_md11", null ]
      ] ],
      [ "Geometry Preparation Service", "index.xhtml#geometry_prep_service", [
        [ "Data Structure", "index.xhtml#autotoc_md12", null ],
        [ "Inputs", "index.xhtml#autotoc_md13", null ],
        [ "Outputs", "index.xhtml#autotoc_md14", null ]
      ] ],
      [ "Scene Tree Preparation Service", "index.xhtml#scenetree_prep_service", [
        [ "Data Structure", "index.xhtml#autotoc_md15", null ],
        [ "Tags", "index.xhtml#tags", null ],
        [ "Inputs", "index.xhtml#autotoc_md16", null ],
        [ "Outputs", "index.xhtml#autotoc_md17", null ]
      ] ],
      [ "Environment Preparation Service", "index.xhtml#env_prep_service", [
        [ "Data Structure", "index.xhtml#autotoc_md18", null ],
        [ "Inputs", "index.xhtml#autotoc_md19", null ],
        [ "Outputs", "index.xhtml#autotoc_md20", null ]
      ] ],
      [ "Sky Preparation Service", "index.xhtml#sky_prep_service", [
        [ "Data Structure", "index.xhtml#autotoc_md21", null ],
        [ "Input", "index.xhtml#autotoc_md22", null ],
        [ "Output", "index.xhtml#autotoc_md23", null ]
      ] ],
      [ "Material Preparation Service", "index.xhtml#material_prep_service", [
        [ "Data Structure", "index.xhtml#autotoc_md24", [
          [ "Surface Optical Properties", "index.xhtml#sop", null ],
          [ "Volume Optical Properties", "index.xhtml#vop", null ],
          [ "Thermal Properties", "index.xhtml#thermal_properties", null ],
          [ "Dielectric Properties", "index.xhtml#dielec_properties", null ],
          [ "Reflection Effect Properties", "index.xhtml#reflection_effect", null ]
        ] ],
        [ "Inputs", "index.xhtml#autotoc_md25", null ],
        [ "Output", "index.xhtml#autotoc_md26", null ]
      ] ],
      [ "Surface Source Preparation Service", "index.xhtml#surface_source_prep_service", [
        [ "Data Structure", "index.xhtml#autotoc_md27", null ],
        [ "Inputs", "index.xhtml#autotoc_md28", null ],
        [ "Output", "index.xhtml#autotoc_md29", null ]
      ] ],
      [ "Directional Light Preparation Service", "index.xhtml#dir_light_prep_service", [
        [ "Data Structure", "index.xhtml#autotoc_md30", null ],
        [ "Inputs", "index.xhtml#autotoc_md31", null ],
        [ "Output", "index.xhtml#autotoc_md32", null ]
      ] ],
      [ "Point Light Preparation Service", "index.xhtml#point_light_prep_service", [
        [ "Data Structure", "index.xhtml#autotoc_md33", null ],
        [ "Inputs", "index.xhtml#autotoc_md34", null ],
        [ "Output", "index.xhtml#autotoc_md35", null ]
      ] ]
    ] ],
    [ "AVxcelerate Asset Preparation API Outputs", "index.xhtml#autotoc_md36", [
      [ "Asset and Track Streams", "index.xhtml#autotoc_md37", null ],
      [ "Asset and Track Files", "index.xhtml#autotoc_md38", null ]
    ] ],
    [ "Classes", "annotated.xhtml", [
      [ "Class List", "annotated.xhtml", "annotated_dup" ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"a00086.xhtml",
"a00387.xhtml#af4f8da35a2d2d51f0bc0f255bfb305e5",
"a00651.xhtml",
"a00935.xhtml#a264bdf8d6b8719849463143b448fe340"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';