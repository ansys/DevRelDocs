var a00127 =
[
    [ "id", "a00127.xhtml#aa7d29542e403e4ff09a6468c8823c8e8", null ],
    [ "irradiance_map_id", "a00127.xhtml#a5916f26662d4b8f336343b0753f8ab99", null ],
    [ "label", "a00127.xhtml#aeedba5b575cce0ebe91feeded83f2ce2", null ],
    [ "name", "a00127.xhtml#ad6415dff8ec512848805e4acc1e63646", null ],
    [ "position", "a00127.xhtml#ae9be579d7f3a5f9c6e4bab7c529696b2", null ]
];