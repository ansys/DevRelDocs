var a00096 =
[
    [ "DeleteResourceRequest", "a00695.xhtml", "a00695" ],
    [ "DeleteResourceResponse", "a00699.xhtml", "a00699" ],
    [ "DownloadResourceAsChunksRequest", "a00675.xhtml", "a00675" ],
    [ "DownloadResourceAsFileRequest", "a00679.xhtml", "a00679" ],
    [ "DownloadResourceAsFileResponse", "a00683.xhtml", "a00683" ],
    [ "ListResourcesRequest", "a00687.xhtml", "a00687" ],
    [ "ListResourcesResponse", "a00691.xhtml", "a00691" ],
    [ "ResourceIdentity", "a00703.xhtml", "a00703" ],
    [ "ResourcePreparation", "a00667.xhtml", "a00667" ],
    [ "UploadResourceResponse", "a00671.xhtml", "a00671" ]
];