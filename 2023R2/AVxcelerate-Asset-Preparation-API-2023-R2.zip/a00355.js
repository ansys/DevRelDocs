var a00355 =
[
    [ "material_part_id", "a00355.xhtml#a5b95f5c3e31a48059f6969e374413c72", null ],
    [ "vertices_array_id", "a00355.xhtml#adc69ef3e246ef26e190419d5ac3dc884", null ]
];