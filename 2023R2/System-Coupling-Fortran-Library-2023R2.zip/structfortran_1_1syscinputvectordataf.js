var structfortran_1_1syscinputvectordataf =
[
    [ "dataptr1", "structfortran_1_1syscinputvectordataf.xhtml#a9ff86b31b305de4d1722dd390eb413d6", null ],
    [ "dataptr2", "structfortran_1_1syscinputvectordataf.xhtml#a3f77c87d288879c34e8f04f2d1f0e159", null ],
    [ "dataptr3", "structfortran_1_1syscinputvectordataf.xhtml#a59296d314ebb802f9490fe430a0cd3d4", null ],
    [ "datasize", "structfortran_1_1syscinputvectordataf.xhtml#ac8d11b0cadefc4f138b1ef4e0ab50b2a", null ],
    [ "primitivetype", "structfortran_1_1syscinputvectordataf.xhtml#a41aa641a12e238b3d8a12707aa047938", null ]
];