var structfortran_1_1sysccouplinginterfacef =
[
    [ "name", "structfortran_1_1sysccouplinginterfacef.xhtml#a72f0326f2d38c6a753a748136992df3a", null ]
];