var structfortran_1_1syscsetupinfof =
[
    [ "analysistype", "structfortran_1_1syscsetupinfof.xhtml#aeab455ed168e2f3e178793e8f6c69c50", null ],
    [ "restartssupported", "structfortran_1_1syscsetupinfof.xhtml#a4a6aff883f05c2ab2f3fedc949218ed0", null ]
];