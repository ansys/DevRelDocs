var interfacefortran_1_1syscgetsetupinfof =
[
    [ "syscgetsetupinfof", "interfacefortran_1_1syscgetsetupinfof.xhtml#a73374df2183a799e03180e006525fcfe", null ],
    [ "syscgetsetupinfof_a", "interfacefortran_1_1syscgetsetupinfof.xhtml#af89452107509346cb3968adad6f1c6d9", null ],
    [ "syscgetsetupinfof_ar", "interfacefortran_1_1syscgetsetupinfof.xhtml#ac3020d59c6b0721f63232f77546a302e", null ]
];