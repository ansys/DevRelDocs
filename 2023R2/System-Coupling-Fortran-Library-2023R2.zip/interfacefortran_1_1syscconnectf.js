var interfacefortran_1_1syscconnectf =
[
    [ "syscconnectf", "interfacefortran_1_1syscconnectf.xhtml#af397378cdff4f98ef3c736cdda2dc2a0", null ],
    [ "syscconnectparallelf", "interfacefortran_1_1syscconnectf.xhtml#a15b29cc1bce67f869dea1b183de9c569", null ]
];