var structSyscOutputScalarData =
[
    [ "data", "structSyscOutputScalarData.xhtml#ac6e4962585166fdc6b76161f513525f8", null ],
    [ "primitiveType", "structSyscOutputScalarData.xhtml#a8d379fbb21a0db72ca1e91725b1c4f17", null ],
    [ "size", "structSyscOutputScalarData.xhtml#a22d6699f074b01a21ee6072272cfa0f3", null ]
];