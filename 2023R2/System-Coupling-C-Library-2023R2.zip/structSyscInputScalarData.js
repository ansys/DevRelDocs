var structSyscInputScalarData =
[
    [ "data", "structSyscInputScalarData.xhtml#a1a84599e793064d8c6275084ffe16cfe", null ],
    [ "primitiveType", "structSyscInputScalarData.xhtml#ab177e62c0635afebce589c1a411144fe", null ],
    [ "size", "structSyscInputScalarData.xhtml#aab4ae5518bec7d42d01359b5459bf7e2", null ]
];