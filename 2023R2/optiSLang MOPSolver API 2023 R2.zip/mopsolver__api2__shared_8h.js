var mopsolver__api2__shared_8h =
[
    [ "DMOP2_DIMENSION_FLAG", "mopsolver__api2__shared_8h.xhtml#ae71ebc38d8f28e122d564249414ea519", [
      [ "DIM_INPUTS", "mopsolver__api2__shared_8h.xhtml#ae71ebc38d8f28e122d564249414ea519adb23389bbc1ccb64fa2bfda339aa782d", null ],
      [ "DIM_RESPONSES", "mopsolver__api2__shared_8h.xhtml#ae71ebc38d8f28e122d564249414ea519a4cbae4944616299dfcc52ddf1e490b61", null ],
      [ "DIM_CRITERIA", "mopsolver__api2__shared_8h.xhtml#ae71ebc38d8f28e122d564249414ea519a205872b5445eefc8aab6dfd4588ddd52", null ]
    ] ],
    [ "DMOP2_NAME_FLAG", "mopsolver__api2__shared_8h.xhtml#a919e4b2e211e2d3c06a2cd81f75a5993", [
      [ "NAME_INPUTS", "mopsolver__api2__shared_8h.xhtml#a919e4b2e211e2d3c06a2cd81f75a5993a79c10bd78049e47bfed6b564d27b62ad", null ],
      [ "NAME_RESPONSES", "mopsolver__api2__shared_8h.xhtml#a919e4b2e211e2d3c06a2cd81f75a5993a7b78423d9c98ddad4e690a2c3b9f8f47", null ],
      [ "NAME_CRITERIA", "mopsolver__api2__shared_8h.xhtml#a919e4b2e211e2d3c06a2cd81f75a5993a3d616f3b9eac8bbf7945fce33b42d0d8", null ]
    ] ],
    [ "DMOP2_PER_RESPONSE_FLAG", "mopsolver__api2__shared_8h.xhtml#a5d50d64a9e5bf93f7e479f274f39a2e8", [
      [ "RESP_EXTRAPOLATE", "mopsolver__api2__shared_8h.xhtml#a5d50d64a9e5bf93f7e479f274f39a2e8a2bf0649346449ad52f658321010a4356", null ],
      [ "RESP_GRADIENTS", "mopsolver__api2__shared_8h.xhtml#a5d50d64a9e5bf93f7e479f274f39a2e8a7acef09112df0227f429ceacc6d64b34", null ],
      [ "RESP_DENSITIES", "mopsolver__api2__shared_8h.xhtml#a5d50d64a9e5bf93f7e479f274f39a2e8afb1a9998534e839d59740c5d98655f57", null ],
      [ "RESP_ERRORS", "mopsolver__api2__shared_8h.xhtml#a5d50d64a9e5bf93f7e479f274f39a2e8ac7007812a879e80f3b9e14d93e715dea", null ]
    ] ],
    [ "DMOP2_RETURN_CODES", "mopsolver__api2__shared_8h.xhtml#afc0920966340b6d1cc6122f8c44b689f", [
      [ "dmop2_success", "mopsolver__api2__shared_8h.xhtml#afc0920966340b6d1cc6122f8c44b689facfba8e56f39398ccadc2b2a8d1db2a8e", null ],
      [ "dmop2_error", "mopsolver__api2__shared_8h.xhtml#afc0920966340b6d1cc6122f8c44b689fa00555fcc07f262400fc44e8e2438140a", null ],
      [ "dmop2_exception_occured", "mopsolver__api2__shared_8h.xhtml#afc0920966340b6d1cc6122f8c44b689fa72e28da48cbaeb44c40f51a78be00317", null ],
      [ "dmop2_custom_interface_not_enabled", "mopsolver__api2__shared_8h.xhtml#afc0920966340b6d1cc6122f8c44b689fa804da28b825cdd5a7ccd869542a9d749", null ],
      [ "dmop2_wrong_input_argument", "mopsolver__api2__shared_8h.xhtml#afc0920966340b6d1cc6122f8c44b689fa75b6d5d3ced1b9b9ec0ee9f96d67b4aa", null ]
    ] ],
    [ "DMOP2_SOLVE_FLAG", "mopsolver__api2__shared_8h.xhtml#a9d02108e77fa0ce32247bd4478fa2b0b", [
      [ "SOLVE_EXTRAPOLATE", "mopsolver__api2__shared_8h.xhtml#a9d02108e77fa0ce32247bd4478fa2b0babdf84129bd1eddedb34a7cb60847a038", null ],
      [ "SOLVE_RESPONSES", "mopsolver__api2__shared_8h.xhtml#a9d02108e77fa0ce32247bd4478fa2b0bab5ca18a75197776540aecf4572c1d5fe", null ],
      [ "SOLVE_CRITERIA", "mopsolver__api2__shared_8h.xhtml#a9d02108e77fa0ce32247bd4478fa2b0bae833c1cfeacab058c7651d5f52a331a3", null ],
      [ "SOLVE_DENSITIES", "mopsolver__api2__shared_8h.xhtml#a9d02108e77fa0ce32247bd4478fa2b0ba0f075abe0480ae5dba49361542105e93", null ],
      [ "SOLVE_ERRORS", "mopsolver__api2__shared_8h.xhtml#a9d02108e77fa0ce32247bd4478fa2b0ba4d0e54817eeefe0b4d3c80da29954879", null ]
    ] ],
    [ "dmop2_cleanup", "mopsolver__api2__shared_8h.xhtml#abaaf6eb148aeb3e5368597475f6b7a75", null ],
    [ "dmop2_free", "mopsolver__api2__shared_8h.xhtml#a932cf054e78fd8f1069a1ea8d9a88cbe", null ],
    [ "dmop2_get_version_str", "mopsolver__api2__shared_8h.xhtml#a3de6521ea7642d7979ad944643edea2b", null ],
    [ "dmop2_getLastError", "mopsolver__api2__shared_8h.xhtml#abd7972e7a1687d4b1708bc9fac570aa1", null ],
    [ "dmop2_set_paths_for_custom_interface", "mopsolver__api2__shared_8h.xhtml#a3b7b35bbecdf38a33b2eb150e61add8f", null ]
];