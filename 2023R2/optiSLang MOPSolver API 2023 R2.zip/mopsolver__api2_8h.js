var mopsolver__api2_8h =
[
    [ "dmop2_get_per_response", "mopsolver__api2_8h.xhtml#a15b7852cc667da87359ab69d62073526", null ],
    [ "dmop2_getCoPValuesPerResponse", "mopsolver__api2_8h.xhtml#a7812100fa3283c0d8a99ec20d7f150e3", null ],
    [ "dmop2_getDimensions", "mopsolver__api2_8h.xhtml#ac1280ce7eec776cb615b9021dde4b49c", null ],
    [ "dmop2_getFilteredStatesPerResponse", "mopsolver__api2_8h.xhtml#a95cb0c5d1a7b4f7c9f2099525c843c1a", null ],
    [ "dmop2_getInputBounds", "mopsolver__api2_8h.xhtml#af68dc3d377e7a0cfa185d7def65a242f", null ],
    [ "dmop2_getInputBoundsPerParameter", "mopsolver__api2_8h.xhtml#a3250031d1d4f5aac7d55245edb398f63", null ],
    [ "dmop2_getNames", "mopsolver__api2_8h.xhtml#af195ed8a6a545eb166ccf2cb3320c8d8", null ],
    [ "dmop2_getNamesWithDelimiter", "mopsolver__api2_8h.xhtml#a2e758e198d50d7222cf8bdf407a2b4e7", null ],
    [ "dmop2_getReferenceValuePerParameter", "mopsolver__api2_8h.xhtml#aa37255246161c9b90c89f8fd546c801e", null ],
    [ "dmop2_hasSurrogate", "mopsolver__api2_8h.xhtml#aeb725607d79714dac00a68915c3b0173", null ],
    [ "dmop2_solve", "mopsolver__api2_8h.xhtml#a4edf6d82a0e1c63e8cdc4f2f56982791", null ]
];