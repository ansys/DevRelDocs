var files_dup =
[
    [ "mopsolver.hpp", "mopsolver_8hpp_source.xhtml", null ],
    [ "mopsolver_api.h", "mopsolver__api_8h.xhtml", "mopsolver__api_8h" ],
    [ "mopsolver_api2.h", "mopsolver__api2_8h.xhtml", "mopsolver__api2_8h" ],
    [ "mopsolver_api2_hash.h", "mopsolver__api2__hash_8h_source.xhtml", null ],
    [ "mopsolver_api2_shared.h", "mopsolver__api2__shared_8h.xhtml", "mopsolver__api2__shared_8h" ],
    [ "mopsolver_api_shared.h", "mopsolver__api__shared_8h_source.xhtml", null ],
    [ "mopsolver_dlpublic.h", "mopsolver__dlpublic_8h_source.xhtml", null ]
];