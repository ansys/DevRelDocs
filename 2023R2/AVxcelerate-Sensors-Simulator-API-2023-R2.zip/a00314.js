var a00314 =
[
    [ "horizontal", "a00314.xhtml#a60d976f1081d89407364d5ca6f20a12f", null ],
    [ "vertical", "a00314.xhtml#af307fb4203ec6300ef2e4e0dafb9270c", null ]
];