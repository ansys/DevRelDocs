var a00490 =
[
    [ "camera_data", "a00490.xhtml#a856edccad58aacacc4bcba672c8e5311", null ],
    [ "camera_format", "a00490.xhtml#a7a78fc4287404ef30766c24e8ba1669b", null ]
];