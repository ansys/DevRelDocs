var a00270 =
[
    [ "beam_shape", "a00270.xhtml#a29897d2bcb736762694a1169629aa193", null ],
    [ "firing_sequence", "a00270.xhtml#affbde9ad9198b76589b18f2abbad8c51", null ],
    [ "frequency", "a00270.xhtml#a6a1412fd0d103f54ff7f78c73a89a0b6", null ],
    [ "laser_pulse", "a00270.xhtml#a42ff3ed005ff83490cf1f2ecf18db2db", null ]
];