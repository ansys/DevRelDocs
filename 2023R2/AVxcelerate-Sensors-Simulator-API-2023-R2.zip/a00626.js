var a00626 =
[
    [ "deploy_hosts", "a00626.xhtml#ae7dfdfc0987ccf6690e2ba96904cc237", null ],
    [ "local_nodes", "a00626.xhtml#a812f1b977d06f1a02ddcb2d476ebbd0b", null ]
];