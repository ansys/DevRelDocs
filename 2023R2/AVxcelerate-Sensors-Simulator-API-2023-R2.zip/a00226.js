var a00226 =
[
    [ "readout_noise_average", "a00226.xhtml#ad39ed7213fb956c2ac38fdb81656bb5d", null ],
    [ "readout_noise_standard", "a00226.xhtml#a8f6f8757d4a93479dce80c6055c90a12", null ]
];