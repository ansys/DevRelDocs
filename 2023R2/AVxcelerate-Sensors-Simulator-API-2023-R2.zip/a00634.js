var a00634 =
[
    [ "address", "a00634.xhtml#aa20b742aa8a5fa9890e1b63a7e373273", null ],
    [ "data_access_server_port", "a00634.xhtml#a1520aff7ae1ad12eef539419e2322dad", null ],
    [ "deploy_nodes", "a00634.xhtml#a69fcdb30fc547f53dcca2acfcf479096", null ],
    [ "gpu_identifiers", "a00634.xhtml#ade569ae443f506dd6f109304b4251dd6", null ],
    [ "resource_manager_port", "a00634.xhtml#a4ba0630268d1749d72664d8f7cfca19f", null ]
];