var a00670 =
[
    [ "generate_2d_bounding_boxes", "a00670.xhtml#ad7b72aaf4baf52d550c760b50d0cb5f2", null ],
    [ "generate_depth_map", "a00670.xhtml#a1e96542155b1004c8f186d96876e6880", null ],
    [ "generate_optical_flow", "a00670.xhtml#afae551176c67884716efc9edfbdc7930", null ],
    [ "generate_pixel_segmentation", "a00670.xhtml#a869dc3f1faa508a9ebfe6a24b84d19b7", null ]
];