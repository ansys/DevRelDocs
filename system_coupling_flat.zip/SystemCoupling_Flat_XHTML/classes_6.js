var searchData=
[
  ['nodedata_0',['NodeData',['../structsysc_1_1_node_data.xhtml',1,'sysc']]]
];
