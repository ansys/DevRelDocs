var searchData=
[
  ['nodedata_0',['NodeData',['../structsysc_1_1_node_data.html',1,'sysc']]]
];
