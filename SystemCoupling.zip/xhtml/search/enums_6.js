var searchData=
[
  ['primitivetype_0',['PrimitiveType',['../group___system_coupling_participant_a_p_is.html#gad3b1c73e4a63f4d292d65f3db875e844',1,'sysc']]]
];
