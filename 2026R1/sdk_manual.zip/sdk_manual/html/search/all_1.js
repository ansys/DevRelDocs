var searchData=
[
  ['2025_20r1_0',['Release notes for 2025 R1',['../changelog.xhtml#autotoc_md4',1,'']]],
  ['2025_20r2_1',['Release notes for 2025 R2',['../changelog.xhtml#autotoc_md0',1,'']]]
];
