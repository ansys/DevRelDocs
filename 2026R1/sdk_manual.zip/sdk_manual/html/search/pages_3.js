var searchData=
[
  ['getting_20started_0',['Getting started',['../getting_started.xhtml',1,'']]],
  ['glossary_1',['Glossary',['../glossary.xhtml',1,'']]]
];
