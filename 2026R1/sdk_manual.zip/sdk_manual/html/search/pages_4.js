var searchData=
[
  ['hooks_0',['Solver hooks',['../solver_hooks.xhtml',1,'']]]
];
