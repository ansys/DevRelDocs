var searchData=
[
  ['windows_0',['Build tools - Windows',['../getting_started.xhtml#autotoc_md10',1,'']]],
  ['windows_2010_1',['Windows 10',['../usage_examples.xhtml#autotoc_md125',1,'Building in Windows 10'],['../getting_started.xhtml#autotoc_md9',1,'Prerequisites for Windows 10']]]
];
