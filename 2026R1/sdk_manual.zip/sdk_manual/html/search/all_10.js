var searchData=
[
  ['near_20entity_0',['Near entity',['../glossary.xhtml#near-entity',1,'']]],
  ['notes_20for_202025_20r1_1',['Release notes for 2025 R1',['../changelog.xhtml#autotoc_md4',1,'']]],
  ['notes_20for_202025_20r2_2',['Release notes for 2025 R2',['../changelog.xhtml#autotoc_md0',1,'']]]
];
