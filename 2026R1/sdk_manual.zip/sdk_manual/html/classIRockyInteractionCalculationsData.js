var classIRockyInteractionCalculationsData =
[
    [ "get_geometry_material_index", "classIRockyInteractionCalculationsData.xhtml#a05cb28a940233bc976b806a5893c639c", null ],
    [ "get_material", "classIRockyInteractionCalculationsData.xhtml#a609eb08b9a568e07c35953bd616d9551", null ],
    [ "get_material_interaction", "classIRockyInteractionCalculationsData.xhtml#aeb94fd8ed1f75bd0523634285ad94e4d", null ],
    [ "get_material_interaction_index", "classIRockyInteractionCalculationsData.xhtml#a1cf7ad2b906aa2f033494b390522bbb3", null ],
    [ "get_number_geometry_materials", "classIRockyInteractionCalculationsData.xhtml#a986da6321cca08d20d20dbd43962a74a", null ],
    [ "get_number_particle_groups", "classIRockyInteractionCalculationsData.xhtml#ab5fb8e3d498bfc78f116eec7b53b22b8", null ],
    [ "get_particle_material_index", "classIRockyInteractionCalculationsData.xhtml#a700a3993ce6c50786c1323e0b91a7c3a", null ],
    [ "get_particle_max_sieve_size", "classIRockyInteractionCalculationsData.xhtml#ac12016128279790932537b32c1c7410d", null ],
    [ "get_particle_min_mass", "classIRockyInteractionCalculationsData.xhtml#a641adbab81c6c430aa1b0eae6eff29f4", null ],
    [ "get_particle_min_sieve_size", "classIRockyInteractionCalculationsData.xhtml#a1ce09b00f677c903a2d25426f8447300", null ]
];