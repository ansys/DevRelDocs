var classansys_1_1_cff_file_consumer =
[
    [ "~CffFileConsumer", "classansys_1_1_cff_file_consumer.xhtml#a6191ac92a63d5f2c011c89eb8902ed92", null ],
    [ "closeData", "classansys_1_1_cff_file_consumer.xhtml#a814475cf644c29548849892d5866b913", null ],
    [ "endWriting", "classansys_1_1_cff_file_consumer.xhtml#ab2d78f6543b28ae60a625e04f531c4b5", null ],
    [ "openData", "classansys_1_1_cff_file_consumer.xhtml#a5d762c0c25901b8dd1f99530752f2f7a", null ],
    [ "setAppendOn", "classansys_1_1_cff_file_consumer.xhtml#a60af0eb64e7671f46b21cfddcece6f85", null ],
    [ "setCombineContinuousZones", "classansys_1_1_cff_file_consumer.xhtml#a158ad434e28f68d5cd363dc8c87156a1", null ],
    [ "setDatasetNameOfPhase", "classansys_1_1_cff_file_consumer.xhtml#a5f7fdd3670b2952c03a82926988f880b", null ],
    [ "setDatasetNameOfVariable", "classansys_1_1_cff_file_consumer.xhtml#af9575dc31e5388b9eb6f53853dfc2b33", null ],
    [ "setOverrideSettingsOn", "classansys_1_1_cff_file_consumer.xhtml#a873ab57b9489bdb71138f401213cfe35", null ],
    [ "setWriteSettingsOn", "classansys_1_1_cff_file_consumer.xhtml#aeded6d881477600213f0be4d367f6184", null ],
    [ "startWriting", "classansys_1_1_cff_file_consumer.xhtml#aff7fae604a6a9ccb6318096c895ec851", null ],
    [ "startWriting", "classansys_1_1_cff_file_consumer.xhtml#a71d96df4941d3ed83f5b33dddb062fdd", null ],
    [ "writeCommonSettings", "classansys_1_1_cff_file_consumer.xhtml#a8a83b4f80d7b1db1016c3f94e09d976c", null ],
    [ "writeGenericSettings", "classansys_1_1_cff_file_consumer.xhtml#ab69fe29cc9758ddec44f5b25cdc7b89b", null ]
];