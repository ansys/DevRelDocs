var classansys_1_1_cff_version =
[
    [ "CffVersion", "classansys_1_1_cff_version.xhtml#a9274e8b4fd14afdc71d46fb66dc405cd", null ],
    [ "~CffVersion", "classansys_1_1_cff_version.xhtml#a3ee0c0a7f11906983671c5b693860430", null ],
    [ "ansysApplicationVersion", "classansys_1_1_cff_version.xhtml#a839a336d8430485ed81d1bafdc6671cc", null ],
    [ "apiVersionAsString", "classansys_1_1_cff_version.xhtml#aba256dcc082e509be94d1c332a88f1dc", null ],
    [ "copyright", "classansys_1_1_cff_version.xhtml#a36112f9aea74b547d2d238c447ab89a9", null ],
    [ "getMajor", "classansys_1_1_cff_version.xhtml#a6eac2194e4845de8b13fc6654a6061db", null ],
    [ "getMinor", "classansys_1_1_cff_version.xhtml#ae580f388b6c6dd9e68db8433749da81e", null ],
    [ "getPatch", "classansys_1_1_cff_version.xhtml#ad1139980443eb9200c7c37e1a48433ac", null ],
    [ "getSHA", "classansys_1_1_cff_version.xhtml#a054bb0e156cf7a084145cd536399fcf1", null ],
    [ "isBeta", "classansys_1_1_cff_version.xhtml#a49bba0b8a37276210f7e51c425ee4788", null ]
];