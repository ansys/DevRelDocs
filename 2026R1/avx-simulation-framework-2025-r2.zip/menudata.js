/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var menudata={children:[
{text:"Introduction",url:"index.xhtml"},
{text:"Getting started",url:"md_documentation_2markdown_2getting__started.xhtml"},
{text:"Installation",url:"md_documentation_2markdown_2installation.xhtml"},
{text:"License setup",url:"md_documentation_2markdown_2setup__license.xhtml"},
{text:"Command line tool",url:"md_documentation_2markdown_2command__line__tool.xhtml"},
{text:"Simulation scheduling",url:"md_documentation_2markdown_2simulation__scheduling.xhtml"},
{text:"Customized standalone activity",url:"md_documentation_2markdown_2customized__activity.xhtml"},
{text:"Customized KPI evaluation",url:"md_documentation_2markdown_2customized__kpi__evaluator.xhtml"},
{text:"AVxcelerate Sensor co-simulation",url:"md_documentation_2markdown_2avx__sensor__co__simulation.xhtml"},
{text:"Performance Profiler",url:"md_documentation_2markdown_2performance__profiler.xhtml"},
{text:"Change Logs",url:"md_documentation_2markdown_2change__log.xhtml"},
{text:"Namespaces",url:"namespaces.xhtml",children:[
{text:"Namespace List",url:"namespaces.xhtml"},
{text:"Namespace Members",url:"namespacemembers.xhtml",children:[
{text:"All",url:"namespacemembers.xhtml"},
{text:"Functions",url:"namespacemembers_func.xhtml"}]}]},
{text:"Classes",url:"annotated.xhtml",children:[
{text:"Class List",url:"annotated.xhtml"},
{text:"Class Index",url:"classes.xhtml"},
{text:"Class Hierarchy",url:"inherits.xhtml"},
{text:"Class Members",url:"functions.xhtml",children:[
{text:"All",url:"functions.xhtml",children:[
{text:"a",url:"functions.xhtml#index_a"},
{text:"b",url:"functions_b.xhtml#index_b"},
{text:"c",url:"functions_c.xhtml#index_c"},
{text:"d",url:"functions_d.xhtml#index_d"},
{text:"e",url:"functions_e.xhtml#index_e"},
{text:"f",url:"functions_f.xhtml#index_f"},
{text:"g",url:"functions_g.xhtml#index_g"},
{text:"i",url:"functions_i.xhtml#index_i"},
{text:"k",url:"functions_k.xhtml#index_k"},
{text:"l",url:"functions_l.xhtml#index_l"},
{text:"m",url:"functions_m.xhtml#index_m"},
{text:"o",url:"functions_o.xhtml#index_o"},
{text:"p",url:"functions_p.xhtml#index_p"},
{text:"r",url:"functions_r.xhtml#index_r"},
{text:"s",url:"functions_s.xhtml#index_s"},
{text:"t",url:"functions_t.xhtml#index_t"},
{text:"v",url:"functions_v.xhtml#index_v"},
{text:"w",url:"functions_w.xhtml#index_w"},
{text:"~",url:"functions_~.xhtml#index__7E"}]},
{text:"Functions",url:"functions_func.xhtml",children:[
{text:"a",url:"functions_func.xhtml#index_a"},
{text:"b",url:"functions_func_b.xhtml#index_b"},
{text:"c",url:"functions_func_c.xhtml#index_c"},
{text:"d",url:"functions_func_d.xhtml#index_d"},
{text:"e",url:"functions_func_e.xhtml#index_e"},
{text:"f",url:"functions_func_f.xhtml#index_f"},
{text:"g",url:"functions_func_g.xhtml#index_g"},
{text:"i",url:"functions_func_i.xhtml#index_i"},
{text:"l",url:"functions_func_l.xhtml#index_l"},
{text:"p",url:"functions_func_p.xhtml#index_p"},
{text:"r",url:"functions_func_r.xhtml#index_r"},
{text:"s",url:"functions_func_s.xhtml#index_s"},
{text:"t",url:"functions_func_t.xhtml#index_t"},
{text:"w",url:"functions_func_w.xhtml#index_w"},
{text:"~",url:"functions_func_~.xhtml#index__7E"}]},
{text:"Variables",url:"functions_vars.xhtml"},
{text:"Typedefs",url:"functions_type.xhtml"}]}]},
{text:"Files",url:"files.xhtml",children:[
{text:"File List",url:"files.xhtml"}]}]}
