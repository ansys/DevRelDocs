var class_open_t_d_1_1_thermo_prop_alias_manager =
[
    [ "CreateOrUpdateAlias", "class_open_t_d_1_1_thermo_prop_alias_manager.xhtml#a4cd7570cb13aff1869521d17e44e8543", null ],
    [ "DeleteAlias", "class_open_t_d_1_1_thermo_prop_alias_manager.xhtml#a7a41cd2c0639dbe359ff3996275f3ee2", null ],
    [ "GetAlias", "class_open_t_d_1_1_thermo_prop_alias_manager.xhtml#a82402d4a608cdea887569d42b8ec319f", null ],
    [ "GetAliases", "class_open_t_d_1_1_thermo_prop_alias_manager.xhtml#ace6ba000925019b0c63dff35bc3ae5d5", null ],
    [ "RenameAlias", "class_open_t_d_1_1_thermo_prop_alias_manager.xhtml#a65680f2836bb851472b3341be6171279", null ]
];