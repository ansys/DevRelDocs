var class_open_t_d_1_1_u_d_f_a =
[
    [ "UdfaInitType", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677b", [
      [ "SINGLE", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba0679273e201afd0bf57af3961f8a23b8", null ],
      [ "MULTIPLE", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba65f405ff27981239b3c296a487786b85", null ],
      [ "FORTRAN", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba36b29acfc7b63ef39d78dd854034ebc5", null ],
      [ "NODE_LOC", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba6b9d763ce3dcf3914e3bcf20ca0e75fa", null ],
      [ "NODE_AREA", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677bad5bf43adaa92605c632480dcc817bace", null ],
      [ "NODE_MASS", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba01c02dda23ed3c8505252b8c3e040b4d", null ],
      [ "NODE_VOL", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba23160bca509bedefac7d2960358b9a5c", null ],
      [ "LUMP_TOTAL_TP", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba5b3ae057d5e4dcf9627ac9e0801de8de", null ],
      [ "LUMP_MASS", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba405e65b42bcfbd0ca3d5f264dc3e1813", null ],
      [ "PATH_DPS", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677bac0edd5f36d988ccb349b958f94d25e76", null ],
      [ "PATH_VEL", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677badd4dd3c71847b5dfa18157d87dab8f30", null ],
      [ "LUMP_STPA", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677baf1eb3803d14973208ae7ac703d9538f0", null ],
      [ "PATH_VOLUMETRIC", "class_open_t_d_1_1_u_d_f_a.xhtml#a676ae086214c878ba8c707557ef6677ba3fa4237d8cf57e7e9091f2227b1745a2", null ]
    ] ],
    [ "UdfaType", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346b", [
      [ "USER_INPUT", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346bab80683b77da929c917a6a968c80fa6a7", null ],
      [ "LUMPS", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346bad8a1c8262d7c5645bf7609dfc96e1312", null ],
      [ "PATHS", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346ba253084ce40bb5281df39844d75a267b2", null ],
      [ "TIES", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346ba2dfd6fe8a950248e5a611bcbcb9244ef", null ],
      [ "IFACES", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346baeca0b2b3cc67ffdb64d082e624befd86", null ],
      [ "NODES", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346ba91333d9dc1ff3a19e07d7d7bd34e18ed", null ],
      [ "CONDS", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346ba498725ab42bd4871ec745891a063b070", null ],
      [ "FTIES", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346baa5bb937f6d12f9c3dc5d0cc0eeebd36a", null ],
      [ "FLUID_SUB", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346ba0ab901c6621281363acb4071862d5f2b", null ],
      [ "THERMAL_SUB", "class_open_t_d_1_1_u_d_f_a.xhtml#ae59990c10a37d1a683c1347bd10a346ba9686f3c94a92b1a814fec97898734eba", null ]
    ] ],
    [ "ValueType", "class_open_t_d_1_1_u_d_f_a.xhtml#adf0c82beb5e1815b6ba807eafcaf569a", [
      [ "REAL", "class_open_t_d_1_1_u_d_f_a.xhtml#adf0c82beb5e1815b6ba807eafcaf569aa8cf125b0e31559ba75a9d9b4f818a554", null ],
      [ "INT", "class_open_t_d_1_1_u_d_f_a.xhtml#adf0c82beb5e1815b6ba807eafcaf569aa53f93baa3057821107c750323892fa92", null ],
      [ "CHAR", "class_open_t_d_1_1_u_d_f_a.xhtml#adf0c82beb5e1815b6ba807eafcaf569aa027acd3aa6b1dd7f26119d3cf0f9a063", null ],
      [ "LOGICAL", "class_open_t_d_1_1_u_d_f_a.xhtml#adf0c82beb5e1815b6ba807eafcaf569aa3ac41e252379806a89e97a5755b95011", null ]
    ] ],
    [ "UDFA", "class_open_t_d_1_1_u_d_f_a.xhtml#a5d8b5da33f5e7e6732a36e4226bf1f69", null ],
    [ "ToString", "class_open_t_d_1_1_u_d_f_a.xhtml#af23249ee344e3edbbfb9d6a2721f1dd7", null ],
    [ "Validate", "class_open_t_d_1_1_u_d_f_a.xhtml#af969f26c306cc8262f48257a54cd02cc", null ],
    [ "DoSave", "class_open_t_d_1_1_u_d_f_a.xhtml#a1da550bcbf82c1bab2513440e4771612", null ],
    [ "DoWarn", "class_open_t_d_1_1_u_d_f_a.xhtml#ad8bfdd36385dd1cd0a23bbe7af7ee1a9", null ],
    [ "DynamicUpdates", "class_open_t_d_1_1_u_d_f_a.xhtml#a93fb4b00bb1a6093cae19dcfc7f0273c", null ],
    [ "Enabled", "class_open_t_d_1_1_u_d_f_a.xhtml#a76ebf25995347c8a48a490fa6e6f6600", null ],
    [ "EnabledExpression", "class_open_t_d_1_1_u_d_f_a.xhtml#a03be85197d316df505dd83613b07afd1", null ],
    [ "IndexName", "class_open_t_d_1_1_u_d_f_a.xhtml#ae21be899237fcb21b213798f830d408a", null ],
    [ "InitData", "class_open_t_d_1_1_u_d_f_a.xhtml#a667dad66defeae8e39152f92fe5c564e", null ],
    [ "InitType", "class_open_t_d_1_1_u_d_f_a.xhtml#a1386129ea5288711de91717555dfcfd8", null ],
    [ "Length", "class_open_t_d_1_1_u_d_f_a.xhtml#a68b34212619e8a4c2e9b3f154f9a56f6", null ],
    [ "LengthExpression", "class_open_t_d_1_1_u_d_f_a.xhtml#adc954e27840082cd46f2c60f48b47764", null ],
    [ "Name", "class_open_t_d_1_1_u_d_f_a.xhtml#a3a107443bb272c4256546e332e61f374", null ],
    [ "Type", "class_open_t_d_1_1_u_d_f_a.xhtml#a16b121ef66f079b3b547ed091e0587c9", null ],
    [ "UdcaStringLength", "class_open_t_d_1_1_u_d_f_a.xhtml#a551045d384975bbf6fbb42cde0151bb1", null ],
    [ "UdcaStringLengthExpression", "class_open_t_d_1_1_u_d_f_a.xhtml#ae5dd0533614c970e7d5403c7b9b16fea", null ],
    [ "UdfaValueType", "class_open_t_d_1_1_u_d_f_a.xhtml#a77962116ea3b6b58e3e2da11a5efdde9", null ]
];