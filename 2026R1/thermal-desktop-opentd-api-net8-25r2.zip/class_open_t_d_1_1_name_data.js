var class_open_t_d_1_1_name_data =
[
    [ "NameData", "class_open_t_d_1_1_name_data.xhtml#a41cceae36eba8a11451505f51289a6db", null ],
    [ "NameData", "class_open_t_d_1_1_name_data.xhtml#a9bc837ecce204a3b524b46a551a186cf", null ],
    [ "ToString", "class_open_t_d_1_1_name_data.xhtml#a33e95348de7aa78c94767037fb70321d", null ],
    [ "Id", "class_open_t_d_1_1_name_data.xhtml#a311068e52dee7ed10338e7be73be8f61", null ],
    [ "Submodel", "class_open_t_d_1_1_name_data.xhtml#afdde8f5aff3e0727dbf5965535847b2e", null ]
];