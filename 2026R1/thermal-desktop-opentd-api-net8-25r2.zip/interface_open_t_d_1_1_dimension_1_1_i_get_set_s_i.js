var interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i =
[
    [ "GetValueSI", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i.xhtml#ac97df4644cd11b65e5f418ece59e455c", null ],
    [ "SetValueSI", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i.xhtml#a4d1c83f4fab3ac28f5af8c6ee14d2ee8", null ]
];