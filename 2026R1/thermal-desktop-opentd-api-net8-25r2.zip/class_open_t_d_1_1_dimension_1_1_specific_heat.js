var class_open_t_d_1_1_dimension_1_1_specific_heat =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_specific_heat.xhtml#af86ae201f0e11924baff936bf2f800e9", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_specific_heat.xhtml#a8d86140734b42ea9f273a0f57f13c0fd", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_specific_heat.xhtml#aee705a66b5ac1f00aa24e859b8c2b077", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_specific_heat.xhtml#a638813647271b764ccc53c880cfb93a5", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_specific_heat.xhtml#abf8f41cb5581766df52002a0b5f01bc8", null ]
];