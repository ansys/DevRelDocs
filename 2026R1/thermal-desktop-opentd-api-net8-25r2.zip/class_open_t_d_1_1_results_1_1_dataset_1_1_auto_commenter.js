var class_open_t_d_1_1_results_1_1_dataset_1_1_auto_commenter =
[
    [ "AutoCommenter", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_commenter.xhtml#a00d24205a4b0fcd056a27396da26e45a", null ],
    [ "AutoCommenter", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_commenter.xhtml#ab19b494822fe29f24fd7b9a5b8d19949", null ],
    [ "ToString", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_commenter.xhtml#aae23711b82bd1c2f62db7a09c05faf2c", null ],
    [ "Comment", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_commenter.xhtml#a675c57643efb6d80f52107ff759a4976", null ],
    [ "InternalSuggestedComment", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_commenter.xhtml#afbbe2f52794eef885655b38a38293085", null ],
    [ "SelfSuggestedComment", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_commenter.xhtml#a0779e86e4bec12fd03a54f330740044c", null ]
];