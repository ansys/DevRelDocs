var class_open_t_d_1_1_dimension_1_1_entropy =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_entropy.xhtml#af930f7df6622d76eded66c436b3b0fbb", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_entropy.xhtml#acdd4dd800b9b500c0461f09fb5ad241b", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_entropy.xhtml#a56aa25b4e1a5a08c5b1e5d9d049f5c72", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_entropy.xhtml#ae1d06d4c3b31caa7962f955fd2a5e6d9", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_entropy.xhtml#a886def8428f1e7cc36043351e7971ec3", null ]
];