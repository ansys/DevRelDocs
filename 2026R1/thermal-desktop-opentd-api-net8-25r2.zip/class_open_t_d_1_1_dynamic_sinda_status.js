var class_open_t_d_1_1_dynamic_sinda_status =
[
    [ "DynamicSindaStatus", "class_open_t_d_1_1_dynamic_sinda_status.xhtml#a8abbea5e6091c819c80beec2125d3b16", null ],
    [ "GetMessages", "class_open_t_d_1_1_dynamic_sinda_status.xhtml#a06b9be58f264800010af40b5eaae088c", null ]
];