var class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_object_info_base =
[
    [ "ObjectInfoBase", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_object_info_base.xhtml#a00f38a3a851b4899195dc1d55cfd1104", null ],
    [ "ItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_object_info_base.xhtml#a64b2f2fc8694f654db6940fd73fac7e4", null ],
    [ "SindaName", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_object_info_base.xhtml#a19e3b5c549147bdf7898b596bced38db", null ]
];