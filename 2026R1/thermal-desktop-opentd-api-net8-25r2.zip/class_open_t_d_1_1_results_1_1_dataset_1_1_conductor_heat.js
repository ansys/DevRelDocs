var class_open_t_d_1_1_results_1_1_dataset_1_1_conductor_heat =
[
    [ "ConductorInfo", "class_open_t_d_1_1_results_1_1_dataset_1_1_conductor_heat.xhtml#a9eddbb83dffaf15d53d21f44a761523b", null ],
    [ "G", "class_open_t_d_1_1_results_1_1_dataset_1_1_conductor_heat.xhtml#a66c42e7834c3ce4db0129d2833edc6d5", null ],
    [ "Heatrate", "class_open_t_d_1_1_results_1_1_dataset_1_1_conductor_heat.xhtml#a8c3557f7ce044e32984fe2d2893bd4d5", null ],
    [ "ToTemp", "class_open_t_d_1_1_results_1_1_dataset_1_1_conductor_heat.xhtml#ab8f7a3f65443e78a3476bda7ab723a0d", null ]
];