var class_open_t_d_1_1_results_1_1_dataset_1_1_node_conductor_heatrates =
[
    [ "Heatrates", "class_open_t_d_1_1_results_1_1_dataset_1_1_node_conductor_heatrates.xhtml#a2aeb5c9c390f7d16716805cafe87fc18", null ],
    [ "NodeInfo", "class_open_t_d_1_1_results_1_1_dataset_1_1_node_conductor_heatrates.xhtml#a1c389901898f133e27bc83fb8e4ae7d8", null ]
];