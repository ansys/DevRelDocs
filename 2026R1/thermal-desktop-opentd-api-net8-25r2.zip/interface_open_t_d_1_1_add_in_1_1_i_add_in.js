var interface_open_t_d_1_1_add_in_1_1_i_add_in =
[
    [ "Run", "interface_open_t_d_1_1_add_in_1_1_i_add_in.xhtml#aa68234b2d46273f6e1d8842f96dc5309", null ],
    [ "Author", "interface_open_t_d_1_1_add_in_1_1_i_add_in.xhtml#a89203a754ee00874366222687a7d7a87", null ],
    [ "Command", "interface_open_t_d_1_1_add_in_1_1_i_add_in.xhtml#a929a1c354df6e330bb54c2c432cf0616", null ],
    [ "Description", "interface_open_t_d_1_1_add_in_1_1_i_add_in.xhtml#ae678f93af807b5980623eb5afc181c82", null ],
    [ "Name", "interface_open_t_d_1_1_add_in_1_1_i_add_in.xhtml#a32434de3a9c57bbac6b8ca307df40e1d", null ],
    [ "ShortDescription", "interface_open_t_d_1_1_add_in_1_1_i_add_in.xhtml#aa392c30735a48f30e755e50d8278a1e1", null ]
];