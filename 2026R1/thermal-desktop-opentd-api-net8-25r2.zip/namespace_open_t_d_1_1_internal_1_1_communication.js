var namespace_open_t_d_1_1_internal_1_1_communication =
[
    [ "AdditionalUnitsSettings", "class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings.xhtml", "class_open_t_d_1_1_internal_1_1_communication_1_1_additional_units_settings" ],
    [ "ITdCommander", "interface_open_t_d_1_1_internal_1_1_communication_1_1_i_td_commander.xhtml", "interface_open_t_d_1_1_internal_1_1_communication_1_1_i_td_commander" ],
    [ "StatusData", "class_open_t_d_1_1_internal_1_1_communication_1_1_status_data.xhtml", "class_open_t_d_1_1_internal_1_1_communication_1_1_status_data" ]
];