var class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype =
[
    [ "ValueTypes", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a0ee2130fc810896f5b6e120e72302dd1", [
      [ "DOUBLE", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a0ee2130fc810896f5b6e120e72302dd1afd3e4ece78a7d422280d5ed379482229", null ],
      [ "INTEGER", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a0ee2130fc810896f5b6e120e72302dd1a5d5cd46919fa987731fb2edefe0f2a0c", null ],
      [ "STRING", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a0ee2130fc810896f5b6e120e72302dd1a63b588d5559f64f89a416e656880b949", null ],
      [ "BOOL", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a0ee2130fc810896f5b6e120e72302dd1aa97b2c144243b2b9d2c593ec268b62f5", null ]
    ] ],
    [ "DataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a3f20420a1ead7a89083a2158e3f36fdd", null ],
    [ "DataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a21526e8be300995b9cc0b67fc721547f", null ],
    [ "DataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#ab5309b0de8ed90e2661351ed729e23e5", null ],
    [ "DataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a6f91b89c3cadcb819047df872790d30d", null ],
    [ "DataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a07826a317459e124b6c2ab0cd77d631f", null ],
    [ "DataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#ae28e8ce7e6ab2363a1ee324a7fd5477e", null ],
    [ "DataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a17f4e988834a1ea43730f829d453b80e", null ],
    [ "Equals", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a2d6a1daf194479f6782f73f22b29e1f4", null ],
    [ "Equals", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#afd1f43d217a9030e8dac9501e57af1c3", null ],
    [ "GetFullStandardDataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#ac544a66fc2de1335978b6103791cb4b8", null ],
    [ "GetHashCode", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a5bad72d44686f88d9df1a43e7e71920b", null ],
    [ "SetFrom", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a427255a73a671371ca506af30396a50e", null ],
    [ "ToString", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a622c2e8a189523712a6785afd559b743", null ],
    [ "BaseSindaDesignator", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a962050613a2b82b38fe719fff3f1d701", null ],
    [ "DataType", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#ac7556d886054b37ffeb65e75efb08655", null ],
    [ "DataTypeFamily", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#aa90da27fbcc4b823cf13051da3f42ea4", null ],
    [ "Description", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a2e2dadf86b64ec8e3086ce6be5b6ec9f", null ],
    [ "Dimension", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#ab1d77dd3490069d039fb983a32d130b0", null ],
    [ "FluidConstituent", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a8fa85e69d45708237d82fed3e5739cb1", null ],
    [ "IsDimensionalOnlyIfPositive", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a13fb31000083f986cfef9baa2c6603ff", null ],
    [ "IsUDFA", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a6af0fcb50ac699fb2c3d4e68645d0361", null ],
    [ "SindaDesignator", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a93fb915a628c2edab67f95101772eed5", null ],
    [ "StandardDataSubtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#aaa31a2d72fe63076f3d8cca9d15baf65", null ],
    [ "ValueType", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_subtype.xhtml#a46f7ee851ecca02fc13ffe4632e97334", null ]
];