var class_open_t_d_1_1_user_interface_1_1_write_event_args =
[
    [ "WriteEventArgs", "class_open_t_d_1_1_user_interface_1_1_write_event_args.xhtml#a58f090726040a6370de54229dc6d8628", null ],
    [ "ToString", "class_open_t_d_1_1_user_interface_1_1_write_event_args.xhtml#ad33ec3ebcaee9b19caba81feecd6080e", null ],
    [ "Message", "class_open_t_d_1_1_user_interface_1_1_write_event_args.xhtml#ac741f57834d7ca5837ceb29b408176be", null ]
];