var class_open_t_d_1_1_results_1_1_dataset_1_1_compare_data =
[
    [ "CompareData", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_data.xhtml#a6bc68216eb0cfbed89a75fc670407733", null ],
    [ "Compare", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_data.xhtml#aa6639e6e56e1fe2f7e1182f70d51b40b", null ],
    [ "ComparerInput", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_data.xhtml#ab28b92faca48552bd62d7b4ecca18215", null ],
    [ "ComparerOutput", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_data.xhtml#ad5d75637e9bd0c8a2d1f3f575dedcaaf", null ]
];