var class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager =
[
    [ "UDFAManager", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager.xhtml#a44328e6f093b78291e59970507c5fd0f", null ],
    [ "GetAsDoubles", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager.xhtml#a6aafb5b84b3e80fdfb84a1def32bc6d0", null ],
    [ "GetCharacterData", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager.xhtml#aaf9ab6d29cd9289cc50d6c5326880c74", null ],
    [ "GetCharUdcaData", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager.xhtml#a15f3dbb94e1aa52653b4205477f50c8a", null ],
    [ "GetDescriptor", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager.xhtml#a3cf6a0fda8fd759bdbcc633da2266277", null ],
    [ "GetDescriptorsAtRecord", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager.xhtml#a502f5bd4598103fb60ce3d4631f68167", null ],
    [ "Descriptors", "class_open_t_d_1_1_results_1_1_dataset_1_1_u_d_f_a_manager.xhtml#a83a33ab26aea0d9adb8bde8477b4d079", null ]
];