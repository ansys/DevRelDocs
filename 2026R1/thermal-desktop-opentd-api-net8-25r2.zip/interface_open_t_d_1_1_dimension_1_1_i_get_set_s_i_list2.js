var interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i_list2 =
[
    [ "GetValuesSI", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i_list2.xhtml#a8ebfed26ce7a1086551fb60ea7cace53", null ],
    [ "SetValuesSI", "interface_open_t_d_1_1_dimension_1_1_i_get_set_s_i_list2.xhtml#ad93a4f39d5ebce1d896759775499e9e6", null ]
];