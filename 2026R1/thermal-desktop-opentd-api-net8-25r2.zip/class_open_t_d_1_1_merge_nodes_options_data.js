var class_open_t_d_1_1_merge_nodes_options_data =
[
    [ "KeepMethods", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a8be592f0db9586c3ce94bde76fabf87a", [
      [ "FIRST_SELECTED", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a8be592f0db9586c3ce94bde76fabf87aa34aedc2929ff3329e63c8962a664a854", null ],
      [ "SMALLEST_NODE_ID", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a8be592f0db9586c3ce94bde76fabf87aa587103a777c80fe92726add93447ccd6", null ],
      [ "LARGEST_NODE_ID", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a8be592f0db9586c3ce94bde76fabf87aadcccca4c6ecda031d0f914996a7eaa15", null ],
      [ "LESSER_SUBMODEL", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a8be592f0db9586c3ce94bde76fabf87aa906c147492fe38232701bd79eae2aa02", null ],
      [ "GREATER_SUBMODEL", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a8be592f0db9586c3ce94bde76fabf87aa2e0693bc605cc8b13601e72cd44c35b9", null ]
    ] ],
    [ "MergeNodesOptionsData", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#ac158b7c4551e6d86d448868b823454a1", null ],
    [ "KeepMethod", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a74032590bdc6e0d4a857f0b31431103a", null ],
    [ "NodeHandles", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a30fcf9714ebac461a0ac4d9a6a6155e2", null ],
    [ "Tolerance", "class_open_t_d_1_1_merge_nodes_options_data.xhtml#a649b11829de43cf158ceaf6880d059ea", null ]
];