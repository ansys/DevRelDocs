var interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_i_face_info =
[
    [ "FromLump", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_i_face_info.xhtml#a0e4e462965b74d47ed4345cf8083db1f", null ],
    [ "IFaceType", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_i_face_info.xhtml#a71ca3d23c0b5eb0f11f2e5ef17b2db63", null ],
    [ "ItemIdentifier", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_i_face_info.xhtml#aecda9a8daeb6a4deb0004989c234f6da", null ],
    [ "SindaName", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_i_face_info.xhtml#a3ab97edc014acb89da92ca8b3e1b8a32", null ],
    [ "ToLump", "interface_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_i_i_face_info.xhtml#af00d1e4e79ec5e9cb316a32954232b56", null ]
];