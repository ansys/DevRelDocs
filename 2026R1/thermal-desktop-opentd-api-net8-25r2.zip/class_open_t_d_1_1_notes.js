var class_open_t_d_1_1_notes =
[
    [ "Clear", "class_open_t_d_1_1_notes.xhtml#a84b5c7fe251f3cb1fb29a7cadfb9709d", null ],
    [ "CreateIn", "class_open_t_d_1_1_notes.xhtml#a89cd633b1316b0392e22797aa5b6842c", null ],
    [ "SetFrom", "class_open_t_d_1_1_notes.xhtml#aa2e0aa2793e95a56891ef59fb4843ca2", null ],
    [ "ToString", "class_open_t_d_1_1_notes.xhtml#a1caf186a5c2d4169b19ab249dcbe51ed", null ],
    [ "Update", "class_open_t_d_1_1_notes.xhtml#aa4fdef4e70614eff9cdf673ced3aa505", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_notes.xhtml#aef99ba55e3338dec6b7c6189f52ea97a", null ],
    [ "UpdateIn", "class_open_t_d_1_1_notes.xhtml#a1e5228ce309c9a85ec09e8119318024d", null ],
    [ "TdProxy", "class_open_t_d_1_1_notes.xhtml#a0da16592e6b635ca0def27b355d669b3", null ],
    [ "_HasPassword", "class_open_t_d_1_1_notes.xhtml#a04223c780b5be6788d5b5749423de92f", null ],
    [ "HasPassword", "class_open_t_d_1_1_notes.xhtml#a842687ed8e45c7c58d936e5c1018f7fe", null ],
    [ "Passwords", "class_open_t_d_1_1_notes.xhtml#a7cef843e6ba39c7cc1aada07e7610f71", null ],
    [ "ShowOnStartup", "class_open_t_d_1_1_notes.xhtml#a7b67ce1f8ad433e6024bce4e1e4b2560", null ],
    [ "Texts", "class_open_t_d_1_1_notes.xhtml#a4abe42497a0695230d087aadcc86e32f", null ],
    [ "Titles", "class_open_t_d_1_1_notes.xhtml#ad7a3f365e39969dba86c42fcaa4dc115", null ]
];