var class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier =
[
    [ "Types", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a75abc6059eea508fdd1d7fa0142a4c8c", [
      [ "NOT_SET", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a75abc6059eea508fdd1d7fa0142a4c8ca1c250a21210b7b88a14db9a0cbe71162", null ],
      [ "SUBMODEL_ID", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a75abc6059eea508fdd1d7fa0142a4c8caabacc032c6e4b86b87af952de7d4da9b", null ],
      [ "RECORDNUM", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a75abc6059eea508fdd1d7fa0142a4c8ca3d4c90ed0ed94f56426a5ae16b1f15d4", null ],
      [ "REGISTER", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a75abc6059eea508fdd1d7fa0142a4c8cad17455cfcb88a53f1603fb817e09c2d6", null ],
      [ "CONSTRAINT", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a75abc6059eea508fdd1d7fa0142a4c8cae0f588affe0abe2e0565de8a962c4502", null ],
      [ "RELIABILITY", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a75abc6059eea508fdd1d7fa0142a4c8cabc19a8994086babbb8f14c370ef36052", null ]
    ] ],
    [ "ItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#aeb5322c9e898d8f1ff2c2ddf5e71ae91", null ],
    [ "ItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a871a21d1fcbf28ace2a02763caa64c5e", null ],
    [ "ItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a8661e2e5abc7e37bdb357e5533b129ae", null ],
    [ "Equals", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#aea136a40e0140d4023e434e874a91b70", null ],
    [ "GetHashCode", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a3006f2eac0b1e924586a6f9187245046", null ],
    [ "GetSelfSuggestedComment", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#aba8bda64b10d88d0dfce763241ad0ff6", null ],
    [ "ToString", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a81b493c8364da13ad11755e7dad7d548", null ],
    [ "AutoCommenter", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a2f5b3069c2e24c0b1a4452dbdabb7b2d", null ],
    [ "Comment", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a1ed5a006a99acd1d66ef39802542f7c2", null ],
    [ "Id", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a49d62313038676b2753e247d78d191b6", null ],
    [ "InternalSuggestedComment", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a06ed076482326fb902657eadbb5eed2d", null ],
    [ "RecordNum", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#aef473fc1376c6364f96d7f7b07c8b90f", null ],
    [ "RegisterName", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a564419699de6c649fdb467e5645aca86", null ],
    [ "Submodel", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#a2f7f06ebe8aae6c61e84f508f4a4632d", null ],
    [ "Type", "class_open_t_d_1_1_results_1_1_dataset_1_1_item_identifier.xhtml#abb088817f11381c0cc3cca0260a78e9f", null ]
];