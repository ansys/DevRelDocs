var structIRockyGeometryMotionData =
[
    [ "get_force", "structIRockyGeometryMotionData.xhtml#a5be8af9c351470d287879e3d6f2a10e9", null ],
    [ "get_id", "structIRockyGeometryMotionData.xhtml#a21c87d2c5d4ad69dfd28651613888be7", null ],
    [ "get_moment", "structIRockyGeometryMotionData.xhtml#af213ddfd08829027f4c45d73cf566ff1", null ],
    [ "get_name", "structIRockyGeometryMotionData.xhtml#ae4a43219e823a55f3ced79f234d7a6d9", null ],
    [ "get_orientation_euler_angles", "structIRockyGeometryMotionData.xhtml#a0dbec31c54d9c33096a0841ac1379fc2", null ],
    [ "get_orientation_quaternion", "structIRockyGeometryMotionData.xhtml#a1a5cc239a4d3485280530fc6a46fe9d4", null ],
    [ "get_position", "structIRockyGeometryMotionData.xhtml#ac676748d6121c999c4d5097ab7246e08", null ],
    [ "get_rotational_velocity", "structIRockyGeometryMotionData.xhtml#ad0aa494b8066b46a6d983031d1a53538", null ],
    [ "get_translational_velocity", "structIRockyGeometryMotionData.xhtml#a08d097c2e959733cb32c365c3fb2eef7", null ],
    [ "has_linked_motion_frame", "structIRockyGeometryMotionData.xhtml#a03b51d01d3dcaaff8bfbd132e92370e7", null ],
    [ "set_orientation", "structIRockyGeometryMotionData.xhtml#a7169363d2fe6b5631ce18293cb31144b", null ],
    [ "set_orientation_angles", "structIRockyGeometryMotionData.xhtml#a059a62e2d9453660725a0dc88313c73c", null ],
    [ "set_position", "structIRockyGeometryMotionData.xhtml#ab3fc0d338a140c8ca95b78bd2e8c4c94", null ],
    [ "set_rotational_velocity", "structIRockyGeometryMotionData.xhtml#a90073262648b9550296f899fc4e85127", null ],
    [ "set_translational_velocity", "structIRockyGeometryMotionData.xhtml#a4f37dc923051f58381e6268199936eac", null ]
];