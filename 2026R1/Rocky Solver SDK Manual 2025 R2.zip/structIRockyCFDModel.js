var structIRockyCFDModel =
[
    [ "get_coupling_mode", "structIRockyCFDModel.xhtml#a121e67b3f5efdd1783a32a7fa642080c", null ],
    [ "get_fluid_scalars", "structIRockyCFDModel.xhtml#a001b18af80c99c01ce4baa357bac4977", null ],
    [ "get_phase_names", "structIRockyCFDModel.xhtml#a6bc367fb97d56786d71d89351957a2a1", null ],
    [ "get_primary_phase_name", "structIRockyCFDModel.xhtml#a83c9a597793b791d1e42e0756ddddb06", null ],
    [ "get_species_names", "structIRockyCFDModel.xhtml#aac7f217cdfc15f0dd301dfd99127a194", null ],
    [ "has_species", "structIRockyCFDModel.xhtml#a4ac3f8164add3366c5f08f4f819a79fd", null ],
    [ "is_cfd_coupling_iteration", "structIRockyCFDModel.xhtml#a733281fb5b40b3cfbf10c29869208343", null ],
    [ "is_single_phase", "structIRockyCFDModel.xhtml#a0eaf07fa0aa63473b83a633dad1e8f25", null ]
];