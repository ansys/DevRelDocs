var searchData=
[
  ['add_0',['Add',['../class_speos_n_x__2512_1_1_optical_properties_geometry.xhtml#ab437b6f556464b59bf1f8cbb621b3724',1,'SpeosNX_2512.OpticalPropertiesGeometry.Add()'],['../class_speos_n_x__2512_1_1_sensor_light_field_selections.xhtml#ab437b6f556464b59bf1f8cbb621b3724',1,'SpeosNX_2512.SensorLightFieldSelections.Add()'],['../class_speos_n_x__2512_1_1_source_surface_emissive_faces.xhtml#ab437b6f556464b59bf1f8cbb621b3724',1,'SpeosNX_2512.SourceSurfaceEmissiveFaces.Add()'],['../class_speos_n_x__2512_1_1_select_face_list.xhtml#a45ef75d2be01145ba99b0bf9888d603a',1,'SpeosNX_2512.SelectFaceList.Add()'],['../class_speos_n_x__2512_1_1_folder_builder.xhtml#a3edde4a5462dcfe792466658461faea7',1,'SpeosNX_2512.FolderBuilder.Add()']]],
  ['addnewgroup_1',['AddNewGroup',['../class_speos_n_x__2512_1_1_sensor_filter.xhtml#a887ceed83fc45e80d3ddc8a3a4f31b93',1,'SpeosNX_2512::SensorFilter']]],
  ['addsourcefacefilteringreferences_2',['AddSourceFaceFilteringReferences',['../class_speos_n_x__2512_1_1_simulation_inverse_builder.xhtml#a053588683e97295e7450f0801c876eec',1,'SpeosNX_2512::SimulationInverseBuilder']]],
  ['addsources_3',['AddSources',['../class_speos_n_x__2512_1_1_source_group_builder.xhtml#ac46b654bd2f52fe74f58eb1a703e7db2',1,'SpeosNX_2512::SourceGroupBuilder']]],
  ['attribute_4',['Attribute',['../class_speos_n_x__2512_1_1_component_optical_design_exchange_result_builder.xhtml#ae98e408a341528ff295f098576401ea2',1,'SpeosNX_2512::ComponentOpticalDesignExchangeResultBuilder']]]
];
