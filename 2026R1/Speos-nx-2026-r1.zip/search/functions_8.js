var searchData=
[
  ['preferences_0',['Preferences',['../class_speos_n_x__2512_1_1_session.xhtml#addcd2ba9f66e956c065f950c2b038a46',1,'SpeosNX_2512::Session']]]
];
