var searchData=
[
  ['update_0',['Update',['../class_speos_n_x__2512_1_1_feature.xhtml#a51f0e84116935db637796345d15b353d',1,'SpeosNX_2512::Feature']]],
  ['updatewavelengthsamplingfromresolution_1',['UpdateWavelengthSamplingFromResolution',['../class_speos_n_x__2512_1_1_sensor_camera_builder.xhtml#aa84cc20a2aa99d1c8ff2ff353cb0923a',1,'SpeosNX_2512::SensorCameraBuilder']]]
];
