var searchData=
[
  ['delete_0',['Delete',['../class_speos_n_x__2512_1_1_preset.xhtml#ac8cc8aecad6e8d51e18f35cf0127f99c',1,'SpeosNX_2512.Preset.Delete()'],['../class_speos_n_x__2512_1_1_feature.xhtml#ac8cc8aecad6e8d51e18f35cf0127f99c',1,'SpeosNX_2512.Feature.Delete()']]],
  ['deletesourcefacefilteringreferences_1',['DeleteSourceFaceFilteringReferences',['../class_speos_n_x__2512_1_1_simulation_inverse_builder.xhtml#a1f2eebc9ec162ea073fb198b19096657',1,'SpeosNX_2512::SimulationInverseBuilder']]]
];
