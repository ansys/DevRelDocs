var searchData=
[
  ['save_0',['Save',['../class_speos_n_x__2512_1_1_preferences.xhtml#a4cc21a7e25dcc2133eced293a4973e82',1,'SpeosNX_2512::Preferences']]],
  ['saveaspreset_1',['SaveAsPreset',['../class_speos_n_x__2512_1_1_simulation_settings.xhtml#af481834f7c7cca6d477a24350b6ad5f2',1,'SpeosNX_2512::SimulationSettings']]],
  ['showresult_2',['ShowResult',['../class_speos_n_x__2512_1_1_feature_builder.xhtml#ae0fcd0d60a901105f0702ff7da8b1041',1,'SpeosNX_2512::FeatureBuilder']]],
  ['size_3',['Size',['../class_speos_n_x__2512_1_1_select_face_list.xhtml#a4256657231ed310618dfa3581a635e7e',1,'SpeosNX_2512::SelectFaceList']]]
];
