var class_speos_n_x__2512_1_1_source_group_builder =
[
    [ "AddSources", "class_speos_n_x__2512_1_1_source_group_builder.xhtml#ac46b654bd2f52fe74f58eb1a703e7db2", null ],
    [ "RemoveSources", "class_speos_n_x__2512_1_1_source_group_builder.xhtml#a4d6030ef50affd799fe288378141b988", null ]
];