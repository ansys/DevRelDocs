var class_speos_n_x__2512_1_1_preset =
[
    [ "Delete", "class_speos_n_x__2512_1_1_preset.xhtml#ac8cc8aecad6e8d51e18f35cf0127f99c", null ],
    [ "Rename", "class_speos_n_x__2512_1_1_preset.xhtml#a0badf3064e7107009ab1899b65a2972c", null ]
];