var class_speos_n_x__2512_1_1_optical_properties_geometry =
[
    [ "Add", "class_speos_n_x__2512_1_1_optical_properties_geometry.xhtml#ab437b6f556464b59bf1f8cbb621b3724", null ],
    [ "Clear", "class_speos_n_x__2512_1_1_optical_properties_geometry.xhtml#ad1f121ac89b5e624a0351c969e95d985", null ],
    [ "Remove", "class_speos_n_x__2512_1_1_optical_properties_geometry.xhtml#ae5875ad27243653f6c314b4a8fa08a29", null ],
    [ "RevertGeometry", "class_speos_n_x__2512_1_1_optical_properties_geometry.xhtml#a2add14ab3d65e3810d3168c915abf044", null ]
];