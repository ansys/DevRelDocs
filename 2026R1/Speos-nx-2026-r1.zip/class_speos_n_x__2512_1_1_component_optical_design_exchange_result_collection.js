var class_speos_n_x__2512_1_1_component_optical_design_exchange_result_collection =
[
    [ "CreateResultBuilder", "class_speos_n_x__2512_1_1_component_optical_design_exchange_result_collection.xhtml#a2bd1a8b1fed62ffd65cdb39aa9b63473", null ],
    [ "FindFromName", "class_speos_n_x__2512_1_1_component_optical_design_exchange_result_collection.xhtml#add274fee0239eee6c9a4f356e5dbed9d", null ]
];