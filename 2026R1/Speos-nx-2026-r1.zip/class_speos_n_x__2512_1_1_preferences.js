var class_speos_n_x__2512_1_1_preferences =
[
    [ "Load", "class_speos_n_x__2512_1_1_preferences.xhtml#a7454373b1b420f2482537b7ee8e83503", null ],
    [ "ResetDefaultValues", "class_speos_n_x__2512_1_1_preferences.xhtml#ad8d210640cd52b7cad231d3421894c95", null ],
    [ "Save", "class_speos_n_x__2512_1_1_preferences.xhtml#a4cc21a7e25dcc2133eced293a4973e82", null ]
];