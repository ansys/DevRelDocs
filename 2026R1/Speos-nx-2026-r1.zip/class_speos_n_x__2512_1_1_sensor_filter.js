var class_speos_n_x__2512_1_1_sensor_filter =
[
    [ "AddNewGroup", "class_speos_n_x__2512_1_1_sensor_filter.xhtml#a887ceed83fc45e80d3ddc8a3a4f31b93", null ],
    [ "FindGroup", "class_speos_n_x__2512_1_1_sensor_filter.xhtml#a801c8732f6d4759309a50c60c6f34e17", null ],
    [ "RemoveGroup", "class_speos_n_x__2512_1_1_sensor_filter.xhtml#a5a28b42e821ad7da1e9f5680dec9253c", null ]
];