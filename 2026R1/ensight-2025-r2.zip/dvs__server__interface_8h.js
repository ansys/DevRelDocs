var dvs__server__interface_8h =
[
    [ "DVS::IServer", "class_d_v_s_1_1_i_server.html", "class_d_v_s_1_1_i_server" ],
    [ "CREATE_SERVER_INSTANCE", "dvs__server__interface_8h.html#a852580b9a49ac305e4ae26ca637bcc75", null ],
    [ "DESTROY_SERVER_INSTANCE", "dvs__server__interface_8h.html#adcdcbab1954ec53631a7136af7fc49b8", null ]
];