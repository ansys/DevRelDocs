var dvs__query__interface_8h =
[
    [ "DVS::IQuery", "class_d_v_s_1_1_i_query.html", "class_d_v_s_1_1_i_query" ],
    [ "CREATE_QUERY_INSTANCE", "dvs__query__interface_8h.html#ac614cf475eca0727cdb5b42faabcca7d", null ]
];