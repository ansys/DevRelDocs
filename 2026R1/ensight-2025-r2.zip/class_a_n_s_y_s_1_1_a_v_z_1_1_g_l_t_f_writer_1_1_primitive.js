var class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive =
[
    [ "PrimitiveType", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ab399de95ea5e67c28e173936dcd913d4", [
      [ "PT_POINTS", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ab399de95ea5e67c28e173936dcd913d4a95e6aea5112aa769b9c43fa3c349505f", null ],
      [ "PT_LINES", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ab399de95ea5e67c28e173936dcd913d4a89e1e2f0c3fe025afc49a1e98ea2fdbd", null ],
      [ "PT_LINE_LOOP", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ab399de95ea5e67c28e173936dcd913d4aba3df38ab933b4d3255ee4dacde9ef3b", null ],
      [ "PT_LINE_STRIP", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ab399de95ea5e67c28e173936dcd913d4adb7a8ae1a83c97c993464252ad279508", null ],
      [ "PT_TRIANGLES", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ab399de95ea5e67c28e173936dcd913d4af8fcc308305daa83626bb3f99db765ec", null ],
      [ "PT_TRIANGLE_STRIP", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ab399de95ea5e67c28e173936dcd913d4a0c9543813e61c03f7e6577b955b5c17a", null ],
      [ "PT_TRIANGLE_FAN", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ab399de95ea5e67c28e173936dcd913d4a0d7958ad650c51bb5739997f5ea811ea", null ]
    ] ],
    [ "PrimitiveXAttachment", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ad30effec5df3eb5e3726ce8a39c2a5a3", [
      [ "PXA_NONE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ad30effec5df3eb5e3726ce8a39c2a5a3aa1f292328c1e11fb9c0fe9d4db490203", null ],
      [ "PXA_LEFT", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ad30effec5df3eb5e3726ce8a39c2a5a3a76b4339ef078d64069add735f11211e2", null ],
      [ "PXA_CENTER", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ad30effec5df3eb5e3726ce8a39c2a5a3a30709b70bb01cddc1b77a72dcd0d6b8a", null ],
      [ "PXA_RIGHT", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ad30effec5df3eb5e3726ce8a39c2a5a3a9f9cc3d3886e3256146dfb791caf8a94", null ]
    ] ],
    [ "PrimitiveYAttachment", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#a36714c9888001092a6e68480e3066630", [
      [ "PYA_NONE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#a36714c9888001092a6e68480e3066630a76645cbe2504d5fdd8fa90a42fda4a60", null ],
      [ "PYA_BOTTOM", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#a36714c9888001092a6e68480e3066630a78b797fae1a3c0c66968f8ada8bad1dc", null ],
      [ "PYA_CENTER", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#a36714c9888001092a6e68480e3066630a836973d99444ff6026dabdd0a1f00914", null ],
      [ "PYA_TOP", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#a36714c9888001092a6e68480e3066630a6014dff136c854ddecb3d7467f9bb9b7", null ]
    ] ],
    [ "AppendAttribute", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#ac4144b4cc35eec9c11b07cc7352d209e", null ],
    [ "Mirror", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html#a515b63672c547b93bf2870492c2935b9", null ]
];