var logger__verbose_8h =
[
    [ "DVS::LoggerVerbose", "class_d_v_s_1_1_logger_verbose.html", "class_d_v_s_1_1_logger_verbose" ]
];