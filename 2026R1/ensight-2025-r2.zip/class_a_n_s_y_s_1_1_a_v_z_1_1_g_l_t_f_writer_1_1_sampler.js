var class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler =
[
    [ "FilterType", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#ad6e1c2114d7b97b1b087fc97326843b7", [
      [ "FT_NEAREST", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#ad6e1c2114d7b97b1b087fc97326843b7acd3c6a961467beb0a99dae179d05f718", null ],
      [ "FT_LINEAR", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#ad6e1c2114d7b97b1b087fc97326843b7a00da2bd2c3f6389c83b221bb46a13e38", null ],
      [ "FT_NEAREST_MIPMAP_NEAREST", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#ad6e1c2114d7b97b1b087fc97326843b7ac4445c73f3de4dd656e03b2c0bca2e33", null ],
      [ "FT_LINEAR_MIPMAP_NEAREST", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#ad6e1c2114d7b97b1b087fc97326843b7ab5b7f99f3cb2f01e6b67a61e2dc41f8f", null ],
      [ "FT_NEAREST_MIPMAP_LINEAR", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#ad6e1c2114d7b97b1b087fc97326843b7a979cf2f946060a8d99bd868d2e9e6d5b", null ],
      [ "FT_LINEAR_MIPMAP_LINEAR", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#ad6e1c2114d7b97b1b087fc97326843b7a587bcfcc7e376dbfcf0e614500224d83", null ]
    ] ],
    [ "WrapType", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#a8e5e0b3dbe97502545bab842604c314e", [
      [ "WT_REPEAT", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#a8e5e0b3dbe97502545bab842604c314ead109b60cfc9bbbb3b127d2c657f243e3", null ],
      [ "WT_CLAMP_TO_EDGE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#a8e5e0b3dbe97502545bab842604c314ea7ee5d7d400880893f22ccf18a98a46b2", null ],
      [ "WT_MIRRORED_REPEAT", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html#a8e5e0b3dbe97502545bab842604c314eafea1c17edee1c96dd316536a292963f1", null ]
    ] ]
];