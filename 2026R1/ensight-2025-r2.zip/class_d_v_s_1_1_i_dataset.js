var class_d_v_s_1_1_i_dataset =
[
    [ "IDataset", "class_d_v_s_1_1_i_dataset.html#a5f47221543a890f8c04c7297f45e9580", null ],
    [ "~IDataset", "class_d_v_s_1_1_i_dataset.html#a99d31f6d38bc358af557ca2fa236959e", null ],
    [ "IDataset", "class_d_v_s_1_1_i_dataset.html#a4fafacbcd842db2b73a89b98d56f8ab4", null ],
    [ "IDataset", "class_d_v_s_1_1_i_dataset.html#aa32d8780f6b7ed895870bea816396600", null ],
    [ "get_chunks_per_rank", "class_d_v_s_1_1_i_dataset.html#afb023f6b10fd4c072e8c7cb140d666ae", null ],
    [ "get_num_chunks_per_rank", "class_d_v_s_1_1_i_dataset.html#a5ec19061a478d6b2aea0976b9e79f73b", null ],
    [ "get_num_parts", "class_d_v_s_1_1_i_dataset.html#a69aa8f4d0ad2c4fd69e6443f662fbc1d", null ],
    [ "get_num_plots", "class_d_v_s_1_1_i_dataset.html#a49e3b27865d865ba36dd5d7e5c659a6b", null ],
    [ "get_num_ranks", "class_d_v_s_1_1_i_dataset.html#a423774f63a6f5275d4d4f33da65f37b4", null ],
    [ "get_num_variables", "class_d_v_s_1_1_i_dataset.html#acd0c0e81b283bce8044d9b4de796574a", null ],
    [ "get_part", "class_d_v_s_1_1_i_dataset.html#af000ab1d7bfdd043cdc2b4f6cd4d682c", null ],
    [ "get_plot", "class_d_v_s_1_1_i_dataset.html#a8f3bb3e37530f0b1dd6630fb6f9925f5", null ],
    [ "get_ranks", "class_d_v_s_1_1_i_dataset.html#ac620a1f5fb513d636ed59d7b4552197a", null ],
    [ "get_unit_system", "class_d_v_s_1_1_i_dataset.html#af69301cb1a2d466933e8fee162411a60", null ],
    [ "get_var", "class_d_v_s_1_1_i_dataset.html#abfef24372147723533c9feebd55666c1", null ],
    [ "operator=", "class_d_v_s_1_1_i_dataset.html#a0cd185542ff0c3d51d5a20762af02958", null ],
    [ "operator=", "class_d_v_s_1_1_i_dataset.html#a6ce85ff405ae57b21a5317b75874f128", null ]
];