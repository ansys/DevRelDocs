var dir_fa146d8b9586d7b9f69631975890494f =
[
    [ "test_dvs_client.c", "test__dvs__client_8c.html", "test__dvs__client_8c" ],
    [ "test_dvs_client_cxx.cpp", "test__dvs__client__cxx_8cpp.html", "test__dvs__client__cxx_8cpp" ],
    [ "test_dvs_reader.cpp", "test__dvs__reader_8cpp.html", "test__dvs__reader_8cpp" ],
    [ "test_dvs_server.cpp", "test__dvs__server_8cpp.html", "test__dvs__server_8cpp" ]
];