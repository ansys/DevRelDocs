var class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f =
[
    [ "GLTFError", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4", [
      [ "GLTF_ERROR_NONE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a6bb637f968acccc24ee2fee2b39f23e5", null ],
      [ "GLTF_ERROR_DUPLICATE_VALUE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4ae6ae707e3c7740bb41560b5c67ac575b", null ],
      [ "GLTF_ERROR_INCOMPATIBLE_VALUE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a574601c24bf71754e08a070fea59a4cf", null ],
      [ "GLTF_ERROR_INVALID_PATH", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a599a5a8fb30f3c105dd718a0e2c8ce49", null ],
      [ "GLTF_ERROR_INVALID_TARGET", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a11d841e07888cb00645557120b8a1f45", null ],
      [ "GLTF_ERROR_INVALID_TYPE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4af3b8dac91a903167b889e6f8562d31f8", null ],
      [ "GLTF_ERROR_INVALID_VALUE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a3e236f59574d0988c1c963d8ab4cdea0", null ],
      [ "GLTF_ERROR_MEMORY", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a3993d0160836fafa0e7c66ceca39c4be", null ],
      [ "GLTF_ERROR_RANGE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4ad20acf50f0dc72fb1c25cea565cef8be", null ],
      [ "GLTF_ERROR_READ", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a5bde666dc50ecc457172466644225908", null ],
      [ "GLTF_ERROR_SIZE_MISMATCH", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a7a986d06fe789cdf64c814bca7cb37fa", null ],
      [ "GLTF_ERROR_VALUE_NOT_INITIALIZED", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4a1917f255f8b610923c01754b828e0366", null ],
      [ "GLTF_ERROR_WRITE", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4ab4952a2b478d79748e74743099c2f3d6", null ],
      [ "GLT_ERROR_MAX", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a5b8141dc8536bc10d1a72996ad6f98b4ad7cffe63d3c21d500fa206db2cf2404e", null ]
    ] ],
    [ "OutputType", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#ad551f06ce7377ce5e50901b2756e4720", [
      [ "OT_AVZ", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#ad551f06ce7377ce5e50901b2756e4720a557d9ef366cca7b05ff7c501a05ca577", null ],
      [ "OT_GLTF", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#ad551f06ce7377ce5e50901b2756e4720a20b38c0c93750658cfd62c552baa233c", null ],
      [ "OT_GLB1", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#ad551f06ce7377ce5e50901b2756e4720a3ee14f4b9417285b3785a0052498d5a1", null ],
      [ "OT_GLTF1", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#ad551f06ce7377ce5e50901b2756e4720ab728887300b0810a30580d9a30511cf7", null ],
      [ "OT_GLB2", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#ad551f06ce7377ce5e50901b2756e4720a2e7a8e3b6e452428a32366628302db55", null ]
    ] ],
    [ "GetError", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a63295f8f31619517e94cf27d3a8b9ea8", null ],
    [ "SetDefaultScene", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a9201c02eb80171c47e40f2600b92ec6f", null ],
    [ "Write", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html#a0bf3a4ec615dc8810776dd82a65eba91", null ]
];