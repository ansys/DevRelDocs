var class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend =
[
    [ "LegendAttachment", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6c", [
      [ "LA_X_Y", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca5bd46276fd06c3a0e49cf6d00bf9c441", null ],
      [ "LA_X_YBOTTOM", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca0bb90de784225c9f6ffd146bbd944fb8", null ],
      [ "LA_X_YTOP", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca09d1436ac3eeec8ccff6dacc5fb5245c", null ],
      [ "LA_X_YCENTER", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca27db75ee4805fc00329de9864e81f25a", null ],
      [ "LA_XLEFT_Y", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca6b3509784591d8c8cec2d296cf627988", null ],
      [ "LA_XLEFT_YBOTTOM", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6caefda43433936f1da77563da0e732a358", null ],
      [ "LA_XLEFT_YTOP", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca19b6e20608b70d907b513a08533cf60f", null ],
      [ "LA_XLEFT_YCENTER", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6cabf28733aa8d48ecbd18987aabf05cbfa", null ],
      [ "LA_XRIGHT_Y", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca08e2594c272df719858fd60aa9056674", null ],
      [ "LA_XRIGHT_YBOTTOM", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca1dc68fd1355cf72e1cc14bd493c81ef0", null ],
      [ "LA_XRIGHT_YTOP", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca5386064bffd3fd3fd2a2676a41b18997", null ],
      [ "LA_XRIGHT_YCENTER", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6cae769e9ddccb58ed6de5ad0d1aaf22290", null ],
      [ "LA_XCENTER_Y", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6cacaabfa58f05da6dee45c803b1e1a5614", null ],
      [ "LA_XCENTER_YBOTTOM", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6cab74939d10eec4cff02293963dbbff518", null ],
      [ "LA_XCENTER_YTOP", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6cac77b00c0ce50215465a1d4fe2afae10a", null ],
      [ "LA_XCENTER_YCENTER", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a07fa70f9cf261ed7649b8dddc8a02a6ca42f24459a26fe33ab2aa41a4f7c78318", null ]
    ] ],
    [ "LegendOrientation", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a01ae5e5c92a51d569fc24cef427a8351", [
      [ "LO_VERTICAL", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a01ae5e5c92a51d569fc24cef427a8351a492438d391f3e162dd7b33f96cf77f31", null ],
      [ "LO_HORIZONTAL", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html#a01ae5e5c92a51d569fc24cef427a8351aeacda46c53212e90196693cd1bc9548c", null ]
    ] ]
];