var structdvs__var__info =
[
    [ "_id", "structdvs__var__info.html#abcef03f7b1e419ae39c7511de2385a9b", null ],
    [ "_location", "structdvs__var__info.html#abfd6a4461939e798ebdc5d6714a4558f", null ],
    [ "_metadata_keys", "structdvs__var__info.html#a9c656726edeeb5c0cf5b9a42f870b3a2", null ],
    [ "_metadata_num_pairs", "structdvs__var__info.html#a9f99fd8ad9d004f44939c830747ebfc8", null ],
    [ "_metadata_vals", "structdvs__var__info.html#abe0afbff61a368336c7750c831a3c056", null ],
    [ "_name", "structdvs__var__info.html#ad1b4aeadeb75d6ab2a446fef37f11d0a", null ],
    [ "_type", "structdvs__var__info.html#a721f90cd12b7e98cf0d2fcf99ed9c7a9", null ],
    [ "_unit", "structdvs__var__info.html#a3d7cdb8a063eaf6c94f95f3b589c8624", null ],
    [ "_unit_label", "structdvs__var__info.html#a262ba1165d1929418e03a2a250774525", null ]
];