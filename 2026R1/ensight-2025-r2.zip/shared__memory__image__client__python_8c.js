var shared__memory__image__client__python_8c =
[
    [ "MAX_STREAMS", "shared__memory__image__client__python_8c.html#a4a1e12ec49840b798c6413a8f6c947a9", null ],
    [ "stream_create", "shared__memory__image__client__python_8c.html#a68584fd5e8630714c738fc30ad19fa03", null ],
    [ "stream_destroy", "shared__memory__image__client__python_8c.html#af656cd2bf739307f1d52221d49da37ae", null ],
    [ "stream_lock", "shared__memory__image__client__python_8c.html#ac78db99f06d47f7718fdcac4ae3cc374", null ],
    [ "stream_putframe", "shared__memory__image__client__python_8c.html#a23b3d9929aaff2a388402452ce5228c1", null ],
    [ "stream_unlock", "shared__memory__image__client__python_8c.html#a233ea80003a929e8e60aabd26a3b5c5e", null ]
];