var logger__interface_8h =
[
    [ "DVS::ILogger", "class_d_v_s_1_1_i_logger.html", "class_d_v_s_1_1_i_logger" ]
];