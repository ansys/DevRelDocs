var dir_91a366c976a8d1e4a038fc52f1384b91 =
[
    [ "test_dvs_client_simple.py", "test__dvs__client__simple_8py.html", null ],
    [ "test_dvs_python_reader_api.py", "test__dvs__python__reader__api_8py.html", null ]
];