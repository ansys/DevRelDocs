var annotated_dup =
[
    [ "ANSYS", "namespace_a_n_s_y_s.html", [
      [ "AVZ", null, [
        [ "GLTFWriter", null, [
          [ "Utils", "namespace_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_utils.html", [
            [ "Repack", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_utils_1_1_repack.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_utils_1_1_repack" ]
          ] ],
          [ "Animation", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_animation.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_animation" ],
          [ "AnimationSampler", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_animation_sampler.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_animation_sampler" ],
          [ "Attribute", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute" ],
          [ "Buffer", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_buffer.html", null ],
          [ "Camera", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_camera.html", null ],
          [ "GLTF", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_g_l_t_f" ],
          [ "Image", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_image.html", null ],
          [ "Index", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_index.html", null ],
          [ "Legend", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_legend" ],
          [ "Light", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_light.html", null ],
          [ "Material", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_material.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_material" ],
          [ "Mesh", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_mesh.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_mesh" ],
          [ "Node", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_node.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_node" ],
          [ "Object", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_object.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_object" ],
          [ "Parameter", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter" ],
          [ "Primitive", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_primitive" ],
          [ "Program", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_program.html", null ],
          [ "Sampler", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_sampler" ],
          [ "Scene", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_scene.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_scene" ],
          [ "Shader", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_shader.html", null ],
          [ "State", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_state.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_state" ],
          [ "Technique", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_technique.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_technique" ],
          [ "Texture", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_texture.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_texture" ],
          [ "Value", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_value.html", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_value" ]
        ] ]
      ] ]
    ] ],
    [ "DVS", null, [
      [ "IClient", "class_d_v_s_1_1_i_client.html", "class_d_v_s_1_1_i_client" ],
      [ "IDataset", "class_d_v_s_1_1_i_dataset.html", "class_d_v_s_1_1_i_dataset" ],
      [ "IElementBlock", "class_d_v_s_1_1_i_element_block.html", "class_d_v_s_1_1_i_element_block" ],
      [ "IHash", "class_d_v_s_1_1_i_hash.html", "class_d_v_s_1_1_i_hash" ],
      [ "ILogger", "class_d_v_s_1_1_i_logger.html", "class_d_v_s_1_1_i_logger" ],
      [ "IMeshChunk", "class_d_v_s_1_1_i_mesh_chunk.html", "class_d_v_s_1_1_i_mesh_chunk" ],
      [ "IObject", "class_d_v_s_1_1_i_object.html", "class_d_v_s_1_1_i_object" ],
      [ "IPlotChunk", "class_d_v_s_1_1_i_plot_chunk.html", "class_d_v_s_1_1_i_plot_chunk" ],
      [ "IQuery", "class_d_v_s_1_1_i_query.html", "class_d_v_s_1_1_i_query" ],
      [ "IServer", "class_d_v_s_1_1_i_server.html", "class_d_v_s_1_1_i_server" ],
      [ "IVar", "class_d_v_s_1_1_i_var.html", "class_d_v_s_1_1_i_var" ],
      [ "IVarHash", "class_d_v_s_1_1_i_var_hash.html", "class_d_v_s_1_1_i_var_hash" ],
      [ "LoggerVerbose", "class_d_v_s_1_1_logger_verbose.html", "class_d_v_s_1_1_logger_verbose" ]
    ] ],
    [ "ensight_grpc", null, [
      [ "EnSightGRPC", "classensight__grpc_1_1_en_sight_g_r_p_c.html", "classensight__grpc_1_1_en_sight_g_r_p_c" ]
    ] ],
    [ "libuserd", null, [
      [ "fileExtensions", "structlibuserd_1_1file_extensions.html", null ],
      [ "LibUserd", "classlibuserd_1_1_lib_userd.html", "classlibuserd_1_1_lib_userd" ],
      [ "Part", "classlibuserd_1_1_part.html", "classlibuserd_1_1_part" ],
      [ "Query", "classlibuserd_1_1_query.html", "classlibuserd_1_1_query" ],
      [ "Reader", "classlibuserd_1_1_reader.html", "classlibuserd_1_1_reader" ],
      [ "ReaderInfo", "classlibuserd_1_1_reader_info.html", "classlibuserd_1_1_reader_info" ],
      [ "Variable", "classlibuserd_1_1_variable.html", null ]
    ] ],
    [ "_SharedMemoryFrame", "struct___shared_memory_frame.html", "struct___shared_memory_frame" ],
    [ "dvs_part_info", "structdvs__part__info.html", "structdvs__part__info" ],
    [ "dvs_plot_info", "structdvs__plot__info.html", "structdvs__plot__info" ],
    [ "dvs_var_info", "structdvs__var__info.html", "structdvs__var__info" ]
];