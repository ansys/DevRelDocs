var class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute =
[
    [ "AttributeType", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#a046f86686637a52f18e250a00d5687d3", [
      [ "AT_INT", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#a046f86686637a52f18e250a00d5687d3aede267b3d98098971964943e31579d32", null ],
      [ "AT_FLOAT", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#a046f86686637a52f18e250a00d5687d3a3d1b024141a9c7de7ffd096701addb85", null ],
      [ "AT_FLOAT_VEC2", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#a046f86686637a52f18e250a00d5687d3a9eab3991f35ae7fb67b3378f9218d0ed", null ],
      [ "AT_FLOAT_VEC3", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#a046f86686637a52f18e250a00d5687d3a2239bf25cc747ce3d3c58688e1289158", null ],
      [ "AT_FLOAT_VEC4", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#a046f86686637a52f18e250a00d5687d3a70cacdf17684e1b3a9fcf16e76dfe0af", null ],
      [ "AT_FLOAT_MAT4", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#a046f86686637a52f18e250a00d5687d3a04fcf6d039fbcf4c7cadfe33cf81d0c3", null ]
    ] ],
    [ "SetLogarithmic", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#a795c8d57e0534017a267ca9511f788ce", null ],
    [ "SetMinMax", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#ae1fbcbb6aad40e3275a39db380ba3192", null ],
    [ "SetMinMax", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_attribute.html#ac7d2ab8c33ae471917966f920524fad1", null ]
];