var class_d_v_s_1_1_i_object =
[
    [ "ObjectDefType", "class_d_v_s_1_1_i_object.html#aa897daa1f7d0467515fd108c29015348", [
      [ "PART", "class_d_v_s_1_1_i_object.html#aa897daa1f7d0467515fd108c29015348a8b2484e08a16329d2d91c18c254f5ca6", null ],
      [ "PLOT", "class_d_v_s_1_1_i_object.html#aa897daa1f7d0467515fd108c29015348abe80fa1e67dae7efb56fdb2936914cae", null ],
      [ "CASE", "class_d_v_s_1_1_i_object.html#aa897daa1f7d0467515fd108c29015348a03dcfd36d493cd1d828af236e2c357fd", null ]
    ] ],
    [ "IObject", "class_d_v_s_1_1_i_object.html#ac8a6734ee192a26b574e9eec520c1495", null ],
    [ "~IObject", "class_d_v_s_1_1_i_object.html#a26912f7959e8f0e610074833c677a904", null ],
    [ "IObject", "class_d_v_s_1_1_i_object.html#aae99076e42a6fc37bf9a71303b3db2b5", null ],
    [ "IObject", "class_d_v_s_1_1_i_object.html#af147aaab5200462fd620dbdd4a39ac76", null ],
    [ "get_dataset", "class_d_v_s_1_1_i_object.html#aea688a307b1cb02ae53e0e8fd3791e64", null ],
    [ "get_metadata_key", "class_d_v_s_1_1_i_object.html#a04ee2919ffeb46d966d4675c8cd4420c", null ],
    [ "get_metadata_value", "class_d_v_s_1_1_i_object.html#aa33105e0510c3a2b0da022d5e9632bc8", null ],
    [ "get_metadata_value", "class_d_v_s_1_1_i_object.html#a7a37d603ccf93f7f1ec9f962fa9d1f61", null ],
    [ "get_name", "class_d_v_s_1_1_i_object.html#a39be8b08200f75b20a7b5cf715ba9dd3", null ],
    [ "get_num_metadata", "class_d_v_s_1_1_i_object.html#a31db3b716cc815c2c73f826f24384f6a", null ],
    [ "get_type", "class_d_v_s_1_1_i_object.html#a889c46624013cc3802c7164d153b95f6", null ],
    [ "operator=", "class_d_v_s_1_1_i_object.html#a9953812222e436976af29d1f84967f85", null ],
    [ "operator=", "class_d_v_s_1_1_i_object.html#ae90f3c11b1fdf916b59490005b148fd5", null ]
];