var classlibuserd_1_1_query =
[
    [ "data", "classlibuserd_1_1_query.html#acbe09d10fcd3e9a7260c7b03b1d19661", null ],
    [ "num_points", "classlibuserd_1_1_query.html#a6752296f06ad53305522f14cc45b3867", null ]
];