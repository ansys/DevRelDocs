var structdvs__part__info =
[
    [ "_chunking", "structdvs__part__info.html#af688078624a42e9ab53d3c194e2861c3", null ],
    [ "_id", "structdvs__part__info.html#ab4e6fd830f27fdfa60c7bf6c2c137695", null ],
    [ "_metadata_keys", "structdvs__part__info.html#aef3ab830a0bfcab49d9cbed978e315c2", null ],
    [ "_metadata_num_pairs", "structdvs__part__info.html#adb36557a49efa5373a258141dd472385", null ],
    [ "_metadata_vals", "structdvs__part__info.html#a59c04a77c663b68008a1f69b62574337", null ],
    [ "_name", "structdvs__part__info.html#aa3ef86ed8620b0419f05e4e255dd01fb", null ],
    [ "_structured", "structdvs__part__info.html#ab458569530b84c8a2403b2610af98989", null ]
];