var class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter =
[
    [ "ParameterType", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91", [
      [ "PT_INT", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a96c27384ccc3e0d4e96963e62446b6bb", null ],
      [ "PT_FLOAT", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a736e8ff919818f9dee867032e0c6a879", null ],
      [ "PT_FLOAT_VEC2", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a9753902c1d448f8f3cb3d5af67de107b", null ],
      [ "PT_FLOAT_VEC3", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a7df34df8e836ef9ec71bcef5be34965e", null ],
      [ "PT_FLOAT_VEC4", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91aae6bfc23c57c981a8f7f59a610bafcf4", null ],
      [ "PT_INT_VEC2", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a31ba1f6740ad8861a8e06c3448b56e90", null ],
      [ "PT_INT_VEC3", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91af96bf17815e5748b0330d1fc82f94fa1", null ],
      [ "PT_INT_VEC4", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a30c2e94bac582ba6a758db308d9327eb", null ],
      [ "PT_BOOL", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a37080a7d8ee9f3c518c00815e0d55db2", null ],
      [ "PT_FLOAT_MAT3", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a6607927c279d448656b22ad0f0727a75", null ],
      [ "PT_FLOAT_MAT4", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a9d6aa4dc44a1c1b282b7d26037fcdf5e", null ],
      [ "PT_SAMPLER_2D", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_parameter.html#a63d6faee02f7330cb56274509b339f91a626e5a9b6734af777f7c8ddd2d185423", null ]
    ] ]
];