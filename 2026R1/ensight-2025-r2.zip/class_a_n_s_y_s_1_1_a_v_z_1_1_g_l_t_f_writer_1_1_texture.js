var class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_texture =
[
    [ "TextureFormat", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_texture.html#a7a15f61f5885a3e0a575d40125631ee0", [
      [ "TF_RGB", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_texture.html#a7a15f61f5885a3e0a575d40125631ee0ad2d3f7c19b6b3dc31097082729d1ea42", null ],
      [ "TF_RGBA", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_texture.html#a7a15f61f5885a3e0a575d40125631ee0a74ec6e31736f6a07eed7d43352e93579", null ]
    ] ],
    [ "TextureTarget", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_texture.html#a731d022c687a76ceb8e4813710e4b80a", [
      [ "TT_TEXTURE_2D", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_texture.html#a731d022c687a76ceb8e4813710e4b80aab2bc887584b1b6af4ba056f3031def75", null ]
    ] ]
];