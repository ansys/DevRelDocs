var class_d_v_s_1_1_i_var =
[
    [ "IVar", "class_d_v_s_1_1_i_var.html#a102df9a173523a896419011582abefb1", null ],
    [ "~IVar", "class_d_v_s_1_1_i_var.html#a0f21e53225c764cb3441f36c32f77bee", null ],
    [ "IVar", "class_d_v_s_1_1_i_var.html#aac24d89cca155832661aaf190e933e30", null ],
    [ "IVar", "class_d_v_s_1_1_i_var.html#afd5bd19f8cf769575e1d6f13890c876b", null ],
    [ "get_dataset", "class_d_v_s_1_1_i_var.html#acd4c1b8698417ac314a45143e92986d6", null ],
    [ "get_float_count_per_value", "class_d_v_s_1_1_i_var.html#a9dbdd84e6f6342deae82ede6dcf2156e", null ],
    [ "get_metadata_key", "class_d_v_s_1_1_i_var.html#ae18e148e2d2996891560734e53cd9671", null ],
    [ "get_metadata_value", "class_d_v_s_1_1_i_var.html#a04bb8ee80947c2bd09576961d65d4403", null ],
    [ "get_metadata_value", "class_d_v_s_1_1_i_var.html#a22432a4b79163a933a850a7a58dfe315", null ],
    [ "get_name", "class_d_v_s_1_1_i_var.html#a12b24dd196d3ddf3dbbdc29eca9cca3f", null ],
    [ "get_num_metadata", "class_d_v_s_1_1_i_var.html#a2deab60f72955106a4a4a3f67a0f295e", null ],
    [ "get_unit_dimension", "class_d_v_s_1_1_i_var.html#a6aa67cf54eb22ee51a7bf5eeb778cee5", null ],
    [ "get_unit_label", "class_d_v_s_1_1_i_var.html#aa484336b355e68f93069e97d771e4a6e", null ],
    [ "get_var_location", "class_d_v_s_1_1_i_var.html#a7e97f43d3d1057267399c0e66deadd3d", null ],
    [ "get_var_type", "class_d_v_s_1_1_i_var.html#ae837af2ee946d8f54695d1abf95c5cda", null ],
    [ "operator=", "class_d_v_s_1_1_i_var.html#aa7eb6e25ea05a45c383d24ef7483486a", null ],
    [ "operator=", "class_d_v_s_1_1_i_var.html#ad2bc5d54f4ba396d261698089d3ec263", null ]
];