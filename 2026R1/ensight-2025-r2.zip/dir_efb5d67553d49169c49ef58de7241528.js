var dir_efb5d67553d49169c49ef58de7241528 =
[
    [ "client", "dir_fdd9705442facc8925ef373a77ec3b73.html", "dir_fdd9705442facc8925ef373a77ec3b73" ],
    [ "server", "dir_da5cd6389272b5997ec6d94e21771192.html", "dir_da5cd6389272b5997ec6d94e21771192" ],
    [ "user_defined_src", "dir_4e0d2d4294803448cbce42ae5b7dbd77.html", "dir_4e0d2d4294803448cbce42ae5b7dbd77" ]
];