var dvs__client__interface_8h =
[
    [ "DVS::IClient", "class_d_v_s_1_1_i_client.html", "class_d_v_s_1_1_i_client" ],
    [ "CREATE_CLIENT_INSTANCE", "dvs__client__interface_8h.html#a2475075c9ab4c2e57a8f0b4ab5bc5df4", null ],
    [ "DESTROY_CLIENT_INSTANCE", "dvs__client__interface_8h.html#a3f13d009a9a07278cbca3449113d78fc", null ]
];