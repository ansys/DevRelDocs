var structdvs__plot__info =
[
    [ "_id", "structdvs__plot__info.html#a7721b22bb882c90e84d68979a748daf3", null ],
    [ "_metadata_keys", "structdvs__plot__info.html#a6182c10a62849ada795123fd6707d612", null ],
    [ "_metadata_num_pairs", "structdvs__plot__info.html#a2d0bc2ca11580a27d9a8637a848d6e14", null ],
    [ "_metadata_vals", "structdvs__plot__info.html#a467b2e79ceb431c9358423647de59699", null ],
    [ "_name", "structdvs__plot__info.html#a00c93696be3b5f9f3c2288daf9975f19", null ],
    [ "_x_axis_title", "structdvs__plot__info.html#a6cdeb2ede603f7aa96c515e2691e11a0", null ],
    [ "_x_axis_units", "structdvs__plot__info.html#aac4a7335b4bcda68808eea67e280346b", null ],
    [ "_y_axis_title", "structdvs__plot__info.html#aae1ce6d97a55e3da272f552508f61e11", null ],
    [ "_y_axis_units", "structdvs__plot__info.html#a368da9b3c7dd1b8b8b37daed5d97554d", null ]
];