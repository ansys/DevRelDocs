var class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_object =
[
    [ "GetID", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_object.html#af3080f74ead5c7ad033fdba61cb54d35", null ],
    [ "GetName", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_object.html#ada6ed2f6abb80a6868e1762e2b9f67ca", null ],
    [ "SetName", "class_a_n_s_y_s_1_1_a_v_z_1_1_g_l_t_f_writer_1_1_object.html#ab0e5063442e5cf0990dfa558dff82ac4", null ]
];