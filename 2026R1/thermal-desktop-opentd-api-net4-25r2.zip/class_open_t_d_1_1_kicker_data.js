var class_open_t_d_1_1_kicker_data =
[
    [ "KickerData", "class_open_t_d_1_1_kicker_data.xhtml#ae134899f9228fd3b102809bf8a023c8e", null ],
    [ "IndividuallyOrAll", "class_open_t_d_1_1_kicker_data.xhtml#a0565a90b78d17cfeebd9b4cb77ddf655", null ],
    [ "KickBoundaryNodes", "class_open_t_d_1_1_kicker_data.xhtml#a5057901b2f8899d8f8ac484fd2bfff2b", null ],
    [ "KickDomains", "class_open_t_d_1_1_kicker_data.xhtml#a8dd06f9b267d3749ec192e8827dad4e0", null ],
    [ "KickSubmodels", "class_open_t_d_1_1_kicker_data.xhtml#ac5ad095706b47679ee64fca5a38e71ca", null ],
    [ "KickValue", "class_open_t_d_1_1_kicker_data.xhtml#aed9022bae9e172943f3e2df7585385e8", null ],
    [ "KickValueExp", "class_open_t_d_1_1_kicker_data.xhtml#af8ed5cba1b1f005236958446c0b55a90", null ],
    [ "Name", "class_open_t_d_1_1_kicker_data.xhtml#a4aebf2c2fa950407989e04b0a1ffe693", null ],
    [ "SubmodelsOrDomains", "class_open_t_d_1_1_kicker_data.xhtml#a56606c4a328d7699450569d90471582c", null ]
];