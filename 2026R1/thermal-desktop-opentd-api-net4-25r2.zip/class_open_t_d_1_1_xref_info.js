var class_open_t_d_1_1_xref_info =
[
    [ "DatabaseName", "class_open_t_d_1_1_xref_info.xhtml#a3e81c19f92766ea8fdd3d3753fc6067c", null ],
    [ "Pathname", "class_open_t_d_1_1_xref_info.xhtml#add6418781d92b24424ab9004beae09d7", null ]
];