var class_open_t_d_1_1_results_1_1_plot_1_1_axis_style =
[
    [ "AxisStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a99f3a037eb1f22cd72f2ca15ae351903", null ],
    [ "IsIntegerStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#ab3b126ba8547c4a8c770166de5354ee6", null ],
    [ "LabelColor", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a561b40c677022544027ae7f2c29e2eca", null ],
    [ "LabelFont", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a6969dfce14fb4d50a4326f5834ce0c5c", null ],
    [ "LabelFormat", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a761feca072280449d5fa17379c478b46", null ],
    [ "LineColor", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#aadf8788728257e528a3eab7c57aac80b", null ],
    [ "LineDashStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a0b1b800cfc6818c4c32cbd2a0524aa7a", null ],
    [ "LineWidth", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a9b578d35a49254db5798a2db1eb6ac34", null ],
    [ "TextOrientation", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a627071dd57c08dc99dca93c2d273e66e", null ],
    [ "TitleColor", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a4ddae5a8d95d5e62075713297ee8c4d5", null ],
    [ "TitleFont", "class_open_t_d_1_1_results_1_1_plot_1_1_axis_style.xhtml#a84e3657e8b5cf1b01100779b41ffdb76", null ]
];