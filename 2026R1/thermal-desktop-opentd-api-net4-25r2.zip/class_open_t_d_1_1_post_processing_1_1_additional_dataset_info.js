var class_open_t_d_1_1_post_processing_1_1_additional_dataset_info =
[
    [ "AdditionalDatasetInfo", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info.xhtml#a917fb3fb1d7cc41d743c039aa578295a", null ],
    [ "_pathname", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info.xhtml#a00d93b38fc9b743e486c5a10251e6890", null ],
    [ "Pathname", "class_open_t_d_1_1_post_processing_1_1_additional_dataset_info.xhtml#adf6ebaab63c773c8f54dafc548bfee91", null ]
];