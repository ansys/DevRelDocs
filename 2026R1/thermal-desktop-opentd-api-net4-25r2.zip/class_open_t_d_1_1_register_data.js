var class_open_t_d_1_1_register_data =
[
    [ "ValueType", "class_open_t_d_1_1_register_data.xhtml#ab205aebc68f32b706f4dcf8caa1681f4", [
      [ "GLOBALVALUE", "class_open_t_d_1_1_register_data.xhtml#ab205aebc68f32b706f4dcf8caa1681f4a168b0b66555ba6fe88b60b729f902887", null ],
      [ "USERVALUE", "class_open_t_d_1_1_register_data.xhtml#ab205aebc68f32b706f4dcf8caa1681f4af09acb6efaf30b2617cf2a884272e7ba", null ],
      [ "SYMBOLEXPRESSION", "class_open_t_d_1_1_register_data.xhtml#ab205aebc68f32b706f4dcf8caa1681f4ae9fbf01d8b8d90e671ad9652a8dc9f60", null ]
    ] ],
    [ "RegisterData", "class_open_t_d_1_1_register_data.xhtml#aaa7413590f45f642b0942f6f23b71192", null ],
    [ "Comment", "class_open_t_d_1_1_register_data.xhtml#aada105942ec7743888ef615236de9f59", null ],
    [ "Disabled", "class_open_t_d_1_1_register_data.xhtml#a300cfdf4e56b013dd692fa89f3a0a7f1", null ],
    [ "Integer", "class_open_t_d_1_1_register_data.xhtml#a0b616f4e6e6707b97b77003b1f4cc9e8", null ],
    [ "Name", "class_open_t_d_1_1_register_data.xhtml#a28817009d5d26fcb1993f1d1333f9765", null ],
    [ "UserValue", "class_open_t_d_1_1_register_data.xhtml#a7d6383c2b6e04259db5493644d7c0b60", null ],
    [ "valueType", "class_open_t_d_1_1_register_data.xhtml#a0a93ea72952ef424516edd361202a746", null ]
];