var interface_open_t_d_1_1_results_1_1_dataset_1_1_i_browser =
[
    [ "GetHeatBetween", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_browser.xhtml#a2e1961ef5c8af1062baabd00b8f9a0cc", null ],
    [ "GetHeatBetween", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_browser.xhtml#a5b811417c3330e77e7dcf15f44b70bea", null ],
    [ "GetHeatBetweenSubmodels", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_browser.xhtml#ae2043488788bb275c5735d835625d969", null ],
    [ "GetHeatMap", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_browser.xhtml#aec1690fc7a963df052906feabeb09337", null ],
    [ "GetHeatMap", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_browser.xhtml#a9dce14584313578ca023082ebc492102", null ]
];