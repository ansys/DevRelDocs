var class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name =
[
    [ "SindaName", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml#ae688df548d7913bcd726c12940a30759", null ],
    [ "Equals", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml#a5400b8c614d3405dc5de0c46e0f26435", null ],
    [ "Equals", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml#affc6718b59fffe2356fed79243f26131", null ],
    [ "GetHashCode", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml#a3f4c74ee66cebcaf04f7a51cccf28695", null ],
    [ "ToString", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml#af752da0928546a4a2f9a9aabe3e04270", null ],
    [ "Id", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml#a5d6e7da30ec1dc3e0f9f177867029fa7", null ],
    [ "Key", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml#a0e09a6a64c78da3d00124af133ea452f", null ],
    [ "Submodel", "class_open_t_d_1_1_results_1_1_dataset_1_1_topology_1_1_sinda_name.xhtml#a1e6d0025b7e8522364836a2d1a1a2191", null ]
];