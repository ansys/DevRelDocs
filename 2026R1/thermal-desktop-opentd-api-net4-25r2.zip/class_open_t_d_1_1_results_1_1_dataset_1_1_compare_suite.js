var class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite =
[
    [ "Add", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a2ebac142b7d974c4bbe6656737330453", null ],
    [ "Add", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a4322fd22b65e6859bc61a852967a2293", null ],
    [ "Clear", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#aae41413143dead911d9953c7c73bb732", null ],
    [ "Contains", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a8dccbf61eaad950e997e8c00659782c0", null ],
    [ "CopyTo", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a6cdd1e824c637e5b29ac9a66be0aa012", null ],
    [ "GetEnumerator", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a5979644d75162a3327f27781de66f470", null ],
    [ "IndexOf", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#af086f6fb258e58887b5fb727a9d1f377", null ],
    [ "Insert", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a784365ca06e54526b29128569eb734a4", null ],
    [ "Remove", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a2eebbe1f639b9389f5a694406f9bc692", null ],
    [ "RemoveAt", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a200865292bf5bb744b3286ef3081faeb", null ],
    [ "Run", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a9b2e69f4822cceb67b9363bcdd1bfec4", null ],
    [ "Count", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a0445210a9817a2470e10fa2bae6cff08", null ],
    [ "IsReadOnly", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#acd5d572c945c110fa3a30a4ecdb2a1c4", null ],
    [ "Log", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a3dbacf3084ecbcd08c486888885192f6", null ],
    [ "Message", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a89dcccae2218d17278080d07850b1334", null ],
    [ "this[int index]", "class_open_t_d_1_1_results_1_1_dataset_1_1_compare_suite.xhtml#a3460371b9429c3a7c2c1008b6f4ffac7", null ]
];