var class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_face_spec =
[
    [ "FaceSpec", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_face_spec.xhtml#a1fdfe8f88ea52d982e130db440cb55b1", null ],
    [ "id", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_face_spec.xhtml#a102c841a39f4351c0a238787366599cd", null ],
    [ "sides", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_face_spec.xhtml#a9756bfb7a8e5c8b09a1b9bc2b5b14709", null ]
];