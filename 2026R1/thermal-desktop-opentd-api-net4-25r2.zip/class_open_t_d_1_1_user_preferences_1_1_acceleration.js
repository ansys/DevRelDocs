var class_open_t_d_1_1_user_preferences_1_1_acceleration =
[
    [ "Acceleration", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a07d62e58e2b88b94a94dda2e3387e649", null ],
    [ "Acceleration", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a3653829760bf2f246f215ad695ff43f2", null ],
    [ "Update", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a50c8a44ce6adc9d6bd5a5009cd272df8", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a5cdbe3b1154db9fd6b8b9346713f34a0", null ],
    [ "Magnitude", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a939252a6717d9ad8eae5e089ae1f40c9", null ],
    [ "MagnitudeExp", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a8e273a7fb8150781d722a909bb9089c0", null ],
    [ "NeedsUpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a012bb0c5f39ee504be222b4292f5ffc3", null ],
    [ "XDir", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#aa435eca9a5d96084b946fb06e38351ae", null ],
    [ "XDirExp", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#ab65eae5d4f4f7427265baa882017d3d3", null ],
    [ "YDir", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a4ad53397748ac32c163b01854eb5e705", null ],
    [ "YDirExp", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#ac92a2890fa1a7005dbf552e4194be630", null ],
    [ "ZDir", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a46c4047106bf2fc14e5f12db7fec3b6c", null ],
    [ "ZDirExp", "class_open_t_d_1_1_user_preferences_1_1_acceleration.xhtml#a03952d31623f63054703e6609bb16a13", null ]
];