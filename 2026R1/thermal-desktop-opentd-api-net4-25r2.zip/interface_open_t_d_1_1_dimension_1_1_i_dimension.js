var interface_open_t_d_1_1_dimension_1_1_i_dimension =
[
    [ "ConvertFromSI", "interface_open_t_d_1_1_dimension_1_1_i_dimension.xhtml#afddcd70691fedb7f5e45b35ab591c2a5", null ],
    [ "ConvertToSI", "interface_open_t_d_1_1_dimension_1_1_i_dimension.xhtml#a47ad8f3b8708cb63cb89777b06affd5f", null ],
    [ "GetName", "interface_open_t_d_1_1_dimension_1_1_i_dimension.xhtml#aeeb6edfa19e874001b5453f595995383", null ],
    [ "GetTitle", "interface_open_t_d_1_1_dimension_1_1_i_dimension.xhtml#a216ec184b866a2be2257c288c7960674", null ],
    [ "GetUnitsName", "interface_open_t_d_1_1_dimension_1_1_i_dimension.xhtml#a545ddcaa082f8f4d78c6e0c8176fcd02", null ]
];