var class_open_t_d_1_1_dimension_1_1_voltage =
[
    [ "ConvertFromSI", "class_open_t_d_1_1_dimension_1_1_voltage.xhtml#af45226baac4a811115b7acba8bc68914", null ],
    [ "ConvertToSI", "class_open_t_d_1_1_dimension_1_1_voltage.xhtml#a4d48a17716caeaeb7900347edbe3124e", null ],
    [ "GetName", "class_open_t_d_1_1_dimension_1_1_voltage.xhtml#a53550e7733aea1d3556870293249c232", null ],
    [ "GetTitle", "class_open_t_d_1_1_dimension_1_1_voltage.xhtml#aba46582e5a3a430a8cd24b2a8fa6601c", null ],
    [ "GetUnitsName", "class_open_t_d_1_1_dimension_1_1_voltage.xhtml#a7b6ed91b278798c10710aa304c9d425b", null ]
];