var interface_open_t_d_1_1_i_updatable =
[
    [ "Update", "interface_open_t_d_1_1_i_updatable.xhtml#a162ef7c717f51047a1d45c7df4282470", null ],
    [ "UpdateFromTD", "interface_open_t_d_1_1_i_updatable.xhtml#a47f3096415cfb5694fd822df8a1eceb0", null ]
];