var class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between =
[
    [ "FromSet", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#af419e01eca4444f912daafbeaadf54da", null ],
    [ "LinearCount", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#ae053304d701fec031184d2db1acb7369", null ],
    [ "LinearHeatrate", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#a80b934c74db32f111ab724a2b3647d20", null ],
    [ "NodeHeatrates", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#aa07a726984dab15bdc80500b84342a2c", null ],
    [ "RadiativeCount", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#a2f760cf0ec1bf9493f110928226faf29", null ],
    [ "RadiativeHeatrate", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#a772414c38ef4192bf8c999576b784f3e", null ],
    [ "TieCount", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#ad4d7ab51f0ccf209194717daf05bf70a", null ],
    [ "TieHeatrate", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#ae5f6b2510453bba65206c4adebfc16ca", null ],
    [ "ToSet", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#acb1cc73586686af5046857076cc2326d", null ],
    [ "TotalCount", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#a153efec7bf5c87ad94aec450ca482570", null ],
    [ "TotalHeatrate", "class_open_t_d_1_1_results_1_1_dataset_1_1_heatrates_between.xhtml#a77151a18e1804da481d8091ad46a65c4", null ]
];