var class_open_t_d_1_1_results_1_1_dataset_1_1_auto_namer =
[
    [ "AutoNamer", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_namer.xhtml#aa0d6cbd6421ed80d2969733ddcb259c0", null ],
    [ "AutoNamer", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_namer.xhtml#af0d083c998fa6a6211b738b7b684f064", null ],
    [ "ToString", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_namer.xhtml#a511d9178b39a424effba1607f41f6eec", null ],
    [ "InternalSuggestedName", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_namer.xhtml#a0d210cc5d724c8db4fc542497880de0b", null ],
    [ "Name", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_namer.xhtml#acd2c5b1ff179008cc999462b74d845ab", null ],
    [ "SelfSuggestedName", "class_open_t_d_1_1_results_1_1_dataset_1_1_auto_namer.xhtml#af7e108bed54e863a01da3773d27c7610", null ]
];