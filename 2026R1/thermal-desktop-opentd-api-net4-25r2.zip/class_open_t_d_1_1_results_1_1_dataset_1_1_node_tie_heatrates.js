var class_open_t_d_1_1_results_1_1_dataset_1_1_node_tie_heatrates =
[
    [ "Heatrates", "class_open_t_d_1_1_results_1_1_dataset_1_1_node_tie_heatrates.xhtml#a16b9eaa73cceb72abfa2ac7d000620e6", null ],
    [ "NodeInfo", "class_open_t_d_1_1_results_1_1_dataset_1_1_node_tie_heatrates.xhtml#ab0ed8601eebd2abd354cd55e4a88cf2a", null ]
];