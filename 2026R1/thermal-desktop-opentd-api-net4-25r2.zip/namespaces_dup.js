var namespaces_dup =
[
    [ "OpenTD", "namespace_open_t_d.xhtml", "namespace_open_t_d" ]
];