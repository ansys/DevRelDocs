var class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_layer_data =
[
    [ "LayerData", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_layer_data.xhtml#a6857e427d468b6ee9722f7fa88c89969", null ],
    [ "alpha", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_layer_data.xhtml#ab7c07e90298d35e57976305421f53a8b", null ],
    [ "blue", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_layer_data.xhtml#afe798ba6f175a90639f7a453aa3401fb", null ],
    [ "green", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_layer_data.xhtml#ab57765cee6248142d4aa77473cbc1f24", null ],
    [ "name", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_layer_data.xhtml#a0cadca33f60bec14cd3fd2ce65a9721e", null ],
    [ "red", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_layer_data.xhtml#a5d12098cb6bad21e4f6c636f05f0066b", null ]
];