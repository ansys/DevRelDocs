var class_open_t_d_1_1_quaternion =
[
    [ "Quaternion", "class_open_t_d_1_1_quaternion.xhtml#a028ca8e12f89d7ad206bc96bcb7bb11e", null ],
    [ "Quaternion", "class_open_t_d_1_1_quaternion.xhtml#ae53ec0b8e53a51033fd62041b6e9c727", null ],
    [ "Quaternion", "class_open_t_d_1_1_quaternion.xhtml#a7399036d28ce6d1858f3ac7fa85ab4e7", null ],
    [ "Quaternion", "class_open_t_d_1_1_quaternion.xhtml#a3decca09c09435f52bebe32ecf62eb7d", null ],
    [ "Quaternion", "class_open_t_d_1_1_quaternion.xhtml#af745d031e582e6cc8c356b10f7ff7262", null ],
    [ "Quaternion", "class_open_t_d_1_1_quaternion.xhtml#a2b4f8fa683e2f07bbeca424af9ca34b4", null ],
    [ "Conjugate", "class_open_t_d_1_1_quaternion.xhtml#ab95099e44eb6c565479c9dfd9bb3d1c6", null ],
    [ "DotProduct", "class_open_t_d_1_1_quaternion.xhtml#ac26fe54cb16044b9358866248b2fc7ea", null ],
    [ "Inverse", "class_open_t_d_1_1_quaternion.xhtml#a62b5af90e9a9636ca223dbce77363df5", null ],
    [ "Norm", "class_open_t_d_1_1_quaternion.xhtml#abf630cdf365f4796a858cc266672f705", null ],
    [ "Normalize", "class_open_t_d_1_1_quaternion.xhtml#a227775089b4cd5fc18b34c5612f8b984", null ],
    [ "s", "class_open_t_d_1_1_quaternion.xhtml#a429c44b1ee58b3beace1d98ef70af08d", null ],
    [ "v", "class_open_t_d_1_1_quaternion.xhtml#a41a60e7b59c046de410f8d61d016aa9d", null ]
];