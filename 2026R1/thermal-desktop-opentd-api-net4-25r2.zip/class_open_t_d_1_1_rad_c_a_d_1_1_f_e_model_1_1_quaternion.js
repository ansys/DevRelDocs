var class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_quaternion =
[
    [ "Quaternion", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_quaternion.xhtml#a4ccebc86604fa06dc00108e6cde22291", null ],
    [ "s", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_quaternion.xhtml#a758ec4a7a062756b4bd586e6a5a74d22", null ],
    [ "v", "class_open_t_d_1_1_rad_c_a_d_1_1_f_e_model_1_1_quaternion.xhtml#a45c4335cf9a30d7ab34ad424da5c0fc4", null ]
];