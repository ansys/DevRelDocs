var class_open_t_d_1_1_internal_1_1_communication_1_1_status_data =
[
    [ "StatusData", "class_open_t_d_1_1_internal_1_1_communication_1_1_status_data.xhtml#ab3e3f8b99f5e1b369a1b5541e399d328", null ],
    [ "ToString", "class_open_t_d_1_1_internal_1_1_communication_1_1_status_data.xhtml#a577e8db3038b6c1d9e81a5ae13dc2974", null ],
    [ "Message", "class_open_t_d_1_1_internal_1_1_communication_1_1_status_data.xhtml#a994d2e817328ee1587e4bc0a414f8a82", null ],
    [ "Success", "class_open_t_d_1_1_internal_1_1_communication_1_1_status_data.xhtml#a29ec196cf06d5df78bd2fcf2676ec364", null ]
];