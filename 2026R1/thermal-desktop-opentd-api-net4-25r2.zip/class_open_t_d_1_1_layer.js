var class_open_t_d_1_1_layer =
[
    [ "CreateIn", "class_open_t_d_1_1_layer.xhtml#a944c943bcbcca5560239fea1ffd53d27", null ],
    [ "SetFrom", "class_open_t_d_1_1_layer.xhtml#aa2e0aa2793e95a56891ef59fb4843ca2", null ],
    [ "ToString", "class_open_t_d_1_1_layer.xhtml#a873e16c0ae5f0c9052f5818032065602", null ],
    [ "Update", "class_open_t_d_1_1_layer.xhtml#aaa6c81edf902be44d4fe012a3a8d131a", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_layer.xhtml#a5ffc066693e6bff5baed4d6b11a71a06", null ],
    [ "UpdateIn", "class_open_t_d_1_1_layer.xhtml#a1e5228ce309c9a85ec09e8119318024d", null ],
    [ "TdProxy", "class_open_t_d_1_1_layer.xhtml#a0da16592e6b635ca0def27b355d669b3", null ],
    [ "ColorIndex", "class_open_t_d_1_1_layer.xhtml#afa9a0a7c95f0e5777ff1fcb9a06c746c", null ],
    [ "Current", "class_open_t_d_1_1_layer.xhtml#a24eb8882e3465b6f5a84a3c46b50e953", null ],
    [ "Frozen", "class_open_t_d_1_1_layer.xhtml#a090d574ef83c46da9e387ef6165a23a2", null ],
    [ "Handle", "class_open_t_d_1_1_layer.xhtml#a4ae081ff77dea9973916f5cf17ed088c", null ],
    [ "Locked", "class_open_t_d_1_1_layer.xhtml#a53d3c34fd869211810f6b418b5f4bb46", null ],
    [ "Name", "class_open_t_d_1_1_layer.xhtml#ab9184bc2b4f1866bfa5b2b78ed8b0b5e", null ],
    [ "Off", "class_open_t_d_1_1_layer.xhtml#a605d3ca1ad8fff7c689eea223f3d5c1e", null ]
];