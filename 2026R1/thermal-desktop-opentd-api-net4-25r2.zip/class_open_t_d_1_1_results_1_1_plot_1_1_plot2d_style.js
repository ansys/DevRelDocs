var class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style =
[
    [ "Plot2dStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a7b1b969d6052281227272d5241ec5f3b", null ],
    [ "CheckPalette", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a4a8ed9af9481a2dd7b21776741e6e64b", null ],
    [ "AutoHideLegend", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a0e6d7d2647e91b73f4d839968f178ac7", null ],
    [ "AutoMarkerStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#ae4a5e8d06a16947b808492fc02d8c761", null ],
    [ "CustomPalette", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a79d22343bf14a15c8224ad4c2a789296", null ],
    [ "LegendStyle", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a4ba60b202cd893d8672e67b341cc2ba9", null ],
    [ "Palette", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a4e6bd03a6c039a26f9cc5807f85bc55a", null ],
    [ "Series2dStyles", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a66b6cc271b3b6264aacc7c1964a1091e", null ],
    [ "Size", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a1a861416f2cf88ec01e332db62e5ce1e", null ],
    [ "TitleColor", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a5f0575c6069e3b03aafc91dff296b4a1", null ],
    [ "TitleEnabled", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a8997d5476244e724c6b423ba491fdb3e", null ],
    [ "TitleFont", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#aa2c49f6767cdcca3b13186dd4f6e44a8", null ],
    [ "TitlePosition", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#af20886d4512706c246e9e1e316bfcd96", null ],
    [ "UseCustomPalette", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a8ea59a459e161b2dc7a4d29a2b3a81a6", null ],
    [ "XAxesStyles", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a5d2027eca2a216b14c5869ddba4786de", null ],
    [ "YAxesStyles", "class_open_t_d_1_1_results_1_1_plot_1_1_plot2d_style.xhtml#a2118d9711edb32a7ad62599e1136b1a0", null ]
];