var interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_reader =
[
    [ "GetCharUserArray", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_reader.xhtml#afc228edaa120d65c81db8668877e004f", null ],
    [ "GetIntegerUserArray", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_reader.xhtml#aeee1b8da4b56550c1b9177f7684f8dad", null ],
    [ "GetLogicalUserArray", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_reader.xhtml#a4c68e3e3b924d69fa08f0da3d66509bc", null ],
    [ "GetRealUserArray", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_reader.xhtml#a9d9df27b17ad00c7e080ad689357028d", null ],
    [ "GetUserArrayNames", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_u_d_f_a_reader.xhtml#a97da4fe569ce099b08e6eea2210cc27c", null ]
];