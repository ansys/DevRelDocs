var interface_open_t_d_1_1_results_1_1_dataset_1_1_i_auto_comment =
[
    [ "Comment", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_auto_comment.xhtml#a9ceecf7f41fc605a928a63053061e0bf", null ],
    [ "InternalSuggestedComment", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_auto_comment.xhtml#a1040486825fa96d315ac4794da2c99e4", null ]
];