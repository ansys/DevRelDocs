var class_open_t_d_1_1_user_preferences_1_1_sinda_preferences =
[
    [ "SindaPreferences", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#acba24cec675e6dde500d38cec13602f8", null ],
    [ "SindaPreferences", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#ab52e8def7e9ecb49a4cedcf675976af8", null ],
    [ "Update", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#a6ac7dfea82f2885a848a5259b2bcc4b8", null ],
    [ "UpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#adad2297fdcb7484d662d2c55676719f5", null ],
    [ "NeedsUpdateFromTD", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#a012bb0c5f39ee504be222b4292f5ffc3", null ],
    [ "sindaCsrOrSave", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#aabce6529f59e3131e2058c5100c7ec71", null ],
    [ "sindaRunStatusWindowIndex", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#a4b58ecdc03e511e477de8640e7b9ec29", null ],
    [ "sindaUseOpenMP", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#ade954c4df0d505ec1f4ee704ac1a77db", null ],
    [ "thermalAnalyzer", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#a43949598f0e1a901057b6d2a774e0149", null ],
    [ "waitForSindaLicense", "class_open_t_d_1_1_user_preferences_1_1_sinda_preferences.xhtml#a36bece7d3c4912b51f721714fd0ea245", null ]
];