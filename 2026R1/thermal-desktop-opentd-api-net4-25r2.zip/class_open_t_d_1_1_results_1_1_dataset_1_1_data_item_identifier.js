var class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier =
[
    [ "DataItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml#a1f38f4e6fd0c13386933bf1a1e145ee4", null ],
    [ "DataItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml#a8d51efecccf2553bb4283c2ef70a4e12", null ],
    [ "Equals", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml#a39c6473eab86a883b0cdc2be328d3c1b", null ],
    [ "GetHashCode", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml#a4cc7fb5f67143010cf3118e99eeee633", null ],
    [ "ToString", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml#ae6cd13961532c29054d5fc75fe6da485", null ],
    [ "ItemIdentifier", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml#adf11b4944bf8ac82d108d334e19f75c0", null ],
    [ "Subtype", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml#a17308c16b38ac5846714a00dacb3ee6a", null ],
    [ "Units", "class_open_t_d_1_1_results_1_1_dataset_1_1_data_item_identifier.xhtml#a67ff77259d1992c12023864afb684670", null ]
];