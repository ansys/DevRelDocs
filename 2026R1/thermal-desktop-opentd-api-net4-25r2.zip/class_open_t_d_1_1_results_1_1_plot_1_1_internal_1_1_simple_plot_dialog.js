var class_open_t_d_1_1_results_1_1_plot_1_1_internal_1_1_simple_plot_dialog =
[
    [ "SimplePlotDialog", "class_open_t_d_1_1_results_1_1_plot_1_1_internal_1_1_simple_plot_dialog.xhtml#a4268eb23f44737b62e3bd59a938844d9", null ],
    [ "Dispose", "class_open_t_d_1_1_results_1_1_plot_1_1_internal_1_1_simple_plot_dialog.xhtml#a0ce78f01cb624e731f0b7ed951d35f6e", null ],
    [ "SaveImage", "class_open_t_d_1_1_results_1_1_plot_1_1_internal_1_1_simple_plot_dialog.xhtml#adabbfbe573905321c292570e7facb827", null ]
];