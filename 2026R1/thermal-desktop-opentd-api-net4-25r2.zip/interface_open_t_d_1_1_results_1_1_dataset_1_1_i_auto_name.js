var interface_open_t_d_1_1_results_1_1_dataset_1_1_i_auto_name =
[
    [ "InternalSuggestedName", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_auto_name.xhtml#aaec42d07f6fbe007045d1581f0548678", null ],
    [ "Name", "interface_open_t_d_1_1_results_1_1_dataset_1_1_i_auto_name.xhtml#aa44f6208ff03f4232611a46affcaa82e", null ]
];