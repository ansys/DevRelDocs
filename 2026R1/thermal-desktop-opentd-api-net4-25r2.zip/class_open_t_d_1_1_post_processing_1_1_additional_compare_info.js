var class_open_t_d_1_1_post_processing_1_1_additional_compare_info =
[
    [ "AdditionalCompareInfo", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml#afa76800766a54f3e3888cecf9ff234e3", null ],
    [ "_pathname", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml#a00d93b38fc9b743e486c5a10251e6890", null ],
    [ "DataSetNames", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml#ab4298a137ff52674dad9305b13121e68", null ],
    [ "Format", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml#af55cd7b90213876d069e56457f1255a8", null ],
    [ "Pathname", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml#adf6ebaab63c773c8f54dafc548bfee91", null ],
    [ "Type", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml#adf4372e051ed8486371bd62f41d544f2", null ],
    [ "Type2", "class_open_t_d_1_1_post_processing_1_1_additional_compare_info.xhtml#a05d489bffadf10349a08ef41e226679f", null ]
];